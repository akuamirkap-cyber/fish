// @ts-nocheck — definisi lengkap 83 senjata dari game Perfect Shot / Halo
import { storage } from './safeStorage';

export type ActiveWeaponId =
  // UMUM (17)
  | 'pistol' | 'ak47' | 'nail' | 'crossbow' | 'shotgun' | 'slingshot' | 'blowgun'
  | 'soaker' | 'snowball' | 'honey' | 'coconut' | 'pencil' | 'sandal' | 'paintball'
  | 'mp5' | 'longbow' | 'banana'
  // LANGKA (22)
  | 'sniper' | 'flamethrower' | 'plasma' | 'laser' | 'rpg' | 'bamboo' | 'fish'
  | 'bubble' | 'harpoon' | 'chicken' | 'confetti' | 'seed' | 'pizza' | 'angklung'
  | 'bee' | 'sakura' | 'ruby' | 'cryo_blaster' | 'hyperdrive' | 'ion_smg' | 'dora' | 'xeno'
  // EPIC (25)
  | 'minigun' | 'railgun' | 'electro' | 'bazooka' | 'keris' | 'shark' | 'ghost'
  | 'cricket' | 'magnet' | 'pirate' | 'card' | 'yoyo' | 'firework' | 'ufo'
  | 'emerald' | 'sapphire' | 'crystal' | 'beerifle' | 'coingun' | 'tesla_rifle'
  | 'identity_disc' | 'proton_pack' | 'mega_buster' | 'harmonic_disruptor' | 'nano_swarm'
  // LEGENDARIS (19)
  | 'freeze' | 'golden' | 'blackhole' | 'dragon' | 'meteor' | 'diamond' | 'holy'
  | 'gravity' | 'moonbeam' | 'storm' | 'obliterator' | 'blaster' | 'photon_saber'
  | 'gauntlet_cannon' | 'heat_ray' | 'absolute_zero' | 'helios_flare' | 'orbital_beacon' | 'singularity';

export type RetiredWeaponId =
  | 'helix_pulsar' | 'pred' | 'yautja' | 'chrono_rifle' | 'prism_lance'
  | 'pulse_rifle' | 'quantum_destabilizer' | 'buster' | 'acid' | 'anchor'
  | 'shrink' | 'grow' | 'phaser' | 'unicorn' | 'rainbow' | 'wand' | 'ironman_hand';

export type WeaponId = ActiveWeaponId | RetiredWeaponId;

export type ProjKind = WeaponId | 'old';
export type Rarity = 'UMUM' | 'LANGKA' | 'EPIC' | 'LEGENDARIS';
export type TrailFx = 'none' | 'glow' | 'smoke' | 'spark' | 'bubble' | 'frost' | 'gold' | 'void' | 'fire';
export type SaveFx = 'return' | 'bubble' | 'portal' | 'glitch' | 'mirror';

export interface BurstFx { colors: string[]; n: number; glow?: boolean; g?: number; spd?: number; size?: number }

export interface Weapon {
  id: WeaponId;
  name: string;
  emoji: string;
  desc: string;
  perk: string;
  rarity: Rarity;
  speed: number;
  cooldown: number;
  auto: boolean;
  points: number;
  ammoDelta?: number;
  coinRadius: number;
  coinValue: number;
  recoil: number;
  shake: number;
  half: number;
  stick: number;
  energy: boolean;
  color: string;
  trail: string;
  trailFx: TrailFx;
  sparks: string[];
  casing?: string;
  ejectY?: number;
  explode?: boolean;
  explodeFx?: 'fire' | 'white';
  slowStyle?: 'ice' | 'water' | 'honey';
  charge?: boolean;
  paint?: boolean;
  meltEvery?: number;
  meltText?: string;
  meltColors?: string[];
  everyBonus?: { n: number; pts: number; text: string };
  randomMagic?: boolean;
  transmute?: number;
  obliterate?: number;
  spinFly?: boolean;
  burnText?: string;
  burnIcon?: string;
  spikeText?: string;
  jackpotText?: string;
  saveText?: string;
  notes?: boolean;
  phaseSpikes?: boolean;
  meltOld?: boolean;
  abductEvery?: number;
  chain?: boolean;
  slow?: boolean;
  slowFactor?: number;
  slowTime?: number;
  slowRgb?: string;
  slowText?: string;
  luckyCoin?: number;
  luckyText?: string;
  pullCoins?: boolean;
  comboWindow?: number;
  backblast?: boolean;
  noSmoke?: boolean;
  burstFx?: BurstFx;
  burst?: number;
  scope?: boolean;
  spinup?: boolean;
  pierceOld?: boolean;
  burn?: boolean;
  saves?: number;
  saveFx?: SaveFx;
  saveSpikeOnly?: boolean;
  reverseChance?: number;
  reverseEvery?: number;
  spikeOff?: number;
  pushSpikes?: boolean;
  chronoEvery?: number;
  shrink?: boolean;
  grow?: boolean;
  snowman?: boolean;
  breakSpike?: boolean;
  randomBonus?: number;
  jackpot?: number;
  confetti?: boolean;
  seed?: boolean;
  bossMult?: number;
  rope?: boolean;
  beam?: boolean;
  previewLen: number;
  previewScale: number;
  previewY: number;
  price?: number;
  coinPrice?: number;
  diamondPrice?: number;
  unlockLevel?: number;
  stats: { rate: number; speed: number; power: number };
}

const base = {
  coinRadius: 15, coinValue: 1, half: 4.75, stick: 30, energy: false, trailFx: 'none' as TrailFx,
  previewLen: 175, previewScale: 0.95, previewY: 30, auto: false, points: 1, recoil: 1, shake: 3,
};
const FIRE = ['#fff3b0', '#ffd23f', '#ff9f1c'];

const ALL_WEAPON_DEFINITIONS: Weapon[] = [
  // ======================== UMUM (17) ========================
  { ...base, id: 'pistol', name: 'SIDEARM', emoji: '🔫', rarity: 'UMUM', perk: 'SEIMBANG', desc: 'Pistol klasik, seimbang di semua hal.',
    speed: 2700, cooldown: 0.12, shake: 15, stick: 17, color: '#ff3030', trail: '255,230,150', sparks: FIRE, casing: '#e0ad40', ejectY: 48, stats: { rate: 3, speed: 3, power: 3 } },
  { ...base, id: 'ak47', name: 'AK-47', emoji: '🪖', rarity: 'UMUM', perk: 'AUTO-FIRE', desc: 'Senapan serbu legendaris. Tahan untuk tembak otomatis!',
    speed: 3200, cooldown: 0.085, auto: true, recoil: 3.4, shake: 15, stick: 17, color: '#ff3030', trail: '255,230,150', sparks: FIRE, casing: '#8f9a62', ejectY: 128,
    previewLen: 262, previewScale: 0.86, previewY: 38, stats: { rate: 5, speed: 4, power: 4 } },
  { ...base, id: 'mp5', name: 'MP5 SMG', emoji: '🔫', rarity: 'UMUM', perk: 'SEMBURAN CEPAT', desc: 'SMG 9x19 dengan 800 tembakan per menit. Tahan untuk menyemburkan peluru tanpa jeda!',
    speed: 3300, cooldown: 0.075, auto: true, recoil: 2.2, shake: 10, half: 3.2, stick: 16, color: '#f59e0b', trail: '255,220,150', sparks: FIRE, casing: '#e0ad40',
    stats: { rate: 5, speed: 4, power: 3 } },
  { ...base, id: 'nail', name: 'NAIL GUN', emoji: '🔩', rarity: 'UMUM', perk: 'TIPIS & AUTO', desc: 'Paku super tipis, muat di celah sempit. Tahan untuk tembak beruntun!',
    speed: 3000, cooldown: 0.07, auto: true, recoil: 3.4, shake: 15, half: 2.4, stick: 18, color: '#ffc400', trail: '220,225,230', sparks: ['#ffffff', '#d8dde3', '#ffd23f'],
    previewLen: 200, previewScale: 0.8, previewY: 50, stats: { rate: 5, speed: 3, power: 2 } },
  { ...base, id: 'crossbow', name: 'CROSSBOW', emoji: '🏹', rarity: 'UMUM', perk: 'PRESISI', desc: 'Panah baja yang cepat dan ramping. Hitbox kecil, cocok buat yang presisi.',
    speed: 3600, cooldown: 0.22, recoil: 3.4, shake: 15, half: 3.2, stick: 18, noSmoke: true, color: '#ff3030', trail: '255,255,255', sparks: ['#ffffff', '#ffd23f', '#d8a060'],
    previewLen: 220, previewScale: 0.85, previewY: 64, stats: { rate: 2, speed: 5, power: 3 } },
  { ...base, id: 'longbow', name: 'LONGBOW RECURVE', emoji: '🏹', rarity: 'UMUM', perk: 'BUSUR TARIK', desc: 'Busur recurve laminasi yang menembakkan anak panah panjang menembus musuh.',
    speed: 3900, cooldown: 0.34, points: 2, recoil: 2.6, shake: 8, half: 3.0, stick: 24, noSmoke: true, color: '#fbbf24', trail: '255,240,200', sparks: ['#ffffff', '#fde68a', '#d97706'],
    stats: { rate: 2, speed: 5, power: 4 } },
  { ...base, id: 'shotgun', name: 'SHOTGUN', emoji: '💥', rarity: 'UMUM', perk: 'TIGA SEKALIGUS', desc: '3 peluru menyebar sekaligus. Cepat selesai dengan hentakan keras!',
    speed: 2700, cooldown: 0.55, recoil: 3.4, shake: 15, half: 4.5, burst: 3, stick: 17, color: '#ff4d2e', trail: '255,200,120', sparks: FIRE, casing: '#d62828', ejectY: 96,
    previewLen: 250, previewScale: 0.82, previewY: 46, stats: { rate: 2, speed: 3, power: 5 } },
  { ...base, id: 'slingshot', name: 'KETAPEL', emoji: '🪨', rarity: 'UMUM', perk: 'KHAS NUSANTARA', desc: 'Ketapel kayu sawo dengan karet ban dalam. Batu kali melesat berputar dengan suara CTAK!',
    speed: 2900, cooldown: 0.36, recoil: 3.4, shake: 15, half: 4, stick: 14, noSmoke: true, spinFly: true, color: '#c0803f', trail: '210,200,190', sparks: ['#ffffff', '#c8c0b0', '#8b7d6b'],
    previewLen: 150, previewScale: 1.05, previewY: 32, stats: { rate: 3, speed: 3, power: 2 } },
  { ...base, id: 'blowgun', name: 'SUMPIT DAYAK', emoji: '🎋', rarity: 'UMUM', perk: 'SENYAP & TIPIS', desc: 'Sumpitan tradisional Dayak lengkap dengan mata tombak. Jarumnya paling tipis dan senyap!',
    speed: 3300, cooldown: 0.16, recoil: 3.4, shake: 15, half: 1.5, stick: 16, noSmoke: true, color: '#9ccc65', trail: '230,255,210', sparks: ['#ffffff', '#e8f5c8', '#9ccc65'],
    previewLen: 290, previewScale: 0.78, previewY: 28, stats: { rate: 4, speed: 4, power: 1 } },
  { ...base, id: 'soaker', name: 'SUPER SOAKER', emoji: '💦', rarity: 'UMUM', perk: 'BASAH', desc: 'Pistol air neon. Semprotan air deras yang membasahi & memperlambat target!',
    speed: 2200, cooldown: 0.08, auto: true, recoil: 1.2, shake: 4, half: 4.5, noSmoke: true, slow: true, slowStyle: 'water', color: '#3b82f6', trail: '96,165,250', trailFx: 'bubble',
    sparks: ['#ffffff', '#e0f7ff', '#38bdf8'], stats: { rate: 5, speed: 3, power: 2 } },
  { ...base, id: 'snowball', name: 'SNOWBALL CANNON', emoji: '⛄', rarity: 'UMUM', perk: 'MANUSIA SALJU', desc: 'Bola salju padat yang pecah menjadi salju putih dan membekukan musuh!',
    speed: 1900, cooldown: 0.22, recoil: 2.0, shake: 6, half: 5.5, noSmoke: true, snowman: true, slow: true, slowStyle: 'ice', color: '#e0f2fe', trail: '230,245,255', trailFx: 'frost',
    sparks: ['#ffffff', '#e0f7ff', '#bae6fd'], stats: { rate: 3, speed: 2, power: 3 } },
  { ...base, id: 'honey', name: 'HONEY BLASTER', emoji: '🍯', rarity: 'UMUM', perk: 'LENGKET', desc: 'Madu kental memercik, menempel di target, dan memperlambat geraknya!',
    speed: 2000, cooldown: 0.16, auto: true, recoil: 1.5, shake: 4, half: 5.0, noSmoke: true, slow: true, slowStyle: 'honey', color: '#f59e0b', trail: '251,191,36', trailFx: 'glow',
    sparks: ['#fff1a8', '#ffcf4c', '#d99116'], stats: { rate: 4, speed: 2, power: 2 } },
  { ...base, id: 'coconut', name: 'MERIAM KELAPA', emoji: '🥥', rarity: 'UMUM', perk: 'KELAPA MUDA', desc: 'Peluncur kelapa muda khas pantai tropis! Kelapa pecah dan menyiram air segar.',
    speed: 2100, cooldown: 0.38, points: 2, recoil: 4.0, shake: 12, half: 6.0, noSmoke: true, color: '#84cc16', trail: '217,249,157', trailFx: 'bubble',
    sparks: ['#ffffff', '#ecfccb', '#84cc16'], stats: { rate: 2, speed: 3, power: 4 } },
  { ...base, id: 'pencil', name: 'PENCIL GUN', emoji: '✏️', rarity: 'UMUM', perk: 'PENGHAPUS', desc: 'Pensil raksasa yang tajam! Melempar serutan kayu dan debu penghapus saat mengenai target.',
    speed: 2900, cooldown: 0.18, recoil: 1.5, shake: 5, half: 3.5, noSmoke: true, color: '#facc15', trail: '255,240,180',
    sparks: ['#fde047', '#f472b6', '#d4a373'], stats: { rate: 3, speed: 4, power: 3 } },
  { ...base, id: 'sandal', name: 'SANDAL JEPIT', emoji: '🩴', rarity: 'UMUM', perk: 'PLAK!', desc: 'Sandal jepit besar melesat lurus dengan bunyi PLAK! yang ikonik dan hantaman keras.',
    speed: 2600, cooldown: 0.28, points: 2, recoil: 3.2, shake: 10, half: 5.5, noSmoke: true, spinFly: true, color: '#38bdf8', trail: '147,197,253',
    sparks: ['#ffffff', '#fde047', '#38bdf8'], stats: { rate: 3, speed: 3, power: 4 } },
  { ...base, id: 'paintball', name: 'PAINTBALL GUN', emoji: '🎨', rarity: 'UMUM', perk: 'WARNA SAMA', desc: 'Bola cat warna-warni! Tahan untuk tembak beruntun dan cipratan cat di setiap tumbukan.',
    speed: 2500, cooldown: 0.12, auto: true, paint: true, recoil: 1.5, shake: 4, half: 4.5, noSmoke: true, color: '#f43f5e', trail: '244,63,94',
    sparks: ['#f43f5e', '#facc15', '#22d3ee', '#a855f7'], stats: { rate: 5, speed: 3, power: 2 } },
  { ...base, id: 'banana', name: 'BANANA GUN', emoji: '🍌', rarity: 'UMUM', perk: 'TERPELESET', desc: 'Daging pisang melesat cepat dan memercikkan sari buah. Kulit menutup lagi saat reload!',
    speed: 2400, cooldown: 0.24, recoil: 2.0, shake: 6, half: 4.8, noSmoke: true, spinFly: true, color: '#facc15', trail: '255,230,80',
    sparks: ['#fef08a', '#facc15', '#ffffff'], stats: { rate: 3, speed: 3, power: 3 } },

  // ======================== LANGKA (22) ========================
  { ...base, id: 'sniper', name: 'SNIPER AWP', emoji: '🎯', rarity: 'LANGKA', perk: 'SLOW-MO SCOPE', desc: 'Klik kanan untuk membidik dengan laser merah. Tembus musuh dan 2x poin!',
    speed: 7000, cooldown: 0.5, points: 2, recoil: 3.4, shake: 15, half: 3.6, scope: true, color: '#ff2020', trail: '255,240,200', sparks: FIRE, casing: '#e0ad40', ejectY: 150,
    previewLen: 300, previewScale: 0.76, previewY: 50, stats: { rate: 1, speed: 5, power: 4 } },
  { ...base, id: 'flamethrower', name: 'FLAMETHROWER', emoji: '🔥', rarity: 'LANGKA', perk: 'MEMBAKAR', desc: 'Bola api beruntun. Target terbakar dan terus terkena damage selama api menyala!',
    speed: 1900, cooldown: 0.13, auto: true, recoil: 3.4, shake: 15, half: 5.5, noSmoke: true, burn: true, color: '#ff7a00', trail: '255,140,40', trailFx: 'fire',
    sparks: ['#fff3b0', '#ff9f1c', '#ff4500'], burstFx: { colors: ['255,200,80', '255,120,30', '255,60,20'], n: 8, glow: true, g: -100, spd: 140, size: 8 },
    previewLen: 200, previewY: 34, stats: { rate: 5, speed: 2, power: 3 } },
  { ...base, id: 'plasma', name: 'PLASMA GUN', emoji: '🟢', rarity: 'LANGKA', perk: '2X POIN', desc: 'Peluru plasma hijau penuh energi, menyengat dan meninggalkan pendaran plasma.',
    speed: 1700, cooldown: 0.16, points: 2, coinRadius: 30, recoil: 3.4, half: 5, energy: true, color: '#39ff9c', trail: '57,255,156', trailFx: 'glow',
    sparks: ['#d6ffe9', '#39ff9c', '#00c26e'], stats: { rate: 2, speed: 2, power: 5 } },
  { ...base, id: 'laser', name: 'LASER BEAM', emoji: '🔴', rarity: 'LANGKA', perk: 'INSTAN', desc: 'Secepat cahaya, langsung kena saat ditembak tanpa jeda.',
    speed: 14000, cooldown: 0.14, recoil: 3.4, shake: 15, half: 4.5, energy: true, beam: true, color: '#ff2a55', trail: '255,42,85', sparks: ['#ffd6de', '#ff2a55', '#ff7a90'],
    stats: { rate: 3, speed: 5, power: 3 } },
  { ...base, id: 'rpg', name: 'RPG-7', emoji: '🚀', rarity: 'LANGKA', perk: 'LEDAKAN 2X', desc: 'Roket anti-tank. Meledak dahsyat saat mengenai target!',
    speed: 2100, cooldown: 0.38, points: 2, coinRadius: 22, recoil: 3.4, shake: 15, half: 6.2, color: '#ff6a00', trail: '255,170,80', trailFx: 'smoke',
    sparks: ['#fff3b0', '#ff9f1c', '#ff4500'], explode: true, backblast: true, previewLen: 280, previewScale: 0.85, previewY: 40, stats: { rate: 2, speed: 3, power: 5 } },
  { ...base, id: 'bamboo', name: 'MERIAM BAMBU', emoji: '🎍', rarity: 'LANGKA', perk: 'DUARR LEBARAN', desc: 'Meriam bambu khas Lebaran! Petasan meledak DUARR dengan asap putih tebal.',
    speed: 1600, cooldown: 0.5, points: 2, recoil: 3.4, shake: 15, half: 5, color: '#7cb342', trail: '240,240,240', trailFx: 'smoke',
    sparks: ['#ffffff', '#fde68a', '#f87171'], explode: true, explodeFx: 'white', previewLen: 230, previewScale: 0.86, previewY: 40, stats: { rate: 1, speed: 2, power: 5 } },
  { ...base, id: 'fish', name: 'FISH GUN', emoji: '🐟', rarity: 'LANGKA', perk: 'IKAN HOKI', desc: 'Nembak ikan hidup dengan gelembung! 35% kemungkinan dapat skor bonus IKAN HOKI.',
    speed: 1500, cooldown: 0.2, coinRadius: 18, recoil: 3.4, half: 6.2, noSmoke: true, color: '#3ec6ff', trail: '120,210,255', trailFx: 'bubble',
    sparks: ['#bfeaff', '#3ec6ff', '#ffffff'], luckyCoin: 0.35, burstFx: { colors: ['#7fd3ff', '#bfeaff', '#ffffff'], n: 10, g: 900 }, stats: { rate: 2, speed: 2, power: 2 } },
  { ...base, id: 'bubble', name: 'BUBBLE GUN', emoji: '🫧', rarity: 'LANGKA', perk: 'PERISAI AIR', desc: 'Pistol gelembung sabun warna-warni! Gelembung membesar lalu pecah dengan suara POP.',
    speed: 1650, cooldown: 0.2, recoil: 1.2, shake: 3, half: 5.5, noSmoke: true, saves: 1, saveFx: 'bubble', color: '#e879f9', trail: '220,200,255', trailFx: 'bubble',
    sparks: ['#ffffff', '#f5d0fe', '#bae6fd'], stats: { rate: 3, speed: 2, power: 2 } },
  { ...base, id: 'harpoon', name: 'HARPOON GUN', emoji: '🔱', rarity: 'LANGKA', perk: 'TALI PENARIK', desc: 'Tombak bajak laut bertali baja yang menembus musuh dan menyeretnya!',
    speed: 3200, cooldown: 0.34, recoil: 3.0, shake: 9, half: 3.8, noSmoke: true, rope: true, color: '#38bdf8', trail: '200,240,255',
    sparks: ['#ffffff', '#bae6fd', '#38bdf8'], stats: { rate: 2, speed: 4, power: 4 } },
  { ...base, id: 'chicken', name: 'RUBBER CHICKEN', emoji: '🐔', rarity: 'LANGKA', perk: 'POIN ACAK', desc: 'Ayam karet raksasa melesat sambil berbunyi CIT! Setiap kena memberi bonus skor acak.',
    speed: 2100, cooldown: 0.28, randomBonus: 5, recoil: 2.2, shake: 6, half: 5.5, noSmoke: true, color: '#facc15', trail: '255,240,150',
    sparks: ['#ffffff', '#fde047', '#ef4444'], stats: { rate: 3, speed: 3, power: 3 } },
  { ...base, id: 'confetti', name: 'CONFETTI CANNON', emoji: '🎉', rarity: 'LANGKA', perk: 'PESTA COMBO', desc: 'Setiap tembakan adalah pesta konfeti warna-warni!',
    speed: 2300, cooldown: 0.24, confetti: true, recoil: 2.5, shake: 7, half: 5.5, noSmoke: true, color: '#f43f5e', trail: '255,180,220', trailFx: 'fire',
    sparks: ['#f43f5e', '#facc15', '#22d3ee', '#a855f7', '#4ade80'], stats: { rate: 3, speed: 3, power: 3 } },
  { ...base, id: 'seed', name: 'SEED GUN', emoji: '🌱', rarity: 'LANGKA', perk: 'TANAM KOIN', desc: 'Menembakkan biji ajaib yang mekar menjadi bunga & kelopak saat mengenai target!',
    speed: 2400, cooldown: 0.2, seed: true, recoil: 1.5, shake: 4, half: 4.0, noSmoke: true, color: '#4ade80', trail: '180,230,120',
    sparks: ['#ffffff', '#bef264', '#4ade80'], stats: { rate: 3, speed: 3, power: 2 } },
  { ...base, id: 'pizza', name: 'PIZZA LAUNCHER', emoji: '🍕', rarity: 'LANGKA', perk: 'IRISAN KOIN', desc: 'Menembakkan irisan pizza panas berputar! 40% peluang bonus skor.',
    speed: 2200, cooldown: 0.24, luckyCoin: 0.4, recoil: 2.2, shake: 6, half: 5.5, noSmoke: true, spinFly: true, color: '#fb923c', trail: '255,200,120',
    sparks: ['#fde047', '#ef4444', '#fb923c'], stats: { rate: 3, speed: 3, power: 3 } },
  { ...base, id: 'angklung', name: 'ANGKLUNG', emoji: '🎶', rarity: 'LANGKA', perk: 'NADA COMBO', desc: 'Alat musik bambu Sunda yang menembakkan not balok dengan nada pentatonik!',
    speed: 2500, cooldown: 0.22, notes: true, recoil: 2.0, shake: 5, half: 4.5, noSmoke: true, color: '#fde047', trail: '253,230,138', trailFx: 'gold',
    sparks: ['#ffffff', '#fde68a', '#fbbf24'], stats: { rate: 3, speed: 3, power: 3 } },
  { ...base, id: 'bee', name: 'BEE HIVE GUN', emoji: '🐝', rarity: 'LANGKA', perk: 'SENGAT', desc: 'Hornet bersengat tajam menancap dan menyengat target beruntun!',
    speed: 2600, cooldown: 0.14, auto: true, burn: true, recoil: 1.5, shake: 4, half: 3.5, noSmoke: true, color: '#facc15', trail: '250,204,21',
    sparks: ['#ffffff', '#fde047', '#1f2937'], stats: { rate: 5, speed: 3, power: 3 } },
  { ...base, id: 'sakura', name: 'SAKURA BLOSSOM', emoji: '🌸', rarity: 'LANGKA', perk: 'HUJAN SAKURA', desc: 'Kelopak sakura yang tajam dan indah bertebaran saat mengenai target!',
    speed: 2500, cooldown: 0.18, luckyCoin: 0.3, recoil: 1.5, shake: 4, half: 4.0, noSmoke: true, color: '#f9a8d4', trail: '249,168,212',
    sparks: ['#ffffff', '#fbcfe8', '#f9a8d4'], stats: { rate: 4, speed: 3, power: 3 } },
  { ...base, id: 'ruby', name: 'RUBY REVOLVER', emoji: '♦️', rarity: 'LANGKA', perk: 'LUCKY SIX', desc: 'Revolver emas bertatah silinder rubi merah. Setiap tembakan ke-6 memberi bonus dahsyat!',
    speed: 3200, cooldown: 0.24, everyBonus: { n: 6, pts: 6, text: '♦️ LUCKY SIX!' }, recoil: 3.6, shake: 12, half: 4.2, color: '#f43f5e', trail: '255,100,130', trailFx: 'glow',
    sparks: ['#ffffff', '#fda4af', '#f43f5e'], casing: '#ffd23f', stats: { rate: 3, speed: 4, power: 4 } },
  { ...base, id: 'cryo_blaster', name: 'CRYO BLASTER', emoji: '🧊', rarity: 'LANGKA', perk: 'BEKU ANTARIKSA', desc: 'Blaster pendingin kriogenik sci-fi! Membekukan musuh seketika.',
    speed: 2600, cooldown: 0.18, energy: true, slow: true, slowStyle: 'ice', recoil: 2.5, shake: 8, half: 4.5, color: '#67e8f9', trail: '103,232,249', trailFx: 'frost',
    sparks: ['#ffffff', '#cffafe', '#22d3ee'], stats: { rate: 3, speed: 3, power: 4 } },
  { ...base, id: 'hyperdrive', name: 'HYPERDRIVE CANNON', emoji: '🛸', rarity: 'LANGKA', perk: 'KANON ANTARIKSA', desc: 'Meriam pesawat luar angkasa! Baut energi biru super cepat dengan jejak kilat.',
    speed: 3800, cooldown: 0.18, points: 2, energy: true, recoil: 3.0, shake: 9, half: 4.5, color: '#60a5fa', trail: '96,165,250', trailFx: 'spark',
    sparks: ['#ffffff', '#bfdbfe', '#3b82f6'], stats: { rate: 4, speed: 5, power: 4 } },
  { ...base, id: 'ion_smg', name: 'ION PULSE SMG', emoji: '⚡', rarity: 'LANGKA', perk: 'BOLT HELIX', desc: 'MP5 ion 650 RPM! Menembakkan bolt plasma helix ungu berpilin super cepat.',
    speed: 3500, cooldown: 0.09, auto: true, points: 2, energy: true, recoil: 2.0, shake: 7, half: 3.6, color: '#c084fc', trail: '192,132,252', trailFx: 'spark',
    sparks: ['#ffffff', '#e9d5ff', '#a855f7'], stats: { rate: 5, speed: 4, power: 3 } },
  { ...base, id: 'dora', name: 'AIR CANNON', emoji: '💨', rarity: 'LANGKA', perk: 'DOKAN!', desc: 'Meriam udara terkompresi! Menembakkan cincin gelombang udara bertekanan tinggi.',
    speed: 2400, cooldown: 0.34, points: 2, recoil: 4.5, shake: 12, half: 6.5, noSmoke: true, color: '#e2e8f0', trail: '255,255,255',
    sparks: ['#ffffff', '#cbd5e1', '#94a3b8'], stats: { rate: 2, speed: 3, power: 4 } },
  { ...base, id: 'xeno', name: 'XENOMORPH SPITTER', emoji: '👽', rarity: 'LANGKA', perk: 'CAIRAN BERACUN', desc: 'Tenggorokan xenomorph yang menyemburkan asam korosif hijau yang membakar target!',
    speed: 2200, cooldown: 0.24, points: 2, burn: true, recoil: 2.5, shake: 8, half: 5.5, noSmoke: true, color: '#a3e635', trail: '182,255,26', trailFx: 'glow',
    sparks: ['#ecfccb', '#bef264', '#65a30d'], stats: { rate: 3, speed: 3, power: 4 } },

  // ======================== EPIC (25) ========================
  { ...base, id: 'minigun', name: 'MINIGUN', emoji: '🌀', rarity: 'EPIC', perk: 'SPIN-UP', desc: 'Tahan layar: laras berputar makin cepat sampai menembak tanpa henti!',
    speed: 3400, cooldown: 0.3, auto: true, spinup: true, recoil: 3.4, shake: 15, half: 3.5, color: '#ff3030', trail: '255,230,150', sparks: FIRE, casing: '#e0ad40', ejectY: 110,
    previewLen: 240, previewScale: 0.8, previewY: 60, stats: { rate: 5, speed: 4, power: 3 } },
  { ...base, id: 'railgun', name: 'RAILGUN', emoji: '🧲', rarity: 'EPIC', perk: 'TEMBUS', desc: 'Sinar elektromagnetik nyaris instan yang menembus SEMUA musuh & pintu!',
    speed: 9500, cooldown: 0.35, points: 2, recoil: 3.4, shake: 15, half: 3, energy: true, beam: true, pierceOld: true, color: '#38bdf8', trail: '120,200,255', trailFx: 'spark',
    sparks: ['#ffffff', '#bae6fd', '#38bdf8'], previewLen: 210, previewY: 30, stats: { rate: 2, speed: 5, power: 5 } },
  { ...base, id: 'electro', name: 'ELECTRO GUN', emoji: '⚡', rarity: 'EPIC', perk: 'COMBO+', desc: 'Bola listrik yang menyambar petir berantai ke musuh di sekitarnya!',
    speed: 2600, cooldown: 0.15, coinRadius: 22, recoil: 3.4, half: 4.5, energy: true, color: '#5ad1ff', trail: '90,209,255', trailFx: 'spark',
    sparks: ['#ffffff', '#bff1ff', '#5ad1ff'], chain: true, comboWindow: 0.9, stats: { rate: 3, speed: 3, power: 3 } },
  { ...base, id: 'bazooka', name: 'BAZOOKA', emoji: '💣', rarity: 'EPIC', perk: '3X POIN', desc: 'Roket raksasa yang lambat, tapi ledakannya paling dahsyat di kelas roket!',
    speed: 1200, cooldown: 0.5, points: 3, coinRadius: 26, recoil: 3.4, shake: 15, half: 6.5, color: '#ff6a00', trail: '255,150,60', trailFx: 'smoke',
    sparks: ['#fff3b0', '#ff9f1c', '#ff4500'], explode: true, backblast: true, previewLen: 270, previewScale: 0.9, previewY: 40, stats: { rate: 1, speed: 1, power: 5 } },
  { ...base, id: 'keris', name: 'KERIS SAKTI', emoji: '🗡️', rarity: 'EPIC', perk: 'TEMBUS GAIB', desc: 'Keris pusaka Jawa berlekuk yang melesat dengan tenaga dalam. Tembus musuh & senyap!',
    speed: 3000, cooldown: 0.25, points: 2, half: 3, stick: 32, shake: 15, noSmoke: true, pierceOld: true, color: '#4deeea', trail: '77,238,234', trailFx: 'gold',
    sparks: ['#ffffff', '#4deeea', '#ffd056', '#a5f5ff'], previewLen: 220, previewY: 36, stats: { rate: 2, speed: 4, power: 4 } },
  { ...base, id: 'shark', name: 'SHARK LAUNCHER', emoji: '🦈', rarity: 'EPIC', perk: 'GIGITAN HIU', desc: 'Meluncurkan hiu lapar dengan cipratan air deras dan damage ganas!',
    speed: 3400, cooldown: 0.3, points: 3, recoil: 3.4, shake: 15, half: 6.5, stick: 32, noSmoke: true, color: '#0ea5e9', trail: '120,200,255', trailFx: 'bubble',
    sparks: ['#ffffff', '#bae6fd', '#0284c7'], burstFx: { colors: ['#7dd3fc', '#e0f2fe', '#ffffff'], n: 12, g: 900, spd: 180 }, previewLen: 200, previewY: 38, stats: { rate: 2, speed: 4, power: 5 } },
  { ...base, id: 'ghost', name: 'GHOST GUN', emoji: '👻', rarity: 'EPIC', perk: 'TEMBUS DURI', desc: 'Peluru roh hantu gaib yang menembus tembok & pintu!',
    speed: 2000, cooldown: 0.22, half: 4.5, energy: true, phaseSpikes: true, color: '#c7d2fe', trail: '220,225,255', trailFx: 'glow',
    sparks: ['#ffffff', '#e0e7ff', '#a5b4fc'], previewY: 34, stats: { rate: 3, speed: 2, power: 3 } },
  { ...base, id: 'cricket', name: 'NOISY CRICKET', emoji: '🦗', rarity: 'EPIC', perk: 'BRUTAL', desc: 'Pistol mini ala Men in Black. Kecil tapi hentakan & ledakan energinya brutal!',
    speed: 3100, cooldown: 0.45, points: 3, energy: true, recoil: 14, shake: 20, half: 6.0, explode: true, color: '#38bdf8', trail: '56,189,248', trailFx: 'glow',
    sparks: ['#ffffff', '#bae6fd', '#0284c7'], stats: { rate: 2, speed: 4, power: 5 } },
  { ...base, id: 'magnet', name: 'MAGNET GUN', emoji: '🧲', rarity: 'EPIC', perk: 'TARIK & TOLAK', desc: 'Menarik musuh dan menjatuhkan senjata dengan medan magnet kuat!',
    speed: 2700, cooldown: 0.26, energy: true, pullCoins: true, recoil: 2.5, shake: 8, half: 5.0, color: '#ef4444', trail: '255,100,100', trailFx: 'spark',
    sparks: ['#ffffff', '#fca5a5', '#ef4444'], stats: { rate: 3, speed: 3, power: 3 } },
  { ...base, id: 'pirate', name: 'MERIAM BAJAK LAUT', emoji: '🏴‍☠️', rarity: 'EPIC', perk: 'PENGHANCUR', desc: 'Bola meriam besi berat yang menghancurkan pintu & musuh dengan sekali hantam!',
    speed: 2000, cooldown: 0.55, points: 2, breakSpike: true, recoil: 9.0, shake: 16, half: 7.0, color: '#fb923c', trail: '255,180,90', trailFx: 'smoke',
    sparks: ['#ffffff', '#ffd23f', '#ff6a00'], stats: { rate: 1, speed: 2, power: 5 } },
  { ...base, id: 'card', name: 'CARD GUN', emoji: '🃏', rarity: 'EPIC', perk: 'JACKPOT AS', desc: 'Kartu remi setajam silet! 15% peluang kartu As dengan bonus skor besar.',
    speed: 3200, cooldown: 0.16, jackpot: 0.15, jackpotText: '🃏 AS! +400', recoil: 1.4, shake: 4, half: 3.5, noSmoke: true, spinFly: true, color: '#f43f5e', trail: '255,255,255',
    sparks: ['#ffffff', '#f43f5e', '#1f2937'], stats: { rate: 4, speed: 4, power: 3 } },
  { ...base, id: 'yoyo', name: 'YOYO MAGIC', emoji: '🪀', rarity: 'EPIC', perk: 'TALI AJAIB', desc: 'Yoyo neon ajaib yang berputar cepat dan memantul di dinding dengan percikan pelangi!',
    speed: 2600, cooldown: 0.24, saves: 2, recoil: 2.0, shake: 6, half: 5.5, noSmoke: true, spinFly: true, color: '#f472b6', trail: '255,140,200', trailFx: 'glow',
    sparks: ['#ffffff', '#f472b6', '#60a5fa', '#facc15'], stats: { rate: 3, speed: 3, power: 4 } },
  { ...base, id: 'firework', name: 'FIREWORK LAUNCHER', emoji: '🎆', rarity: 'EPIC', perk: 'KEMBANG API', desc: 'Roket kembang api yang meledak menjadi bunga api warna-warni di langit!',
    speed: 2100, cooldown: 0.42, points: 2, explode: true, confetti: true, recoil: 4.5, shake: 12, half: 5.5, color: '#f43f5e', trail: '255,180,200', trailFx: 'spark',
    sparks: ['#f43f5e', '#facc15', '#22d3ee', '#a855f7'], stats: { rate: 2, speed: 3, power: 5 } },
  { ...base, id: 'ufo', name: 'UFO RAY', emoji: '🛸', rarity: 'EPIC', perk: 'CULIK', desc: 'Sinar traktor UFO hijau yang melayang cepat dan mengacaukan target!',
    speed: 2800, cooldown: 0.22, energy: true, abductEvery: 3, recoil: 2.4, shake: 7, half: 4.5, color: '#4ade80', trail: '134,239,172', trailFx: 'glow',
    sparks: ['#ffffff', '#bbf7d0', '#22c55e'], stats: { rate: 3, speed: 4, power: 4 } },
  { ...base, id: 'emerald', name: 'EMERALD LASER', emoji: '💚', rarity: 'EPIC', perk: 'KILAU ZAMRUD', desc: 'Sinar laser zamrud instan yang berkilau dan menembus target!',
    speed: 14000, cooldown: 0.2, points: 2, energy: true, beam: true, luckyCoin: 0.25, recoil: 2.5, shake: 8, half: 4.0, color: '#34d399', trail: '52,211,153',
    sparks: ['#ffffff', '#a7f3d0', '#10b981'], stats: { rate: 3, speed: 5, power: 4 } },
  { ...base, id: 'sapphire', name: 'SAPPHIRE SHOTGUN', emoji: '💙', rarity: 'EPIC', perk: 'BEKU SAFIR', desc: 'Shotgun laras ganda bertatah safir. 3 pecahan safir menyebar dan membekukan target!',
    speed: 2800, cooldown: 0.48, burst: 3, slow: true, slowStyle: 'ice', recoil: 5.5, shake: 13, half: 4.5, color: '#60a5fa', trail: '96,165,250', trailFx: 'frost',
    sparks: ['#ffffff', '#bfdbfe', '#3b82f6'], stats: { rate: 2, speed: 3, power: 5 } },
  { ...base, id: 'crystal', name: 'CRYSTAL CANNON', emoji: '🔮', rarity: 'EPIC', perk: 'PECAH KRISTAL', desc: 'Meriam kristal kuarsa! Kristal ungu pecah menjadi prisma berkilau saat kena.',
    speed: 2600, cooldown: 0.34, points: 3, breakSpike: true, recoil: 5.0, shake: 12, half: 5.5, energy: true, color: '#f0abfc', trail: '240,171,252', trailFx: 'glow',
    sparks: ['#ffffff', '#fae8ff', '#d946ef'], stats: { rate: 2, speed: 3, power: 5 } },
  { ...base, id: 'beerifle', name: 'BEE RIFLE', emoji: '🐝', rarity: 'EPIC', perk: 'SENGAT RATU', desc: 'Senapan runduk bergaris lebah! Menembakkan sengat ratu super cepat dan membakar target.',
    speed: 4800, cooldown: 0.36, points: 2, burn: true, scope: true, recoil: 4.5, shake: 11, half: 3.5, noSmoke: true, color: '#facc15', trail: '250,204,21',
    sparks: ['#ffffff', '#fef08a', '#eab308'], stats: { rate: 2, speed: 5, power: 4 } },
  { ...base, id: 'coingun', name: 'COIN GUN', emoji: '🪙', rarity: 'EPIC', perk: 'PABRIK KOIN', desc: 'Menembakkan koin emas murni berkilau! Tiap kill memberi skor bonus emas.',
    speed: 3100, cooldown: 0.16, coinValue: 2, recoil: 2.0, shake: 6, half: 4.5, noSmoke: true, color: '#facc15', trail: '250,204,21', trailFx: 'gold',
    sparks: ['#ffffff', '#fef08a', '#f59e0b'], stats: { rate: 4, speed: 4, power: 3 } },
  { ...base, id: 'tesla_rifle', name: 'TESLA RIFLE ARC', emoji: '⚡', rarity: 'EPIC', perk: 'BOLA PETIR', desc: 'Senapan Tesla 50 kV: menembakkan bola petir yang meloncat berantai ke musuh sekitar!',
    speed: 2900, cooldown: 0.24, points: 2, energy: true, chain: true, recoil: 3.0, shake: 9, half: 4.8, color: '#38bdf8', trail: '90,210,255', trailFx: 'spark',
    sparks: ['#ffffff', '#bae6fd', '#0284c7'], stats: { rate: 3, speed: 4, power: 4 } },
  { ...base, id: 'identity_disc', name: 'IDENTITY DISC', emoji: '💿', rarity: 'EPIC', perk: 'CAKRAM CAHAYA', desc: 'Cakram neon Tron yang berputar cepat, memantul & menembus musuh!',
    speed: 3000, cooldown: 0.28, points: 2, coinValue: 2, energy: true, pierceOld: true, spinFly: true, recoil: 2.0, shake: 6, half: 5.5, noSmoke: true, color: '#22d3ee', trail: '34,211,238', trailFx: 'glow',
    sparks: ['#ffffff', '#a5f3fc', '#06b6d4'], stats: { rate: 3, speed: 4, power: 4 } },
  { ...base, id: 'proton_pack', name: 'PROTON PACK', emoji: '⚛️', rarity: 'EPIC', perk: 'ALIRAN PROTON', desc: 'Paket proton pemburu hantu! Sinar partikel mendesis panas yang menyapu target.',
    speed: 14000, cooldown: 0.16, points: 3, energy: true, beam: true, burn: true, recoil: 2.2, shake: 8, half: 5.0, color: '#fde047', trail: '253,224,71',
    sparks: ['#ffffff', '#fef08a', '#f97316'], stats: { rate: 4, speed: 5, power: 5 } },
  { ...base, id: 'mega_buster', name: 'MEGA BUSTER', emoji: '🤖', rarity: 'EPIC', perk: 'CHARGE SHOT', desc: 'Meriam lengan ala Mega Man! Tembakan plasma biru cepat yang menghancurkan perisai.',
    speed: 3200, cooldown: 0.2, points: 2, energy: true, charge: true, recoil: 2.8, shake: 8, half: 5.2, color: '#8cc8ff', trail: '140,200,255', trailFx: 'glow',
    sparks: ['#ffffff', '#bae6fd', '#0284c7'], stats: { rate: 4, speed: 4, power: 4 } },
  { ...base, id: 'harmonic_disruptor', name: 'HARMONIC DISRUPTOR', emoji: '🔊', rarity: 'EPIC', perk: 'GELOMBANG SUARA', desc: 'Meriam resonansi sonik: gelombang kejut suara yang menghempaskan musuh!',
    speed: 2700, cooldown: 0.26, points: 2, energy: true, recoil: 4.0, shake: 11, half: 6.0, color: '#bea0ff', trail: '190,160,255', trailFx: 'glow',
    sparks: ['#ffffff', '#e9d5ff', '#9333ea'], stats: { rate: 3, speed: 3, power: 4 } },
  { ...base, id: 'nano_swarm', name: 'NANO-SWARM', emoji: '🛰️', rarity: 'EPIC', perk: 'GEROMBOLAN DRON', desc: 'Peluncur dron nano otomatis yang menyebar cepat menggerogoti target!',
    speed: 2500, cooldown: 0.14, auto: true, points: 2, burst: 2, energy: true, recoil: 1.8, shake: 5, half: 4.0, color: '#82e696', trail: '130,230,150', trailFx: 'spark',
    sparks: ['#ffffff', '#bbf7d0', '#22c55e'], stats: { rate: 5, speed: 3, power: 4 } },

  // ======================== LEGENDARIS (19) ========================
  { ...base, id: 'freeze', name: 'FREEZE RAY', emoji: '❄️', rarity: 'LEGENDARIS', perk: 'BEKUKAN', desc: 'Tiap tembakan membekukan musuh di tempat dengan pecahan kristal es!',
    speed: 2200, cooldown: 0.18, recoil: 3.4, shake: 15, energy: true, color: '#9be7ff', trail: '155,231,255', trailFx: 'frost',
    sparks: ['#ffffff', '#d6f6ff', '#7fe3ff'], slow: true, slowFactor: 0.3, slowTime: 1.3, slowRgb: '170,230,255', slowText: '❄ BEKU!', previewY: 40, stats: { rate: 3, speed: 3, power: 4 } },
  { ...base, id: 'golden', name: 'GOLDEN GUN', emoji: '🌟', rarity: 'LEGENDARIS', perk: '3X KOIN', desc: 'Pistol emas legendaris James Bond. Damage super besar & bonus +300 skor tiap kill!',
    speed: 3000, cooldown: 0.15, points: 2, coinRadius: 18, coinValue: 3, recoil: 3.4, color: '#ffd23f', trail: '255,215,90', trailFx: 'gold',
    sparks: ['#ffffff', '#fff1a8', '#ffd23f'], casing: '#ffd23f', ejectY: 90, previewScale: 1, previewY: 26, stats: { rate: 3, speed: 4, power: 4 } },
  { ...base, id: 'blackhole', name: 'BLACK HOLE', emoji: '🕳️', rarity: 'LEGENDARIS', perk: 'SEDOT MUSUH', desc: 'Menembak lubang hitam mini yang menyeret & menyedot semua musuh di sekitarnya!',
    speed: 1400, cooldown: 0.35, coinRadius: 200, recoil: 3.4, half: 6, energy: true, pullCoins: true, color: '#a855f7', trail: '168,85,247', trailFx: 'void',
    sparks: ['#f5d0fe', '#a855f7', '#6b21a8'], previewLen: 180, previewY: 34, stats: { rate: 1, speed: 2, power: 4 } },
  { ...base, id: 'dragon', name: 'DRAGON BREATH', emoji: '🐉', rarity: 'LEGENDARIS', perk: 'PEMBURU BOS', desc: 'Naga api mini yang membakar target. Damage 2x lipat saat melawan BOSS!',
    speed: 2200, cooldown: 0.22, points: 2, recoil: 3.4, shake: 15, half: 6, noSmoke: true, burn: true, bossMult: 2, color: '#ef4444', trail: '255,120,40', trailFx: 'fire',
    sparks: ['#fff3b0', '#ff9f1c', '#ef4444'], burstFx: { colors: ['255,200,80', '255,120,30', '255,40,20'], n: 14, glow: true, g: -80, spd: 200, size: 9 },
    previewLen: 200, previewY: 50, stats: { rate: 3, speed: 3, power: 5 } },
  { ...base, id: 'meteor', name: 'METEOR LAUNCHER', emoji: '☄️', rarity: 'LEGENDARIS', perk: 'HUJAN METEOR', desc: 'Memanggil meteor membara dengan ledakan TERBESAR di game!',
    speed: 1300, cooldown: 0.55, points: 4, recoil: 3.4, shake: 15, half: 7, stick: 20, explode: true, breakSpike: true, color: '#f97316', trail: '255,140,50', trailFx: 'fire',
    sparks: ['#fff3b0', '#fb923c', '#dc2626'], previewY: 38, stats: { rate: 1, speed: 1, power: 5 } },
  { ...base, id: 'diamond', name: 'DIAMOND GUN', emoji: '💎', rarity: 'LEGENDARIS', perk: 'BERLIAN', desc: 'Pistol kristal yang menembakkan berlian tembus musuh & 25% peluang JACKPOT +400!',
    speed: 3400, cooldown: 0.16, half: 3, coinValue: 2, jackpot: 0.25, jackpotText: '💎 BERLIAN! +400', noSmoke: true, color: '#67e8f9', trail: '200,250,255', trailFx: 'gold',
    sparks: ['#ffffff', '#cffafe', '#67e8f9'], previewY: 30, stats: { rate: 3, speed: 4, power: 4 } },
  { ...base, id: 'holy', name: 'HOLY LIGHT GUN', emoji: '😇', rarity: 'LEGENDARIS', perk: 'CAHAYA SUCI', desc: 'Senjata bersayap malaikat. Sinar cahaya suci instan yang menembus 3 musuh sekaligus!',
    speed: 14000, cooldown: 0.2, points: 2, half: 4, stick: 32, recoil: 3.4, shake: 15, energy: true, beam: true, meltEvery: 1,
    saves: 1, saveFx: 'bubble', color: '#fde68a', trail: '255,236,170', sparks: ['#ffffff', '#fff2b0', '#ffd24a'], previewY: 40, stats: { rate: 3, speed: 5, power: 5 } },
  { ...base, id: 'gravity', name: 'GRAVITY GUN', emoji: '🌌', rarity: 'LEGENDARIS', perk: 'BALIK ARAH', desc: 'Gelombang gravitasi ungu yang menyedot musuh & melontarkannya!',
    speed: 2300, cooldown: 0.26, energy: true, pullCoins: true, reverseEvery: 4, recoil: 3.4, shake: 10, half: 5.5, color: '#818cf8', trail: '129,140,248', trailFx: 'void',
    sparks: ['#ffffff', '#c7d2fe', '#6366f1'], stats: { rate: 3, speed: 3, power: 4 } },
  { ...base, id: 'moonbeam', name: 'MOONBEAM', emoji: '🌙', rarity: 'LEGENDARIS', perk: 'CAHAYA BULAN', desc: 'Tongkat bulan menembakkan bintang-bintang beraura kuat secepat kilat!',
    speed: 3600, cooldown: 0.18, points: 2, luckyCoin: 0.3, energy: true, recoil: 2.2, shake: 7, half: 4.5, color: '#c4b5fd', trail: '205,186,255', trailFx: 'gold',
    sparks: ['#ffffff', '#ede9fe', '#c4b5fd', '#fff1be'], stats: { rate: 4, speed: 5, power: 4 } },
  { ...base, id: 'storm', name: 'STORM CALLER', emoji: '🌩️', rarity: 'LEGENDARIS', perk: 'BADAI PETIR', desc: 'Memanggil badai petir dahsyat! Petir berantai menyambar banyak musuh sekaligus.',
    speed: 3100, cooldown: 0.24, points: 2, energy: true, chain: true, breakSpike: true, recoil: 4.0, shake: 12, half: 5.0, color: '#93c5fd', trail: '147,197,253', trailFx: 'spark',
    sparks: ['#ffffff', '#dbeafe', '#3b82f6'], stats: { rate: 3, speed: 4, power: 5 } },
  { ...base, id: 'obliterator', name: 'OBLITERATOR 9000', emoji: '☢️', rarity: 'LEGENDARIS', perk: 'PEMUSNAH', desc: 'Meriam energi hijau raksasa 5x damage dengan tentakel petir pemusnah!',
    speed: 1900, cooldown: 0.45, points: 5, obliterate: 3, energy: true, explode: true, recoil: 9.0, shake: 18, half: 7.0, color: '#4ade80', trail: '74,222,128', trailFx: 'glow',
    sparks: ['#dcfce7', '#86efac', '#22c55e'], stats: { rate: 1, speed: 2, power: 5 } },
  { ...base, id: 'blaster', name: 'WARS BLASTER', emoji: '🔫', rarity: 'LEGENDARIS', perk: 'LASER GALAXY', desc: 'Blaster energi galaksi ala Star Wars! Baut plasma merah terang dengan suara sci-fi otentik.',
    speed: 3500, cooldown: 0.15, points: 3, energy: true, recoil: 2.8, shake: 9, half: 4.5, color: '#ef4444', trail: '239,68,68', trailFx: 'glow',
    sparks: ['#ffffff', '#fecaca', '#ef4444'], stats: { rate: 4, speed: 4, power: 5 } },
  { ...base, id: 'photon_saber', name: 'PHOTON SABER', emoji: '⚔️', rarity: 'LEGENDARIS', perk: 'PEDANG CAHAYA', desc: 'Pedang energi plasma bercahaya! Meluncurkan bilah cahaya menembus musuh.',
    speed: 3300, cooldown: 0.22, points: 3, energy: true, pierceOld: true, recoil: 3.0, shake: 9, half: 5.0, color: '#22d3ee', trail: '34,211,238', trailFx: 'glow',
    sparks: ['#ffffff', '#cffafe', '#06b6d4'], stats: { rate: 3, speed: 4, power: 5 } },
  { ...base, id: 'gauntlet_cannon', name: 'GAUNTLET CANNON', emoji: '🦾', rarity: 'LEGENDARIS', perk: 'TELAPAK BESI', desc: 'Meriam telapak tangan robotik raksasa! Tinju surya dengan ledakan & hentakan dahsyat.',
    speed: 2800, cooldown: 0.34, points: 3, energy: true, explode: true, recoil: 8.0, shake: 16, half: 6.5, color: '#fb923c', trail: '251,146,60', trailFx: 'fire',
    sparks: ['#ffffff', '#fef08a', '#ef4444'], stats: { rate: 2, speed: 4, power: 5 } },
  { ...base, id: 'heat_ray', name: 'MARTIAN HEAT-RAY', emoji: '🔴', rarity: 'LEGENDARIS', perk: 'SINAR PANAS', desc: 'Meriam panas tripod Mars! Sinar merah membara instan yang membakar & melelehkan target.',
    speed: 14000, cooldown: 0.24, points: 3, energy: true, beam: true, burn: true, recoil: 4.5, shake: 12, half: 5.5, color: '#ef4444', trail: '255,80,40',
    sparks: ['#ffffff', '#fde047', '#ef4444'], stats: { rate: 3, speed: 5, power: 5 } },
  { ...base, id: 'absolute_zero', name: 'ABSOLUTE ZERO', emoji: '❄️', rarity: 'LEGENDARIS', perk: 'TOMBAK KRISTAL', desc: 'Tombak kristal krio yang menembus & membekukan seluruh musuh seketika!',
    speed: 3400, cooldown: 0.26, points: 2, energy: true, slow: true, slowStyle: 'ice', pierceOld: true, recoil: 3.2, shake: 10, half: 4.5, color: '#a5f3fc', trail: '165,243,252', trailFx: 'frost',
    sparks: ['#ffffff', '#cffafe', '#06b6d4'], stats: { rate: 3, speed: 4, power: 5 } },
  { ...base, id: 'helios_flare', name: 'HELIOS FLARE', emoji: '☀️', rarity: 'LEGENDARIS', perk: 'BINTANG PANAS', desc: 'Proyektor plasma bintang! Bola api raksasa yang meledak panas & membakar area luas.',
    speed: 2100, cooldown: 0.42, points: 3, energy: true, explode: true, burn: true, recoil: 6.0, shake: 14, half: 6.5, color: '#fb923c', trail: '255,170,60', trailFx: 'fire',
    sparks: ['#ffffff', '#fef08a', '#f97316'], stats: { rate: 2, speed: 3, power: 5 } },
  { ...base, id: 'orbital_beacon', name: 'ORBITAL ION BEACON', emoji: '🛰️', rarity: 'LEGENDARIS', perk: 'SERANGAN ORBITAL', desc: 'Penanda sasaran orbital: sinar ion raksasa jatuh dari langit menembus semua musuh!',
    speed: 14000, cooldown: 0.38, points: 3, energy: true, beam: true, pierceOld: true, recoil: 5.0, shake: 14, half: 5.5, color: '#ff96d2', trail: '255,150,210',
    sparks: ['#ffffff', '#fbcfe8', '#ec4899'], stats: { rate: 2, speed: 5, power: 5 } },
  { ...base, id: 'singularity', name: 'SINGULARITY CANNON', emoji: '🕳️', rarity: 'LEGENDARIS', perk: 'HORIZON PERISTIWA', desc: 'Meriam lubang hitam cakram akresi yang menyedot & melumat musuh di sekitarnya!',
    speed: 1500, cooldown: 0.42, points: 3, energy: true, pullCoins: true, recoil: 4.5, shake: 12, half: 6.5, color: '#c084fc', trail: '192,132,252', trailFx: 'void',
    sparks: ['#ffffff', '#e9d5ff', '#7e22ce'], stats: { rate: 2, speed: 2, power: 5 } },
];

export const CHEAP_PRICE: Record<Rarity, { coin: number; diamond: number }> = {
  UMUM: { coin: 75, diamond: 0 },
  LANGKA: { coin: 195, diamond: 0 },
  EPIC: { coin: 0, diamond: 34 },
  LEGENDARIS: { coin: 0, diamond: 58 },
};

export function getWeaponCoinPrice(w: Weapon): number {
  if (w.id === 'pistol') return 0;
  if (w.coinPrice !== undefined) return w.coinPrice;
  if (w.price !== undefined) return Math.min(w.price, CHEAP_PRICE[w.rarity].coin);
  return CHEAP_PRICE[w.rarity].coin;
}
export function getWeaponDiamondPrice(w: Weapon): number {
  if (w.id === 'pistol') return 0;
  if (w.diamondPrice !== undefined) return w.diamondPrice;
  return CHEAP_PRICE[w.rarity].diamond;
}
export function getWeaponPriceLabel(w: Weapon): string {
  const c = getWeaponCoinPrice(w);
  const d = getWeaponDiamondPrice(w);
  if (c === 0 && d === 0) return 'FREE';
  if (d > 0 && c === 0) return `${d}💎`;
  if (c > 0 && d === 0) return `${c}🪙`;
  return `${d}💎 / ${c}🪙`;
}
export function isWeaponFree(w: Weapon): boolean {
  return getWeaponCoinPrice(w) === 0 && getWeaponDiamondPrice(w) === 0;
}
export function getWeaponCurrency(w: Weapon): 'coin' | 'diamond' | 'free' {
  if (isWeaponFree(w)) return 'free';
  return getWeaponDiamondPrice(w) > 0 ? 'diamond' : 'coin';
}

export const WEAPONS: Weapon[] = ALL_WEAPON_DEFINITIONS;

export const RARITY_COLOR: Record<Rarity, string> = {
  UMUM: '#9ca3af',
  LANGKA: '#3b82f6',
  EPIC: '#a855f7',
  LEGENDARIS: '#f59e0b',
};

export const getWeapon = (id: string) => WEAPONS.find((w) => w.id === id) || WEAPONS[0];

export function isWeaponUnlocked(w: Weapon, ownedIds: string[] = [], _highestLevel?: number): boolean {
  if (isWeaponFree(w)) return true;
  if (ownedIds.includes(w.id)) return true;
  return false;
}

export function canAffordWithCoins(w: Weapon, coins: number): boolean {
  return coins >= getWeaponCoinPrice(w);
}
export function canAffordWithDiamonds(w: Weapon, diamonds: number): boolean {
  return diamonds >= getWeaponDiamondPrice(w);
}

export const GIFT_RARITY_WEIGHT: Record<Rarity, number> = {
  UMUM: 45,
  LANGKA: 27,
  EPIC: 17,
  LEGENDARIS: 11,
};

export function rollGiftWeapon(excludeId?: string): Weapon {
  const pool = WEAPONS.filter((w) => w.id !== excludeId && w.rarity !== 'LANGKA');
  const source = pool.length > 0 ? pool : WEAPONS;
  const total = source.reduce((s, w) => s + GIFT_RARITY_WEIGHT[w.rarity], 0);
  let r = Math.random() * total;
  for (const w of source) {
    r -= GIFT_RARITY_WEIGHT[w.rarity];
    if (r <= 0) return w;
  }
  return source[source.length - 1];
}

export function getWeaponAmmoDelta(weapon: Weapon): number {
  return weapon.ammoDelta ?? 0;
}

void storage;
