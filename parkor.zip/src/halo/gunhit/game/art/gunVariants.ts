// @ts-nocheck — ported from Perfect Shot
import type { WeaponId } from '../weapons';

export type GunVariant = 'current';
export type GunEffect = 'new';
export type EditableWeapon = WeaponId;
export type VariantWeapon = WeaponId;
export type OriginalDesignWeapon = WeaponId;
export type LatestDesignWeapon = WeaponId;
export type FixedClassicWeapon = never;

export const FIXED_CLASSIC_WEAPONS = [] as const satisfies readonly WeaponId[];
export const EDITABLE_WEAPONS: readonly WeaponId[] = [];
export const UNIQUE_EDITABLE_WEAPONS: readonly WeaponId[] = [];

export const isFixedClassicGun = (_id: string): _id is never => false;
export const supportsGunVariants = (_id: string): boolean => false;
export const hasSeparateOriginal = (_id: string): boolean => false;
export const supportsLatestDesign = (_id: string): boolean => false;
export const hasNoNewShot = (_id: string): boolean => false;

export const isSetOneDesignWeapon = (_id: string): boolean => false;
export const isSetSevenDesignWeapon = (_id: string): boolean => false;
export const isSetNineDesignWeapon = (_id: string): boolean => false;
export const isSetElevenDesignWeapon = (_id: string): boolean => false;
export const isElevenOnlyWeapon = (_id: string): boolean => false;
export const isSetSixDesignWeapon = (_id: string): boolean => false;

export function getGunVariant(_id: WeaponId): GunVariant {
  return 'current';
}

export function getGunEffect(_id: WeaponId | 'old'): GunEffect {
  return 'new';
}
