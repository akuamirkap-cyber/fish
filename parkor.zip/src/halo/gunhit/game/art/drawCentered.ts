// @ts-nocheck — ported from Perfect Shot
import type { WeaponId } from '../weapons';
import type { GunVariant } from './gunVariants';
import { drawGun } from './guns';
import { getGunMetrics } from './metrics';
import { gunState } from './kit';
import { commonGunPreviewState, isCommonGun } from './commonGunMotion';

/**
 * Draws any weapon with its true geometric mass center placed at (0, 0).
 */
export function drawGunCentered(
  c: CanvasRenderingContext2D,
  id: WeaponId,
  t = 0,
  flash = 0,
  ready = true,
  variant?: GunVariant,
  demo = false,
) {
  const m = getGunMetrics(id, variant);
  const x = -m.centerOffsetX;
  const y = -m.centerOffsetY;
  if (!demo || (!isCommonGun(id) && id !== 'keris' && id !== 'ghost')) {
    drawGun(c, id, x, y, t, flash, ready, variant);
    return;
  }

  const state = commonGunPreviewState(t);
  const previousShot = gunState.sinceShot;
  const previousReload = gunState.reloadT;
  const previousPreview = gunState.inPreview;
  const previousGhostSide = gunState.ghostSide;
  try {
    gunState.sinceShot = state.sinceShot;
    gunState.reloadT = state.reloadT;
    gunState.inPreview = true;
    if (id === 'ghost') gunState.ghostSide = Math.floor(t / 2.8) % 2 ? -1 : 1;
    const demoReady = state.ready || id === 'keris' || (id === 'slingshot' && state.sinceShot >= 0.36);
    drawGun(c, id, x, y, t, Math.max(flash, state.flash), ready && demoReady, variant);
  } finally {
    gunState.sinceShot = previousShot;
    gunState.reloadT = previousReload;
    gunState.inPreview = previousPreview;
    gunState.ghostSide = previousGhostSide;
  }
}
