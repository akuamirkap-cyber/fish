// @ts-nocheck — ported from Perfect Shot
import type { ProjKind } from '../weapons';
import type { GunEffect } from './gunVariants';

type C = CanvasRenderingContext2D;

const trailGradCache = new WeakMap<C, Record<string, CanvasGradient | CanvasGradient[]>>();

function getTrailGrad(c: C, key: string, build: () => CanvasGradient): CanvasGradient {
  let bag = trailGradCache.get(c);
  if (!bag) {
    bag = {};
    trailGradCache.set(c, bag);
  }
  let g = bag[key] as CanvasGradient | undefined;
  if (!g) {
    g = build();
    bag[key] = g;
  }
  return g;
}

function getTrailGradList(c: C, key: string, build: () => CanvasGradient[]): CanvasGradient[] {
  let bag = trailGradCache.get(c);
  if (!bag) {
    bag = {};
    trailGradCache.set(c, bag);
  }
  let list = bag[key] as CanvasGradient[] | undefined;
  if (!list) {
    list = build();
    bag[key] = list;
  }
  return list;
}

const BAMBOO_ASH_SPECS: ReadonlyArray<readonly [number, number, number, number]> = [
  [0, 23, 10, 0.36],
  [5, 38, 13, 0.28],
  [-6, 57, 11, 0.2],
  [3, 75, 8, 0.12],
];

/** Material trails for shots that should not have the ordinary sharp laser wedge. */
export function drawMaterialTrail(c: C, kind: ProjKind, _effect?: GunEffect, _time = 0): boolean {
  if (kind === 'keris' || kind === 'bazooka' || kind === 'diamond') return true;
  if (kind === 'golden') {
    c.save(); c.globalCompositeOperation = 'lighter';
    const ribbon = getTrailGrad(c, 'golden', () => {
      const g = c.createLinearGradient(0, 10, 0, 100);
      g.addColorStop(0, 'rgba(255,241,165,0.8)');
      g.addColorStop(0.5, 'rgba(250,182,52,0.38)');
      g.addColorStop(1, 'rgba(250,182,52,0)');
      return g;
    });
    c.fillStyle = ribbon; c.beginPath(); c.moveTo(-5, 12);
    c.quadraticCurveTo(-11, 45, -2, 70); c.lineTo(0, 104);
    c.lineTo(2, 70); c.quadraticCurveTo(11, 45, 5, 12);
    c.closePath(); c.fill();
    c.fillStyle = '#fff4b8';
    for (const [x, y, r] of [[-9, 30, 2.3], [8, 49, 2], [-4, 73, 1.5]] as const) {
      c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
    }
    c.restore(); return true;
  }
  if (kind === 'dragon' || kind === 'meteor') {
    c.save();
    const ember = getTrailGrad(c, 'dragon', () => {
      const g = c.createLinearGradient(0, 13, 0, 105);
      g.addColorStop(0, 'rgba(255,239,159,0.73)');
      g.addColorStop(0.4, 'rgba(251,121,33,0.54)');
      g.addColorStop(1, 'rgba(220,38,38,0)');
      return g;
    });
    c.fillStyle = ember; c.beginPath(); c.moveTo(-7, 12);
    c.bezierCurveTo(-14, 32, -3, 47, -8, 77);
    c.quadraticCurveTo(0, 110, 8, 77);
    c.bezierCurveTo(3, 47, 14, 32, 7, 12); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,215,123,0.74)';
    for (const [x, y, r] of [[-12, 36, 1.8], [10, 59, 1.6], [-4, 84, 1.4]]) {
      c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
    }
    c.restore(); return true;
  }
  if (kind === 'bamboo') {
    c.save();
    const grads = getTrailGradList(c, 'bamboo', () =>
      BAMBOO_ASH_SPECS.map(([x, y, size, opacity]) => {
        const ash = c.createRadialGradient(x, y, 0, x, y, size);
        ash.addColorStop(0, `rgba(247,245,235,${opacity})`);
        ash.addColorStop(1, 'rgba(247,245,235,0)');
        return ash;
      }),
    );
    for (let i = 0; i < BAMBOO_ASH_SPECS.length; i++) {
      const [x, y, size] = BAMBOO_ASH_SPECS[i];
      c.fillStyle = grads[i]; c.beginPath(); c.arc(x, y, size, 0, Math.PI * 2); c.fill();
    }
    c.fillStyle = '#ffe6a2';
    for (const [x, y, r] of [[-8, 38, 2], [9, 53, 1.4], [-3, 71, 1.1]]) {
      c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
    }
    c.restore(); return true;
  }
  return false;
}
