import { drawGun, drawHatShape, type GunKind } from './character';
import { rand, TAU } from './math';
import type { World } from './world';

export type PKind =
  | 'blood'
  | 'mist'
  | 'spark'
  | 'smoke'
  | 'fire'
  | 'debris'
  | 'shell'
  | 'dust'
  | 'flash'
  | 'ring'
  | 'gun'
  | 'glass'
  | 'feather'
  | 'plank'
  | 'hat'
  | 'impact'
  | 'shock'
  | 'puff'
  | 'wake'
  | 'beam'
  | 'slash';

export interface Particle {
  kind: PKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  rot: number;
  vr: number;
  color: string;
  g: number;
  drag: number;
  bounce: number;
  collide: boolean;
  w: number;
  h: number;
  bounced: number;
  gun: GunKind;
  band: string;
}

export interface Decal {
  x: number;
  y: number;
  w: number;
  h: number;
  rot: number;
  color: string;
  kind: 'blood' | 'hole' | 'scorch' | 'crack';
}

const BLOOD_COLS = ['#a3111b', '#8a0c14', '#b8141f', '#7a0a10'];

export class Particles {
  list: Particle[] = [];
  decals: Decal[] = [];
  max = 1800;
  maxDecals = 1400;
  onShell: (() => void) | null = null;
  onGunDrop: (() => void) | null = null;

  spawn(p: Partial<Particle> & { kind: PKind; x: number; y: number }): Particle {
    const part: Particle = {
      vx: 0,
      vy: 0,
      life: 1,
      max: 1,
      size: 2,
      rot: 0,
      vr: 0,
      color: '#fff',
      g: 0,
      drag: 0,
      bounce: 0.3,
      collide: false,
      w: 4,
      h: 2,
      bounced: 0,
      gun: null,
      band: '#111',
      ...p,
    };
    part.max = part.life;
    if (this.list.length >= this.max) {
      // drop oldest non-persistent
      const idx = this.list.findIndex((q) => q.kind !== 'gun');
      if (idx >= 0) this.list.splice(idx, 1);
    }
    this.list.push(part);
    return part;
  }

  addDecal(d: Decal) {
    if (this.decals.length >= this.maxDecals) this.decals.splice(0, 60);
    this.decals.push(d);
  }

  blood(x: number, y: number, dx: number, dy: number, count: number, power = 1) {
    const len = Math.hypot(dx, dy) || 1;
    const ux = dx / len;
    const uy = dy / len;
    for (let i = 0; i < count; i++) {
      const sp = rand(80, 520) * power;
      const spread = rand(-0.6, 0.6);
      const c = Math.cos(spread);
      const s = Math.sin(spread);
      const bx = ux * c - uy * s;
      const by = ux * s + uy * c;
      this.spawn({
        kind: 'blood',
        x,
        y,
        vx: bx * sp + rand(-40, 40),
        vy: by * sp + rand(-120, 30),
        life: rand(0.8, 2),
        size: rand(1.2, 3.4),
        color: BLOOD_COLS[(Math.random() * BLOOD_COLS.length) | 0],
        g: 1500,
        drag: 0.4,
        collide: true,
      });
    }
    for (let i = 0; i < Math.ceil(count / 5); i++) {
      this.spawn({
        kind: 'mist',
        x: x + rand(-3, 3),
        y: y + rand(-3, 3),
        vx: ux * rand(20, 90),
        vy: uy * rand(20, 90) - 10,
        life: rand(0.25, 0.5),
        size: rand(5, 11),
        color: '#b0101a',
        drag: 3,
      });
    }
  }

  sparks(x: number, y: number, nx: number, ny: number, count: number, color = '#ffd36b') {
    for (let i = 0; i < count; i++) {
      const a = Math.atan2(ny, nx) + rand(-1.1, 1.1);
      const sp = rand(150, 650);
      this.spawn({
        kind: 'spark',
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rand(0.08, 0.28),
        size: rand(1, 2),
        color,
        g: 900,
        drag: 2,
      });
    }
  }

  dust(x: number, y: number, count: number, dir = 0, color = 'rgba(210,200,185,1)') {
    for (let i = 0; i < count; i++) {
      this.spawn({
        kind: 'dust',
        x: x + rand(-6, 6),
        y: y + rand(-3, 1),
        vx: dir * rand(20, 120) + rand(-50, 50),
        vy: rand(-60, -10),
        life: rand(0.3, 0.6),
        size: rand(3, 7),
        color,
        drag: 3,
      });
    }
  }

  smoke(x: number, y: number, count: number, size = 12, dark = false) {
    for (let i = 0; i < count; i++) {
      this.spawn({
        kind: 'smoke',
        x: x + rand(-size, size),
        y: y + rand(-size, size),
        vx: rand(-60, 60),
        vy: rand(-90, -20),
        life: rand(0.8, 1.8),
        size: rand(size * 0.6, size * 1.4),
        color: dark ? '#2a2624' : '#77706a',
        drag: 1.5,
      });
    }
  }

  debris(x: number, y: number, count: number, color: string, power = 1, big = false) {
    for (let i = 0; i < count; i++) {
      const a = rand(0, TAU);
      const sp = rand(80, 420) * power;
      this.spawn({
        kind: 'debris',
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 150 * power,
        life: rand(1.2, 2.8),
        w: big ? rand(5, 14) : rand(2, 5),
        h: big ? rand(2, 5) : rand(1.5, 3),
        rot: rand(0, TAU),
        vr: rand(-18, 18),
        color,
        g: 1600,
        drag: 0.3,
        bounce: 0.35,
        collide: true,
      });
    }
  }

  glass(x: number, y: number, w: number, h: number, vx: number, vy: number) {
    const n = Math.min(46, Math.floor((w * h) / 70) + 18);
    for (let i = 0; i < n; i++) {
      this.spawn({
        kind: 'glass',
        x: x + rand(0, w),
        y: y + rand(0, h),
        vx: vx * rand(0.3, 1.1) + rand(-160, 160),
        vy: vy * rand(0.2, 0.8) + rand(-220, 60),
        life: rand(1.4, 3),
        size: rand(3, 9),
        rot: rand(0, TAU),
        vr: rand(-20, 20),
        color: Math.random() < 0.5 ? 'rgba(190,230,255,0.85)' : 'rgba(150,205,240,0.8)',
        g: 1500,
        drag: 0.2,
        bounce: 0.3,
        collide: true,
      });
    }
  }

  shell(x: number, y: number, vx: number, vy: number, big = false) {
    this.spawn({
      kind: 'shell',
      x,
      y,
      vx,
      vy,
      life: rand(4, 6),
      w: big ? 7 : 5,
      h: big ? 3 : 2.1,
      rot: rand(0, TAU),
      vr: rand(-30, 30),
      color: big ? '#c0392b' : '#d8a62a',
      g: 1700,
      drag: 0.2,
      bounce: 0.45,
      collide: true,
    });
  }

  dropGun(x: number, y: number, vx: number, vy: number, gun: GunKind) {
    this.spawn({
      kind: 'gun',
      x,
      y,
      vx,
      vy,
      life: 9999,
      rot: rand(0, TAU),
      vr: rand(-14, 14),
      g: 1700,
      drag: 0.3,
      bounce: 0.35,
      collide: true,
      gun,
    });
  }

  explosion(x: number, y: number, energy = false) {
    if (energy) {
      this.spawn({ kind: 'flash', x, y, life: 0.3, size: 340, color: '#9fe8ff' });
      this.spawn({ kind: 'ring', x, y, life: 0.45, size: 240, color: '#dff6ff' });
      this.spawn({ kind: 'ring', x, y, life: 0.3, size: 140, color: '#ffffff' });
      for (let i = 0; i < 34; i++) {
        const a = rand(0, TAU);
        const sp = rand(80, 520);
        this.spawn({
          kind: 'fire',
          x: x + rand(-10, 10),
          y: y + rand(-10, 10),
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp - 60,
          life: rand(0.25, 0.7),
          size: rand(10, 28),
          color: Math.random() < 0.5 ? '#7fdcff' : '#3fa8ff',
          drag: 3.5,
          g: -60,
        });
      }
      this.sparks(x, y, 0, -1, 40, '#e6fbff');
      this.sparks(x, y, 0, 1, 20, '#9fe8ff');
      this.smoke(x, y - 10, 12, 22, false);
      this.debris(x, y, 18, '#3a3a3a', 1.6, true);
      return;
    }
    this.spawn({ kind: 'flash', x, y, life: 0.22, size: 260, color: '#ffb347' });
    this.spawn({ kind: 'ring', x, y, life: 0.35, size: 170, color: '#fff' });
    for (let i = 0; i < 30; i++) {
      const a = rand(0, TAU);
      const sp = rand(60, 420);
      this.spawn({
        kind: 'fire',
        x: x + rand(-10, 10),
        y: y + rand(-10, 10),
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 120,
        life: rand(0.25, 0.65),
        size: rand(10, 26),
        color: Math.random() < 0.5 ? '#ffb02e' : '#ff6a1a',
        drag: 3.5,
        g: -120,
      });
    }
    this.smoke(x, y - 10, 18, 22, true);
    this.sparks(x, y, 0, -1, 26, '#ffcf5a');
    this.debris(x, y, 14, '#8b1e1e', 1.6, true);
    this.debris(x, y, 10, '#3a3a3a', 1.3, false);
  }

  update(dt: number, world: World) {
    const list = this.list;
    for (let i = list.length - 1; i >= 0; i--) {
      const p = list[i];
      p.life -= dt;
      if (p.life <= 0) {
        list[i] = list[list.length - 1];
        list.pop();
        continue;
      }
      const ox = p.x;
      const oy = p.y;
      p.vy += p.g * dt;
      if (p.drag > 0) {
        const k = Math.max(0, 1 - p.drag * dt);
        p.vx *= k;
        p.vy *= k;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
      if (!p.collide) continue;
      const off = p.kind === 'plank' ? p.h * 0.5 : p.kind === 'hat' ? p.size * 0.35 : 0;
      const s = world.solidAt(p.x, p.y + off, true);
      if (!s) continue;
      if (s.oneWay && !(oy + off <= s.y + 0.5 && p.vy > 0)) continue;
      if (p.kind === 'blood') {
        // stick as decal
        const vertical = !world.solidAt(ox, p.y, true);
        const r = p.size * rand(1.1, 2.4);
        const floor = !vertical && p.vy > 0;
        this.addDecal({
          x: vertical ? ox : p.x,
          y: floor ? s.y + rand(-0.5, 1.2) : vertical ? p.y : oy,
          w: vertical ? r * 0.75 : r * 1.9,
          h: vertical ? r * 1.6 : r * 0.62,
          rot: 0,
          color: p.color,
          kind: 'blood',
        });
        list[i] = list[list.length - 1];
        list.pop();
        continue;
      }
      // bounce
      const hitY = world.solidAt(ox, p.y + off, true);
      if (hitY && !(hitY.oneWay && oy + off > hitY.y + 0.5)) {
        p.y = oy;
        if (Math.abs(p.vy) > 60) {
          p.bounced++;
          if (p.kind === 'shell' && p.bounced <= 2 && this.onShell) this.onShell();
          if (p.kind === 'gun' && p.bounced <= 1 && this.onGunDrop) this.onGunDrop();
        }
        p.vy = -p.vy * p.bounce;
        p.vx *= 0.65;
        p.vr *= 0.6;
        if (Math.abs(p.vy) < 30) {
          p.vy = 0;
          if (
            p.kind === 'shell' ||
            p.kind === 'gun' ||
            p.kind === 'glass' ||
            p.kind === 'debris' ||
            p.kind === 'plank' ||
            p.kind === 'hat'
          ) {
            // settle flat
            p.vr *= 0.5;
            if (Math.abs(p.vx) < 15) {
              p.vx = 0;
              p.vr = 0;
              p.rot = Math.round(p.rot / Math.PI) * Math.PI;
            }
          }
        }
      } else {
        p.x = ox;
        p.vx = -p.vx * p.bounce;
      }
    }
  }

  drawDecals(ctx: CanvasRenderingContext2D, vx0: number, vy0: number, vx1: number, vy1: number) {
    for (const d of this.decals) {
      if (d.x < vx0 - 60 || d.x > vx1 + 60 || d.y < vy0 - 60 || d.y > vy1 + 60) continue;
      if (d.kind === 'blood') {
        ctx.fillStyle = d.color;
        ctx.beginPath();
        ctx.ellipse(d.x, d.y, d.w, d.h, d.rot, 0, TAU);
        ctx.fill();
      } else if (d.kind === 'hole') {
        ctx.fillStyle = 'rgba(0,0,0,0.25)';
        ctx.beginPath();
        ctx.arc(d.x, d.y, d.w + 1.6, 0, TAU);
        ctx.fill();
        ctx.fillStyle = '#141210';
        ctx.beginPath();
        ctx.arc(d.x, d.y, d.w, 0, TAU);
        ctx.fill();
      } else if (d.kind === 'crack') {
        // ground cracked by a heavy landing
        let sd = Math.floor(d.rot) % 2147483646 || 7;
        const rnd = () => {
          sd = (sd * 16807) % 2147483647;
          return sd / 2147483647;
        };
        ctx.strokeStyle = 'rgba(18,14,10,0.8)';
        ctx.lineCap = 'round';
        for (let i = 0; i < 7; i++) {
          let x = d.x + (rnd() - 0.5) * 6;
          let y = d.y + 1;
          let ang = 0.15 * Math.PI + (i / 6) * 0.7 * Math.PI + (rnd() - 0.5) * 0.3;
          ctx.lineWidth = 2.6 - i * 0.12;
          ctx.beginPath();
          ctx.moveTo(x, y);
          const segs = 3 + Math.floor(rnd() * 2);
          for (let k = 0; k < segs; k++) {
            ang += (rnd() - 0.5) * 0.9;
            const len = (d.w / segs) * (0.5 + rnd() * 0.8);
            x += Math.cos(ang) * len;
            y += Math.max(0.5, Math.sin(ang)) * len * 0.75;
            ctx.lineTo(x, y);
          }
          ctx.stroke();
        }
      } else {
        const g = ctx.createRadialGradient(d.x, d.y, 0, d.x, d.y, d.w);
        g.addColorStop(0, 'rgba(10,8,6,0.75)');
        g.addColorStop(0.6, 'rgba(20,14,10,0.4)');
        g.addColorStop(1, 'rgba(20,14,10,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(d.x, d.y, d.w, d.h, 0, 0, TAU);
        ctx.fill();
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D, vx0: number, vy0: number, vx1: number, vy1: number) {
    // normal blend
    for (const p of this.list) {
      if (p.x < vx0 - 80 || p.x > vx1 + 80 || p.y < vy0 - 80 || p.y > vy1 + 80) continue;
      const a = Math.min(1, p.life / Math.min(0.5, p.max));
      switch (p.kind) {
        case 'blood':
          ctx.fillStyle = p.color;
          ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
          break;
        case 'mist': {
          const t = 1 - p.life / p.max;
          ctx.globalAlpha = (1 - t) * 0.45;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (0.6 + t * 1.2), 0, TAU);
          ctx.fill();
          ctx.globalAlpha = 1;
          break;
        }
        case 'smoke': {
          const t = 1 - p.life / p.max;
          ctx.globalAlpha = (1 - t) * 0.5;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (0.5 + t * 1.6), 0, TAU);
          ctx.fill();
          ctx.globalAlpha = 1;
          break;
        }
        case 'dust': {
          const t = 1 - p.life / p.max;
          ctx.globalAlpha = (1 - t) * 0.45;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (0.5 + t), 0, TAU);
          ctx.fill();
          ctx.globalAlpha = 1;
          break;
        }
        case 'debris':
        case 'shell':
          ctx.globalAlpha = a;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
          if (p.kind === 'shell') {
            ctx.fillStyle = 'rgba(255,255,255,0.45)';
            ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h * 0.35);
          }
          ctx.restore();
          ctx.globalAlpha = 1;
          break;
        case 'glass':
          ctx.globalAlpha = a;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.moveTo(-p.size / 2, -p.size / 3);
          ctx.lineTo(p.size / 2, 0);
          ctx.lineTo(-p.size / 4, p.size / 2);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = 'rgba(255,255,255,0.9)';
          ctx.lineWidth = 0.8;
          ctx.stroke();
          ctx.restore();
          ctx.globalAlpha = 1;
          break;
        case 'gun':
          drawGun(ctx, p.gun, p.x, p.y, p.rot, 0);
          break;
        case 'plank':
          ctx.globalAlpha = a;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          ctx.strokeStyle = '#1b1410';
          ctx.lineWidth = 1.6;
          ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
          ctx.strokeRect(-p.w / 2, -p.h / 2, p.w, p.h);
          ctx.fillStyle = 'rgba(0,0,0,0.25)';
          ctx.fillRect(-p.w / 2 + 3, -1, p.w - 6, 2);
          ctx.restore();
          ctx.globalAlpha = 1;
          break;
        case 'hat':
          ctx.globalAlpha = a;
          drawHatShape(ctx, p.x, p.y, p.rot, p.size, p.color, p.band);
          ctx.globalAlpha = 1;
          break;
        case 'puff': {
          const t = 1 - p.life / p.max;
          ctx.globalAlpha = (1 - t) * 0.55;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (0.6 + t * 1.5), 0, TAU);
          ctx.fill();
          ctx.globalAlpha = 1;
          break;
        }
        case 'shock': {
          const t = 1 - p.life / p.max;
          ctx.globalAlpha = (1 - t) * 0.85;
          ctx.strokeStyle = p.color;
          ctx.lineWidth = 6 * (1 - t) + 1;
          ctx.beginPath();
          ctx.ellipse(p.x, p.y - 3, p.size * (0.12 + 0.88 * t), p.size * 0.12 * (0.5 + 0.5 * t), 0, 0, TAU);
          ctx.stroke();
          ctx.globalAlpha = 1;
          break;
        }
        default:
          break;
      }
    }
    // additive
    ctx.globalCompositeOperation = 'lighter';
    for (const p of this.list) {
      if (
        p.kind !== 'spark' &&
        p.kind !== 'fire' &&
        p.kind !== 'flash' &&
        p.kind !== 'ring' &&
        p.kind !== 'impact' &&
        p.kind !== 'wake' &&
        p.kind !== 'beam' &&
        p.kind !== 'slash'
      ) {
        continue;
      }
      if (p.kind !== 'beam' && (p.x < vx0 - 300 || p.x > vx1 + 300 || p.y < vy0 - 300 || p.y > vy1 + 300)) continue;
      const t = 1 - p.life / p.max;
      if (p.kind === 'spark') {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = p.size;
        ctx.globalAlpha = 1 - t * 0.5;
        ctx.beginPath();
        ctx.moveTo(p.x - p.vx * 0.025, p.y - p.vy * 0.025);
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
      } else if (p.kind === 'fire') {
        ctx.globalAlpha = (1 - t) * 0.85;
        ctx.fillStyle = t < 0.4 ? '#fff1a8' : p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1 - t * 0.6), 0, TAU);
        ctx.fill();
      } else if (p.kind === 'flash') {
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
        g.addColorStop(0, `rgba(255,240,200,${0.9 * (1 - t)})`);
        g.addColorStop(0.35, `rgba(255,170,60,${0.5 * (1 - t)})`);
        g.addColorStop(1, 'rgba(255,120,20,0)');
        ctx.globalAlpha = 1;
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, TAU);
        ctx.fill();
      } else if (p.kind === 'impact') {
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
        g.addColorStop(0, `rgba(255,255,240,${1 - t})`);
        g.addColorStop(0.45, `rgba(255,225,150,${0.6 * (1 - t)})`);
        g.addColorStop(1, 'rgba(255,200,120,0)');
        ctx.globalAlpha = 1;
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, TAU);
        ctx.fill();
      } else if (p.kind === 'slash') {
        // anime slash mark: a lens of light cut across the target
        const len = p.size * (0.55 + 0.45 * Math.min(1, t * 4));
        const wid = p.w * (1 - t * 0.85);
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.globalAlpha = 1 - t * 0.7;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.moveTo(-len / 2, 0);
        ctx.quadraticCurveTo(0, -wid * 2.2, len / 2, 0);
        ctx.quadraticCurveTo(0, wid * 2.2, -len / 2, 0);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.moveTo(-len / 2, 0);
        ctx.quadraticCurveTo(0, -wid, len / 2, 0);
        ctx.quadraticCurveTo(0, wid, -len / 2, 0);
        ctx.fill();
        ctx.restore();
      } else if (p.kind === 'beam') {
        // lingering sniper trail: (x,y) -> (w,h)
        const k = 1 - t;
        ctx.globalAlpha = 1;
        ctx.lineCap = 'round';
        ctx.strokeStyle = `rgba(255,190,90,${0.28 * k})`;
        ctx.lineWidth = 9 * k + 2 + t * 6;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.w, p.h);
        ctx.stroke();
        ctx.strokeStyle = `rgba(255,255,235,${0.9 * k * k})`;
        ctx.lineWidth = 2.2 * k + 0.6;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.w, p.h);
        ctx.stroke();
      } else if (p.kind === 'wake') {
        ctx.globalAlpha = (1 - t) * 0.55;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.ellipse(p.x, p.y, p.size * (0.25 + t) * 0.45, p.size * (0.25 + t), p.rot, 0, TAU);
        ctx.stroke();
      } else if (p.kind === 'ring') {
        ctx.globalAlpha = (1 - t) * 0.7;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 6 * (1 - t) + 1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (0.2 + t), 0, TAU);
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
  }

  clear() {
    this.list.length = 0;
  }
}
