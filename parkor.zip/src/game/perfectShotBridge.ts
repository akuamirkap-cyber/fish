/**
 * Bridge lengkap ke seluruh Engine Visual FX & Audio ASLI dari Perfect Shot:
 * - SetSevenFx + FIRE_RECIPES (golden, blackhole, slingshot, blowgun, shotgun, soaker)
 * - Signature Slide FX (firework8fx, yoyoSlideFx, kerisSlideFx, diamondSlideFx, bazookaSlideFx, sharkWaterFx)
 * - SetNineFx (longbow, mp5, tesla_rifle, identity_disc, proton_pack)
 * - SetElevenFx (mega_buster, harmonic_disruptor, absolute_zero, helios_flare, orbital_beacon, singularity, nano_swarm, ion_smg)
 * - AcidFluid metaballs (xeno)
 * - Game.ts Muzzle + Mach Trail + MaterialTrail + Afterimages + Beams + spawnImpact + explodeAt (fireball/flame) + spawnHitPolish
 */
import {
  sfx,
  withSfxGain,
  setMuted as setPsMuted,
  setMasterVolume as setPsVolume,
} from '../halo/gunhit/game/audio';
import { sfx2 } from '../halo/gunhit/game/sfx2';
import { sfx3 } from '../halo/gunhit/game/sfx3';
import { sfx4 } from '../halo/gunhit/game/sfx4';
import { sfx5 } from '../halo/gunhit/game/sfx5';
import { sfx6 } from '../halo/gunhit/game/sfx6';
import { slide23Sfx } from '../halo/gunhit/game/slide23Sfx';
import { fireworkSfx } from '../halo/gunhit/game/fireworkSlide2Sfx';
import { audio as nineAudio } from '../halo/gunhit/vendor/game-6/src/game/core';
import { SoundEngine as ElevenSoundEngine } from '../halo/gunhit/vendor/game-8/src/game/sound';
import {
  FX,
  cssColor,
  drawDropParticles,
  drawFxParticle,
  drawSmokeParticle,
  spawnImpact,
  spawnMuzzle,
  spawnSpeedLines,
  type FxProfile,
  type FxSink,
  type Particle,
} from '../halo/gunhit/game/fx';
import { SetSevenFx } from '../halo/gunhit/game/setSevenFx';
import { FIRE_RECIPES } from '../halo/gunhit/game/setSevenFire';
import { slideThreeIdFor } from '../halo/gunhit/game/setSevenArt';
import { setOneIdFor } from '../halo/gunhit/game/setOneArt';
import type { Projectile as SevenProj } from '../halo/gunhit/vendor/game-4/src/game/projectiles';
import { sfx as sevenAudioSfx } from '../halo/gunhit/vendor/game-4/src/game/audio';
import {
  createFirework8State,
  drawFirework8ParticlesAndRings,
  drawFirework8Projectile,
  firework8ShotHue,
  spawnFirework8FlightSparks,
  spawnFirework8Muzzle,
  spawnFirework8StickBurst,
  updateFirework8State,
  type Firework8State,
} from '../halo/gunhit/game/firework8fx';
import {
  createYoyoSlideState,
  drawSlide6String,
  drawSlide6Yoyo,
  drawYoyoSlideParticlesRingsAndStrings,
  spawnYoyoFlightSparks,
  spawnYoyoLaunch,
  spawnYoyoStickBurst,
  updateYoyoSlideState,
  yoyoAmmoHue,
  type YoyoSlideState,
} from '../halo/gunhit/game/yoyoSlideFx';
import {
  createKerisSlideState,
  drawKerisSlideParticlesAndArcs,
  spawnKerisFlightSparks,
  spawnKerisImpact,
  spawnKerisLaunch,
  updateKerisSlideState,
  type KerisSlideState,
} from '../halo/gunhit/game/kerisSlideFx';
import {
  createDiamondSlideState,
  drawDiamondSlideForeground,
  drawSlide2DiamondBullet,
  spawnDiamondFlightSparks,
  spawnDiamondLaunch,
  spawnDiamondStickBurst,
  updateDiamondSlideState,
  type DiamondSlideState,
} from '../halo/gunhit/game/diamondSlideFx';
import { BazookaSlideFx, BAZOOKA_HUES } from '../halo/gunhit/game/bazookaSlideFx';
import {
  spawnSharkWaterImpact,
  spawnSharkWaterLaunch,
  spawnSharkWaterTrail,
} from '../halo/gunhit/game/sharkWaterFx';
import { drawXenoHybridFlight } from '../halo/gunhit/game/art/xenoHybrid';
import { drawClassicBeam, drawLaserBeam } from '../halo/gunhit/game/art/beamEffects';
import { drawHolyLightLance } from '../halo/gunhit/game/art/holyLight';
import { SetNineFx, setNineMuted, unlockNineAudio } from '../halo/gunhit/game/setNineFx';
import { setNineIdFor, type NineId } from '../halo/gunhit/game/setNineArt';
import type { Bullet as NineBullet } from '../halo/gunhit/vendor/game-6/src/game/types';
import { SetElevenFx, setElevenMuted } from '../halo/gunhit/game/setElevenFx';
import { setElevenIdFor, type ElevenId } from '../halo/gunhit/game/setElevenArt';
import type { Proj as ElevenProj } from '../halo/gunhit/vendor/game-8/src/game/types';
import type { Weapon } from '../halo/gunhit/game/weapons';

const TAU = Math.PI * 2;
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T,>(arr: readonly T[]): T => arr[Math.floor(Math.random() * arr.length)];
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

export const PAINT_COLORS = ['#f43f5e', '#facc15', '#22d3ee', '#a855f7', '#4ade80', '#fb923c'] as const;
export const PAINT_RGBS = ['244,63,94', '250,204,21', '34,211,238', '168,85,247', '74,222,128', '251,146,60'] as const;

export const NINE_EXCLUSIVE_IDS = new Set<string>(['longbow', 'mp5', 'tesla_rifle', 'identity_disc', 'proton_pack']);
export const ELEVEN_EXCLUSIVE_IDS = new Set<string>([
  'mega_buster', 'harmonic_disruptor', 'absolute_zero', 'helios_flare', 'orbital_beacon', 'singularity', 'nano_swarm', 'ion_smg',
]);

// ------------------------------------------------------------------ Audio
let elevenSfx: ElevenSoundEngine | null = null;
let lastMuted = false;

function getElevenSfx(): ElevenSoundEngine | null {
  if (typeof window === 'undefined') return null;
  if (!elevenSfx) {
    try {
      elevenSfx = new ElevenSoundEngine();
      elevenSfx.musicOn = false;
      elevenSfx.muted = lastMuted;
    } catch {
      return null;
    }
  }
  return elevenSfx;
}

export function syncPerfectShotMute(muted: boolean) {
  lastMuted = muted;
  setPsMuted(muted);
  setPsVolume(1);
  setNineMuted(muted);
  setElevenMuted(muted);
  try {
    sevenAudioSfx.muted = muted;
  } catch { /* ignore */ }
  try {
    nineAudio.muted = muted;
    if (nineAudio.master) nineAudio.master.gain.value = muted ? 0 : 0.92;
  } catch { /* ignore */ }
  if (elevenSfx) {
    try {
      elevenSfx.muted = muted;
      if (muted) elevenSfx.stopAll();
      if (elevenSfx.master) elevenSfx.master.gain.value = muted ? 0 : 0.94;
    } catch { /* ignore */ }
  }
}

export function unlockPerfectShotAudio() {
  try { sfx.unlock(); } catch { /* ignore */ }
  try { sevenAudioSfx.ensure(); } catch { /* ignore */ }
  try { slide23Sfx.unlock(); } catch { /* ignore */ }
  try { fireworkSfx.unlock(); } catch { /* ignore */ }
  try { unlockNineAudio(); } catch { /* ignore */ }
  try { getElevenSfx()?.ensure(); } catch { /* ignore */ }
}

const ELEVEN_ID_MAP: Record<string, string> = {
  mega_buster: 'mega-buster',
  harmonic_disruptor: 'harmonic',
  absolute_zero: 'absolute-zero',
  helios_flare: 'helios',
  orbital_beacon: 'orbital-beacon',
  singularity: 'singularity',
  nano_swarm: 'nano-swarm',
  ion_smg: 'mp5-electro',
};

let angklungNoteIdx = 0;

const FIRE_SFX: Record<string, () => void> = {
  pistol: sfx.shoot,
  ak47: sfx.shootAk,
  plasma: sfx.shootPlasma,
  laser: sfx.shootLaser,
  cricket: sfx.shootCricket,
  electro: sfx.shootElectro,
  nail: sfx.shootNail,
  fish: sfx.shootFish,
  crossbow: sfx.shootCrossbow,
  bazooka: () => slide23Sfx.shoot('bazooka'),
  rpg: () => slide23Sfx.shoot('rpg', 1.6),
  freeze: sfx.shootFreeze,
  golden: sfx.shootGolden,
  blackhole: () => slide23Sfx.shoot('blackhole', 2.2),
  shotgun: sfx2.shotgun,
  sniper: sfx2.sniper,
  minigun: sfx2.minigun,
  railgun: sfx2.railgun,
  flamethrower: sfx2.flame,
  slingshot: sfx2.slingshot,
  blowgun: sfx2.blowgun,
  bamboo: () => slide23Sfx.shoot('bamboo', 1.8),
  banana: sfx2.banana,
  magnet: sfx2.magnet,
  bubble: sfx2.bubble,
  harpoon: sfx2.harpoon,
  soaker: () => slide23Sfx.shoot('soaker', 3.2),
  snowball: sfx2.snowball,
  pirate: sfx2.pirate,
  chicken: sfx2.chicken,
  card: sfx2.card,
  confetti: sfx2.confetti,
  seed: sfx2.seed,
  dragon: sfx2.dragon,
  gravity: sfx2.gravity,
  pizza: sfx2.pizza,
  honey: sfx3.honey,
  coconut: sfx3.coconut,
  angklung: sfx3.angklung,
  bee: sfx3.bee,
  yoyo: () => slide23Sfx.shoot('yoyo', 4),
  sakura: sfx3.sakura,
  keris: () => slide23Sfx.shoot('keris', 3.4),
  firework: () => fireworkSfx.shoot(),
  shark: () => slide23Sfx.shoot('shark', 3.4),
  ghost: sfx3.ghost,
  ufo: sfx3.ufo,
  meteor: sfx3.meteor,
  diamond: () => slide23Sfx.shoot('diamond', 1.8),
  moonbeam: sfx3.moonbeam,
  storm: sfx3.storm,
  obliterator: sfx4.obliterator,
  paintball: sfx4.paintball,
  holy: sfx4.holy,
  beerifle: sfx4.beeRifle,
  emerald: sfx4.emerald,
  ruby: sfx4.ruby,
  sapphire: sfx4.sapphire,
  crystal: () => slide23Sfx.shoot('crystal', 4),
  pencil: sfx4.pencil,
  sandal: sfx4.sandal,
  coingun: sfx5.coinGun,
  blaster: sfx5.blaster,
  photon_saber: sfx6.saberShoot,
  gauntlet_cannon: sfx6.gauntlet,
  cryo_blaster: sfx6.cryo,
  hyperdrive: sfx6.hyper,
  xeno: sfx6.xeno,
  dora: sfx6.dora,
};

const FIRE_GAIN: Record<string, number> = {
  emerald: 5.6,
  ufo: 3.75,
  holy: 3.75,
  chicken: 3,
  sakura: 3,
  ghost: 3,
  moonbeam: 2.8,
  magnet: 2.5,
  seed: 2.25,
  bee: 2.25,
  laser: 1.6,
};

const HIT_SFX: Record<string, () => void> = {
  coingun: sfx.coin,
  blaster: sfx5.blasterHit,
  photon_saber: sfx6.saberHit,
  gauntlet_cannon: sfx6.gauntletHit,
  cryo_blaster: sfx6.cryoHit,
  hyperdrive: sfx6.hyperHit,
  chicken: sfx2.squeak,
  bubble: sfx2.pop,
  card: sfx2.card,
  snowball: sfx2.thud,
  soaker: sfx2.splat,
  pizza: sfx2.splat,
  banana: sfx2.splat,
  seed: sfx2.seed,
  slingshot: sfx2.thud,
  pirate: sfx2.crash,
  magnet: sfx2.metal,
  gravity: sfx2.gravity,
  railgun: sfx.zap,
  honey: sfx2.splat,
  coconut: sfx3.coconutHit,
  bee: sfx3.sting,
  yoyo: sfx3.bloop,
  sakura: sfx3.chime,
  angklung: () => { sfx3.note(angklungNoteIdx); angklungNoteIdx = (angklungNoteIdx + 1) % 10; },
  keris: sfx3.kerisStick,
  shark: sfx3.chomp,
  ghost: sfx3.wail,
  ufo: sfx.zap,
  diamond: sfx3.chime,
  moonbeam: sfx3.chime,
  storm: sfx3.thunder,
  obliterator: sfx4.obliteratorHit,
  paintball: sfx4.paintSplat,
  holy: sfx4.purify,
  emerald: sfx3.chime,
  ruby: sfx2.metal,
  sapphire: sfx.ice,
  crystal: sfx4.shatter,
  pencil: sfx4.scribble,
  sandal: sfx4.plak,
  freeze: sfx.ice,
  fish: sfx.splash,
  blackhole: sfx.suck,
  firework: sfx3.fireworkBoom,
  bamboo: sfx.explosion,
  rpg: sfx.explosion,
  bazooka: sfx.explosion,
  meteor: sfx.explosion,
  xeno: sfx6.xenoHit,
  dora: sfx6.dora,
  beerifle: sfx3.sting,
  confetti: sfx2.confetti,
};

const SLIDE23_IDS = new Set([
  'bazooka', 'rpg', 'blackhole', 'bamboo', 'soaker', 'yoyo', 'keris', 'firework', 'shark', 'diamond', 'crystal',
]);

export function playPerfectShotFire(artId: string, muted = false) {
  if (muted) return;
  syncPerfectShotMute(false);

  try {
    // SET 1 weapons play their own sevenSfx inside FIRE_RECIPES — only fire fallback if not handled there
    if (setOneIdFor(artId)) {
      sevenAudioSfx.ensure();
      return;
    }
    if (artId in ELEVEN_ID_MAP) {
      const e = getElevenSfx();
      if (e) {
        e.ensure();
        e.playFire(ELEVEN_ID_MAP[artId]);
        return;
      }
    }
    // Slide 9 fires its own weapon recipe inside SetNineFx.fire().
    if (NINE_EXCLUSIVE_IDS.has(artId)) return;
    const fn = FIRE_SFX[artId];
    if (fn) {
      sfx.unlock();
      const k = FIRE_GAIN[artId] ?? 1;
      if (k === 1) fn();
      else withSfxGain(k, fn);
      return;
    }
    sfx.unlock();
    sfx.shoot();
  } catch {
    /* ignore audio errors */
  }
}

export function playPerfectShotHit(artId: string, isEnemy: boolean, muted = false, hitIdx = 0, nativeRound = true) {
  if (muted) return;
  syncPerfectShotMute(false);

  try {
    // The imported 7/9/11 layers already voice their own impacts. Do not
    // stack a generic hit and a second synthesized copy over that sound.
    if (setOneIdFor(artId)) {
      // Slide 1 layers the Slide 2/3 impact accent over the Slide 7 round.
      if (SLIDE23_IDS.has(artId)) slide23Sfx.hit(artId as never, hitIdx);
      return;
    }
    if (NINE_EXCLUSIVE_IDS.has(artId)) return;
    if (ELEVEN_EXCLUSIVE_IDS.has(artId)) {
      if (!nativeRound) getElevenSfx()?.impact(ELEVEN_ID_MAP[artId]);
      return;
    }
    if (SLIDE23_IDS.has(artId)) {
      slide23Sfx.unlock();
      if (artId === 'yoyo') slide23Sfx.hit('yoyo-spin', 0);
      else if (artId === 'firework') fireworkSfx.hit(hitIdx);
      else slide23Sfx.hit(artId as never, hitIdx);
      return;
    }
    const hitFn = HIT_SFX[artId];
    if (hitFn) {
      sfx.unlock();
      hitFn();
    }
    if (isEnemy || !hitFn) {
      sfx.unlock();
      sfx.hit();
    }
  } catch {
    /* ignore */
  }
}

// ------------------------------------------------------------------ Helpers
interface LightFx {
  x: number;
  y: number;
  r: number;
  rgb: string;
  life: number;
  max: number;
}

interface ExtraFx {
  k: 'beam' | 'psLaser' | 'psHoly' | 'psBeam' | 'bolt' | 'pillar' | 'ring' | 'glow' | 'text' | 'shard' | 'bubble' | 'paper' | 'smoke';
  x: number;
  y: number;
  x2: number;
  y2: number;
  vx: number;
  vy: number;
  g: number;
  drag: number;
  size: number;
  w: number;
  rot: number;
  vr: number;
  grow: number;
  rgb: string;
  life: number;
  max: number;
  text?: string;
  seed: number;
}

const DEFAULT_FX_PROF: FxProfile = {
  impact: 'bullet',
  decal: 'hole',
  muzzle: 'fire',
  light: '255,200,120',
  lightR: 90,
  hitstop: 0.02,
  kick: 3,
  ghost: 0,
  streak: 1,
  speedLines: false,
  tint: 0,
};

export function fxProfileOf(artId: string): FxProfile {
  return (FX as Record<string, FxProfile>)[artId] ?? DEFAULT_FX_PROF;
}

const CUSTOM_PARTICLE_KINDS = new Set([
  'slap', 'pencilShaving', 'paintSplat', 'prism', 'feather', 'star',
  'snowflake', 'snowDust', 'snowChunk', 'shard', 'spirit', 'shock',
  'petal', 'bananaSplash', 'bananaDrop', 'honeySplash', 'honeyDrop',
  'waterSplash', 'waterDrop', 'streak', 'fireball', 'flame', 'ringE',
  'puff', 'wind', 'ash', 'speed', 'bubble',
]);

/** Putar item partikel/FX yang dibuat tegak di sekitar (0,0) sejauh `rot` lalu geser ke (ox,oy). */
function transformUprightItems(arr: unknown[], startIdx: number, ox: number, oy: number, rot: number) {
  const cos = Math.cos(rot);
  const sin = Math.sin(rot);
  const mapPt = (px: number, py: number): [number, number] => [
    ox + px * cos - py * sin,
    oy + px * sin + py * cos,
  ];
  for (let i = startIdx; i < arr.length; i++) {
    const it = arr[i] as Record<string, unknown> | null;
    if (!it || typeof it !== 'object') continue;
    // SetSeven Lightning: pts[][], x1/y1/x2/y2
    if (Array.isArray(it.pts) && typeof it.x1 === 'number' && typeof it.y1 === 'number') {
      [it.x1, it.y1] = mapPt(it.x1, it.y1);
      if (typeof it.x2 === 'number' && typeof it.y2 === 'number') [it.x2, it.y2] = mapPt(it.x2, it.y2);
      for (const br of it.pts as unknown[]) {
        if (!Array.isArray(br)) continue;
        for (let k = 0; k + 1 < br.length; k += 2) {
          if (typeof br[k] === 'number' && typeof br[k + 1] === 'number') {
            [br[k], br[k + 1]] = mapPt(br[k] as number, br[k + 1] as number);
          }
        }
      }
      continue;
    }
    // SetSeven Streak: x, y1, y2, ang
    if (typeof it.x === 'number' && typeof it.y1 === 'number' && typeof it.y2 === 'number' && typeof it.ang === 'number') {
      [it.x, it.y1] = mapPt(it.x, it.y1);
      it.ang += rot;
      continue;
    }
    if (typeof it.x === 'number' && typeof it.y === 'number') {
      [it.x, it.y] = mapPt(it.x, it.y);
    }
    if (typeof it.tx === 'number' && typeof it.ty === 'number') {
      [it.tx, it.ty] = mapPt(it.tx, it.ty);
    }
    if (typeof it.vx === 'number' && typeof it.vy === 'number') {
      const vx = it.vx;
      const vy = it.vy;
      it.vx = vx * cos - vy * sin;
      it.vy = vx * sin + vy * cos;
    }
    if (typeof it.ang === 'number') it.ang += rot;
    if (typeof it.rot === 'number') it.rot += rot;
    if (it.kind === 'flame' && typeof it.extra === 'number') it.extra += rot;
  }
}

export interface LiveShotHandle {
  s7?: SevenProj;
  s9?: NineBullet;
  s11?: ElevenProj;
  hue?: number;
  tintRgb?: string;
  paintCss?: string;
}

export class PerfectShotFx {
  particles: Particle[] = [];
  lights: LightFx[] = [];
  extras: ExtraFx[] = [];
  time = 0;

  // Sub-engines asli dari Perfect Shot
  s7: SetSevenFx;
  s9: SetNineFx;
  s11: SetElevenFx;
  fwState: Firework8State;
  yoyoState: YoyoSlideState;
  kerisState: KerisSlideState;
  diamondState: DiamondSlideState;
  bazookaState: BazookaSlideFx;

  shotIdx = 0;
  hitIdx = 0;
  private screenShakeCb?: (a: number) => void;
  private s7ActiveMuzzle = { x: 0, y: 0, rot: 0 };

  constructor() {
    this.s7 = new SetSevenFx({
      shake: (a) => this.screenShakeCb?.(a),
      paintWheel: () => {},
      wheel: () => ({ x: 0, y: 0, R: 95, angle: 0 }),
    });
    this.s7.special = true;

    this.s9 = new SetNineFx({
      shake: (a) => this.screenShakeCb?.(a * 0.45),
      flash: () => {},
      hitStop: () => {},
      wheel: () => ({ x: 0, y: 0, R: 95, angle: 0 }),
    });
    this.s9.W = 4000;
    this.s9.H = 4000;

    this.s11 = new SetElevenFx({
      shake: (a) => this.screenShakeCb?.(a * 0.45),
      flash: () => {},
      hitStop: () => {},
      wheel: () => ({ x: 0, y: 0, R: 95, angle: 0, marks: false }),
    });

    this.fwState = createFirework8State(1280, 760);
    this.yoyoState = createYoyoSlideState(1280, 760);
    this.kerisState = createKerisSlideState(1280, 760);
    this.diamondState = createDiamondSlideState(1280, 760);
    this.bazookaState = new BazookaSlideFx();
  }

  setShakeCallback(cb: (a: number) => void) {
    this.screenShakeCb = cb;
  }

  sink: FxSink = {
    push: (p: Particle) => {
      if (this.particles.length > 1000) this.particles.splice(0, 140);
      this.particles.push(p);
    },
    light: (x: number, y: number, r: number, rgb: string, life: number) => {
      if (this.lights.length > 72) this.lights.shift();
      this.lights.push({ x, y, r, rgb, life, max: life });
    },
  };

  clear() {
    this.particles.length = 0;
    this.lights.length = 0;
    this.extras.length = 0;
    this.s7.clear();
    this.s9.clear();
    this.s11.clear();
    this.fwState = createFirework8State(1280, 760);
    this.yoyoState = createYoyoSlideState(1280, 760);
    this.kerisState = createKerisSlideState(1280, 760);
    this.diamondState = createDiamondSlideState(1280, 760);
    this.bazookaState.reset();
  }

  addExtra(p: Partial<ExtraFx> & { k: ExtraFx['k']; x: number; y: number }): ExtraFx {
    const life = p.life ?? 0.3;
    const f: ExtraFx = {
      x2: 0, y2: 0, vx: 0, vy: 0, g: 0, drag: 0, size: 6, w: 2, rot: 0, vr: 0, grow: 0,
      rgb: '255,255,255', seed: Math.random() * 1000,
      ...p,
      life,
      max: life,
    };
    if (this.extras.length > 650) this.extras.splice(0, 90);
    this.extras.push(f);
    return f;
  }

  glow(x: number, y: number, rgb: string, size: number, life: number, vx = 0, vy = 0, g = 0, drag = 0, grow = 0) {
    return this.addExtra({ k: 'glow', x, y, rgb, size, life, vx, vy, g, drag, grow });
  }

  /** Perfect Shot's shared contact flash, kept crisp without a bloom halo. */
  hitPolish(x: number, y: number, nx: number, ny: number, rgb: string) {
    this.sink.push({ x, y, vx: 0, vy: 0, life: 0.12, max: 0.12, size: 12.5,
      color: '#ffffff', kind: 'star', rot: rnd(0, TAU), vr: 6, g: 0 });
    this.sink.push({ x, y, vx: 0, vy: 0, life: 0.16, max: 0.16, size: 30,
      color: '255,255,255', kind: 'shock', rot: 0, vr: 0, g: 0 });
    this.sink.push({ x, y, vx: 0, vy: 0, life: 0.28, max: 0.28, size: 50,
      color: rgb, kind: 'shock', rot: 0, vr: 0, g: 0 });
    const base = Math.atan2(ny, nx);
    for (let i = 0; i < 5; i++) {
      const a = base + ((i - 2) / 5) * 2.1 + rnd(-0.18, 0.18);
      const speed = rnd(240, 520);
      this.sink.push({ x, y, vx: Math.cos(a) * speed, vy: Math.sin(a) * speed,
        life: 0.19, max: 0.19, size: rnd(1.4, 2.3),
        color: i % 2 ? rgb : '#ffffff', kind: 'streak', rot: 0, vr: 0, g: 0, drag: 3.2 });
    }
  }

  ring(x: number, y: number, rgb: string, size: number, life: number, w = 3, implode = false) {
    return this.addExtra({ k: 'ring', x, y, rgb, size, life, w, grow: implode ? -1 : 0 });
  }

  beam(x1: number, y1: number, x2: number, y2: number, rgb: string, w: number, life: number) {
    return this.addExtra({ k: 'beam', x: x1, y: y1, x2, y2, rgb, w, life });
  }

  psBeam(kind: 'psLaser' | 'psHoly' | 'psBeam', x1: number, y1: number, x2: number, y2: number, rgb: string, life: number) {
    return this.addExtra({ k: kind, x: x1, y: y1, x2, y2, rgb, life });
  }

  bolt(x1: number, y1: number, x2: number, y2: number, rgb: string, w = 2, life = 0.16) {
    return this.addExtra({ k: 'bolt', x: x1, y: y1, x2, y2, rgb, w, life });
  }

  sparks(x: number, y: number, nx: number, ny: number, cols: string[], n: number, spd = 220, g = 520, size = 3.2) {
    for (let i = 0; i < n; i++) {
      const a = Math.atan2(ny, nx) + rnd(-1.1, 1.1);
      const v = rnd(0.3, 1) * spd;
      this.sink.push({
        x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
        life: rnd(0.14, 0.34), max: 0.34, size: rnd(0.8, 1.5) * size * 0.6,
        color: cols[(Math.random() * cols.length) | 0],
        kind: 'spark', rot: 0, vr: 0, g, drag: 2.0,
      });
    }
  }

  /**
   * Muzzle & persiapan peluru ASLI Perfect Shot untuk senjata apapun.
   * Mengembalikan handle proyektil (`s7` / `s9` / `s11` / `hue` / `tint`) agar
   * proyektil terbang, jejak, dan tumbukannya 100% identik dengan Perfect Shot.
   */
  fireWeapon(artId: string, def: Weapon, mx: number, my: number, ang: number, ammoRatio = 1): LiveShotHandle {
    const rot = ang + Math.PI / 2;
    const ca = Math.cos(ang);
    const sa = Math.sin(ang);
    const idx = this.shotIdx++;
    const handle: LiveShotHandle = {};

    if (artId === 'paintball') {
      const ci = idx % PAINT_COLORS.length;
      handle.paintCss = PAINT_COLORS[ci];
      handle.tintRgb = PAINT_RGBS[ci];
    }

    // 1. SET 1 (golden, blackhole, slingshot, blowgun, shotgun, soaker): SetSevenFx asli!
    if (setOneIdFor(artId)) {
      const s7id = slideThreeIdFor(artId);
      if (s7id) {
        this.s7.weaponId = s7id;
        this.s7.shotsFired++;
        this.s7.ammoTotal = 100;
        this.s7.ammoLeft = Math.max(0, Math.round(ammoRatio * 100));
        this.s7ActiveMuzzle = { x: mx, y: my, rot };
        const p0 = this.s7.particles.list.length;
        const f0 = this.s7.fx.length;
        try {
          FIRE_RECIPES[s7id](this.s7, 0, 0);
        } catch { /* ignore */ }
        transformUprightItems(this.s7.particles.list, p0, mx, my, rot);
        transformUprightItems(this.s7.fx, f0, mx, my, rot);
        const made = this.s7.takeShots();
        if (made.length > 0) {
          handle.s7 = made[0];
        } else {
          // blackhole / blowgun memicu tembakan lewat after() — majukan timer singkat atau buat instance langsung
          const tNow = this.s7.timers.length;
          if (tNow > 0) {
            for (const tm of this.s7.timers) tm.t = Math.min(tm.t, 0.01);
            const p1 = this.s7.particles.list.length;
            const f1 = this.s7.fx.length;
            this.s7.update(0.02, true);
            transformUprightItems(this.s7.particles.list, p1, mx, my, rot);
            transformUprightItems(this.s7.fx, f1, mx, my, rot);
            const delayed = this.s7.takeShots();
            if (delayed.length > 0) handle.s7 = delayed[0];
          }
        }
        return handle;
      }
    }

    // 2. Signature Slide Weapons: firework, yoyo, keris, diamond, bazooka, shark
    if (artId === 'firework') {
      const hue = firework8ShotHue(1, idx);
      handle.hue = hue;
      const p0 = this.fwState.particles.length;
      const g0 = this.fwState.glows.length;
      const r0 = this.fwState.rings.length;
      spawnFirework8Muzzle(this.fwState, 0, 0, hue);
      transformUprightItems(this.fwState.particles, p0, mx, my, rot);
      transformUprightItems(this.fwState.glows, g0, mx, my, rot);
      transformUprightItems(this.fwState.rings, r0, mx, my, rot);
      this.sink.light(mx, my, 80, '255,180,220', 0.25);
      return handle;
    }
    if (artId === 'yoyo') {
      const hue = yoyoAmmoHue(idx);
      handle.hue = hue;
      const p0 = this.yoyoState.particles.length;
      const r0 = this.yoyoState.rings.length;
      spawnYoyoLaunch(this.yoyoState, 0, 0, hue);
      transformUprightItems(this.yoyoState.particles, p0, mx, my, rot);
      transformUprightItems(this.yoyoState.rings, r0, mx, my, rot);
      this.sink.light(mx, my, 75, '255,160,220', 0.25);
      return handle;
    }
    if (artId === 'keris') {
      const p0 = this.kerisState.particles.length;
      spawnKerisLaunch(this.kerisState, 0, 0);
      transformUprightItems(this.kerisState.particles, p0, mx, my, rot);
      this.sink.light(mx, my, 75, '77,238,234', 0.25);
      return handle;
    }
    if (artId === 'diamond') {
      handle.hue = 205 + ((idx * 13) % 22);
      const p0 = this.diamondState.particles.length;
      const g0 = this.diamondState.glows.length;
      const r0 = this.diamondState.rings.length;
      const s0 = this.diamondState.starflashes.length;
      spawnDiamondLaunch(this.diamondState, 0, 0);
      transformUprightItems(this.diamondState.particles, p0, mx, my, rot);
      transformUprightItems(this.diamondState.glows, g0, mx, my, rot);
      transformUprightItems(this.diamondState.rings, r0, mx, my, rot);
      transformUprightItems(this.diamondState.starflashes, s0, mx, my, rot);
      this.sink.light(mx, my, 80, '165,243,252', 0.28);
      return handle;
    }
    if (artId === 'bazooka') {
      const hue = BAZOOKA_HUES[idx % BAZOOKA_HUES.length];
      handle.hue = hue;
      this.bazookaState.onShoot(mx, my, my + 220, rot);
      this.sink.light(mx, my, 120, '255,150,55', 0.35);
      return handle;
    }
    if (artId === 'shark') {
      const p0 = this.particles.length;
      const l0 = this.lights.length;
      spawnSharkWaterLaunch(this.sink, 0, 0, 0);
      transformUprightItems(this.particles, p0, mx, my, rot);
      transformUprightItems(this.lights, l0, mx, my, rot);
      return handle;
    }

    // 3. Slide-9 exclusive (longbow, mp5, tesla_rifle, identity_disc, proton_pack)
    if (NINE_EXCLUSIVE_IDS.has(artId)) {
      const nineId = setNineIdFor(artId) as NineId | null;
      if (nineId) {
        this.s9.selectWeapon(nineId);
        this.s9.time = this.time;
        this.s9.gunX = mx;
        this.s9.gunY = my;
        // One source of truth: the original weapon's fire() plays its own voice.
        this.s9.fire(mx, my, ang, artId === 'longbow' ? 1 : 0);
        const made = this.s9.takeShots();
        if (made[0]) handle.s9 = made[0];
        return handle;
      }
    }

    // 4. Slide-11 exclusive (mega_buster, harmonic_disruptor, absolute_zero, helios_flare, orbital_beacon, singularity, nano_swarm, ion_smg)
    if (ELEVEN_EXCLUSIVE_IDS.has(artId)) {
      const elevenId = setElevenIdFor(artId) as ElevenId | null;
      if (elevenId && this.s11.raw) {
        this.s11.selectWeapon(elevenId);
        const raw = this.s11.raw;
        const p0 = raw.parts.length;
        const f0 = raw.fx.length;
        const prevMuted = raw.sfx.muted;
        raw.sfx.muted = true;
        try {
          this.s11.fire(0, 0, artId === 'mega_buster' ? 1 : 0);
        } finally {
          raw.sfx.muted = prevMuted;
        }
        transformUprightItems(raw.parts, p0, mx, my, rot);
        transformUprightItems(raw.fx, f0, mx, my, rot);
        const made = this.s11.takeShots();
        if (made[0]) {
          handle.s11 = made[0];
          // Simpan arah tembak agar drawShot memutarnya ke arah terbang Parkour
          this.s11.carry(made[0], mx, my, ang);
        }
        return handle;
      }
    }

    // 5. Classic / Zip / Sci-Fi weapons: Game.ts fire() + spawnMuzzle() + spawnSpeedLines()
    const prof = fxProfileOf(artId);
    const p0 = this.particles.length;
    const l0 = this.lights.length;
    const activeProf = handle.tintRgb ? { ...prof, light: handle.tintRgb } : prof;

    spawnMuzzle(this.sink, activeProf, def, 0, -4);

    if (artId === 'xeno') {
      for (let i = 0; i < 16; i++) {
        const k = i / 16;
        this.sink.push({
          x: rnd(-3, 3), y: -4 - k * 12, vx: rnd(-25, 25), vy: -1200 * (0.45 + k * 0.5),
          life: rnd(0.45, 0.85), max: 0.85, size: rnd(2.2, 5.2) * (1 - k * 0.5) + 1.4,
          color: '#b6ff1a', kind: 'drop', rot: 0, vr: 0, g: 0, drag: 1.5,
        });
      }
      for (let i = 0; i < 10; i++) {
        this.sink.push({
          x: rnd(-6, 6), y: -4 - rnd(0, 4), vx: rnd(-120, 120), vy: rnd(-750, -260),
          life: rnd(0.3, 0.6), max: 0.6, size: rnd(1.5, 2.5),
          color: '#b6ff1a', kind: 'drop', rot: 0, vr: 0, g: 0, drag: 2.2,
        });
      }
      this.sink.light(0, -6, 85, '182,255,26', 0.22);
      this.sink.push({ x: 0, y: -6, vx: 0, vy: 0, life: 0.2, max: 0.2, size: 28, color: '182,255,26', kind: 'glow', rot: 0, vr: 0, g: 0 });
      this.sink.push({ x: 0, y: -6, vx: 0, vy: 0, life: 0.3, max: 0.3, size: 26, color: '182,255,26', kind: 'ring', rot: 0, vr: 0, g: 0 });
      for (let i = 0; i < 6; i++) {
        this.sink.push({
          x: rnd(-12, 12), y: -6, vx: rnd(-40, 40), vy: rnd(-90, -30),
          life: rnd(0.6, 1.1), max: 1.1, size: rnd(9, 18), color: 'rgba(155,209,58,', kind: 'smoke', rot: 0, vr: 0, g: 0, drag: 2,
        });
      }
    } else if (artId === 'dora') {
      this.sink.light(0, -6, 120, '255,255,255', 0.16);
      this.sink.push({ x: 0, y: -6, vx: 0, vy: 0, life: 0.3, max: 0.3, size: 80, color: '255,255,255', kind: 'ring', rot: 0, vr: 0, g: 0 });
      this.sink.push({ x: 0, y: -6, vx: 0, vy: 0, life: 0.3, max: 0.3, size: 18, color: '255,255,255', kind: 'ringE', rot: 0, vr: 0, g: 0 });
      for (let i = 0; i < 8; i++) {
        const a = rnd(0, TAU);
        const sp = rnd(90, 240);
        this.sink.push({
          x: Math.cos(a) * 12, y: Math.sin(a) * 6, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.5 - 30,
          life: rnd(0.45, 0.8), max: 0.8, size: rnd(10, 18), color: '#ffffff', kind: 'puff', rot: rnd(0, TAU), vr: randRange(-2, 2), g: 0, drag: 3.2,
        });
      }
      for (let i = 0; i < 10; i++) {
        const a = -Math.PI / 2 + rnd(-0.5, 0.5);
        this.sink.push({
          x: 0, y: -6, vx: Math.cos(a) * rnd(450, 820), vy: Math.sin(a) * rnd(450, 820),
          life: rnd(0.16, 0.28), max: 0.28, size: rnd(14, 28), color: '#ffffff', kind: 'wind', rot: 0, vr: 0, g: 0, drag: 1,
        });
      }
    } else if (artId === 'cricket') {
      this.sink.light(0, -4, 160, '56,189,248', 0.25);
      this.sink.push({ x: 0, y: -4, vx: 0, vy: 0, life: 0.3, max: 0.3, size: 95, color: '#38bdf8', kind: 'ring', rot: 0, vr: 0, g: 0 });
      for (let i = 0; i < 10; i++) {
        const a = rnd(0, TAU);
        const v = rnd(70, 220);
        this.sink.push({
          x: 0, y: -4, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
          life: rnd(0.25, 0.5), max: 0.5, size: rnd(3, 6), color: '56,189,248', kind: 'glow', rot: 0, vr: 0, g: 0,
        });
      }
    } else if (def.energy && artId !== 'laser') {
      this.sink.push({ x: 0, y: -4, vx: 0, vy: 0, life: 0.28, max: 0.28, size: 46, color: def.color, kind: 'ring', rot: 0, vr: 0, g: 0 });
      for (let i = 0; i < 8; i++) {
        const a = rnd(0, TAU);
        const v = rnd(50, 180);
        this.sink.push({
          x: 0, y: -4, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 40,
          life: rnd(0.22, 0.45), max: 0.45, size: rnd(3, 5.5), color: def.trail, kind: 'glow', rot: 0, vr: 0, g: 0,
        });
      }
    }

    if (!def.energy && !def.noSmoke) {
      const ns = def.backblast || artId === 'bamboo' || artId === 'pirate' ? 9 : 4;
      for (let i = 0; i < ns; i++) {
        this.sink.push({
          x: rnd(-5, 5), y: -6, vx: rnd(-45, 45), vy: rnd(-90, -30),
          life: 0.45, max: 0.45, size: rnd(5, def.backblast ? 15 : 10), color: 'rgba(200,200,200,', kind: 'smoke', rot: 0, vr: 0, g: 0,
        });
      }
    }

    transformUprightItems(this.particles, p0, mx, my, rot);
    transformUprightItems(this.lights, l0, mx, my, rot);

    if (activeProf.speedLines) {
      spawnSpeedLines(this.sink, mx + ca * 30, my + sa * 30, my, activeProf.light, ca * 1800, sa * 1800, activeProf.streak);
    }

    if (def.backblast) {
      for (let i = 0; i < 12; i++) {
        const ba = ang + Math.PI + rnd(-0.6, 0.6);
        const bv = rnd(110, 320);
        this.sink.push({
          x: mx - ca * 42 + rnd(-10, 10), y: my - sa * 42 + rnd(-10, 10),
          vx: Math.cos(ba) * bv, vy: Math.sin(ba) * bv,
          life: rnd(0.45, 0.9), max: 0.9, size: rnd(9, 20), color: 'rgba(180,180,180,', kind: 'smoke', rot: 0, vr: 0, g: -20,
        });
        this.sink.push({
          x: mx - ca * 42 + rnd(-8, 8), y: my - sa * 42 + rnd(-8, 8),
          vx: Math.cos(ba) * bv * 0.7, vy: Math.sin(ba) * bv * 0.7,
          life: rnd(0.18, 0.36), max: 0.36, size: rnd(5, 10), color: '255,150,40', kind: 'glow', rot: 0, vr: 0, g: 0,
        });
      }
    }

    if (def.burstFx) {
      const bf = def.burstFx;
      for (let i = 0; i < bf.n; i++) {
        const a = ang + rnd(-0.55, 0.55);
        const v = rnd(0.4, 1) * (bf.spd ?? 200);
        this.sink.push({
          x: mx + rnd(-4, 4), y: my + rnd(-4, 4), vx: Math.cos(a) * v, vy: Math.sin(a) * v,
          life: rnd(0.32, 0.7), max: 0.7, size: bf.glow ? rnd(3, bf.size ?? 6) : rnd(2, 4.5),
          color: pick(bf.colors),
          kind: artId === 'snowball' ? 'snowflake' : bf.glow ? 'glow' : 'chip',
          rot: rnd(0, TAU), vr: rnd(-10, 10), g: (bf.g ?? 600) * 0.4,
        });
      }
    }

    return handle;
  }

  /**
   * Jejak proyektil di udara per langkah lintasan (~12 px), 100% sesuai Perfect Shot.
   */
  emitFlightTrail(
    artId: string,
    def: Weapon,
    x: number,
    y: number,
    vx: number,
    vy: number,
    dt: number,
    handle?: LiveShotHandle,
  ) {
    const ang = Math.atan2(vy, vx) + Math.PI / 2;

    if (artId === 'soaker') {
      // WaterJet.update() in the reference sheds fine, gravity-driven drops.
      // The parkour engine owns the projectile motion, so emit them here.
      if (Math.random() < 0.55) {
        this.sink.push({
          x: x + rnd(-3, 3), y: y + rnd(-3, 3),
          vx: vx * rnd(0.5, 0.78) + rnd(-30, 30),
          vy: vy * rnd(0.5, 0.78) + rnd(-30, 30),
          life: 0.55, max: 0.55, size: rnd(1.1, 2.3),
          color: '#96d2ff', kind: 'drop', rot: 0, vr: 0, g: 750,
        });
      }
      return;
    }

    if (handle?.s7) {
      const p0 = this.s7.particles.list.length;
      const f0 = this.s7.fx.length;
      try {
        handle.s7.x = 0;
        handle.s7.y = 0;
        handle.s7.trail(dt);
      } catch { /* ignore */ }
      transformUprightItems(this.s7.particles.list, p0, x, y, ang);
      transformUprightItems(this.s7.fx, f0, x, y, ang);
      return;
    }
    if (handle?.s9) {
      this.s9.carry(handle.s9, x, y, Math.atan2(vy, vx));
      return;
    }
    if (handle?.s11) {
      this.s11.carry(handle.s11, x, y, Math.atan2(vy, vx));
      return;
    }

    if (artId === 'firework') {
      spawnFirework8FlightSparks(this.fwState, x, y, handle?.hue ?? 340, ang);
      return;
    }
    if (artId === 'yoyo') {
      spawnYoyoFlightSparks(this.yoyoState, x, y, handle?.hue ?? 0, ang);
      return;
    }
    if (artId === 'keris') {
      spawnKerisFlightSparks(this.kerisState, x, y, ang);
      return;
    }
    if (artId === 'diamond') {
      spawnDiamondFlightSparks(this.diamondState, x, y, ang);
      return;
    }
    if (artId === 'bazooka') {
      return; // BazookaSlideFx.update handles sustained rocket trail
    }
    if (artId === 'shark') {
      spawnSharkWaterTrail(this.sink, x, y, vx, vy);
      return;
    }

    const sp = Math.hypot(vx, vy) || 1;
    const ux = vx / sp;
    const uy = vy / sp;
    const px = -uy;
    const py = ux;

    if (artId === 'xeno') {
      this.sink.push({
        x: x + rnd(-3, 3), y: y + rnd(-3, 3),
        vx: rnd(-20, 20) - ux * 40, vy: rnd(-20, 20) - uy * 40,
        life: rnd(0.28, 0.55), max: 0.55, size: rnd(3, 5.8),
        color: '#b6ff1a', kind: 'drop', rot: 0, vr: 0, g: 450, drag: 0.9,
      });
      return;
    }
    if (artId === 'dora') {
      this.sink.push({
        x, y, vx: rnd(-35, 35) - ux * 35, vy: rnd(-35, 35) - uy * 35,
        life: rnd(0.35, 0.7), max: 0.7, size: rnd(7, 13),
        color: 'rgba(220,240,255,', kind: 'smoke', rot: rnd(0, TAU), vr: randRange(-2, 2), g: -20, drag: 3,
      });
      if (Math.random() < 0.38) this.ring(x, y, '255,255,255', 14, 0.18, 2);
      return;
    }
    if (artId === 'sakura') {
      if (Math.random() < 0.7) {
        this.sink.push({
          x, y, vx: rnd(-80, 80) - ux * 30, vy: rnd(-40, 40) - uy * 30,
          life: rnd(0.6, 1.1), max: 1.1, size: rnd(2.5, 4.5),
          color: pick(['#fbcfe8', '#f9a8d4', '#fdf2f8']), kind: 'petal', rot: rnd(0, TAU), vr: randRange(-8, 8), g: 60, drag: 1.5,
        });
      }
      return;
    }
    if (artId === 'angklung') {
      if (Math.random() < 0.28) {
        this.sink.push({
          x: x + rnd(-10, 10), y: y + rnd(-10, 10),
          vx: rnd(-35, 35), vy: rnd(-45, 15),
          life: 0.65, max: 0.65, size: 14, color: pick(['#fde68a', '#fca5a5', '#a5f3fc']), kind: 'text', rot: 0, vr: 0, g: 0, text: pick(['♪', '♫']),
        });
      }
      this.glow(x, y, def.trail, 3, 0.25);
      return;
    }
    if (artId === 'confetti') {
      this.sink.push({
        x, y, vx: rnd(-70, 70), vy: rnd(-70, 70),
        life: rnd(0.35, 0.65), max: 0.65, size: rnd(2.2, 4.2),
        color: pick(def.sparks), kind: 'chip', rot: rnd(0, TAU), vr: randRange(-18, 18), g: 200,
      });
      return;
    }

    switch (def.trailFx) {
      case 'glow':
      case 'void':
        this.glow(x + rnd(-2, 2), y + rnd(-2, 2), def.trail, rnd(2.6, 5), rnd(0.18, 0.36), -ux * 35 + rnd(-20, 20), -uy * 35 + rnd(-20, 20));
        break;
      case 'smoke':
        this.sink.push({
          x: x + rnd(-4, 4), y: y + rnd(-4, 4),
          vx: -ux * rnd(30, 80) + rnd(-20, 20), vy: -uy * rnd(30, 80) + rnd(-20, 20),
          life: rnd(0.45, 0.85), max: 0.85, size: rnd(5.5, 11),
          color: 'rgba(170,170,170,', kind: 'smoke', rot: 0, vr: 0, g: -20,
        });
        this.glow(x, y, '255,160,50', rnd(4.5, 8.5), 0.14, -ux * 70, -uy * 70);
        break;
      case 'spark':
        this.sink.push({
          x, y, vx: px * rnd(-160, 160) - ux * 60, vy: py * rnd(-160, 160) - uy * 60,
          life: 0.14, max: 0.14, size: 1.6, color: pick(def.sparks), kind: 'spark', rot: 0, vr: 0, g: 0,
        });
        if (Math.random() < 0.25) {
          this.bolt(x, y, x - ux * rnd(10, 22) + px * rnd(-10, 10), y - uy * rnd(10, 22) + py * rnd(-10, 10), def.trail, 1.1, 0.08);
        }
        break;
      case 'bubble':
        if (Math.random() < 0.6) {
          this.addExtra({
            k: 'bubble', x: x + rnd(-3, 3), y: y + rnd(-3, 3),
            rgb: '170,225,255', size: rnd(1.5, 3.5), life: rnd(0.45, 0.9),
            vx: rnd(-20, 20), vy: rnd(-65, -20), drag: 1.2,
          });
        }
        break;
      case 'frost':
        this.glow(x, y, def.trail, rnd(2.2, 4), 0.32, rnd(-30, 30), rnd(-30, 30));
        if (Math.random() < 0.45) {
          this.addExtra({
            k: 'shard', x, y, rgb: '215,245,255', size: rnd(1.5, 2.8), life: rnd(0.3, 0.6),
            vx: rnd(-30, 30), vy: rnd(10, 50), g: 160, rot: rnd(0, TAU), vr: randRange(-8, 8),
          });
        }
        break;
      case 'gold':
        this.sink.push({
          x: x + rnd(-3, 3), y: y + rnd(-3, 3), vx: rnd(-45, 45), vy: rnd(-20, 50),
          life: 0.26, max: 0.26, size: rnd(2.4, 4.5), color: pick(def.sparks), kind: 'star', rot: rnd(0, TAU), vr: 0, g: 0, drag: 1.5,
        });
        break;
      case 'fire':
        for (let k = 0; k < 2; k++) {
          this.glow(x + rnd(-2, 2), y + rnd(-2, 2), pick(['255,200,80', '255,120,30', '255,60,20']), rnd(4, 7.5), rnd(0.18, 0.38), rnd(-35, 35) - ux * 40, rnd(-90, -25) - uy * 40, -90);
        }
        break;
    }
  }

  /**
   * Efek tumbukan target ASLI Perfect Shot (`SetSevenFx`, signature slides, `SetNineFx`, `SetElevenFx`,
   * `spawnImpact`, `explodeAt` volumetric fireball/flame, `spawnHitPolish`, `applyNewPerks`).
   */
  spawnPerfectImpact(
    artId: string,
    def: Weapon,
    hx: number,
    hy: number,
    nx: number,
    ny: number,
    ux: number,
    uy: number,
    isEnemy: boolean,
    handle?: LiveShotHandle,
    muzzleX = hx - ux * 180,
    muzzleY = hy - uy * 180,
  ) {
    const idx = this.hitIdx++;
    const rot = Math.atan2(uy, ux) + Math.PI / 2;
    const hitTheta = Math.atan2(ny, nx);

    // 1. SET 1 (golden, blackhole, slingshot, blowgun, shotgun, soaker)
    if (handle?.s7) {
      const p0 = this.s7.particles.list.length;
      const f0 = this.s7.fx.length;
      try {
        handle.s7.x = 0;
        handle.s7.y = 0;
        handle.s7.hit(hitTheta - rot, 0, 0);
        // Released WaterJet assumes a stationary Perfect Shot wheel; that
        // would draw a stray jet at world origin in the scrolling level.
        if (artId !== 'soaker') this.s7.release(handle.s7);
      } catch { /* ignore */ }
      transformUprightItems(this.s7.particles.list, p0, hx, hy, rot);
      transformUprightItems(this.s7.fx, f0, hx, hy, rot);
      return;
    }

    // 2. Signature Slide Weapons
    if (artId === 'firework') {
      spawnFirework8StickBurst(this.fwState, hx, hy, handle?.hue ?? firework8ShotHue(1, idx));
      return;
    }
    if (artId === 'yoyo') {
      spawnYoyoStickBurst(this.yoyoState, hx, hy, handle?.hue ?? 0, muzzleX, muzzleY);
      return;
    }
    if (artId === 'keris') {
      spawnKerisImpact(this.kerisState, hx, hy, muzzleX, muzzleY, hitTheta);
      return;
    }
    if (artId === 'diamond') {
      spawnDiamondStickBurst(this.diamondState, hx, hy, 1);
      return;
    }
    if (artId === 'bazooka') {
      this.bazookaState.onHit(hx, hy, 1.05);
      return;
    }
    if (artId === 'shark') {
      spawnSharkWaterImpact(this.sink, hx, hy, nx, ny, 1.0);
      return;
    }

    // 3. Slide-9 exclusive
    if (NINE_EXCLUSIVE_IDS.has(artId)) {
      const nineId = setNineIdFor(artId) as NineId | null;
      if (nineId) {
        this.s9.selectWeapon(nineId);
        this.s9.impact(hx, hy, hitTheta, handle?.s9, Math.atan2(uy, ux));
        return;
      }
    }

    // 4. Slide-11 exclusive
    if (ELEVEN_EXCLUSIVE_IDS.has(artId)) {
      const elevenId = setElevenIdFor(artId) as ElevenId | null;
      if (elevenId && this.s11.raw) {
        this.s11.selectWeapon(elevenId);
        const raw = this.s11.raw;
        const p0 = raw.parts.length;
        const f0 = raw.fx.length;
        // Native onHit owns both the burst and its sound; don't synthesize
        // the same impact again in playPerfectShotHit().
        this.s11.impact(0, 0, handle?.s11);
        transformUprightItems(raw.parts, p0, hx, hy, rot);
        transformUprightItems(raw.fx, f0, hx, hy, rot);
        return;
      }
    }

    // 5. Classic / Zip / Sci-Fi weapons: Game.ts spawnImpact + explodeAt + spawnHitPolish
    const prof = fxProfileOf(artId);
    const activeProf = handle?.tintRgb ? { ...prof, light: handle.tintRgb } : prof;
    const targetChips = isEnemy
      ? ['#ef4444', '#fca5a5', '#ffd23f']
      : ['#cbd5e1', '#94a3b8', '#64748b'];

    spawnImpact(this.sink, activeProf, def, hx, hy, nx, ny, targetChips);

    if (activeProf.speedLines) {
      spawnSpeedLines(this.sink, hx - ux * 36, hy - uy * 36, hy, activeProf.light, ux * 1800, uy * 1800, activeProf.streak);
    }

    if (handle?.tintRgb) {
      for (let i = 0; i < 22; i++) {
        const a = rnd(0, TAU);
        const v = rnd(120, 520);
        this.sink.push({
          x: hx, y: hy, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
          life: rnd(0.4, 0.8), max: 0.8, size: rnd(2, 5), color: `rgb(${handle.tintRgb})`, kind: 'drop', rot: 0, vr: 0, g: 1100,
        });
      }
      this.sink.push({
        x: hx, y: hy, vx: 0, vy: 0, life: 0.3, max: 0.3, size: 24, color: `rgb(${handle.tintRgb})`, kind: 'paintSplat', rot: rnd(0, TAU), vr: 0, g: 0,
      });
    }

    // Ledakan volumetrik asli Perfect Shot (`explodeAt`: fireball + flame + smoke + glow + ring)
    if (def.explode) {
      this.spawnPerfectExplosion(hx, hy, artId === 'bamboo' ? 1.2 : artId === 'meteor' ? 1.35 : 1.0, def.explodeFx === 'white');
    }

    if (artId === 'cricket') {
      this.sink.push({ x: hx, y: hy, vx: 0, vy: 0, life: 0.5, max: 0.5, size: 180, color: '#7cc8ff', kind: 'ring', rot: 0, vr: 0, g: 0 });
    }

    if (artId === 'dora') {
      this.sink.light(hx, hy, 160, '255,255,255', 0.2);
      this.sink.push({ x: hx, y: hy, vx: 0, vy: 0, life: 0.32, max: 0.32, size: 70, color: '255,255,255', kind: 'ring', rot: 0, vr: 0, g: 0 });
      this.sink.push({ x: hx, y: hy, vx: 0, vy: 0, life: 0.4, max: 0.4, size: 105, color: '159,220,255', kind: 'ring', rot: 0, vr: 0, g: 0 });
      for (let i = 0; i < 10; i++) {
        const a = rnd(0, TAU);
        const v = rnd(120, 320);
        this.sink.push({
          x: hx, y: hy, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
          life: rnd(0.35, 0.7), max: 0.7, size: rnd(10, 18), color: '#ffffff', kind: 'puff', rot: rnd(0, TAU), vr: randRange(-2, 2), g: 0, drag: 3,
        });
      }
      for (let i = 0; i < 8; i++) {
        const a = rnd(0, TAU);
        this.sink.push({
          x: hx, y: hy, vx: Math.cos(a) * rnd(320, 620), vy: Math.sin(a) * rnd(320, 620),
          life: 0.22, max: 0.22, size: rnd(14, 24), color: '#ffffff', kind: 'wind', rot: 0, vr: 0, g: 0, drag: 1.5,
        });
      }
    } else if (artId === 'xeno') {
      for (let i = 0; i < 14; i++) {
        const a = Math.atan2(ny, nx) + rnd(-1.3, 1.3);
        const v = rnd(80, 300);
        this.sink.push({
          x: hx, y: hy, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
          life: rnd(0.35, 0.7), max: 0.7, size: rnd(2.5, 5.2),
          color: pick(['#b6ff1a', '#a3e635', '#ecfccb']), kind: 'drop', rot: 0, vr: 0, g: 850, drag: 1.3,
        });
      }
      this.ring(hx, hy, '182,255,26', 36, 0.3, 2.8);
    } else if (artId === 'angklung') {
      const noteCols = ['#fde68a', '#fca5a5', '#a5f3fc', '#bbf7d0', '#ddd6fe'];
      for (let i = 0; i < 3; i++) {
        this.sink.push({
          x: hx + rnd(-18, 18), y: hy, vx: rnd(-60, 60), vy: rnd(-160, -80),
          life: 1.0, max: 1.0, size: 18 + (idx % 6), color: pick(noteCols), kind: 'text', rot: 0, vr: 0, g: 0, text: pick(['♪', '♫', '♬']),
        });
      }
    } else if (artId === 'storm') {
      this.sink.push({ x: hx + rnd(-20, 20), y: hy - 260, tx: hx, ty: hy, vx: 0, vy: 0, life: 0.3, max: 0.3, size: 4, color: '#dbeafe', kind: 'bolt', rot: 0, vr: 0, g: 0 });
    } else if (artId === 'meteor') {
      this.sink.push({ x: hx - 160, y: hy - 220, tx: hx, ty: hy, vx: 0, vy: 0, life: 0.16, max: 0.16, size: 5, color: '#fb923c', kind: 'bolt', rot: 0, vr: 0, g: 0 });
      for (let i = 0; i < 10; i++) {
        const a = rnd(-Math.PI, 0);
        this.addExtra({
          k: 'shard', x: hx, y: hy, rgb: '120,60,30', size: rnd(3, 6), life: rnd(0.6, 1.1),
          vx: Math.cos(a) * rnd(140, 420), vy: Math.sin(a) * rnd(200, 520), g: 900, rot: rnd(0, TAU), vr: randRange(-12, 12),
        });
      }
    } else if (artId === 'holy') {
      this.sink.push({ x: hx, y: hy - 240, tx: hx, ty: hy, vx: 0, vy: 0, life: 0.4, max: 0.4, size: 5, color: '#fef9c3', kind: 'bolt', rot: 0, vr: 0, g: 0 });
      this.addExtra({ k: 'pillar', x: hx, y: hy + 8, rgb: '255,236,170', size: 14, w: 220, life: 0.45 });
      this.ring(hx, hy, '255,244,200', 44, 0.36, 3.2);
    } else if (artId === 'obliterator') {
      for (let i = 0; i < 6; i++) {
        const a = rnd(0, TAU);
        const d = rnd(40, 110);
        this.sink.push({ x: hx, y: hy, tx: hx + Math.cos(a) * d, ty: hy + Math.sin(a) * d, vx: 0, vy: 0, life: 0.42, max: 0.42, size: 3.5, color: '#86efac', kind: 'bolt', rot: 0, vr: 0, g: 0 });
      }
      this.sink.light(hx, hy, 280, '74,222,128', 0.6);
      this.sink.push({ x: hx, y: hy, vx: 0, vy: 0, life: 0.55, max: 0.55, size: 160, color: '134,239,172', kind: 'shock', rot: 0, vr: 0, g: 0 });
    } else if (artId === 'chicken') {
      for (let i = 0; i < 8; i++) {
        const a = Math.atan2(ny, nx) + rnd(-1.4, 1.4);
        const v = rnd(70, 240);
        this.sink.push({
          x: hx, y: hy, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 50,
          life: rnd(0.6, 1.2), max: 1.2, size: rnd(4, 7), color: '#ffffff', kind: 'feather', rot: rnd(0, TAU), vr: randRange(-4, 4), g: 120, drag: 2.5,
        });
      }
    } else if (artId === 'confetti') {
      for (let i = 0; i < 18; i++) {
        const a = rnd(0, TAU);
        this.addExtra({
          k: 'paper', x: hx, y: hy,
          rgb: pick(['244,63,94', '250,204,21', '34,211,238', '168,85,247', '74,222,128']),
          size: rnd(2.0, 3.6), life: rnd(0.65, 1.3),
          vx: Math.cos(a) * rnd(80, 340), vy: Math.sin(a) * rnd(80, 340) - 90,
          g: 280, drag: 1.9, rot: rnd(0, TAU), vr: randRange(-11, 11),
        });
      }
    } else if (artId === 'blackhole') {
      this.ring(hx, hy, activeProf.light, 78, 0.42, 4.5, true);
      this.ring(hx, hy, '255,255,255', 42, 0.28, 2.2, true);
    }

    if (def.burstFx) {
      const bf = def.burstFx;
      for (let i = 0; i < bf.n; i++) {
        const a = Math.atan2(ny, nx) + rnd(-1.4, 1.4);
        const v = rnd(0.35, 1) * (bf.spd ?? 200);
        this.sink.push({
          x: hx, y: hy, vx: Math.cos(a) * v, vy: Math.sin(a) * v,
          life: rnd(0.25, 0.58), max: 0.58, size: rnd(0.55, 1.05) * (bf.size ?? 5) * 0.6,
          color: bf.colors[i % bf.colors.length],
          kind: bf.glow ? 'glow' : 'drop', rot: 0, vr: 0, g: (bf.g ?? 300) * 0.7, drag: 1.6,
        });
      }
    }
  }

  /** Ledakan volumetrik `fireball` + `flame` + `smoke` + `glow` + `ring` ASLI Perfect Shot */
  spawnPerfectExplosion(x: number, y: number, big = 1.0, white = false) {
    this.sink.light(x, y, 260 * big, white ? '255,245,210' : '255,140,40', 0.65);

    const fbCount = Math.round(7 * big);
    for (let i = 0; i < fbCount; i++) {
      const a = rnd(0, TAU);
      const v = rnd(25, 130) * big;
      const life = rnd(0.32, 0.66);
      this.sink.push({
        x: x + rnd(-12, 12), y: y + rnd(-12, 12),
        vx: Math.cos(a) * v, vy: Math.sin(a) * v - 45,
        life, max: life, size: rnd(18, 36) * big,
        color: '#ff8a1f', kind: 'fireball', rot: rnd(0, TAU), vr: randRange(-3, 3), g: -90, drag: 2.8,
      });
    }
    const flCount = Math.round(12 * big);
    for (let i = 0; i < flCount; i++) {
      const a = rnd(0, TAU);
      const v = rnd(110, 310) * big;
      const life = rnd(0.24, 0.52);
      this.sink.push({
        x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 65,
        life, max: life, size: rnd(9, 18) * big,
        color: pick(['#f97316', '#ef4444', '#fb923c', '#f59e0b']), kind: 'flame', rot: rnd(0, TAU), vr: 0, g: -200, drag: 2.3, extra: -Math.PI / 2,
      });
    }
    for (let i = 0; i < 20 * big; i++) {
      const a = rnd(0, TAU);
      const v = rnd(60, 360) * big;
      this.sink.push({
        x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: rnd(0.3, 0.7), max: 0.7,
        size: rnd(5, 11), color: pick(white ? ['255,250,220', '255,230,150', '255,200,120'] : ['255,200,80', '255,120,30', '255,60,20']),
        kind: 'glow', rot: 0, vr: 0, g: -60,
      });
    }
    for (let i = 0; i < (white ? 18 : 11); i++) {
      this.sink.push({
        x: x + rnd(-22, 22), y: y + rnd(-18, 18), vx: rnd(-100, 100), vy: rnd(-120, 20),
        life: rnd(0.7, 1.35), max: 1.35, size: randRange(15, 32) * big,
        color: white ? 'rgba(245,245,245,' : 'rgba(70,70,70,', kind: 'smoke', rot: 0, vr: 0, g: -45,
      });
    }
    if (white) {
      for (let i = 0; i < 16; i++) {
        this.sink.push({
          x, y, vx: rnd(-300, 300), vy: rnd(-350, 100), life: rnd(0.5, 0.9), max: 0.9,
          size: rnd(2.2, 4.2), color: pick(['#dc2626', '#fde047', '#ffffff']), kind: 'chip', rot: rnd(0, TAU), vr: randRange(-20, 20), g: 900,
        });
      }
    }
    this.sink.push({ x, y, vx: 0, vy: 0, life: 0.42, max: 0.42, size: 135 * big, color: white ? '#ffffff' : '#ffb347', kind: 'ring', rot: 0, vr: 0, g: 0 });
  }

  /** Gambar tali yoyo atau selang blackhole ke peluru yang sedang terbang */
  drawFlyingExtras(ctx: CanvasRenderingContext2D, artId: string, b: { x: number; y: number; sx: number; sy: number }, handle?: LiveShotHandle) {
    if (artId === 'yoyo') {
      drawSlide6String(
        ctx,
        { x: b.sx, y: b.sy },
        { x: b.x, y: b.y },
        7, 4, this.time * 32, 0, 1, handle?.hue ?? 0,
      );
    }
  }

  /** Gambar peluru asli dari sub-engine Perfect Shot (SET 1, SetNine, SetEleven, Diamond, Firework, Yoyo, Xeno) */
  drawSpecialRound(
    ctx: CanvasRenderingContext2D,
    artId: string,
    b: { x: number; y: number; vx: number; vy: number; sx: number; sy: number; age?: number },
    ps: number,
    handle?: LiveShotHandle,
  ): boolean {
    const sp = Math.hypot(b.vx, b.vy) || 1;
    const ang = Math.atan2(b.vy, b.vx) + Math.PI / 2;
    const travelled = Math.hypot(b.x - b.sx, b.y - b.sy);

    if (handle?.s7) {
      const shot = handle.s7 as unknown as {
        x: number; y: number; startY?: number; age: number;
        draw: (c: CanvasRenderingContext2D) => void;
      };
      const prevX = shot.x;
      const prevY = shot.y;
      const prevAge = shot.age;
      const prevStartY = shot.startY;
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(ang);
      const sc = artId === 'shotgun' ? 0.65 : artId === 'blackhole' ? 0.72 : 0.78;
      ctx.scale(sc, sc);
      shot.x = 0;
      shot.y = 0;
      shot.age = b.age ?? 0;
      if (typeof prevStartY === 'number') shot.startY = travelled / sc;
      try { shot.draw(ctx); } catch { /* ignore */ }
      ctx.restore();
      shot.x = prevX;
      shot.y = prevY;
      shot.age = prevAge;
      if (typeof prevStartY === 'number') shot.startY = prevStartY;
      return true;
    }

    if (handle?.s9) {
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(ang);
      ctx.scale(0.68, 0.68);
      const savedX = handle.s9.x;
      const savedY = handle.s9.y;
      const savedAngle = handle.s9.angle;
      const savedTrail = handle.s9.trail;
      handle.s9.x = 0;
      handle.s9.y = 0;
      handle.s9.angle = -Math.PI / 2;
      handle.s9.trail = [{ x: 0, y: Math.min(36, travelled) }, { x: 0, y: 0 }];
      try { handle.s9.draw(ctx, handle.s9, this.time); } catch { /* ignore */ }
      handle.s9.x = savedX;
      handle.s9.y = savedY;
      handle.s9.angle = savedAngle;
      handle.s9.trail = savedTrail;
      ctx.restore();
      return true;
    }

    if (handle?.s11 && this.s11.raw) {
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(ang);
      ctx.scale(0.68, 0.68);
      const savedX = handle.s11.x;
      const savedY = handle.s11.y;
      const savedVx = handle.s11.vx;
      const savedVy = handle.s11.vy;
      handle.s11.x = 0;
      handle.s11.y = 0;
      handle.s11.vx = 0;
      handle.s11.vy = -sp;
      try { handle.s11.draw(ctx, this.s11.raw, handle.s11); } catch { /* ignore */ }
      handle.s11.x = savedX;
      handle.s11.y = savedY;
      handle.s11.vx = savedVx;
      handle.s11.vy = savedVy;
      ctx.restore();
      return true;
    }

    if (artId === 'firework') {
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(ang);
      ctx.scale(ps * 1.15, ps * 1.15);
      drawFirework8Projectile(ctx, handle?.hue ?? 340, 0);
      ctx.restore();
      return true;
    }

    if (artId === 'yoyo') {
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(ang);
      ctx.scale(ps * 1.15, ps * 1.15);
      drawSlide6Yoyo(ctx, 0, 14, 15, (b.age ?? 0) * 14, 0.4, handle?.hue ?? 0, 0);
      ctx.restore();
      return true;
    }

    if (artId === 'diamond') {
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(ang);
      ctx.scale(ps * 1.15, ps * 1.15);
      drawSlide2DiamondBullet(ctx, 13, this.time, (b.sx + b.sy) * 0.01, 0);
      ctx.restore();
      return true;
    }

    if (artId === 'xeno') {
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(ang);
      ctx.scale(ps * 1.15, ps * 1.15);
      drawXenoHybridFlight(ctx, 0, 0, b.age ?? this.time);
      ctx.restore();
      return true;
    }

    return false;
  }

  update(dt: number, activeArtId = '', mx = 0, my = 0, flyingBazookas: { x: number; y: number; vx?: number; vy?: number }[] = []) {
    this.time += dt;

    // 1. Update Perfect Shot particles
    const P = this.particles;
    let pw = 0;
    for (let i = 0; i < P.length; i++) {
      const p = P[i];
      p.life -= dt;
      if (p.life <= 0) continue;
      if (p.g) p.vy += p.g * dt;
      if (p.drag) {
        const k = Math.exp(-p.drag * dt);
        p.vx *= k;
        p.vy *= k;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.grow) p.size = Math.max(0.2, p.size + p.grow * dt);
      if (p.vr) p.rot += p.vr * dt;
      P[pw++] = p;
    }
    P.length = pw;

    // 2. Update lights
    const L = this.lights;
    let lw = 0;
    for (let i = 0; i < L.length; i++) {
      const f = L[i];
      f.life -= dt;
      if (f.life > 0) L[lw++] = f;
    }
    L.length = lw;

    // 3. Update extras
    const E = this.extras;
    let ew = 0;
    for (let i = 0; i < E.length; i++) {
      const f = E[i];
      f.life -= dt;
      if (f.life <= 0) continue;
      if (f.g) f.vy += f.g * dt;
      if (f.drag) {
        const k = Math.exp(-f.drag * dt);
        f.vx *= k;
        f.vy *= k;
      }
      f.x += f.vx * dt;
      f.y += f.vy * dt;
      if (f.grow) f.size = Math.max(0.2, f.size + f.grow * dt);
      if (f.vr) f.rot += f.vr * dt;
      E[ew++] = f;
    }
    E.length = ew;

    // 4. Update SET 1 (SetSevenFx)
    if (this.s7.particles.list.length || this.s7.fx.length || this.s7.timers.length || this.s7.released.length) {
      const p0 = this.s7.particles.list.length;
      const f0 = this.s7.fx.length;
      try {
        this.s7.update(dt, false);
      } catch { /* ignore */ }
      if (this.s7.particles.list.length > p0 || this.s7.fx.length > f0) {
        transformUprightItems(this.s7.particles.list, p0, this.s7ActiveMuzzle.x, this.s7ActiveMuzzle.y, this.s7ActiveMuzzle.rot);
        transformUprightItems(this.s7.fx, f0, this.s7ActiveMuzzle.x, this.s7ActiveMuzzle.y, this.s7ActiveMuzzle.rot);
      }
    }

    // 5. Update SetNine & SetEleven
    if (this.s9.busy) {
      try { this.s9.update(dt); } catch { /* ignore */ }
    }
    if (this.s11.busy) {
      try { this.s11.advance(dt, false); } catch { /* ignore */ }
    }

    // 6. Update Signature Slide states
    if (this.fwState.particles.length || this.fwState.rings.length || this.fwState.glows.length) {
      updateFirework8State(this.fwState, dt, false);
    }
    if (this.yoyoState.particles.length || this.yoyoState.rings.length || this.yoyoState.strings.length || this.yoyoState.flash > 0) {
      updateYoyoSlideState(this.yoyoState, dt, []);
    }
    if (this.kerisState.particles.length || this.kerisState.crawlArcs.length || this.kerisState.dust.length || this.kerisState.thunderFlash > 0) {
      updateKerisSlideState(this.kerisState, dt, this.time, mx, my, false);
    }
    if (this.diamondState.particles.length || this.diamondState.shards.length || this.diamondState.rings.length || this.diamondState.starflashes.length || this.diamondState.flash > 0) {
      updateDiamondSlideState(this.diamondState, dt, [], false, mx, my);
    }
    if (activeArtId === 'bazooka' || flyingBazookas.length > 0 || this.bazookaState.particles.length || this.bazookaState.smokes.length || this.bazookaState.fireballs.length || this.bazookaState.flashes.length || this.bazookaState.debris.length || this.bazookaState.timers.length) {
      this.bazookaState.update(dt, flyingBazookas.length > 0, mx, my, flyingBazookas, my + 240);
    }
  }

  draw(ctx: CanvasRenderingContext2D, vx0: number, vy0: number, vx1: number, vy1: number) {
    const P = this.particles;
    const L = this.lights;
    const E = this.extras;

    ctx.save();

    // Keep impact debris, but omit the broad radial light pass.
    void L;

    // Pass B: Batched drop particles
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    drawDropParticles(ctx, P, false);

    // Pass C: Individual Perfect Shot particles
    for (let i = 0; i < P.length; i++) {
      const p = P[i];
      if (p.kind === 'drop') continue;
      if (p.x < vx0 - 160 || p.x > vx1 + 160 || p.y < vy0 - 160 || p.y > vy1 + 260) continue;
      const a = clamp01(p.life / p.max);
      if (p.kind === 'smoke') {
        drawSmokeParticle(ctx, p, a);
        continue;
      }
      if (CUSTOM_PARTICLE_KINDS.has(p.kind)) {
        drawFxParticle(ctx, p, this.time);
        continue;
      }
      switch (p.kind) {
        case 'spark': {
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = a;
          ctx.strokeStyle = cssColor(p.color);
          ctx.lineWidth = p.size * (0.6 + 0.5 * a);
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 0.028, p.y - p.vy * 0.028);
          ctx.stroke();
          ctx.restore();
          break;
        }
        case 'chip': {
          ctx.save();
          ctx.globalAlpha = Math.min(1, a * 1.8);
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = cssColor(p.color);
          ctx.fillRect(-p.size * 0.6, -p.size * 0.6, p.size * 1.2, p.size * 1.2);
          ctx.restore();
          break;
        }
        case 'glow': {
          // Keep the original coloured sparks and impact timing, without
          // adding the soft bloom removed from Perfect Shot weapon effects.
          ctx.save();
          ctx.globalAlpha = a * 0.85;
          ctx.fillStyle = cssColor(p.color);
          ctx.beginPath();
          ctx.arc(p.x, p.y, Math.max(1, p.size * 0.38), 0, TAU);
          ctx.fill();
          ctx.restore();
          break;
        }
        case 'bolt': {
          if (p.tx === undefined || p.ty === undefined) break;
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.lineCap = 'round';
          const dx = p.tx - p.x;
          const dy = p.ty - p.y;
          const d = Math.hypot(dx, dy) || 1;
          const px = -dy / d;
          const py = dx / d;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          for (let s = 1; s < 5; s++) {
            const k = s / 5;
            const off = rnd(-1, 1) * Math.min(12, d * 0.16);
            ctx.lineTo(p.x + dx * k + px * off, p.y + dy * k + py * off);
          }
          ctx.lineTo(p.tx, p.ty);
          ctx.globalAlpha = a * 0.45;
          ctx.strokeStyle = cssColor(p.color);
          ctx.lineWidth = p.size * 2.6;
          ctx.stroke();
          ctx.globalAlpha = a;
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = p.size * 0.85;
          ctx.stroke();
          ctx.restore();
          break;
        }
        case 'ring': {
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = a;
          ctx.strokeStyle = cssColor(p.color);
          ctx.lineWidth = Math.max(0.8, 2.5 * a);
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (1 - a * 0.6), 0, TAU);
          ctx.stroke();
          ctx.restore();
          break;
        }
        case 'text': {
          if (!p.text) break;
          ctx.save();
          ctx.globalAlpha = Math.min(1, a * 1.6);
          ctx.font = `900 ${Math.round(p.size)}px sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.strokeStyle = 'rgba(0,0,0,0.7)';
          ctx.lineWidth = 3;
          ctx.strokeText(p.text, p.x, p.y);
          ctx.fillStyle = cssColor(p.color);
          ctx.fillText(p.text, p.x, p.y);
          ctx.restore();
          break;
        }
      }
    }

    // Pass D: Beams, bolts, pillars, rings, paper confetti, extra smoke
    for (let pass = 0; pass < 2; pass++) {
      const add = pass === 1;
      ctx.globalCompositeOperation = add ? 'lighter' : 'source-over';
      for (let i = 0; i < E.length; i++) {
        const f = E[i];
        const isAdd = f.k !== 'smoke' && f.k !== 'bubble' && f.k !== 'paper' && f.k !== 'shard';
        if (isAdd !== add) continue;
        const far = f.k === 'beam' || f.k === 'psLaser' || f.k === 'psHoly' || f.k === 'psBeam' || f.k === 'bolt';
        if (!far && (f.x < vx0 - 120 || f.x > vx1 + 120 || f.y < vy0 - 120 || f.y > vy1 + 260)) continue;
        const a = clamp01(f.life / f.max);
        switch (f.k) {
          case 'glow': {
            ctx.globalAlpha = a * 0.85;
            ctx.fillStyle = `rgb(${f.rgb})`;
            ctx.beginPath();
            ctx.arc(f.x, f.y, Math.max(1, f.size * 0.45), 0, TAU);
            ctx.fill();
            break;
          }
          case 'ring': {
            const r = f.grow < 0 ? f.size * a : f.size * (1 - a * a);
            ctx.globalAlpha = a;
            ctx.strokeStyle = `rgb(${f.rgb})`;
            ctx.lineWidth = Math.max(0.6, f.w * a);
            ctx.beginPath();
            ctx.arc(f.x, f.y, Math.max(0.5, r), 0, TAU);
            ctx.stroke();
            break;
          }
          case 'beam': {
            ctx.globalAlpha = a * 0.3;
            ctx.strokeStyle = `rgb(${f.rgb})`;
            ctx.lineWidth = f.w * 3.4 * (0.5 + 0.5 * a);
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(f.x, f.y);
            ctx.lineTo(f.x2, f.y2);
            ctx.stroke();
            ctx.globalAlpha = a * 0.78;
            ctx.lineWidth = f.w * 1.5 * (0.4 + 0.6 * a);
            ctx.stroke();
            ctx.globalAlpha = a;
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = Math.max(0.8, f.w * 0.55 * a);
            ctx.stroke();
            break;
          }
          case 'psLaser':
          case 'psHoly':
          case 'psBeam': {
            const dx = f.x2 - f.x;
            const dy = f.y2 - f.y;
            const d = Math.hypot(dx, dy);
            if (d < 2) break;
            const ang = Math.atan2(dy, dx) + Math.PI / 2;
            ctx.save();
            ctx.translate(f.x, f.y);
            ctx.rotate(ang);
            if (f.k === 'psLaser') drawLaserBeam(ctx, 0, -d, 0, a, this.time);
            else if (f.k === 'psHoly') drawHolyLightLance(ctx, 0, -d, 0, a, this.time);
            else drawClassicBeam(ctx, 0, -d, 0, a, f.rgb);
            ctx.restore();
            break;
          }
          case 'bolt': {
            const dx = f.x2 - f.x;
            const dy = f.y2 - f.y;
            const d = Math.hypot(dx, dy) || 1;
            const segs = Math.max(3, Math.min(14, Math.round(d / 16)));
            const px = -dy / d;
            const py = dx / d;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(f.x, f.y);
            for (let s = 1; s < segs; s++) {
              const k = s / segs;
              const off = rnd(-1, 1) * Math.min(14, d * 0.12);
              ctx.lineTo(f.x + dx * k + px * off, f.y + dy * k + py * off);
            }
            ctx.lineTo(f.x2, f.y2);
            ctx.globalAlpha = a * 0.45;
            ctx.strokeStyle = `rgb(${f.rgb})`;
            ctx.lineWidth = f.w * 3;
            ctx.stroke();
            ctx.globalAlpha = a;
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = f.w * 0.85;
            ctx.stroke();
            break;
          }
          case 'pillar': {
            const w = f.size * (0.4 + 0.6 * a);
            const g = ctx.createLinearGradient(0, f.y - f.w, 0, f.y);
            g.addColorStop(0, `rgba(${f.rgb},0)`);
            g.addColorStop(0.6, `rgba(${f.rgb},${0.55 * a})`);
            g.addColorStop(1, `rgba(255,255,255,${0.9 * a})`);
            ctx.globalAlpha = 1;
            ctx.fillStyle = g;
            ctx.fillRect(f.x - w, f.y - f.w, w * 2, f.w);
            break;
          }
          case 'smoke': {
            ctx.globalAlpha = a * 0.42;
            ctx.fillStyle = `rgb(${f.rgb})`;
            ctx.beginPath();
            ctx.arc(f.x, f.y, f.size, 0, TAU);
            ctx.fill();
            break;
          }
          case 'bubble': {
            ctx.globalAlpha = Math.min(1, a * 1.6);
            ctx.strokeStyle = `rgba(${f.rgb},0.95)`;
            ctx.fillStyle = `rgba(${f.rgb},0.22)`;
            ctx.lineWidth = 0.9;
            ctx.beginPath();
            ctx.arc(f.x + Math.sin(f.seed + f.life * 9) * 1.6, f.y, f.size, 0, TAU);
            ctx.fill();
            ctx.stroke();
            break;
          }
          case 'shard':
          case 'paper': {
            ctx.globalAlpha = Math.min(1, a * 1.5);
            ctx.save();
            ctx.translate(f.x, f.y);
            ctx.rotate(f.rot);
            ctx.fillStyle = `rgb(${f.rgb})`;
            if (f.k === 'shard') {
              ctx.beginPath();
              ctx.moveTo(0, -f.size);
              ctx.lineTo(f.size * 0.45, 0);
              ctx.lineTo(0, f.size);
              ctx.lineTo(-f.size * 0.45, 0);
              ctx.closePath();
              ctx.fill();
            } else {
              ctx.fillRect(-f.size, -f.size * 0.5 * Math.abs(Math.cos(f.rot * 2)), f.size * 2, f.size * Math.abs(Math.cos(f.rot * 2)) + 0.4);
            }
            ctx.restore();
            break;
          }
        }
      }
    }

    // Pass E: Sub-engines asli Perfect Shot (SetSevenFx, SetNine, SetEleven, Firework8, Yoyo, Keris, Diamond, Bazooka)
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    if (this.s7.particles.list.length || this.s7.fx.length || this.s7.released.length) {
      try {
        this.s7.draw(ctx);
        this.s7.drawFront(ctx);
      } catch { /* ignore */ }
    }
    if (this.s9.busy) {
      try { this.s9.draw(ctx); } catch { /* ignore */ }
    }
    if (this.s11.busy) {
      try { this.s11.draw(ctx); } catch { /* ignore */ }
    }
    if (this.fwState.particles.length || this.fwState.rings.length || this.fwState.glows.length) {
      try { drawFirework8ParticlesAndRings(ctx, this.fwState); } catch { /* ignore */ }
    }
    if (this.yoyoState.particles.length || this.yoyoState.rings.length || this.yoyoState.strings.length) {
      try { drawYoyoSlideParticlesRingsAndStrings(ctx, this.yoyoState, 0, 0, this.time); } catch { /* ignore */ }
    }
    if (this.kerisState.particles.length || this.kerisState.crawlArcs.length || this.kerisState.dust.length) {
      try { drawKerisSlideParticlesAndArcs(ctx, this.kerisState, vx1 - vx0, vy1 - vy0); } catch { /* ignore */ }
    }
    if (this.diamondState.particles.length || this.diamondState.shards.length || this.diamondState.rings.length || this.diamondState.starflashes.length) {
      try { drawDiamondSlideForeground(ctx, this.diamondState, 0, 0); } catch { /* ignore */ }
    }
    if (this.bazookaState.particles.length || this.bazookaState.smokes.length || this.bazookaState.fireballs.length || this.bazookaState.flashes.length || this.bazookaState.debris.length) {
      try { this.bazookaState.drawForeground(ctx, vx1 - vx0, vy1 - vy0); } catch { /* ignore */ }
    }

    ctx.restore();
  }
}

function randRange(a: number, b: number) {
  return a + Math.random() * (b - a);
}
