import { drawBanana } from './props';
import { clamp, distToSeg, rand, segCircle, sign, TAU, wrapAngle } from './math';
import type { Particles } from './particles';
import type { Player } from './player';
import type { Sound } from './audio';
import type { World } from './world';

export type HazardKind = 'cleaver' | 'dynamite' | 'wave' | 'bomb' | 'laser' | 'minion';

export interface Hazard {
  kind: HazardKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  vr: number;
  t: number;
  life: number;
  dmg: number;
  hp: number;
  dir: number;
  a: number;
  va: number;
  phase: number;
  aimT: number;
  fireT: number;
  stuck: boolean;
  alive: boolean;
  hit: boolean;
  cd: number;
  ox: number;
  oy: number;
  src: (() => { x: number; y: number }) | null;
  len: number;
  flash: number;
  batted?: boolean;
}

export interface HazardHost {
  world: World;
  player: Player;
  particles: Particles;
  sfx: Sound;
  hurtPlayer(dmg: number, dirx: number, knock: number): boolean;
  explodeAt(x: number, y: number, tags: string[], radius?: number, playerScale?: number): void;
  shake(a: number): void;
  enemyShoot(x: number, y: number, angle: number, speed: number, dmg: number): void;
}

const OUT = '#1b1410';

export class Hazards {
  list: Hazard[] = [];

  add(h: Partial<Hazard> & { kind: HazardKind; x: number; y: number }): Hazard {
    const hz: Hazard = {
      vx: 0,
      vy: 0,
      rot: 0,
      vr: 0,
      t: 0,
      life: 6,
      dmg: 10,
      hp: 1,
      dir: 1,
      a: 0,
      va: 0,
      phase: 0,
      aimT: 0.9,
      fireT: 1.4,
      stuck: false,
      alive: true,
      hit: false,
      cd: 0,
      ox: 0,
      oy: 0,
      src: null,
      len: 0,
      flash: 0,
      ...h,
    };
    this.list.push(hz);
    return hz;
  }

  clear() {
    this.list.length = 0;
  }

  count(kind: HazardKind) {
    let n = 0;
    for (const h of this.list) if (h.alive && h.kind === kind) n++;
    return n;
  }

  update(dt: number, host: HazardHost) {
    const w = host.world;
    const p = host.player;
    const pcx = p.x;
    const pcy = p.y - p.h * 0.5;
    for (const h of this.list) {
      if (!h.alive) continue;
      h.t += dt;
      h.flash = Math.max(0, h.flash - dt);
      switch (h.kind) {
        case 'cleaver': {
          if (h.stuck) {
            if (h.t > h.life) h.alive = false;
            break;
          }
          h.vy += 1500 * dt;
          const nx = h.x + h.vx * dt;
          const ny = h.y + h.vy * dt;
          h.rot += h.vr * dt;
          if (w.solidAt(nx, ny, false)) {
            h.stuck = true;
            h.x = nx;
            h.y = ny;
            h.vx = 0;
            h.vy = 0;
            h.t = 0;
            h.life = 2.2;
            host.particles.sparks(nx, ny, 0, -1, 6);
            host.particles.debris(nx, ny, 4, '#77736c', 0.5);
            host.sfx.wallHit();
            break;
          }
          h.x = nx;
          h.y = ny;
          if (!h.hit && p.alive && Math.abs(h.x - pcx) < 22 && Math.abs(h.y - pcy) < p.h * 0.5 + 6) {
            if (host.hurtPlayer(h.dmg, sign(h.vx), 260)) {
              h.alive = false;
              host.particles.blood(h.x, h.y, h.vx, h.vy, 12, 0.9);
              host.sfx.hit(false);
            } else h.hit = true;
          }
          if (h.t > h.life) h.alive = false;
          break;
        }
        case 'dynamite': {
          h.vy += 1500 * dt;
          let nx = h.x + h.vx * dt;
          let ny = h.y + h.vy * dt;
          if (w.solidAt(nx, h.y, false)) {
            h.vx = -h.vx * 0.45;
            nx = h.x;
          }
          const g = w.solidAt(nx, ny + 4, true);
          if (g && h.vy > 0 && !(g.oneWay && h.y + 4 > g.y + 2)) {
            ny = g.y - 4;
            h.vy = -h.vy * 0.4;
            h.vx *= 0.7;
            h.vr *= 0.6;
            if (Math.abs(h.vy) < 80) h.vy = 0;
          } else if (h.vy < 0 && w.solidAt(nx, ny - 4, false)) {
            h.vy = Math.abs(h.vy) * 0.3;
            ny = h.y;
          }
          h.x = nx;
          h.y = ny;
          h.rot += h.vr * dt;
          if (Math.random() < 0.6) {
            const c = Math.cos(h.rot);
            const s = Math.sin(h.rot);
            host.particles.sparks(h.x + 2 * c + 16 * s, h.y + 2 * s - 16 * c, 0, -1, 1, '#ffd36b');
          }
          if (h.t >= h.life) {
            h.alive = false;
            host.explodeAt(h.x, h.y, [], 135, 0.85);
          }
          break;
        }
        case 'wave': {
          h.x += h.dir * 600 * dt;
          if (w.solidAt(h.x + h.dir * 12, h.y - 14, false) || !w.solidAt(h.x, h.y + 4, true) || h.t > h.life) {
            h.alive = false;
            host.particles.dust(h.x, h.y, 5, h.dir);
            break;
          }
          if (Math.random() < 0.8) host.particles.dust(h.x, h.y, 1, h.dir);
          if (Math.random() < 0.3) host.particles.debris(h.x, h.y - 2, 1, '#77736c', 0.6);
          if (!h.hit && p.alive && Math.abs(p.x - h.x) < 28 && p.y > h.y - 34 && p.y < h.y + 8) {
            if (host.hurtPlayer(h.dmg, h.dir, 300) || p.dodging) h.hit = true;
          }
          break;
        }
        case 'bomb': {
          const oy = h.y;
          if (!h.batted) h.vy = Math.min(900, h.vy + 900 * dt);
          h.x += h.vx * dt;
          h.y += h.vy * dt;
          h.rot += h.vr * dt;
          const g = w.solidAt(h.x, h.y + 10, true);
          const land = g && h.vy > 0 && !(g.oneWay && oy + 10 > g.y + 2);
          const touch =
            !h.batted && p.alive && Math.abs(h.x - pcx) < 20 && Math.abs(h.y - pcy) < p.h * 0.5 + 8 && !p.dodging;
          if (land || touch || h.t > h.life) {
            h.alive = false;
            host.explodeAt(h.x, h.y, [], 72, 0.45);
          }
          break;
        }
        case 'laser': {
          const o = h.src ? h.src() : { x: h.x, y: h.y };
          h.x = o.x;
          h.y = o.y;
          const want = Math.atan2(pcy - h.y, pcx - h.x);
          if (h.phase === 0) {
            h.a += clamp(wrapAngle(want - h.a), -2.6 * dt, 2.6 * dt);
            if (h.t >= h.aimT) {
              h.phase = 1;
              h.t = 0;
              h.a = want - h.dir * 0.6;
              host.sfx.laserHum(true);
              host.shake(5);
            }
          } else {
            h.a += h.va * h.dir * dt;
            if (h.t >= h.fireT) {
              h.alive = false;
              host.sfx.laserHum(false);
              break;
            }
          }
          const L = 1900;
          const hit = w.raycast(h.x, h.y, h.x + Math.cos(h.a) * L, h.y + Math.sin(h.a) * L, false, false);
          h.len = hit ? hit.t * L : L;
          if (h.phase === 1) {
            const ex = h.x + Math.cos(h.a) * h.len;
            const ey = h.y + Math.sin(h.a) * h.len;
            if (Math.random() < 0.7) host.particles.sparks(ex, ey, -Math.cos(h.a), -Math.sin(h.a), 2, '#ff9aa8');
            if (Math.random() < 0.12) {
              host.particles.addDecal({ x: ex, y: ey, w: 7, h: 4, rot: 0, color: '#000', kind: 'scorch' });
            }
            h.cd -= dt;
            if (h.cd <= 0 && p.alive) {
              const d1 = distToSeg(p.x, p.y - p.h * 0.8, h.x, h.y, ex, ey);
              const d2 = distToSeg(p.x, p.y - p.h * 0.25, h.x, h.y, ex, ey);
              if (Math.min(d1, d2) < 18) h.cd = host.hurtPlayer(h.dmg, sign(Math.cos(h.a)), 150) ? 0.14 : 0.05;
            }
          }
          break;
        }
        case 'minion': {
          h.ox += dt * 1.6;
          const tx = pcx + Math.cos(h.ox) * 150;
          const ty = pcy - 150 + Math.sin(h.ox * 1.7) * 40;
          h.vx += ((tx - h.x) * 6 - h.vx * 2.4) * dt;
          h.vy += ((ty - h.y) * 6 - h.vy * 2.4) * dt;
          const sp = Math.hypot(h.vx, h.vy);
          if (sp > 420) {
            h.vx *= 420 / sp;
            h.vy *= 420 / sp;
          }
          h.x += h.vx * dt;
          h.y += h.vy * dt;
          h.rot = Math.sin(h.t * 6) * 0.3;
          h.dir = pcx >= h.x ? 1 : -1;
          h.cd -= dt;
          if (h.cd <= 0 && p.alive && w.los(h.x, h.y, pcx, pcy)) {
            host.enemyShoot(h.x, h.y, Math.atan2(pcy - h.y, pcx - h.x), 620, 7);
            h.cd = rand(1.5, 2.3);
            h.flash = 0.08;
          }
          break;
        }
      }
    }
    if (this.list.some((h) => !h.alive)) this.list = this.list.filter((h) => h.alive);
  }

  /** player bullet vs shootable hazards */
  hitTest(x1: number, y1: number, x2: number, y2: number): { h: Hazard; t: number } | null {
    let best: { h: Hazard; t: number } | null = null;
    for (const h of this.list) {
      if (!h.alive) continue;
      let r = 0;
      if (h.kind === 'cleaver' && !h.stuck) r = 15;
      else if (h.kind === 'dynamite') r = 13;
      else if (h.kind === 'bomb') r = 15;
      else if (h.kind === 'minion') r = 17;
      if (!r) continue;
      const t = segCircle(x1, y1, x2, y2, h.x, h.y, r);
      if (t !== null && (!best || t < best.t)) best = { h, t };
    }
    return best;
  }

  draw(ctx: CanvasRenderingContext2D, t: number) {
    for (const h of this.list) {
      if (!h.alive) continue;
      switch (h.kind) {
        case 'cleaver':
          drawCleaver(ctx, h);
          break;
        case 'dynamite':
          drawDynamite(ctx, h, t);
          break;
        case 'wave':
          drawWave(ctx, h);
          break;
        case 'bomb':
          drawBomb(ctx, h, t);
          break;
        case 'minion':
          drawMinion(ctx, h, t);
          break;
        default:
          break;
      }
    }
    for (const h of this.list) if (h.alive && h.kind === 'laser') drawLaser(ctx, h, t);
  }
}

function drawCleaver(ctx: CanvasRenderingContext2D, h: Hazard) {
  const fade = h.stuck ? clamp((h.life - h.t) / 0.5, 0, 1) : 1;
  ctx.save();
  ctx.globalAlpha = fade;
  ctx.translate(h.x, h.y);
  if (!h.stuck) {
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 20, h.rot, h.rot + 2.2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, 20, h.rot + Math.PI, h.rot + Math.PI + 2.2);
    ctx.stroke();
  }
  ctx.rotate(h.rot);
  ctx.lineJoin = 'round';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 1.6;
  ctx.fillStyle = '#5a3a1f';
  ctx.beginPath();
  ctx.roundRect(-19, -2.2, 12, 4.4, 1.5);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#c9ced4';
  ctx.beginPath();
  ctx.moveTo(-8, -7);
  ctx.lineTo(15, -8.5);
  ctx.lineTo(16, 7);
  ctx.lineTo(-8, 5.5);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#eef2f5';
  ctx.fillRect(-6, 3, 21, 2);
  ctx.fillStyle = '#8a1414';
  ctx.beginPath();
  ctx.ellipse(5, 0, 4, 1.8, 0.2, 0, TAU);
  ctx.fill();
  ctx.restore();
}

function drawDynamite(ctx: CanvasRenderingContext2D, h: Hazard, t: number) {
  const blink = h.life - h.t < 0.5 && Math.floor(t * 20) % 2 === 0;
  ctx.save();
  ctx.translate(h.x, h.y);
  ctx.rotate(h.rot);
  ctx.fillStyle = blink ? '#ffffff' : '#c0392b';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.roundRect(-4, -9, 8, 18, 2);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#1b1410';
  ctx.fillRect(-4, -2, 8, 3);
  ctx.strokeStyle = '#3a2a1a';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(0, -9);
  ctx.quadraticCurveTo(4, -13, 2, -16);
  ctx.stroke();
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(2, -16, 0, 2, -16, 9);
  g.addColorStop(0, 'rgba(255,240,170,0.95)');
  g.addColorStop(1, 'rgba(255,160,40,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(2, -16, 9, 0, TAU);
  ctx.fill();
  ctx.restore();
}

function drawWave(ctx: CanvasRenderingContext2D, h: Hazard) {
  const k = 1 - clamp(h.t / h.life, 0, 1) * 0.4;
  ctx.save();
  ctx.translate(h.x, h.y);
  ctx.scale(h.dir, 1);
  ctx.globalAlpha = 0.9 * k;
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-26, 0);
  ctx.quadraticCurveTo(-6, -36, 14, -32);
  ctx.quadraticCurveTo(4, -18, 10, 0);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,200,110,0.9)';
  ctx.beginPath();
  ctx.moveTo(-14, 0);
  ctx.quadraticCurveTo(-2, -21, 8, -21);
  ctx.quadraticCurveTo(2, -10, 6, 0);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawBomb(ctx: CanvasRenderingContext2D, h: Hazard, t: number) {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(h.x, h.y, 0, h.x, h.y, 26);
  g.addColorStop(0, `rgba(255,80,60,${0.35 + Math.sin(t * 20) * 0.15})`);
  g.addColorStop(1, 'rgba(255,80,60,0)');
  ctx.fillStyle = g;
  ctx.fillRect(h.x - 26, h.y - 26, 52, 52);
  ctx.restore();
  drawBanana(ctx, h.x, h.y, 0.6, h.rot, false);
}

function drawMinion(ctx: CanvasRenderingContext2D, h: Hazard, t: number) {
  const flap = Math.sin(t * 30 + h.ox * 3) * 0.6;
  ctx.save();
  ctx.translate(h.x, h.y);
  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 1.4;
  for (const sg of [-1, 1]) {
    ctx.save();
    ctx.rotate(sg * (0.5 + flap));
    ctx.beginPath();
    ctx.ellipse(sg * 4, -16, 5, 11, 0, 0, TAU);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
  ctx.scale(-h.dir, 1);
  drawBanana(ctx, 0, 0, 0.75, h.rot, true);
  ctx.rotate(h.rot);
  ctx.scale(0.75, 0.75);
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 1.8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-11.8, -7);
  ctx.lineTo(-7, -5.2);
  ctx.moveTo(-5.6, -4.6);
  ctx.lineTo(-1.4, -5.6);
  ctx.stroke();
  if (h.flash > 0) {
    ctx.fillStyle = '#fff6c8';
    ctx.beginPath();
    ctx.arc(-15, 3, 5, 0, TAU);
    ctx.fill();
  }
  ctx.restore();
}

function drawLaser(ctx: CanvasRenderingContext2D, h: Hazard, t: number) {
  const ex = h.x + Math.cos(h.a) * h.len;
  const ey = h.y + Math.sin(h.a) * h.len;
  ctx.save();
  ctx.lineCap = 'round';
  if (h.phase === 0) {
    const k = clamp(h.t / h.aimT, 0, 1);
    ctx.strokeStyle = `rgba(255,40,60,${0.4 + Math.random() * 0.45})`;
    ctx.lineWidth = 1.5 + k * 2;
    ctx.setLineDash([12, 8]);
    ctx.lineDashOffset = -t * 140;
    ctx.beginPath();
    ctx.moveTo(h.x, h.y);
    ctx.lineTo(ex, ey);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(h.x, h.y, 0, h.x, h.y, 12 + k * 26);
    g.addColorStop(0, 'rgba(255,240,240,0.95)');
    g.addColorStop(0.4, 'rgba(255,60,90,0.6)');
    g.addColorStop(1, 'rgba(255,0,60,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(h.x, h.y, 12 + k * 26, 0, TAU);
    ctx.fill();
  } else {
    ctx.globalCompositeOperation = 'lighter';
    const wob = 1 + Math.sin(t * 60) * 0.12;
    const layers: [number, string][] = [
      [36 * wob, 'rgba(255,40,80,0.26)'],
      [17 * wob, 'rgba(255,90,120,0.55)'],
      [6, 'rgba(255,255,255,0.95)'],
    ];
    for (const [lw, col] of layers) {
      ctx.strokeStyle = col;
      ctx.lineWidth = lw;
      ctx.beginPath();
      ctx.moveTo(h.x, h.y);
      ctx.lineTo(ex, ey);
      ctx.stroke();
    }
    for (const [cx, cy, r] of [
      [ex, ey, 44],
      [h.x, h.y, 34],
    ] as [number, number, number][]) {
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, 'rgba(255,255,255,0.9)');
      g.addColorStop(0.35, 'rgba(255,80,110,0.55)');
      g.addColorStop(1, 'rgba(255,0,60,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, TAU);
      ctx.fill();
    }
  }
  ctx.restore();
}
