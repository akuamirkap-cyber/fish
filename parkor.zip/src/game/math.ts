export interface Vec2 {
  x: number;
  y: number;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export const TAU = Math.PI * 2;

export const clamp = (v: number, lo: number, hi: number) => (v < lo ? lo : v > hi ? hi : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const rand = (a: number, b: number) => a + Math.random() * (b - a);
export const randi = (a: number, b: number) => Math.floor(rand(a, b + 1));
export const sign = (v: number) => (v < 0 ? -1 : 1);
export const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

export function approach(v: number, target: number, step: number) {
  return v < target ? Math.min(v + step, target) : Math.max(v - step, target);
}

export function wrapAngle(a: number) {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
}

export function angleLerp(a: number, b: number, t: number) {
  return a + wrapAngle(b - a) * t;
}

export function smooth(rate: number, dt: number) {
  return 1 - Math.exp(-rate * dt);
}

export function dist(ax: number, ay: number, bx: number, by: number) {
  return Math.hypot(bx - ax, by - ay);
}

export function rectOverlap(a: Rect, b: Rect) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

export function pointInRect(px: number, py: number, r: Rect) {
  return px >= r.x && px <= r.x + r.w && py >= r.y && py <= r.y + r.h;
}

export interface RayHit {
  t: number;
  nx: number;
  ny: number;
}

/** Segment (x1,y1)->(x2,y2) vs axis aligned rect. Returns entry param t in [0,1] */
export function segRect(x1: number, y1: number, x2: number, y2: number, r: Rect): RayHit | null {
  const dx = x2 - x1;
  const dy = y2 - y1;
  let tmin = 0;
  let tmax = 1;
  let nx = 0;
  let ny = 0;
  if (Math.abs(dx) < 1e-9) {
    if (x1 < r.x || x1 > r.x + r.w) return null;
  } else {
    const inv = 1 / dx;
    let t1 = (r.x - x1) * inv;
    let t2 = (r.x + r.w - x1) * inv;
    let n = -1;
    if (t1 > t2) {
      const tmp = t1;
      t1 = t2;
      t2 = tmp;
      n = 1;
    }
    if (t1 > tmin) {
      tmin = t1;
      nx = n;
      ny = 0;
    }
    if (t2 < tmax) tmax = t2;
    if (tmin > tmax) return null;
  }
  if (Math.abs(dy) < 1e-9) {
    if (y1 < r.y || y1 > r.y + r.h) return null;
  } else {
    const inv = 1 / dy;
    let t1 = (r.y - y1) * inv;
    let t2 = (r.y + r.h - y1) * inv;
    let n = -1;
    if (t1 > t2) {
      const tmp = t1;
      t1 = t2;
      t2 = tmp;
      n = 1;
    }
    if (t1 > tmin) {
      tmin = t1;
      nx = 0;
      ny = n;
    }
    if (t2 < tmax) tmax = t2;
    if (tmin > tmax) return null;
  }
  if (nx === 0 && ny === 0) {
    // started inside
    const len = Math.hypot(dx, dy) || 1;
    return { t: 0, nx: -dx / len, ny: -dy / len };
  }
  return { t: tmin, nx, ny };
}

/** Segment vs circle. Returns param t or null */
export function segCircle(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  cx: number,
  cy: number,
  rad: number,
): number | null {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const fx = x1 - cx;
  const fy = y1 - cy;
  const a = dx * dx + dy * dy;
  if (a < 1e-9) return fx * fx + fy * fy <= rad * rad ? 0 : null;
  const b = 2 * (fx * dx + fy * dy);
  const c = fx * fx + fy * fy - rad * rad;
  let disc = b * b - 4 * a * c;
  if (disc < 0) return null;
  disc = Math.sqrt(disc);
  const t1 = (-b - disc) / (2 * a);
  const t2 = (-b + disc) / (2 * a);
  if (t1 >= 0 && t1 <= 1) return t1;
  if (t1 < 0 && t2 >= 0) return 0;
  return null;
}

export function distToSeg(px: number, py: number, ax: number, ay: number, bx: number, by: number) {
  const dx = bx - ax;
  const dy = by - ay;
  const l2 = dx * dx + dy * dy;
  let t = l2 > 0 ? ((px - ax) * dx + (py - ay) * dy) / l2 : 0;
  t = clamp(t, 0, 1);
  return Math.hypot(px - (ax + dx * t), py - (ay + dy * t));
}

/** 2-bone IK. bend = +1/-1 chooses side of the joint */
export function ik2(
  ax: number,
  ay: number,
  tx: number,
  ty: number,
  l1: number,
  l2: number,
  bend: number,
) {
  let dx = tx - ax;
  let dy = ty - ay;
  let d = Math.hypot(dx, dy);
  const maxD = l1 + l2 - 0.01;
  if (d > maxD) {
    dx *= maxD / d;
    dy *= maxD / d;
    d = maxD;
  }
  const minD = Math.abs(l1 - l2) + 0.5;
  if (d < minD) {
    if (d < 1e-4) {
      dx = 0;
      dy = minD;
    } else {
      dx *= minD / d;
      dy *= minD / d;
    }
    d = minD;
  }
  const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
  const ux = dx / d;
  const uy = dy / d;
  const px = -uy * bend;
  const py = ux * bend;
  return {
    jx: ax + ux * a + px * h,
    jy: ay + uy * a + py * h,
    ex: ax + dx,
    ey: ay + dy,
  };
}

export function easeOutCubic(t: number) {
  const u = 1 - t;
  return 1 - u * u * u;
}

export function easeInOut(t: number) {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}

export function formatNum(n: number) {
  return Math.round(n)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

export function smoothstep(a: number, b: number, x: number) {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
}

function orient(ax: number, ay: number, bx: number, by: number, cx: number, cy: number) {
  return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
}

/** shortest distance between segments AB and CD (0 if they cross) */
export function segSegDist(
  ax: number,
  ay: number,
  bx: number,
  by: number,
  cx: number,
  cy: number,
  dx: number,
  dy: number,
) {
  const o1 = orient(ax, ay, bx, by, cx, cy);
  const o2 = orient(ax, ay, bx, by, dx, dy);
  const o3 = orient(cx, cy, dx, dy, ax, ay);
  const o4 = orient(cx, cy, dx, dy, bx, by);
  if (o1 * o2 < 0 && o3 * o4 < 0) return 0;
  return Math.min(
    distToSeg(ax, ay, cx, cy, dx, dy),
    distToSeg(bx, by, cx, cy, dx, dy),
    distToSeg(cx, cy, ax, ay, bx, by),
    distToSeg(dx, dy, ax, ay, bx, by),
  );
}

/** weighted random choice that avoids picking the same option three times in a row */
export function weightedPick<T>(opts: [T, number][], last: T[]): T {
  const f = opts.filter(([a]) => !(last.length >= 2 && last[0] === a && last[1] === a));
  const list = f.length ? f : opts;
  let total = 0;
  for (const [, w] of list) total += w;
  let r = Math.random() * total;
  for (const [a, w] of list) {
    r -= w;
    if (r <= 0) return a;
  }
  return list[list.length - 1][0];
}
