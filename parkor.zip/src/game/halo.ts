/**
 * HALO ARSENAL — jembatan antara SEMUA 83 senjata dari game Perfect Shot / Halo
 * dan engine parkour.
 *
 * Semua gambar senjata, kilatan moncong, proyektil, suara tembakan, suara kena target,
 * dan efek partikel tumbukan memakai kode ASLI dari Perfect Shot (`src/halo/gunhit/...`).
 */
import { drawFlash as artDrawFlash, drawGun as artDrawGun } from '../halo/gunhit/game/art/guns';
import { drawProjectile as artDrawProjectile } from '../halo/gunhit/game/art/projectiles';
import { drawRedesign8 } from '../halo/gunhit/game/art/redesign8';
import { gunState } from '../halo/gunhit/game/art/kit';
import { getGunMetrics } from '../halo/gunhit/game/art/metrics';
import {
  setNineIdFor,
  drawSetNineGun,
  restNineState,
  NINE_SCALE,
  type NineId,
} from '../halo/gunhit/game/setNineArt';
import {
  setElevenIdFor,
  drawSetElevenGun,
  restElevenState,
  elevenScale,
  type ElevenId,
} from '../halo/gunhit/game/setElevenArt';
import { ZIP_ART, hasZipArt, type ZipArt } from '../halo/gunhit/zipWeapons/index';
import { drawZipCrystalRound } from '../halo/gunhit/game/zipShotFx';
import { drawMaterialTrail } from '../halo/gunhit/game/art/projectileTrails';
import { drawSoakerWaterStream } from '../halo/gunhit/game/art/soakerWater';
import { sevenCooldown } from '../halo/gunhit/game/setSevenShot';
import { slideThreeIdFor } from '../halo/gunhit/game/setSevenArt';
import { WEAPONS as HALO_DEFS, type Weapon as HaloDef, type WeaponId as HaloArtId } from '../halo/gunhit/game/weapons';
import {
  PerfectShotFx,
  fxProfileOf,
  playPerfectShotFire,
  playPerfectShotHit,
  syncPerfectShotMute,
  unlockPerfectShotAudio,
  type LiveShotHandle,
} from './perfectShotBridge';

export {
  PerfectShotFx as HaloFx,
  fxProfileOf,
  playPerfectShotFire,
  playPerfectShotHit,
  syncPerfectShotMute,
  unlockPerfectShotAudio,
  type LiveShotHandle,
};

const TAU = Math.PI * 2;
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

export type HaloId = `h_${string}`;
export type HaloRarity = 'UMUM' | 'LANGKA' | 'EPIC' | 'LEGENDARIS';
export type HaloSound =
  | 'bullet' | 'auto' | 'heavy' | 'sniper' | 'energy' | 'beam' | 'rail' | 'launcher' | 'flame'
  | 'silent' | 'magic' | 'water' | 'ice' | 'void' | 'holy' | 'boom';

export const HALO_RARITY_COLOR: Record<HaloRarity, string> = {
  UMUM: '#b6bfcc',
  LANGKA: '#4f9bff',
  EPIC: '#c27bff',
  LEGENDARIS: '#ffb020',
};

export interface HaloSpec {
  id: HaloId;
  art: HaloArtId;
  def: HaloDef;
  name: string;
  rarity: HaloRarity;
  perk: string;
  /** warna utama (hex) & warna jejak "r,g,b" */
  color: string;
  rgb: string;
  sparks: string[];
  /** panjang senjata di dunia parkour (px), moncong -> popor */
  len: number;
  two: boolean;
  /** posisi gagang: gy = fraksi panjang dari moncong, gx = fraksi panjang ke sisi gagang */
  gy: number;
  gx: number;
  /** tangan penopang: fraksi panjang di depan gagang (senjata dua tangan) */
  fore: number;
  /** art aslinya punya gagang di sisi -x */
  flip: boolean;
  mag: number;
  cd: number;
  cdMin: number;
  dmg: number;
  speed: number;
  life: number;
  pellets: number;
  spread: number;
  pierce: number;
  pow: number;
  kick: number;
  shake: number;
  /** skala gambar proyektil */
  ps: number;
  sound: HaloSound;
  beam: boolean;
  explode: number;
  phase: boolean;
  burn: boolean;
  freeze: boolean;
  chain: boolean;
  pull: boolean;
  gravity: number;
  silent: boolean;
  scope: boolean;
  spinup: boolean;
  spin: boolean;
  bounce: number;
  bossMul: number;
  bonus: '' | 'gold' | 'fish' | 'diamond' | 'coin' | 'card' | 'chicken' | 'pizza' | 'sakura' | 'moon' | 'emerald' | 'ruby';
  heat: number;
}

interface Row {
  len: number;
  two?: boolean;
  g: [number, number];
  fore?: number;
  flip?: boolean;
  mag: number;
  cd: number;
  dmg: number;
  speed: number;
  x?: Partial<HaloSpec>;
}

/**
 * Tabel penyesuaian tiap senjata (83 senjata Perfect Shot) untuk dunia parkour.
 * g = [gy, gx] posisi gagang relatif dari moncong.
 */
const ROWS: Record<string, Row> = {
  // ======================== UMUM (17) ========================
  pistol:     { len: 25, g: [0.79, 0.27], mag: 12, cd: 0.14, dmg: 1.25, speed: 3300, x: { sound: 'bullet' } },
  ak47:       { len: 56, two: true, g: [0.64, 0.10], fore: 0.36, mag: 30, cd: 0.085, dmg: 1.25, speed: 3700, x: { sound: 'auto', heat: 0.1, kick: 2.2, shake: 1.4 } },
  mp5:        { len: 46, two: true, g: [0.66, 0.13], fore: 0.34, mag: 32, cd: 0.072, dmg: 1.05, speed: 3500, x: { sound: 'auto', heat: 0.08, kick: 1.6, shake: 1.0, spread: 0.02 } },
  nail:       { len: 28, g: [0.70, 0.27], mag: 40, cd: 0.07, dmg: 0.70, speed: 3200, x: { sound: 'silent', kick: 1.1, shake: 0.8, spread: 0.02 } },
  crossbow:   { len: 46, two: true, g: [0.68, 0.08], fore: 0.28, mag: 8, cd: 0.42, dmg: 3.6, speed: 3600, x: { sound: 'silent', pierce: 1, silent: true, kick: 2, shake: 1.4, ps: 0.5 } },
  longbow:    { len: 52, two: true, g: [0.56, 0.04], fore: 0.22, mag: 10, cd: 0.36, dmg: 4.2, speed: 4100, x: { sound: 'silent', pierce: 2, silent: true, kick: 1.8, shake: 1.2, ps: 0.56 } },
  shotgun:    { len: 50, two: true, g: [0.69, 0.09], fore: 0.42, mag: 8, cd: 0.60, dmg: 7.8, speed: 3000, x: { sound: 'heavy', kick: 9, shake: 8, life: 0.3, pow: 1150 } },
  slingshot:  { len: 24, g: [0.76, 0.00], mag: 20, cd: 0.36, dmg: 2.0, speed: 2100, x: { sound: 'silent', gravity: 420, spin: true, silent: true, kick: 0.8, shake: 0.6, ps: 0.5 } },
  blowgun:    { len: 58, two: true, g: [0.80, 0.02], fore: 0.34, mag: 20, cd: 0.18, dmg: 1.6, speed: 3300, x: { sound: 'silent', silent: true, kick: 0.6, shake: 0.4, spread: 0.004 } },
  soaker:     { len: 42, two: true, g: [0.72, 0.18], fore: 0.36, mag: 45, cd: 0.08, dmg: 0.75, speed: 2200, x: { sound: 'water', freeze: true, kick: 0.7, shake: 0.5, life: 0.6, ps: 0.5 } },
  snowball:   { len: 44, two: true, g: [0.72, 0.16], fore: 0.34, mag: 15, cd: 0.24, dmg: 1.8, speed: 2000, x: { sound: 'ice', freeze: true, gravity: 240, kick: 1.8, shake: 1.4, ps: 0.55 } },
  honey:      { len: 40, two: true, g: [0.72, 0.18], fore: 0.34, mag: 30, cd: 0.15, dmg: 1.1, speed: 2100, x: { sound: 'water', freeze: true, kick: 1.0, shake: 0.8, ps: 0.52 } },
  coconut:    { len: 48, two: true, g: [0.70, 0.12], fore: 0.32, mag: 8, cd: 0.42, dmg: 3.8, speed: 2100, x: { sound: 'water', gravity: 260, spin: true, kick: 4.5, shake: 4.0, ps: 0.62, pow: 950 } },
  pencil:     { len: 38, g: [0.74, 0.14], mag: 24, cd: 0.18, dmg: 1.9, speed: 3000, x: { sound: 'silent', silent: true, pierce: 1, kick: 1.2, shake: 1.0, ps: 0.5 } },
  sandal:     { len: 32, g: [0.74, 0.14], mag: 16, cd: 0.28, dmg: 3.2, speed: 2600, x: { sound: 'heavy', spin: true, kick: 3.6, shake: 3.2, ps: 0.62, pow: 950 } },
  paintball:  { len: 36, g: [0.76, 0.18], mag: 35, cd: 0.11, dmg: 1.05, speed: 2600, x: { sound: 'water', kick: 1.1, shake: 0.8, ps: 0.52 } },
  banana:     { len: 34, g: [0.74, 0.16], mag: 16, cd: 0.24, dmg: 2.0, speed: 2500, x: { sound: 'water', spin: true, kick: 1.6, shake: 1.4, ps: 0.55 } },

  // ======================== LANGKA (22) ========================
  sniper:       { len: 66, two: true, g: [0.63, 0.11], fore: 0.25, mag: 5, cd: 0.90, dmg: 10, speed: 6500, x: { perk: 'SCOPE & TEMBUS', sound: 'sniper', pierce: 4, scope: true, spread: 0.002, kick: 13, shake: 9, life: 0.45, pow: 1400 } },
  flamethrower: { len: 46, two: true, g: [0.77, 0.23], fore: 0.40, mag: 60, cd: 0.085, dmg: 0.6, speed: 1250, x: { sound: 'flame', burn: true, life: 0.55, spread: 0.07, kick: 0.6, shake: 0.5, ps: 0.55, pow: 300 } },
  plasma:       { len: 44, two: true, g: [0.81, 0.21], fore: 0.39, mag: 24, cd: 0.16, dmg: 2.4, speed: 1900, x: { perk: 'BOLA PLASMA', sound: 'energy', ps: 0.5, life: 1.1 } },
  laser:        { len: 44, two: true, g: [0.60, 0.23], fore: 0.22, mag: 30, cd: 0.14, dmg: 1.5, speed: 14000, x: { perk: 'SINAR INSTAN', sound: 'beam', beam: true, kick: 0.8, shake: 0.7, spread: 0.003 } },
  rpg:          { len: 60, two: true, g: [0.64, 0.11], fore: 0.24, mag: 4, cd: 0.80, dmg: 6.0, speed: 2100, x: { perk: 'ROKET LEDAK', sound: 'launcher', explode: 150, kick: 10, shake: 7, ps: 0.62, life: 1.2 } },
  bamboo:       { len: 54, two: true, g: [0.66, 0.07], fore: 0.30, mag: 5, cd: 0.70, dmg: 5.0, speed: 1700, x: { sound: 'boom', explode: 130, kick: 11, shake: 9, ps: 0.6, life: 1.2 } },
  fish:         { len: 30, g: [0.81, 0.09], mag: 20, cd: 0.20, dmg: 1.7, speed: 1700, x: { perk: 'IKAN HOKI', sound: 'water', bonus: 'fish', ps: 0.55, life: 1.1, kick: 1.4, shake: 1 } },
  bubble:       { len: 30, g: [0.76, 0.18], mag: 24, cd: 0.18, dmg: 1.4, speed: 1650, x: { sound: 'water', ps: 0.58, life: 1.1, kick: 0.8, shake: 0.6 } },
  harpoon:      { len: 52, two: true, g: [0.68, 0.10], fore: 0.30, mag: 8, cd: 0.36, dmg: 4.0, speed: 3400, x: { sound: 'silent', pierce: 2, kick: 3.4, shake: 2.5, ps: 0.58, pow: 1050 } },
  chicken:      { len: 32, g: [0.74, 0.14], mag: 16, cd: 0.28, dmg: 2.2, speed: 2100, x: { sound: 'water', bonus: 'chicken', ps: 0.62, life: 0.9, kick: 2.0, shake: 1.5 } },
  confetti:     { len: 42, two: true, g: [0.70, 0.14], fore: 0.34, mag: 16, cd: 0.24, dmg: 1.9, speed: 2300, x: { sound: 'magic', ps: 0.55, kick: 2.4, shake: 2.0 } },
  seed:         { len: 36, g: [0.74, 0.16], mag: 20, cd: 0.20, dmg: 1.7, speed: 2400, x: { sound: 'silent', ps: 0.52, kick: 1.2, shake: 1.0 } },
  pizza:        { len: 38, two: true, g: [0.72, 0.14], fore: 0.32, mag: 16, cd: 0.24, dmg: 2.1, speed: 2200, x: { sound: 'water', bonus: 'pizza', spin: true, ps: 0.6, kick: 2.0, shake: 1.6 } },
  angklung:     { len: 40, g: [0.72, 0.08], mag: 20, cd: 0.22, dmg: 2.1, speed: 2500, x: { sound: 'magic', ps: 0.55, kick: 1.6, shake: 1.2 } },
  bee:          { len: 36, g: [0.74, 0.16], mag: 32, cd: 0.13, dmg: 1.2, speed: 2700, x: { sound: 'auto', burn: true, ps: 0.52, kick: 1.4, shake: 1.0 } },
  sakura:       { len: 38, g: [0.72, 0.14], mag: 24, cd: 0.18, dmg: 1.9, speed: 2600, x: { sound: 'magic', bonus: 'sakura', ps: 0.56, kick: 1.4, shake: 1.0 } },
  ruby:         { len: 30, g: [0.78, 0.22], mag: 6, cd: 0.26, dmg: 3.8, speed: 3500, x: { sound: 'bullet', bonus: 'ruby', kick: 4.0, shake: 3.2, pow: 950, ps: 0.5 } },
  cryo_blaster: { len: 42, two: true, g: [0.72, 0.16], fore: 0.32, mag: 24, cd: 0.18, dmg: 1.8, speed: 2700, x: { sound: 'ice', freeze: true, ps: 0.54, kick: 2.2, shake: 1.8 } },
  hyperdrive:   { len: 46, two: true, g: [0.72, 0.16], fore: 0.32, mag: 24, cd: 0.18, dmg: 2.6, speed: 4000, x: { sound: 'energy', pierce: 1, ps: 0.54, kick: 2.8, shake: 2.2 } },
  ion_smg:      { len: 44, two: true, g: [0.68, 0.14], fore: 0.34, mag: 36, cd: 0.085, dmg: 1.35, speed: 3600, x: { sound: 'energy', ps: 0.5, kick: 1.6, shake: 1.2 } },
  dora:         { len: 42, two: true, g: [0.70, 0.14], fore: 0.32, mag: 12, cd: 0.34, dmg: 3.5, speed: 2400, x: { sound: 'boom', pow: 1450, ps: 0.65, kick: 5.5, shake: 4.8 } },
  xeno:         { len: 44, two: true, g: [0.70, 0.12], fore: 0.30, mag: 18, cd: 0.24, dmg: 2.1, speed: 2300, x: { sound: 'flame', burn: true, gravity: 180, ps: 0.58, kick: 2.4, shake: 2.0 } },

  // ======================== EPIC (25) ========================
  minigun:            { len: 58, two: true, g: [0.75, 0.13], fore: 0.29, mag: 150, cd: 0.20, dmg: 0.9, speed: 3600, x: { sound: 'auto', spinup: true, cdMin: 0.04, spread: 0.035, kick: 1.5, shake: 1.5 } },
  railgun:            { len: 58, two: true, g: [0.74, 0.07], fore: 0.34, mag: 6, cd: 0.70, dmg: 8.0, speed: 9500, x: { perk: 'TEMBUS SEMUA', sound: 'rail', beam: true, pierce: 99, kick: 12, shake: 9, spread: 0.001, pow: 1300 } },
  electro:            { len: 38, g: [0.77, 0.23], mag: 24, cd: 0.18, dmg: 1.5, speed: 2800, x: { perk: 'PETIR BERANTAI', sound: 'energy', chain: true, ps: 0.5 } },
  bazooka:            { len: 64, two: true, g: [0.63, 0.11], fore: 0.25, mag: 3, cd: 0.90, dmg: 8.0, speed: 1500, x: { perk: 'LEDAKAN BESAR', sound: 'launcher', explode: 185, kick: 13, shake: 9, ps: 0.66, life: 1.5 } },
  keris:              { len: 36, g: [0.76, 0.00], mag: 12, cd: 0.25, dmg: 3.0, speed: 3000, x: { perk: 'TEMBUS 3 MUSUH', sound: 'magic', pierce: 3, silent: true, kick: 1, shake: 0.8, ps: 0.55 } },
  shark:              { len: 56, two: true, g: [0.58, 0.16], fore: 0.23, mag: 6, cd: 0.45, dmg: 6.0, speed: 2600, x: { perk: 'GIGITAN HIU', sound: 'water', kick: 8, shake: 6, ps: 0.7, life: 0.9, pow: 1200 } },
  ghost:              { len: 30, g: [0.75, 0.00], mag: 20, cd: 0.22, dmg: 2.0, speed: 1900, x: { perk: 'TEMBUS TEMBOK', sound: 'void', phase: true, silent: true, ps: 0.55, life: 1.1, kick: 0.8, shake: 0.6 } },
  cricket:            { len: 22, g: [0.76, 0.24], mag: 4, cd: 0.52, dmg: 6.5, speed: 3100, x: { perk: 'LEDAKAN BRUTAL', sound: 'boom', explode: 175, kick: 14, shake: 12, ps: 0.6, pow: 1400 } },
  magnet:             { len: 42, two: true, g: [0.72, 0.16], fore: 0.30, mag: 16, cd: 0.26, dmg: 2.2, speed: 2800, x: { sound: 'energy', pull: true, ps: 0.55, kick: 2.4, shake: 2.0 } },
  pirate:             { len: 54, two: true, g: [0.68, 0.10], fore: 0.30, mag: 5, cd: 0.62, dmg: 6.0, speed: 2000, x: { sound: 'boom', pierce: 2, kick: 10, shake: 8, ps: 0.72, pow: 1350 } },
  card:               { len: 30, g: [0.78, 0.20], mag: 28, cd: 0.16, dmg: 1.8, speed: 3400, x: { sound: 'silent', silent: true, bonus: 'card', spin: true, pierce: 1, ps: 0.5, kick: 1.1, shake: 0.8 } },
  yoyo:               { len: 32, g: [0.74, 0.14], mag: 16, cd: 0.24, dmg: 2.6, speed: 2700, x: { sound: 'magic', bounce: 3, spin: true, ps: 0.58, kick: 1.8, shake: 1.4 } },
  firework:           { len: 52, two: true, g: [0.68, 0.12], fore: 0.30, mag: 6, cd: 0.48, dmg: 4.5, speed: 2100, x: { sound: 'launcher', explode: 155, ps: 0.62, life: 1.1, kick: 6.5, shake: 5.5 } },
  ufo:                { len: 36, g: [0.74, 0.16], mag: 20, cd: 0.22, dmg: 2.3, speed: 2800, x: { sound: 'energy', pull: true, ps: 0.56, kick: 2.2, shake: 1.8 } },
  emerald:            { len: 44, two: true, g: [0.68, 0.18], fore: 0.30, mag: 20, cd: 0.20, dmg: 3.0, speed: 14000, x: { perk: 'SINAR ZAMRUD', sound: 'beam', beam: true, pierce: 2, bonus: 'emerald', kick: 2.0, shake: 1.6 } },
  sapphire:           { len: 48, two: true, g: [0.70, 0.12], fore: 0.38, mag: 8, cd: 0.52, dmg: 2.2, speed: 2900, x: { sound: 'ice', pellets: 3, spread: 0.08, freeze: true, kick: 7.5, shake: 6.5, life: 0.45, pow: 1050 } },
  crystal:            { len: 46, two: true, g: [0.70, 0.14], fore: 0.32, mag: 14, cd: 0.32, dmg: 4.0, speed: 2800, x: { sound: 'magic', pierce: 2, ps: 0.6, kick: 4.5, shake: 3.8 } },
  beerifle:           { len: 56, two: true, g: [0.66, 0.12], fore: 0.28, mag: 10, cd: 0.36, dmg: 4.8, speed: 5200, x: { sound: 'sniper', scope: true, burn: true, pierce: 2, ps: 0.52, kick: 5.0, shake: 4.2 } },
  coingun:            { len: 34, g: [0.76, 0.20], mag: 30, cd: 0.16, dmg: 1.8, speed: 3200, x: { sound: 'bullet', bonus: 'coin', ps: 0.55, kick: 1.8, shake: 1.4 } },
  tesla_rifle:        { len: 52, two: true, g: [0.68, 0.14], fore: 0.32, mag: 18, cd: 0.24, dmg: 2.8, speed: 3000, x: { sound: 'energy', chain: true, ps: 0.56, kick: 3.2, shake: 2.6 } },
  identity_disc:      { len: 32, g: [0.72, 0.14], mag: 12, cd: 0.28, dmg: 3.6, speed: 3100, x: { sound: 'energy', bounce: 4, pierce: 2, spin: true, ps: 0.62, kick: 2.0, shake: 1.6 } },
  proton_pack:        { len: 50, two: true, g: [0.68, 0.14], fore: 0.32, mag: 24, cd: 0.16, dmg: 2.6, speed: 14000, x: { perk: 'ALIRAN PROTON', sound: 'beam', beam: true, burn: true, pierce: 2, kick: 2.4, shake: 2.0 } },
  mega_buster:        { len: 38, g: [0.72, 0.12], mag: 20, cd: 0.20, dmg: 3.2, speed: 3300, x: { sound: 'energy', pierce: 1, ps: 0.62, kick: 3.0, shake: 2.4 } },
  harmonic_disruptor: { len: 46, two: true, g: [0.70, 0.14], fore: 0.32, mag: 16, cd: 0.26, dmg: 3.0, speed: 2700, x: { sound: 'energy', pow: 1450, ps: 0.6, kick: 4.2, shake: 3.6 } },
  nano_swarm:         { len: 44, two: true, g: [0.70, 0.14], fore: 0.32, mag: 36, cd: 0.13, dmg: 1.3, speed: 2600, x: { sound: 'energy', pellets: 2, spread: 0.06, ps: 0.52, kick: 1.6, shake: 1.4 } },

  // ======================== LEGENDARIS (19) ========================
  freeze:          { len: 36, g: [0.78, 0.17], mag: 24, cd: 0.18, dmg: 1.0, speed: 2400, x: { sound: 'ice', freeze: true, ps: 0.5 } },
  golden:          { len: 28, g: [0.78, 0.20], mag: 7, cd: 0.20, dmg: 4.0, speed: 3400, x: { perk: 'BONUS SKOR', sound: 'bullet', bonus: 'gold', kick: 3.4, shake: 2.4, pow: 900 } },
  blackhole:       { len: 36, g: [0.69, 0.04], mag: 5, cd: 0.60, dmg: 3.0, speed: 1250, x: { perk: 'SEDOT MUSUH', sound: 'void', pull: true, ps: 0.6, life: 1.4, kick: 3, shake: 3 } },
  dragon:          { len: 50, two: true, g: [0.70, 0.06], fore: 0.30, mag: 20, cd: 0.22, dmg: 2.2, speed: 2000, x: { sound: 'flame', burn: true, bossMul: 2, ps: 0.6, life: 0.9, kick: 3, shake: 2.4 } },
  meteor:          { len: 52, two: true, g: [0.70, 0.09], fore: 0.30, mag: 3, cd: 1.00, dmg: 10, speed: 1400, x: { perk: 'LEDAKAN METEOR', sound: 'launcher', explode: 200, kick: 13, shake: 10, ps: 0.7, life: 1.6 } },
  diamond:         { len: 32, g: [0.74, 0.12], mag: 24, cd: 0.16, dmg: 1.7, speed: 3400, x: { perk: 'BONUS BERLIAN', sound: 'magic', pierce: 1, bonus: 'diamond', ps: 0.5 } },
  holy:            { len: 40, g: [0.57, 0.22], mag: 8, cd: 0.50, dmg: 6.0, speed: 14000, x: { perk: 'SINAR SUCI', sound: 'holy', beam: true, pierce: 3, kick: 5, shake: 4, spread: 0.001 } },
  gravity:         { len: 48, two: true, g: [0.70, 0.14], fore: 0.32, mag: 14, cd: 0.26, dmg: 2.8, speed: 2400, x: { sound: 'void', pull: true, ps: 0.58, kick: 3.4, shake: 2.8 } },
  moonbeam:        { len: 44, g: [0.72, 0.04], mag: 20, cd: 0.18, dmg: 2.8, speed: 3700, x: { sound: 'magic', bonus: 'moon', pierce: 1, ps: 0.58, kick: 2.0, shake: 1.6 } },
  storm:           { len: 48, two: true, g: [0.70, 0.12], fore: 0.30, mag: 16, cd: 0.24, dmg: 3.0, speed: 3200, x: { sound: 'energy', chain: true, ps: 0.58, kick: 4.0, shake: 3.4 } },
  obliterator:     { len: 60, two: true, g: [0.68, 0.14], fore: 0.32, mag: 5, cd: 0.55, dmg: 8.5, speed: 1900, x: { perk: 'PEMUSNAH', sound: 'rail', explode: 185, chain: true, ps: 0.72, kick: 11, shake: 9 } },
  blaster:         { len: 34, g: [0.75, 0.20], mag: 24, cd: 0.15, dmg: 3.2, speed: 3600, x: { sound: 'energy', ps: 0.58, kick: 2.6, shake: 2.0 } },
  photon_saber:    { len: 44, g: [0.78, 0.04], mag: 18, cd: 0.22, dmg: 3.8, speed: 3400, x: { sound: 'energy', pierce: 2, ps: 0.64, kick: 2.8, shake: 2.2 } },
  gauntlet_cannon: { len: 36, g: [0.70, 0.10], mag: 10, cd: 0.34, dmg: 5.5, speed: 2800, x: { sound: 'launcher', explode: 145, ps: 0.66, kick: 8.5, shake: 7.0 } },
  heat_ray:        { len: 54, two: true, g: [0.68, 0.12], fore: 0.30, mag: 16, cd: 0.24, dmg: 4.5, speed: 14000, x: { perk: 'SINAR PANAS', sound: 'beam', beam: true, burn: true, pierce: 2, kick: 4.5, shake: 3.8 } },
  absolute_zero:   { len: 46, two: true, g: [0.70, 0.14], fore: 0.32, mag: 16, cd: 0.26, dmg: 3.2, speed: 3500, x: { sound: 'ice', freeze: true, pierce: 2, ps: 0.58, kick: 3.0, shake: 2.5 } },
  helios_flare:    { len: 54, two: true, g: [0.68, 0.14], fore: 0.32, mag: 8, cd: 0.44, dmg: 6.5, speed: 2100, x: { sound: 'launcher', explode: 170, burn: true, ps: 0.66, kick: 7.5, shake: 6.0 } },
  orbital_beacon:  { len: 48, two: true, g: [0.68, 0.14], fore: 0.30, mag: 8, cd: 0.38, dmg: 7.0, speed: 14000, x: { perk: 'SERANGAN ORBITAL', sound: 'rail', beam: true, pierce: 5, kick: 6.5, shake: 5.5 } },
  singularity:     { len: 54, two: true, g: [0.68, 0.14], fore: 0.32, mag: 6, cd: 0.46, dmg: 4.5, speed: 1500, x: { perk: 'HORIZON PERISTIWA', sound: 'void', pull: true, ps: 0.66, life: 1.5, kick: 5.0, shake: 4.5 } },
};

/** penjelasan tiap senjata sesuai perilakunya di game parkour */
export const HALO_DESC: Record<string, string> = Object.fromEntries(
  HALO_DEFS.map((d) => [d.id, d.desc]),
);

function hexToRgb(c: string): string {
  if (!c.startsWith('#')) return c;
  let h = c.slice(1);
  if (h.length === 3) h = h.split('').map((ch) => ch + ch).join('');
  return `${parseInt(h.slice(0, 2), 16)},${parseInt(h.slice(2, 4), 16)},${parseInt(h.slice(4, 6), 16)}`;
}

export const HALO_SPECS: Record<string, HaloSpec> = {};
export const HALO_ORDER: HaloId[] = [];

for (const def of HALO_DEFS) {
  const row = ROWS[def.id];
  if (!row) continue;
  const id = `h_${def.id}` as HaloId;
  const spec: HaloSpec = {
    id,
    art: def.id,
    def,
    name: def.name,
    rarity: def.rarity as HaloRarity,
    perk: def.perk,
    color: def.color,
    rgb: def.trail,
    sparks: def.sparks.map(hexToRgb),
    len: Math.round(row.len * 1.2),
    two: !!row.two,
    gy: row.g[0],
    gx: row.g[1],
    fore: row.fore ?? 0.3,
    flip: !!row.flip,
    mag: row.mag,
    cd: sevenCooldown(slideThreeIdFor(def.id) ?? def.id) ?? row.cd,
    cdMin: sevenCooldown(slideThreeIdFor(def.id) ?? def.id) ?? row.cd,
    dmg: row.dmg,
    speed: row.speed,
    life: 0.55,
    pellets: 1,
    spread: 0.012,
    pierce: 0,
    pow: 650,
    kick: 2.4,
    shake: 1.8,
    ps: 0.42,
    sound: 'bullet',
    beam: false,
    explode: 0,
    phase: false,
    burn: false,
    freeze: false,
    chain: false,
    pull: false,
    gravity: 0,
    silent: false,
    scope: false,
    spinup: false,
    spin: false,
    bounce: 0,
    bossMul: 1,
    bonus: '',
    heat: 0,
    ...(row.x ?? {}),
  };
  HALO_SPECS[id] = spec;
  HALO_ORDER.push(id);
}

export function isHaloId(s: unknown): s is HaloId {
  return typeof s === 'string' && s.charCodeAt(0) === 104 && s.charCodeAt(1) === 95 && s in HALO_SPECS;
}

export function haloSpec(id: string): HaloSpec {
  return HALO_SPECS[id];
}

// ------------------------------------------------------------------ live state
/** keadaan animasi senjata yang sedang dipegang pemain; diisi game tiap frame */
export const haloLive = {
  time: 0,
  sinceShot: 9,
  spin: 0,
  spinAngle: 0,
  charge: 0,
  ammoRatio: 1,
  shots: 0,
  ready: true,
};

function applyGunState(live: boolean) {
  const gs = gunState as Record<string, unknown>;
  gs.sinceShot = live ? haloLive.sinceShot : 9;
  gs.reloadT = 0;
  gs.spin = live ? haloLive.spin : 0;
  gs.spinAngle = live ? haloLive.spinAngle : 0;
  gs.charge = live ? haloLive.charge : 0;
  gs.ammoRatio = live ? haloLive.ammoRatio : 1;
  gs.shots = live ? haloLive.shots : 0;
  gs.inPreview = !live;
  gs.bigShot = 0;
}

// ------------------------------------------------------------------ zip (SVG) art
interface ZipRaster {
  art: ZipArt;
  /** panjang moncong -> popor dalam unit SVG */
  len: number;
  idle: HTMLCanvasElement | null;
  fire: HTMLCanvasElement | null;
  /** kotak potong (unit SVG) */
  cx: number;
  cy: number;
  cw: number;
  ch: number;
  failed: boolean;
}

const RASTER_PX = 280;
const zipRasters: Record<string, ZipRaster> = {};
let artVersion = 0;
/** naik tiap kali sebuah art SVG selesai dirender (untuk menggambar ulang ikon) */
export const haloArtVersion = () => artVersion;

function buildSvg(markup: string, cx: number, cy: number, cw: number, ch: number, pxPerUnit: number, firing: boolean): string {
  const w = Math.ceil(cw * pxPerUnit);
  const h = Math.ceil(ch * pxPerUnit);
  let s = markup.replace(/viewBox="[^"]*"/, `viewBox="${cx} ${cy} ${cw} ${ch}" width="${w}" height="${h}"`);
  s = s.replace(/^<svg style="[^"]*"/, '<svg');
  if (firing) {
    s = s.replace(/class="weapon-svg/, 'class="weapon-svg wx-is-firing');
    s = s.replace(/(<svg[^>]*>)/, '$1<style>*{animation-play-state:paused!important;animation-delay:-0.07s!important}</style>');
  }
  // Strip bloom from imported SVG weapon packs without altering their geometry.
  const close = s.lastIndexOf('</svg>');
  if (close !== -1) s = s.slice(0, close) + '<style>*{filter:none!important;box-shadow:none!important;text-shadow:none!important;mix-blend-mode:normal!important}</style>' + s.slice(close);
  return s;
}

function rasterize(svg: string, w: number, h: number, done: (cv: HTMLCanvasElement | null) => void) {
  const img = new Image();
  img.onload = () => {
    try {
      const cv = document.createElement('canvas');
      cv.width = w;
      cv.height = h;
      const c = cv.getContext('2d');
      if (!c) return done(null);
      c.drawImage(img, 0, 0, w, h);
      done(cv);
    } catch {
      done(null);
    }
  };
  img.onerror = () => done(null);
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}

function initZip(artId: string) {
  if (zipRasters[artId]) return;
  const art = (ZIP_ART as Record<string, ZipArt>)[artId];
  if (!art) return;
  const ink = art.ink;
  const len = Math.max(1, ink.y1 - ink.muzzleY);
  const mx = 70;
  const top = 150;
  const cx = ink.x0 - mx;
  const cy = Math.min(ink.y0, ink.muzzleY) - top;
  const cw = ink.x1 - ink.x0 + mx * 2;
  const ch = ink.y1 + 40 - cy;
  const r: ZipRaster = { art, len, idle: null, fire: null, cx, cy, cw, ch, failed: false };
  zipRasters[artId] = r;
  const ppu = RASTER_PX / len;
  const w = Math.max(1, Math.ceil(cw * ppu));
  const h = Math.max(1, Math.ceil(ch * ppu));
  rasterize(buildSvg(art.markup, cx, cy, cw, ch, ppu, false), w, h, (cv) => {
    if (cv) r.idle = cv;
    else r.failed = true;
    artVersion++;
  });
  const fireSrc = art.fireMarkup
    ? buildSvg(art.fireMarkup, cx, cy, cw, ch, ppu, false)
    : /wx-is-firing/.test(art.markup)
      ? buildSvg(art.markup, cx, cy, cw, ch, ppu, true)
      : null;
  if (fireSrc) {
    rasterize(fireSrc, w, h, (cv) => {
      r.fire = cv;
      artVersion++;
    });
  }
}

let zipStarted = false;
/** mulai merender semua art SVG (dipanggil sekali; aman dipanggil berulang) */
export function preloadHaloArt() {
  if (zipStarted || typeof document === 'undefined') return;
  zipStarted = true;
  const ids = Object.keys(ZIP_ART).filter((id) => hasZipArt(id));
  ids.forEach((id, i) => setTimeout(() => initZip(id), 25 + i * 35));
}

const NINE_EXCLUSIVE = new Set<string>(['longbow', 'mp5', 'tesla_rifle', 'identity_disc', 'proton_pack']);
const ELEVEN_EXCLUSIVE = new Set<string>([
  'mega_buster', 'harmonic_disruptor', 'absolute_zero', 'helios_flare', 'orbital_beacon', 'singularity', 'nano_swarm', 'ion_smg',
]);

// Keep the source weapon silhouettes and paint, but never apply additive bloom.
const flatContexts = new WeakMap<CanvasRenderingContext2D, CanvasRenderingContext2D>();
function flatArtContext(ctx: CanvasRenderingContext2D): CanvasRenderingContext2D {
  let flat = flatContexts.get(ctx);
  if (!flat) {
    flat = new Proxy(ctx, {
      get(target, key) {
        const value = Reflect.get(target, key, target);
        return typeof value === 'function' ? value.bind(target) : value;
      },
      set(target, key, value) {
        if (key === 'shadowBlur') value = 0;
        if (key === 'globalCompositeOperation' && value === 'lighter') value = 'source-over';
        return Reflect.set(target, key, value, target);
      },
    });
    flatContexts.set(ctx, flat);
  }
  return flat;
}

/**
 * Gambar art tegak: moncong di (0,0), laras ke +y, panjang senjata = 1 unit.
 * `flash` 0..1 = kilatan moncong.
 */
function drawArtUnit(ctx: CanvasRenderingContext2D, spec: HaloSpec, flash: number, live: boolean) {
  ctx = flatArtContext(ctx);
  const artId = spec.art;
  const t = haloLive.time;
  applyGunState(live);

  // 1. Zip SVG packs (31 active Perfect Shot SVG weapons)
  if (hasZipArt(artId)) {
    initZip(artId);
    const z = zipRasters[artId];
    if (z && z.idle) {
      const k = 1 / z.len;
      const firing = live && z.fire && (flash > 0 || haloLive.sinceShot < 0.09);
      const cv = firing ? (z.fire as HTMLCanvasElement) : z.idle;
      ctx.save();
      ctx.scale(k, k);
      ctx.drawImage(cv, z.cx - z.art.ink.muzzleX, z.cy - z.art.ink.muzzleY, z.cw, z.ch);
      ctx.restore();
      if (flash > 0) {
        const canvasLen = getGunMetrics(artId).totalLen;
        ctx.save();
        ctx.scale(1 / canvasLen, 1 / canvasLen);
        try { artDrawFlash(ctx, artId, 0, 0, t, flash); } catch { /* ignore */ }
        ctx.restore();
      }
      return;
    }
  }

  // 2. Redesign8 (Noisy Cricket, Martian Heat-Ray)
  if (artId === 'cricket' || artId === 'heat_ray') {
    const canvasLen = artId === 'heat_ray' ? 268 : 172;
    ctx.save();
    ctx.scale(1 / canvasLen, 1 / canvasLen);
    const ok = drawRedesign8(ctx, artId, artId === 'heat_ray' ? 'zip' : 'current', 0, 0, t, live ? haloLive.sinceShot : 9);
    ctx.restore();
    if (ok) {
      if (flash > 0) {
        ctx.save();
        ctx.scale(1 / canvasLen, 1 / canvasLen);
        try { artDrawFlash(ctx, artId, 0, 0, t, flash); } catch { /* ignore */ }
        ctx.restore();
      }
      return;
    }
  }

  // 3. Slide-9 exclusive guns (Longbow, MP5, Tesla Rifle, Identity Disc, Proton Pack)
  if (NINE_EXCLUSIVE.has(artId)) {
    const nineId = setNineIdFor(artId) as NineId | null;
    if (nineId) {
      const canvasLen = 190;
      const recoil = live ? clamp01(1 - haloLive.sinceShot / 0.22) : 0;
      ctx.save();
      ctx.scale(1 / canvasLen, 1 / canvasLen);
      drawSetNineGun(ctx, nineId, 0, 0, t, restNineState({ recoil, t }), NINE_SCALE, live);
      ctx.restore();
      if (flash > 0) {
        ctx.save();
        ctx.scale(1 / canvasLen, 1 / canvasLen);
        try { artDrawFlash(ctx, artId, 0, 0, t, flash); } catch { /* ignore */ }
        ctx.restore();
      }
      return;
    }
  }

  // 4. Slide-11 exclusive guns (Mega Buster, Harmonic Disruptor, Absolute Zero, Helios Flare, Orbital Beacon, Singularity, Nano-Swarm, Ion SMG)
  if (ELEVEN_EXCLUSIVE.has(artId)) {
    const elevenId = setElevenIdFor(artId) as ElevenId | null;
    if (elevenId) {
      const canvasLen = 190;
      const recoil = live ? clamp01(1 - haloLive.sinceShot / 0.22) : 0;
      const ws = restElevenState();
      ws.recoil = recoil;
      ctx.save();
      ctx.scale(1 / canvasLen, 1 / canvasLen);
      drawSetElevenGun(ctx, elevenId, 0, 0, t, ws, elevenScale(elevenId), live);
      ctx.restore();
      if (flash > 0) {
        ctx.save();
        ctx.scale(1 / canvasLen, 1 / canvasLen);
        try { artDrawFlash(ctx, artId, 0, 0, t, flash); } catch { /* ignore */ }
        ctx.restore();
      }
      return;
    }
  }

  // 5. Perfect Shot canvas gun renderers (guns.ts .. guns8.ts)
  const canvasLen = getGunMetrics(artId).totalLen;
  ctx.save();
  ctx.scale(1 / canvasLen, 1 / canvasLen);
  try {
    artDrawGun(ctx, artId, 0, 0, t, flash, live ? haloLive.ready : true);
  } catch {
    /* jangan pernah menjatuhkan game karena satu gambar */
  }
  ctx.restore();
}

/** untuk lembar kontak / debugging: art tegak, panjang = `len` px */
export function drawHaloUpright(ctx: CanvasRenderingContext2D, id: string, x: number, y: number, len: number, flash = 0) {
  const spec = HALO_SPECS[id];
  if (!spec) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(len, len);
  drawArtUnit(ctx, spec, flash, flash > 0);
  ctx.restore();
}

/**
 * Senjata di tangan: (x,y) = posisi tangan (gagang), `angle` = arah bidik.
 * Moncong dijamin menghadap `angle`; saat membidik ke kiri art dicerminkan
 * agar gagang & magasin tetap di bawah.
 */
export function drawHaloGun(ctx: CanvasRenderingContext2D, id: string, x: number, y: number, angle: number, flashT: number, live = true) {
  const spec = HALO_SPECS[id];
  if (!spec) return;
  const flash = clamp01(flashT / 0.07);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle + Math.PI / 2);
  const right = Math.cos(angle) >= 0;
  const sx = (right ? 1 : -1) * (spec.flip ? -1 : 1);
  ctx.scale(spec.len * sx, spec.len);
  ctx.translate(-spec.gx * (spec.flip ? -1 : 1), -spec.gy);
  drawArtUnit(ctx, spec, flash, live);
  ctx.restore();
}

/** offset moncong dari tangan: sepanjang laras & tegak lurus (gaya `Player.muzzle`) */
export function haloMuzzleOffset(id: string): { along: number; ly: number } {
  const s = HALO_SPECS[id];
  return { along: s.gy * s.len, ly: -s.gx * s.len };
}

const ICON_W = 208;
const ICON_H = 112;
const iconCache = new Map<string, { cv: HTMLCanvasElement; ver: number }>();

function renderIcon(ctx: CanvasRenderingContext2D, spec: HaloSpec) {
  const thick = spec.art === 'holy' ? 0.95 : spec.art === 'crossbow' || spec.art === 'dragon' || spec.art === 'longbow' ? 0.8 : 0.52;
  const s = Math.min(ICON_W * 0.94, ICON_H / thick);
  ctx.save();
  ctx.translate(ICON_W / 2, ICON_H / 2);
  ctx.rotate(Math.PI / 2);
  ctx.scale(s * (spec.flip ? -1 : 1), s);
  ctx.translate(-(spec.gx * 0.45) * (spec.flip ? -1 : 1), -0.5);
  drawArtUnit(ctx, spec, 0, false);
  ctx.restore();
}

/**
 * ikon mendatar (moncong ke kanan) yang pas di kotak w x h berpusat di (cx,cy).
 */
export function drawHaloIcon(ctx: CanvasRenderingContext2D, id: string, cx: number, cy: number, w: number, h: number) {
  const spec = HALO_SPECS[id];
  if (!spec) return;
  let ic = iconCache.get(id);
  if (!ic || ic.ver !== artVersion) {
    const cv = ic ? ic.cv : document.createElement('canvas');
    cv.width = ICON_W;
    cv.height = ICON_H;
    const c = cv.getContext('2d');
    if (c) renderIcon(c, spec);
    ic = { cv, ver: artVersion };
    iconCache.set(id, ic);
  }
  const k = Math.min(w / ICON_W, h / ICON_H);
  ctx.drawImage(ic.cv, cx - (ICON_W * k) / 2, cy - (ICON_H * k) / 2, ICON_W * k, ICON_H * k);
}

// ------------------------------------------------------------------ projectiles
export interface HaloBulletLike {
  x: number;
  y: number;
  vx: number;
  vy: number;
  sx: number;
  sy: number;
  age?: number;
  hist?: { x: number; y: number }[];
  shotHandle?: LiveShotHandle;
}

const ZIP_SHOT_IDS = new Set<string>(['diamond', 'blaster', 'paintball', 'shark', 'heat_ray']);

function paintClassicProjBody(ctx: CanvasRenderingContext2D, spec: HaloSpec, b: HaloBulletLike, len: number, age: number) {
  const def = spec.def;
  const h = b.shotHandle;
  if (h?.paintCss) gunState.tint = h.paintCss;
  if (h?.hue !== undefined) {
    gunState.bazookaHue = h.hue;
    gunState.rocketHue = h.hue;
    gunState.yoyoHue = h.hue;
    gunState.diamondSeed = h.hue * 0.13;
  }
  try {
    if (ZIP_SHOT_IDS.has(def.id)) {
      drawZipCrystalRound(ctx, len, haloLive.time, (b.sx + b.sy) * 0.01, 0, false, def.id, h?.paintCss);
    } else {
      artDrawProjectile(ctx, def.id, len, haloLive.time, age, false);
    }
  } catch {
    ctx.fillStyle = spec.color;
    ctx.fillRect(-2, 0, 4, len);
  }
}

/** proyektil asli Perfect Shot (beserta jejak Mach, material trail, afterimage & art sub-engine) */
export function drawHaloBullet(ctx: CanvasRenderingContext2D, spec: HaloSpec, b: HaloBulletLike, fx?: PerfectShotFx) {
  const sp = Math.hypot(b.vx, b.vy) || 1;
  const ux = b.vx / sp;
  const uy = b.vy / sp;
  const ang = Math.atan2(uy, ux) + Math.PI / 2;
  const def = spec.def;
  const age = b.age ?? 0;
  const travelled = Math.hypot(b.x - b.sx, b.y - b.sy);
  const prof = fxProfileOf(def.id);
  const trailCol = b.shotHandle?.tintRgb ?? spec.rgb;
  const len = def.stick + 21;

  if (def.id === 'soaker') {
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.rotate(ang);
    // Perfect Shot's WaterJet sprays for 75 ms at 1300 units/s. Preserve
    // its original silhouette, ripple and rounded water tip at bridge scale.
    const scale = 0.78;
    ctx.scale(scale, scale);
    drawSoakerWaterStream(ctx, 0, 0, Math.min(travelled / scale, 1300 * Math.min(age, 0.075)), age);
    ctx.restore();
    return;
  }

  // 1. Tali yoyo / elemen pelengkap antar moncong dan peluru
  if (fx) fx.drawFlyingExtras(ctx, def.id, b, b.shotHandle);

  // 2. Proyektil khusus dari sub-engine Perfect Shot (SET 1, SetNine, SetEleven, Firework, Yoyo, Diamond, Xeno)
  if (fx && fx.drawSpecialRound(ctx, def.id, b, spec.ps, b.shotHandle)) {
    return;
  }

  // 3. Afterimages (`fxp.ghost` dari Perfect Shot)
  if (prof.ghost > 0 && def.id !== 'diamond' && b.hist && b.hist.length > 0) {
    for (let gi = 0; gi < b.hist.length; gi++) {
      const h = b.hist[gi];
      ctx.save();
      ctx.globalAlpha = ((gi + 1) / (b.hist.length + 1)) * 0.32;
      ctx.translate(h.x, h.y);
      ctx.rotate(ang);
      ctx.scale(spec.ps, spec.ps);
      if (def.energy) ctx.globalCompositeOperation = 'lighter';
      paintClassicProjBody(ctx, spec, b, len, age);
      ctx.restore();
    }
  }

  // 4. Tapered Mach Trail + White Core + Radial Bloom + Mach Shock Cone / Material Trail
  ctx.save();
  ctx.translate(b.x, b.y);
  ctx.rotate(ang);
  ctx.scale(spec.ps, spec.ps);

  if (!drawMaterialTrail(ctx, def.id, undefined, haloLive.time)) {
    const tl = Math.min(260, Math.min(travelled / Math.max(0.2, spec.ps), (52 + def.speed * 0.042) * prof.streak));
    if (tl > 6) {
      const tw = Math.max(2.2, def.half) * 1.25;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const tg = ctx.createLinearGradient(0, 6, 0, 6 + tl);
      tg.addColorStop(0, `rgba(${trailCol},0.78)`);
      tg.addColorStop(0.35, `rgba(${trailCol},0.28)`);
      tg.addColorStop(1, `rgba(${trailCol},0)`);
      ctx.fillStyle = tg;
      ctx.beginPath();
      ctx.moveTo(-tw, 8);
      ctx.lineTo(tw, 8);
      ctx.lineTo(0.5, 8 + tl);
      ctx.lineTo(-0.5, 8 + tl);
      ctx.closePath();
      ctx.fill();

      const cg = ctx.createLinearGradient(0, 6, 0, 6 + tl * 0.55);
      cg.addColorStop(0, 'rgba(255,255,255,0.88)');
      cg.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = cg;
      ctx.fillRect(-0.9, 8, 1.8, tl * 0.55);

      if (prof.speedLines || def.speed >= 3200) {
        const coneW = tw * 2.1;
        const coneL = 26;
        ctx.globalAlpha = 0.45;
        ctx.strokeStyle = `rgba(${trailCol},0.85)`;
        ctx.lineWidth = 1.4;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-coneW, coneL);
        ctx.lineTo(0, -4);
        ctx.lineTo(coneW, coneL);
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  if (spec.spin) {
    ctx.translate(0, len * 0.5);
    ctx.rotate(age * 22);
    ctx.translate(0, -len * 0.5);
  }
  paintClassicProjBody(ctx, spec, b, len, age);
  ctx.restore();
}

// ------------------------------------------------------------------ FX wrappers
const FIRE = ['255,236,160', '255,170,50', '255,90,20'];

/** efek di moncong saat menembak: memanggil fireWeapon() asli Perfect Shot */
export function haloMuzzleFx(fx: PerfectShotFx, s: HaloSpec, x: number, y: number, ang: number): LiveShotHandle {
  return fx.fireWeapon(s.art, s.def, x, y, ang, haloLive.ammoRatio);
}

/** jejak di belakang proyektil */
export function haloTrailFx(
  fx: PerfectShotFx,
  s: HaloSpec,
  x: number,
  y: number,
  vx: number,
  vy: number,
  dt: number,
  handle?: LiveShotHandle,
) {
  fx.emitFlightTrail(s.art, s.def, x, y, vx, vy, dt, handle);
}

/** efek tumbukan target ASLI dari Perfect Shot */
export function haloImpactFx(
  fx: PerfectShotFx,
  s: HaloSpec,
  x: number,
  y: number,
  nx: number,
  ny: number,
  ux = -nx,
  uy = -ny,
  isEnemy = false,
  handle?: LiveShotHandle,
  sx = x - ux * 180,
  sy = y - uy * 180,
) {
  fx.spawnPerfectImpact(s.art, s.def, x, y, nx, ny, ux, uy, isEnemy, handle, sx, sy);
}

/** ledakan berwarna khas senjata Perfect Shot */
export function haloExplodeFx(fx: PerfectShotFx, s: HaloSpec, x: number, y: number, r: number) {
  if (s.art === 'firework' || s.art === 'bazooka') return;
  if (s.art === 'obliterator') {
    fx.ring(x, y, '74,222,128', r * 1.1, 0.55, 6);
    fx.ring(x, y, '220,252,231', r * 0.7, 0.35, 3);
    return;
  }
  fx.spawnPerfectExplosion(x, y, Math.max(0.85, r / 145), s.def.explodeFx === 'white');
  fx.ring(x, y, s.rgb, r * 0.95, 0.45, 6);
  fx.ring(x, y, '255,255,255', r * 0.6, 0.3, 3);
}

/** sinar instan (laser / railgun / holy / emerald / proton_pack / heat_ray / orbital_beacon) */
export function haloBeamFx(fx: PerfectShotFx, s: HaloSpec, x1: number, y1: number, x2: number, y2: number) {
  const d = Math.hypot(x2 - x1, y2 - y1) || 1;
  const ux = (x2 - x1) / d;
  const uy = (y2 - y1) / d;
  if (s.art === 'laser') {
    fx.psBeam('psLaser', x1, y1, x2, y2, s.rgb, 0.24);
    const n = Math.min(20, Math.floor(d / 38));
    for (let i = 0; i < n; i++) {
      const k = Math.random();
      fx.glow(x1 + ux * d * k + rnd(-3, 3), y1 + uy * d * k + rnd(-3, 3), s.rgb, rnd(2, 4.5), rnd(0.18, 0.38), rnd(-90, 90), rnd(-90, 90), 0, 4);
    }
  } else if (s.art === 'holy') {
    fx.psBeam('psHoly', x1, y1, x2, y2, '255,236,170', 0.24);
    for (let i = 0; i < 12; i++) {
      const k = Math.random();
      fx.sink.push({
        x: x1 + ux * d * k + rnd(-2.5, 2.5), y: y1 + uy * d * k + rnd(-2.5, 2.5),
        vx: ux * rnd(380, 800) + rnd(-18, 18), vy: uy * rnd(380, 800) + rnd(-18, 18),
        life: rnd(0.14, 0.28), max: 0.28, size: rnd(1.5, 3.2), color: 'rgba(255,242,176,0.92)', kind: 'streak', rot: 0, vr: 0, g: 0, drag: 2,
      });
    }
  } else if (s.art === 'emerald') {
    fx.psBeam('psBeam', x1, y1, x2, y2, s.rgb, 0.24);
    const n = Math.min(24, Math.floor(d / 32));
    for (let i = 0; i < n; i++) {
      const k = (i + Math.random()) / n;
      fx.sink.push({
        x: x1 + ux * d * k + rnd(-5, 5), y: y1 + uy * d * k + rnd(-5, 5),
        vx: rnd(-30, 30), vy: rnd(-30, 30), life: rnd(0.2, 0.4), max: 0.4,
        size: rnd(3, 6), color: '#a7f3d0', kind: 'star', rot: rnd(0, TAU), vr: 0, g: 0,
      });
    }
  } else if (s.art === 'railgun' || s.art === 'orbital_beacon') {
    fx.psBeam('psBeam', x1, y1, x2, y2, s.rgb, 0.36);
    fx.beam(x1, y1, x2, y2, s.rgb, s.art === 'orbital_beacon' ? 5.6 : 4.2, 0.44);
    const n = Math.min(46, Math.floor(d / 26));
    for (let i = 0; i < n; i++) {
      const k = (i + Math.random()) / n;
      const ph = k * d * 0.12;
      const o = Math.sin(ph) * 7;
      fx.glow(x1 + ux * d * k - uy * o, y1 + uy * d * k + ux * o, i % 2 ? s.rgb : '255,255,255', rnd(1.8, 3.2), rnd(0.3, 0.6), -uy * o * 6, ux * o * 6, 0, 3);
    }
    for (let i = 0; i < 3; i++) {
      const k = Math.random();
      fx.bolt(x1 + ux * d * k, y1 + uy * d * k, x1 + ux * d * k + rnd(-26, 26), y1 + uy * d * k + rnd(-26, 26), s.rgb, 1.1, 0.14);
    }
  } else {
    fx.psBeam('psBeam', x1, y1, x2, y2, s.rgb, 0.28);
    fx.beam(x1, y1, x2, y2, s.rgb, 4.6, 0.28);
    for (let i = 0; i < 3; i++) {
      fx.bolt(x1, y1, x2, y2, s.art === 'proton_pack' ? '254,215,170' : '255,140,80', 1.4, 0.18);
    }
  }
}

/** partikel status yang menempel di tubuh musuh saat terbakar / beku */
export function haloStatusFx(fx: PerfectShotFx, kind: 'burn' | 'freeze', ex: number, ey: number, eh: number) {
  const x = ex + rnd(-10, 10);
  const y = ey - rnd(8, eh * 0.85);
  if (kind === 'burn') {
    fx.glow(x, y, FIRE[(Math.random() * 3) | 0], rnd(4, 7), rnd(0.25, 0.45), rnd(-15, 15), rnd(-90, -35), -80, 1.5, -8);
  } else {
    fx.addExtra({
      k: 'shard', x, y, rgb: '190,235,255', size: rnd(1.8, 3.2), life: rnd(0.35, 0.6),
      vx: rnd(-16, 16), vy: rnd(-20, 15), g: 120, rot: rnd(0, TAU), vr: rnd(-6, 6),
    });
  }
}
