import type { LevelDef, SolidDef, SolidKind } from './level';
import { segRect, type Rect } from './math';

export interface Solid extends SolidDef {
  id: number;
}

export type DynKind = 'glass' | 'door';

export interface DynSolid extends Rect {
  id: number;
  kind: DynKind;
  ref: number; // prop id
}

export type AnySolid = (Solid | DynSolid) & { kind: SolidKind | DynKind; oneWay?: boolean };

export interface Body {
  x: number; // top-left
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
}

export interface MoveResult {
  hitX: number;
  hitY: number;
  onGround: boolean;
  ground: AnySolid | null;
  wallSolid: AnySolid | null;
  dynHit: DynSolid | null;
}

export interface CastHit {
  t: number;
  nx: number;
  ny: number;
  x: number;
  y: number;
  solid: AnySolid;
  dyn: boolean;
}

const CELL = 256;

export class World {
  solids: Solid[] = [];
  dyn: DynSolid[] = [];
  private grid = new Map<number, number[]>();
  private stamp: Int32Array;
  private stampId = 1;
  private tmp: Solid[] = [];

  constructor(level: LevelDef) {
    level.solids.forEach((s, i) => this.solids.push({ ...s, id: i }));
    this.stamp = new Int32Array(this.solids.length + 1);
    for (const s of this.solids) {
      const cx0 = Math.floor(s.x / CELL);
      const cx1 = Math.floor((s.x + s.w) / CELL);
      const cy0 = Math.floor(s.y / CELL);
      const cy1 = Math.floor((s.y + s.h) / CELL);
      for (let cx = cx0; cx <= cx1; cx++) {
        for (let cy = cy0; cy <= cy1; cy++) {
          const k = this.key(cx, cy);
          let arr = this.grid.get(k);
          if (!arr) {
            arr = [];
            this.grid.set(k, arr);
          }
          arr.push(s.id);
        }
      }
    }
  }

  private key(cx: number, cy: number) {
    return (cx + 2000) * 8192 + (cy + 2000);
  }

  /** returns static solids overlapping the rect (shared array; copy if needed) */
  query(x: number, y: number, w: number, h: number): Solid[] {
    const out = this.tmp;
    out.length = 0;
    this.stampId++;
    if (this.stampId > 2e9) {
      this.stamp.fill(0);
      this.stampId = 1;
    }
    const cx0 = Math.floor(x / CELL);
    const cx1 = Math.floor((x + w) / CELL);
    const cy0 = Math.floor(y / CELL);
    const cy1 = Math.floor((y + h) / CELL);
    for (let cx = cx0; cx <= cx1; cx++) {
      for (let cy = cy0; cy <= cy1; cy++) {
        const arr = this.grid.get(this.key(cx, cy));
        if (!arr) continue;
        for (let i = 0; i < arr.length; i++) {
          const id = arr[i];
          if (this.stamp[id] === this.stampId) continue;
          this.stamp[id] = this.stampId;
          const s = this.solids[id];
          if (s.x < x + w && s.x + s.w > x && s.y < y + h && s.y + s.h > y) out.push(s);
        }
      }
    }
    return out;
  }

  moveBody(b: Body, dt: number, dropThrough: boolean, res: MoveResult) {
    res.hitX = 0;
    res.hitY = 0;
    res.onGround = false;
    res.ground = null;
    res.wallSolid = null;
    res.dynHit = null;

    // ---- X axis
    let nx = b.x + b.vx * dt;
    if (nx !== b.x) {
      const minX = Math.min(b.x, nx);
      const list = this.query(minX, b.y, b.w + Math.abs(nx - b.x), b.h);
      const all: AnySolid[] = list.slice();
      for (const d of this.dyn) all.push(d as AnySolid);
      for (const s of all) {
        if (s.oneWay) continue;
        if (b.y + b.h <= s.y + 0.01 || b.y >= s.y + s.h - 0.01) continue;
        if (b.vx > 0 && b.x + b.w <= s.x + 0.5 && nx + b.w > s.x) {
          nx = s.x - b.w;
          res.hitX = 1;
          res.wallSolid = s;
          if ((s as DynSolid).ref !== undefined && (s.kind === 'glass' || s.kind === 'door')) res.dynHit = s as DynSolid;
        } else if (b.vx < 0 && b.x >= s.x + s.w - 0.5 && nx < s.x + s.w) {
          nx = s.x + s.w;
          res.hitX = -1;
          res.wallSolid = s;
          if ((s as DynSolid).ref !== undefined && (s.kind === 'glass' || s.kind === 'door')) res.dynHit = s as DynSolid;
        }
      }
      b.x = nx;
    }

    // ---- Y axis
    let ny = b.y + b.vy * dt;
    const minY = Math.min(b.y, ny);
    const list = this.query(b.x, minY, b.w, b.h + Math.abs(ny - b.y) + 1);
    const all: AnySolid[] = list.slice();
    for (const d of this.dyn) all.push(d as AnySolid);
    for (const s of all) {
      if (b.x + b.w <= s.x + 0.01 || b.x >= s.x + s.w - 0.01) continue;
      if (b.vy >= 0) {
        if (b.y + b.h <= s.y + 0.5 && ny + b.h >= s.y) {
          if (s.oneWay && dropThrough) continue;
          ny = s.y - b.h;
          res.onGround = true;
          res.ground = s;
          res.hitY = 1;
        }
      } else {
        if (s.oneWay) continue;
        if (b.y >= s.y + s.h - 0.5 && ny < s.y + s.h) {
          ny = s.y + s.h;
          res.hitY = -1;
        }
      }
    }
    b.y = ny;
  }

  /** Is the rect free of solid (non one-way) geometry */
  rectFree(x: number, y: number, w: number, h: number, withDyn = true) {
    const list = this.query(x, y, w, h);
    for (const s of list) if (!s.oneWay) return false;
    if (withDyn) {
      for (const d of this.dyn) {
        if (d.x < x + w && d.x + d.w > x && d.y < y + h && d.y + d.h > y) return false;
      }
    }
    return true;
  }

  solidAt(x: number, y: number, oneWay = false): AnySolid | null {
    const list = this.query(x - 0.5, y - 0.5, 1, 1);
    for (const s of list) {
      if (s.oneWay && !oneWay) continue;
      return s as AnySolid;
    }
    for (const d of this.dyn) {
      if (x >= d.x && x <= d.x + d.w && y >= d.y && y <= d.y + d.h) return d as AnySolid;
    }
    return null;
  }

  raycast(x1: number, y1: number, x2: number, y2: number, withDyn = true, oneWay = false): CastHit | null {
    const minX = Math.min(x1, x2);
    const minY = Math.min(y1, y2);
    const list = this.query(minX - 1, minY - 1, Math.abs(x2 - x1) + 2, Math.abs(y2 - y1) + 2);
    let best: CastHit | null = null;
    for (const s of list) {
      if (s.oneWay && !oneWay) continue;
      const h = segRect(x1, y1, x2, y2, s);
      if (h && (!best || h.t < best.t)) {
        best = {
          t: h.t,
          nx: h.nx,
          ny: h.ny,
          x: x1 + (x2 - x1) * h.t,
          y: y1 + (y2 - y1) * h.t,
          solid: s as AnySolid,
          dyn: false,
        };
      }
    }
    if (withDyn) {
      for (const d of this.dyn) {
        const h = segRect(x1, y1, x2, y2, d);
        if (h && (!best || h.t < best.t)) {
          best = {
            t: h.t,
            nx: h.nx,
            ny: h.ny,
            x: x1 + (x2 - x1) * h.t,
            y: y1 + (y2 - y1) * h.t,
            solid: d as AnySolid,
            dyn: true,
          };
        }
      }
    }
    return best;
  }

  /** line of sight ignoring one-way platforms */
  los(x1: number, y1: number, x2: number, y2: number) {
    return this.raycast(x1, y1, x2, y2, true, false) === null;
  }
}
