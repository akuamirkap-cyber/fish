import { LEVEL1, type LevelDef, type RoomStyle, type DecoType } from './level';

// Each chapter is a playable mafia location, not merely a palette change.
const CHAPTERS: { title: string; place: string; style: RoomStyle; deco: DecoType; color: string; weapon: string }[] = [
  { title: 'PELABUHAN GELAP', place: 'Dermaga penyelundupan', style: 'alley', deco: 'boxes', color: '#eab35e', weapon: 'shotgun' },
  { title: 'KLUB BELUDRU', place: 'Ruang VIP keluarga Kumis', style: 'penthouse', deco: 'curtain', color: '#a84455', weapon: 'uzi' },
  { title: 'DAPUR RAHASIA', place: 'Restoran di balik kedok', style: 'kitchen', deco: 'stove', color: '#d68d55', weapon: 'shotgun' },
  { title: 'BRANKAS BAWAH TANAH', place: 'Lorong penyimpanan uang', style: 'basement', deco: 'pipe', color: '#b59a6e', weapon: 'uzi' },
  { title: 'PABRIK ES', place: 'Penyimpanan barang sitaan', style: 'freezer', deco: 'fridge', color: '#8ac9d4', weapon: 'shotgun' },
  { title: 'ATAP KOTA', place: 'Jalur pelarian di atas kota', style: 'alley', deco: 'antenna', color: '#e6a36e', weapon: 'uzi' },
  { title: 'KASINO EMAS', place: 'Meja taruhan sang Don', style: 'penthouse', deco: 'painting', color: '#e3be65', weapon: 'shotgun' },
  { title: 'DEPOT SENJATA', place: 'Gudang persenjataan mafia', style: 'warehouse', deco: 'forklift', color: '#d79264', weapon: 'uzi' },
  { title: 'MARKAS DON', place: 'Pertarungan terakhir', style: 'penthouse', deco: 'curtain', color: '#c96358', weapon: 'shotgun' },
];

function chapter(i: number): LevelDef {
  const cfg = CHAPTERS[i];
  const n = i + 2;
  const roof = cfg.style === 'alley';
  const upper = i % 2 === 0;
  return {
    name: `LEVEL ${n}`,
    subtitle: cfg.title,
    bounds: { x: -80, y: -850, w: 3390, h: 1320 },
    killY: 460,
    spawn: { x: 100, y: 0 },
    sky: 'city',
    solids: [
      { x: -150, y: 0, w: 3450, h: 500, kind: roof ? 'roof' : 'concrete' },
      { x: -150, y: -850, w: 90, h: 850, kind: 'brick' },
      { x: 3250, y: -850, w: 90, h: 850, kind: 'brick' },
      ...(!roof ? [{ x: -60, y: -650, w: 3310, h: 90, kind: 'concrete' as const }] : []),
      { x: 440, y: -55, w: 78, h: 55, kind: 'crate' },
      { x: 760, y: -130, w: 200, h: 16, kind: 'metal', oneWay: true },
      { x: 1120, y: -60, w: 105, h: 60, kind: 'crate' },
      { x: 1380, y: upper ? -190 : -120, w: 250, h: 16, kind: 'wood', oneWay: true },
      { x: 1750, y: -48, w: 130, h: 48, kind: 'table' },
      { x: 2010, y: -145, w: 210, h: 16, kind: 'metal', oneWay: true },
      { x: 2360, y: -72, w: 90, h: 72, kind: 'crate' },
      { x: 2670, y: -118, w: 180, h: 16, kind: 'wood', oneWay: true },
    ],
    rooms: [{ x: -60, y: -560, w: 3310, h: 560, style: cfg.style }],
    enemies: [
      { x: 680, y: 0, type: 'thug', facing: -1, section: 1, variant: i % 6 },
      { x: 1030, y: 0, type: 'gunner', facing: -1, section: 1, variant: (i + 1) % 6 },
      { x: 1480, y: upper ? -190 : -120, type: 'thug', facing: -1, section: 1, variant: (i + 2) % 6 },
      { x: 1840, y: 0, type: i > 3 ? 'rifleman' : 'thug', facing: -1, section: 1, variant: (i + 3) % 6 },
      { x: 2130, y: -145, type: 'sniper', facing: -1, section: 1, variant: 0 },
      { x: 2530, y: 0, type: 'gunner', facing: -1, section: 1, variant: (i + 4) % 6 },
      { x: 2900, y: 0, type: 'boss', facing: -1, section: 1, variant: 0 },
    ],
    props: [
      { type: 'weapon', gun: cfg.weapon, x: 360, y: 0, section: 1 },
      { type: 'barrel', x: 910, y: 0, section: 1 },
      { type: 'banana', x: 1510, y: -270, section: 1 },
      { type: 'lamp', x: 1670, y: -560, h: 65, section: 1 },
      { type: 'barrel', x: 2460, y: 0, section: 1 },
      { type: 'lamp', x: 2800, y: -560, h: 65, section: 1 },
    ],
    ziplines: [],
    hints: [
      { id: `chapter-${n}`, trigger: { x: 0, y: -360, w: 320, h: 360 }, text: `${cfg.title}: ${cfg.place}. Habisi penjaga, kalahkan Don, lalu menuju pintu keluar!` },
      { id: `boss-${n}`, trigger: { x: 2510, y: -360, w: 220, h: 360 }, text: 'Bos ada di depan! Gunakan SHIFT untuk fokus, SPACE untuk menghindari peluru.' },
    ],
    checkpoints: [{ id: 1, trigger: { x: 1640, y: -360, w: 180, h: 360 }, spawn: { x: 1690, y: 0 }, section: 1 }],
    decos: [
      { type: 'sign', x: 210, y: -430, text: cfg.title, color: cfg.color },
      ...[520, 1080, 1640, 2200, 2790].map((x) => ({ type: cfg.deco, x, y: cfg.style === 'alley' ? -120 : -310, color: cfg.color })),
      ...(!roof ? [800, 1930, 2750].map((x) => ({ type: 'lamp' as const, x, y: -560 })) : [800, 1930, 2750].map((x) => ({ type: 'streetlamp' as const, x, y: 0 }))),
      { type: 'exitsign', x: 3120, y: -225 },
    ],
    exit: { x: 3110, y: -170, w: 90, h: 170 },
    bossHint: 'Bos tumbang! Pintu keluar terbuka. Lanjutkan operasi ke markas berikutnya!',
  };
}

export const CAMPAIGN: LevelDef[] = [LEVEL1, ...CHAPTERS.map((_, i) => chapter(i))];