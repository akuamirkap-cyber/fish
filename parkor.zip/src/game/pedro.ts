import { Enemy, type EnemyHost } from './enemy';
import type { BossHost } from './bosses';
import type { Hazard } from './hazards';
import type { EnemyDef } from './level';
import type { Sound } from './audio';
import { approach, clamp, dist, rand, segCircle, TAU, weightedPick } from './math';

type PAct = 'intro' | 'float' | 'laser' | 'rain' | 'minions' | 'dashWind' | 'dash' | 'ring' | 'phase' | 'dying';

/** banana body as circles in local (unscaled) coords: [x, y, r] */
const BODY: [number, number, number][] = [
  [-9.5, -11, 4.4],
  [-12, -4, 5.6],
  [-12, 3, 6.6],
  [-8, 9.5, 6.6],
  [-1, 13, 6],
  [7, 14.5, 5],
  [14, 13.5, 4],
];
const EYE = { x: -6.2, y: -1, r: 4.6 };
const OUT = '#1b1410';

export interface PedroLook {
  talk: number;
  angry: boolean;
  glow: number;
  flash: number;
  phase: number;
  dying: number;
  lx: number;
  ly: number;
  t: number;
}

/** giant Pedro, drawn with fixed-width outlines (facing: 1 = looking right) */
export function drawPedroBoss(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  s: number,
  rot: number,
  facing: number,
  o: PedroLook,
) {
  const P = (v: number) => v * s;
  ctx.save();
  ctx.translate(x, y);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const auraCol = o.phase === 1 ? '255,220,120' : o.phase === 2 ? '255,150,90' : '255,70,60';
  const ag = ctx.createRadialGradient(0, 0, P(6), 0, 0, P(30));
  ag.addColorStop(0, `rgba(${auraCol},${0.26 + Math.sin(o.t * 3) * 0.06})`);
  ag.addColorStop(1, `rgba(${auraCol},0)`);
  ctx.fillStyle = ag;
  ctx.beginPath();
  ctx.arc(0, 0, P(30), 0, TAU);
  ctx.fill();
  ctx.restore();
  ctx.rotate(rot);
  ctx.scale(-facing, 1);
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  const body = () => {
    ctx.beginPath();
    ctx.moveTo(P(-12), P(-14));
    ctx.quadraticCurveTo(P(-20), P(6), P(2), P(16));
    ctx.quadraticCurveTo(P(14), P(20), P(20), P(12));
    ctx.quadraticCurveTo(P(6), P(10), P(-2), P(2));
    ctx.quadraticCurveTo(P(-8), P(-6), P(-7), P(-15));
    ctx.closePath();
  };
  body();
  ctx.lineWidth = 8;
  ctx.strokeStyle = OUT;
  ctx.stroke();
  ctx.fillStyle = o.phase === 3 ? '#ffcf3f' : '#ffd93b';
  ctx.fill();
  ctx.save();
  body();
  ctx.clip();
  ctx.fillStyle = '#f2b81c';
  ctx.beginPath();
  ctx.moveTo(P(-9), P(-12));
  ctx.quadraticCurveTo(P(-14), P(6), P(4), P(13));
  ctx.quadraticCurveTo(P(-6), P(4), P(-9), P(-12));
  ctx.fill();
  ctx.fillStyle = 'rgba(105,65,20,0.55)';
  const spots: [number, number, number][] = [
    [-14, 4, 1.1],
    [-6, 12, 0.9],
    [6, 13, 1.2],
    [-11, -7, 0.7],
    [1, 10, 0.8],
    [11, 13.5, 0.7],
    [-15, -1, 0.6],
  ];
  const ns = o.phase === 1 ? 2 : o.phase === 2 ? 4 : 7;
  for (let i = 0; i < ns; i++) {
    const [sx, sy, r] = spots[i];
    ctx.beginPath();
    ctx.ellipse(P(sx), P(sy), P(r), P(r * 0.7), 0.4, 0, TAU);
    ctx.fill();
  }
  ctx.strokeStyle = 'rgba(255,255,255,0.5)';
  ctx.lineWidth = P(1.3);
  ctx.beginPath();
  ctx.moveTo(P(-16), P(-3));
  ctx.quadraticCurveTo(P(-16.5), P(6), P(-10), P(11.5));
  ctx.stroke();
  if (o.flash > 0) {
    ctx.fillStyle = `rgba(255,255,255,${Math.min(0.8, o.flash * 6)})`;
    ctx.fillRect(P(-25), P(-25), P(50), P(50));
  }
  if (o.dying > 0) {
    ctx.strokeStyle = `rgba(255,255,220,${0.6 + Math.random() * 0.4})`;
    ctx.lineWidth = P(0.7);
    const cracks = [
      [-12, -8, -8, -2, -11, 4],
      [-6, 10, -2, 6, 2, 12],
      [6, 14, 9, 10, 13, 13],
      [-15, 2, -12, 6, -14, 9],
      [-3, 2, 0, 7, -2, 9],
      [-9, -12, -6, -9, -8, -5],
    ];
    const n = Math.min(cracks.length, 1 + Math.floor(o.dying * 3.5));
    for (let i = 0; i < n; i++) {
      const c = cracks[i];
      ctx.beginPath();
      ctx.moveTo(P(c[0]), P(c[1]));
      ctx.lineTo(P(c[2]), P(c[3]));
      ctx.lineTo(P(c[4]), P(c[5]));
      ctx.stroke();
    }
  }
  ctx.restore();
  // stem & tip
  ctx.fillStyle = '#5a3a1a';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(P(-12), P(-14));
  ctx.lineTo(P(-11), P(-19.5));
  ctx.lineTo(P(-6.5), P(-18.5));
  ctx.lineTo(P(-7), P(-15));
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(P(19.5), P(12), P(2), 0, TAU);
  ctx.fill();
  ctx.stroke();
  // eyes
  const eyes: [number, number, number, number][] = [
    [-9, -2, 2.6, 3.2],
    [-3.5, 0, 2.4, 3],
  ];
  for (const [ex, ey, rx, ry] of eyes) {
    ctx.fillStyle = o.glow > 0.5 ? '#ffd6d6' : '#ffffff';
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(P(ex), P(ey), P(rx), P(ry), 0, 0, TAU);
    ctx.fill();
    ctx.stroke();
    const px = P(ex + o.lx * 1.0);
    const py = P(ey + o.ly * 1.3);
    ctx.fillStyle = o.glow > 0.5 ? '#d1001f' : '#111111';
    ctx.beginPath();
    ctx.arc(px, py, P(1.3), 0, TAU);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(px - P(0.4), py - P(0.5), P(0.4), 0, TAU);
    ctx.fill();
  }
  if (o.glow > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const [ex, ey] of eyes) {
      const g = ctx.createRadialGradient(P(ex), P(ey), 0, P(ex), P(ey), P(6) * o.glow);
      g.addColorStop(0, 'rgba(255,200,200,0.9)');
      g.addColorStop(0.5, 'rgba(255,40,70,0.5)');
      g.addColorStop(1, 'rgba(255,0,40,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(P(ex), P(ey), P(6) * o.glow, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }
  // brows
  ctx.strokeStyle = OUT;
  ctx.lineWidth = P(0.9);
  ctx.beginPath();
  if (o.angry) {
    ctx.moveTo(P(-11.8), P(-6.8));
    ctx.lineTo(P(-7.2), P(-5));
    ctx.moveTo(P(-5.6), P(-4.3));
    ctx.lineTo(P(-1.4), P(-5.4));
  } else {
    ctx.moveTo(P(-11.4), P(-6.3));
    ctx.quadraticCurveTo(P(-9), P(-7.6), P(-6.8), P(-6.4));
    ctx.moveTo(P(-5.6), P(-4.6));
    ctx.quadraticCurveTo(P(-3.5), P(-5.8), P(-1.6), P(-4.6));
  }
  ctx.stroke();
  // mouth
  ctx.lineWidth = 3;
  if (o.talk > 0.5 || o.dying > 0) {
    ctx.fillStyle = '#6b1414';
    ctx.beginPath();
    ctx.ellipse(P(-6), P(6.4), P(2.6), P(2.1), 0.3, 0, TAU);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(P(-7.6), P(4.9), P(2.6), P(0.8));
  } else if (o.angry) {
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.roundRect(P(-9), P(5), P(6.4), P(2.2), P(0.6));
    ctx.fill();
    ctx.stroke();
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    for (let i = 1; i < 4; i++) {
      ctx.moveTo(P(-9 + i * 1.6), P(5));
      ctx.lineTo(P(-9 + i * 1.6), P(7.2));
    }
    ctx.stroke();
  } else {
    ctx.beginPath();
    ctx.moveTo(P(-9), P(5.5));
    ctx.quadraticCurveTo(P(-5.5), P(8.5), P(-2), P(6.5));
    ctx.stroke();
  }
  ctx.restore();
}

export class PedroBoss extends Enemy {
  act: PAct = 'intro';
  actT = 0;
  phase = 1;
  pendingPhase = 0;
  nextAtk = 1.6;
  last: PAct[] = [];
  s = 4.8;
  cx: number;
  cy: number;
  pvx = 0;
  pvy = 0;
  rot = 0;
  tx: number;
  ty: number;
  talk = 0;
  hurtFlash = 0;
  eyeGlow = 0;
  dashDir = 1;
  dashHit = false;
  dashes = 0;
  quickWind = false;
  spawned = false;
  rainT = 0;
  ringN = 0;
  finished = false;
  dyingInit = false;
  laser: Hazard | null = null;
  lx = -1;
  ly = 0;
  arena = { x: 0, y: -820, w: 1700, h: 820 };

  constructor(def: EnemyDef) {
    super(def);
    this.isBossMode = true;
    this.maxHp = 175;
    this.hp = 175;
    this.hpShown = 175;
    this.bossName = 'PEDRO';
    this.bossTitle = 'PISANG DARI ALAM MIMPI';
    this.phaseMarks = [0.66, 0.33];
    this.state = 'alert';
    this.gun = null;
    this.w = 30 * this.s;
    this.h = 34 * this.s;
    this.cx = def.x;
    this.cy = def.y;
    this.tx = def.x;
    this.ty = def.y;
    this.dims = { ...this.dims, headR: 12 };
    this.syncBox();
  }

  get customDeath() {
    return true;
  }

  toWorld(lx: number, ly: number) {
    const x = lx * -this.facing;
    const c = Math.cos(this.rot);
    const sn = Math.sin(this.rot);
    return { x: this.cx + (x * c - ly * sn) * this.s, y: this.cy + (x * sn + ly * c) * this.s };
  }

  eyePos() {
    return this.toWorld(EYE.x, EYE.y);
  }

  private syncBox() {
    this.x = this.cx;
    this.y = this.cy + 17 * this.s;
    const top = this.toWorld(-10, -14);
    this.wp.head.x = top.x;
    this.wp.head.y = top.y + 8;
    const e = this.eyePos();
    this.wp.neck.x = e.x;
    this.wp.neck.y = e.y;
    this.wp.pelvis.x = this.cx;
    this.wp.pelvis.y = this.cy + 6 * this.s;
    this.wp.haF.x = this.cx;
    this.wp.haF.y = this.cy;
  }

  private overlaps(px: number, py: number, pad: number) {
    for (const [lx, ly, r] of BODY) {
      const c = this.toWorld(lx, ly);
      if (dist(px, py, c.x, c.y) < r * this.s + pad) return true;
    }
    return false;
  }

  hitTestCustom(x1: number, y1: number, x2: number, y2: number) {
    if (this.act === 'dying' || this.act === 'intro') return null;
    const R = 26 * this.s;
    if (
      Math.max(x1, x2) < this.cx - R ||
      Math.min(x1, x2) > this.cx + R ||
      Math.max(y1, y2) < this.cy - R ||
      Math.min(y1, y2) > this.cy + R
    ) {
      return null;
    }
    let tb: number | null = null;
    for (const [lx, ly, r] of BODY) {
      const c = this.toWorld(lx, ly);
      const t = segCircle(x1, y1, x2, y2, c.x, c.y, r * this.s);
      if (t !== null && (tb === null || t < tb)) tb = t;
    }
    const e = this.eyePos();
    const te = segCircle(x1, y1, x2, y2, e.x, e.y, EYE.r * this.s);
    if (te !== null) return { t: tb !== null ? Math.min(tb, te) : te, head: true };
    if (tb !== null) return { t: tb, head: false };
    return null;
  }

  hurt(dmg: number, _dirx: number, head: boolean, _time: number, _sfx: Sound) {
    if (this.act === 'dying' || this.act === 'intro') return false;
    this.hp -= dmg;
    this.hitT = 0.22;
    this.hurtFlash = 0.12;
    this.lastHitHead = head;
    if (this.hp <= 0) {
      this.hp = 0;
      this.act = 'dying';
      this.actT = 0;
      return false;
    }
    const k = this.hp / this.maxHp;
    if (this.phase === 1 && k <= this.phaseMarks[0]) this.pendingPhase = 2;
    else if (this.phase === 2 && k <= this.phaseMarks[1]) this.pendingPhase = 3;
    return false;
  }

  stunFor(_t: number, _vx: number, _vy: number) {
    if (this.act === 'dying') return;
    this.pvy -= 160;
    this.hurtFlash = 0.2;
  }

  private setAct(a: PAct) {
    this.act = a;
    this.actT = 0;
    this.spawned = false;
  }

  private endAttack() {
    this.rot = 0;
    this.eyeGlow = 0;
    this.setAct('float');
    this.nextAtk = rand(0.9, 1.6) / (1 + 0.2 * (this.phase - 1));
  }

  private speak(host: BossHost, text: string, dur: number) {
    host.say(this, text, dur);
    this.talk = dur;
  }

  private pickAttack(host: BossHost) {
    const opts: [PAct, number][] = [
      ['laser', 1.25],
      ['rain', 1.0],
      ['dashWind', 1.0],
    ];
    if (host.hazards.count('minion') < 3) opts.push(['minions', 0.9]);
    if (this.phase >= 3) opts.push(['ring', 1.1]);
    const pick = weightedPick(opts, this.last);
    this.last.unshift(pick);
    if (this.last.length > 3) this.last.pop();
    this.setAct(pick);
    const A = this.arena;
    if (pick === 'dashWind') {
      this.dashDir = host.player.x < A.x + A.w / 2 ? -1 : 1;
      this.dashes = this.phase >= 2 ? 1 : 0;
      this.quickWind = false;
      this.speak(host, 'MINGGIR!', 1);
    } else if (pick === 'rain') {
      this.rainT = 0;
      this.speak(host, 'HUJAN PISANG!', 1.4);
    } else if (pick === 'minions') {
      this.speak(host, 'Anak-anakku, serang!', 1.4);
    } else if (pick === 'ring') {
      this.ringN = 0;
      this.speak(host, 'BERPUTAAAR!', 1.2);
    }
  }

  protected bossUpdate(dt: number, hostE: EnemyHost): boolean {
    const host = hostE as BossHost;
    const p = host.player;
    const A = host.arenaRect;
    this.arena = A;
    this.animT += dt;
    this.actT += dt;
    this.hitT -= dt;
    this.hurtFlash = Math.max(0, this.hurtFlash - dt);
    this.talk = Math.max(0, this.talk - dt);
    this.hpShown = approach(this.hpShown, this.hp, dt * 30);
    const midX = A.x + A.w / 2;
    if (this.act !== 'dash' && this.act !== 'dashWind' && this.act !== 'dying') this.facing = p.x >= this.cx ? 1 : -1;
    if (host.bossIntro > 0 && this.act !== 'intro' && this.act !== 'dying') this.setAct('intro');
    if (this.pendingPhase && this.act !== 'dying' && this.act !== 'dash') {
      this.phase = this.pendingPhase;
      this.pendingPhase = 0;
      for (const h of host.hazards.list) if (h.kind === 'laser') h.alive = false;
      host.sfx.laserHum(false);
      this.laser = null;
      this.setAct('phase');
      host.setDreamPhase(this.phase);
      host.sfx.roar();
      host.shake(14);
      host.stamp(`FASE ${this.phase}!`, this.cx, this.cy - 140, '#ffffff', 52, this.phase === 2 ? '#ff7b3a' : '#ff2e4d');
      this.speak(host, this.phase === 2 ? 'Tanpa aku, kamu BUKAN SIAPA-SIAPA!' : 'INI CUMA MIMPI! BANGUN!!', 2.2);
      host.particles.spawn({ kind: 'ring', x: this.cx, y: this.cy, life: 0.6, size: 420, color: '#ffffff' });
    }
    const hoverX = midX + Math.sin(this.animT * 0.45) * A.w * 0.27;
    const hoverY = A.y + A.h * 0.4 + Math.sin(this.animT * 1.3) * 30;
    switch (this.act) {
      case 'intro':
        this.tx = this.cx;
        this.ty = A.y + A.h * 0.45 + Math.sin(this.animT * 2) * 12;
        if (host.bossIntro <= 0) {
          this.setAct('float');
          this.speak(host, 'Kamu masih butuh aku, kan?!', 2.2);
        }
        break;
      case 'float':
        this.tx = hoverX;
        this.ty = hoverY;
        if (this.actT > this.nextAtk && p.alive) this.pickAttack(host);
        break;
      case 'laser': {
        this.tx = p.x < midX ? A.x + A.w - 280 : A.x + 280;
        this.ty = A.y + 170;
        if (!this.spawned && this.actT > 0.55) {
          this.spawned = true;
          const e = this.eyePos();
          this.laser = host.hazards.add({
            kind: 'laser',
            x: e.x,
            y: e.y,
            src: () => this.eyePos(),
            a: Math.atan2(p.y - 50 - e.y, p.x - e.x),
            aimT: 1.0 - (this.phase - 1) * 0.12,
            fireT: 1.5 + (this.phase - 1) * 0.35,
            va: 0.72 + (this.phase - 1) * 0.16,
            dir: Math.random() < 0.5 ? 1 : -1,
            dmg: 9,
            life: 99,
          });
          host.sfx.laserCharge();
          this.speak(host, 'LIHAT MATAKU!', 1.3);
        }
        if (this.spawned) {
          this.eyeGlow = approach(this.eyeGlow, 1, dt * 3);
          if (!this.laser || !this.laser.alive) {
            this.laser = null;
            this.endAttack();
          }
        }
        break;
      }
      case 'rain': {
        this.tx = midX;
        this.ty = A.y + 120;
        if (this.actT > 0.6 && this.actT < 3.2) {
          this.rainT -= dt;
          if (this.rainT <= 0) {
            this.rainT = this.phase === 3 ? 0.1 : this.phase === 2 ? 0.13 : 0.16;
            const targeted = Math.random() < 0.3;
            const bx = targeted ? p.x + rand(-40, 40) : rand(A.x + 40, A.x + A.w - 40);
            host.hazards.add({
              kind: 'bomb',
              x: bx,
              y: A.y + 20,
              vx: rand(-20, 20),
              vy: rand(40, 140),
              vr: rand(-8, 8),
              life: 4,
              dmg: 14,
            });
          }
        }
        if (this.actT > 3.6) this.endAttack();
        break;
      }
      case 'minions': {
        this.tx = hoverX;
        this.ty = hoverY;
        this.rot = Math.sin(this.actT * 14) * 0.25 * Math.max(0, 1 - this.actT);
        if (!this.spawned && this.actT > 0.5) {
          this.spawned = true;
          const n = Math.min(this.phase === 1 ? 2 : 3, 4 - host.hazards.count('minion'));
          for (let i = 0; i < n; i++) {
            host.hazards.add({
              kind: 'minion',
              x: this.cx + rand(-60, 60),
              y: this.cy + rand(-40, 40),
              vx: rand(-300, 300),
              vy: rand(-300, -100),
              hp: 2,
              cd: rand(1.2, 2.2),
              ox: rand(0, TAU),
              life: 999,
            });
          }
          host.sfx.bananaPop();
          host.particles.spawn({ kind: 'ring', x: this.cx, y: this.cy, life: 0.4, size: 160, color: '#fff3a0' });
        }
        if (this.actT > 1.3) this.endAttack();
        break;
      }
      case 'dashWind': {
        this.tx = this.dashDir > 0 ? A.x + 150 : A.x + A.w - 150;
        this.ty = clamp(p.y - p.h * 0.55, A.y + 220, A.y + A.h - 92);
        this.facing = this.dashDir;
        this.rot = Math.sin(this.actT * 40) * 0.05 * Math.min(1, this.actT);
        if (this.actT > (this.quickWind ? 0.55 : 1.05)) {
          this.setAct('dash');
          this.dashHit = false;
          this.pvx = 0;
          this.pvy = 0;
          host.sfx.roar();
          host.shake(6);
        }
        break;
      }
      case 'dash': {
        this.facing = this.dashDir;
        this.rot = this.dashDir * 0.25;
        if (Math.random() < 0.8) {
          host.particles.spawn({
            kind: 'dust',
            x: this.cx - this.dashDir * 70,
            y: this.cy + rand(-60, 60),
            vx: -this.dashDir * 200,
            vy: 0,
            life: 0.4,
            size: 10,
            color: 'rgba(255,230,140,1)',
            drag: 2,
          });
        }
        if (!this.dashHit && p.alive && this.overlaps(p.x, p.y - p.h * 0.5, 20)) {
          this.dashHit = true;
          if (host.hurtPlayer(24, this.dashDir, 720)) {
            host.stamp('BOINK!', p.x, p.y - 110, '#ffffff', 40, '#c77dff');
            host.camKick(this.dashDir * 12, -4);
          } else if (p.dodging) host.popup('MELESET!', p.x, p.y - 110, '#9fe8ff');
        }
        const end = this.dashDir > 0 ? this.cx > A.x + A.w - 130 : this.cx < A.x + 130;
        if (end) {
          host.shake(8);
          if (this.dashes > 0) {
            this.dashes--;
            this.dashDir *= -1;
            this.setAct('dashWind');
            this.quickWind = true;
          } else this.endAttack();
        }
        break;
      }
      case 'ring': {
        this.tx = this.cx;
        this.ty = this.cy;
        this.rot += dt * 10;
        if (this.ringN < 3 && this.actT > 0.4 + this.ringN * 0.35) {
          for (let k = 0; k < 14; k++) host.enemyShoot(this.cx, this.cy, (k / 14) * TAU + this.ringN * 0.22, 390, 9);
          this.ringN++;
          host.sfx.shoot('enemy', 0.7);
          host.particles.spawn({ kind: 'ring', x: this.cx, y: this.cy, life: 0.3, size: 120, color: '#ffd23f' });
        }
        if (this.actT > 1.6) this.endAttack();
        break;
      }
      case 'phase':
        this.tx = midX;
        this.ty = A.y + A.h * 0.36;
        this.rot = Math.sin(this.actT * 30) * 0.08;
        if (this.actT > 1.8) this.endAttack();
        break;
      case 'dying': {
        if (!this.dyingInit) {
          this.dyingInit = true;
          host.hazards.clear();
          host.sfx.laserHum(false);
          host.sfx.roar();
          host.shake(12);
          this.speak(host, 'A-aku... cuma ingin... dipeluk...', 2.2);
        }
        this.tx = this.cx;
        this.ty = this.cy;
        this.rot = Math.sin(this.actT * 45) * 0.1;
        this.hurtFlash = Math.random() < 0.3 ? 0.1 : 0;
        if (Math.random() < 0.5) {
          const c = this.toWorld(rand(-14, 14), rand(-12, 14));
          host.particles.sparks(c.x, c.y, rand(-1, 1), rand(-1, 1), 3, '#fff6c8');
        }
        if (Math.random() < 0.08) {
          host.shake(4);
          host.sfx.bananaPop();
        }
        if (this.actT > 2.0 && !this.finished) {
          this.finished = true;
          host.finishBoss(this);
        }
        break;
      }
    }
    if (this.act === 'dash') {
      this.cx += this.dashDir * 1250 * dt;
    } else {
      const k = this.act === 'dashWind' ? 4 : 2.2;
      this.pvx += ((this.tx - this.cx) * k * k - this.pvx * 2 * k) * dt;
      this.pvy += ((this.ty - this.cy) * k * k - this.pvy * 2 * k) * dt;
      this.cx += this.pvx * dt;
      this.cy += this.pvy * dt;
    }
    this.cx = clamp(this.cx, A.x + 90, A.x + A.w - 90);
    this.cy = clamp(this.cy, A.y + 90, A.y + A.h - 85);
    if (this.act === 'float' || this.act === 'laser' || this.act === 'rain' || this.act === 'intro') {
      this.rot = approach(this.rot, Math.sin(this.animT * 1.7) * 0.08 + clamp(this.pvx / 2000, -0.15, 0.15), dt * 2);
    }
    this.syncBox();
    // pupils follow the player
    const e = this.eyePos();
    let ddx = p.x - e.x;
    let ddy = p.y - 50 - e.y;
    const L = Math.hypot(ddx, ddy) || 1;
    ddx /= L;
    ddy /= L;
    const c = Math.cos(-this.rot);
    const sn = Math.sin(-this.rot);
    this.lx = (ddx * c - ddy * sn) * -this.facing;
    this.ly = ddx * sn + ddy * c;
    return true;
  }

  drawSelf(ctx: CanvasRenderingContext2D, t: number): boolean {
    drawPedroBoss(ctx, this.cx, this.cy, this.s, this.rot, this.facing, {
      talk: this.talk > 0 && Math.sin(t * 22) > 0 ? 1 : 0,
      angry: this.phase >= 2 || this.act === 'dashWind' || this.act === 'dash' || this.act === 'laser',
      glow: this.eyeGlow,
      flash: this.hurtFlash,
      phase: this.phase,
      dying: this.act === 'dying' ? this.actT : 0,
      lx: this.lx,
      ly: this.ly,
      t,
    });
    return true;
  }

  drawOverlay(ctx: CanvasRenderingContext2D, t: number): void {
    if (this.act !== 'dashWind') return;
    const A = this.arena;
    const a = 0.1 + Math.abs(Math.sin(t * 10)) * 0.12;
    ctx.fillStyle = `rgba(255,40,60,${a})`;
    ctx.fillRect(A.x, this.cy - 16 * this.s, A.w, 32 * this.s);
    ctx.save();
    ctx.font = '42px Bangers, Impact, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = `rgba(255,255,255,${0.35 + a})`;
    const arrows = this.dashDir > 0 ? '>>>' : '<<<';
    for (let x = A.x + 120; x < A.x + A.w; x += 260) ctx.fillText(arrows, x + ((t * 300 * this.dashDir) % 260), this.cy);
    ctx.restore();
  }

  onCustomDeath(hostE: EnemyHost): void {
    const host = hostE as BossHost;
    host.hazards.clear();
    host.sfx.laserHum(false);
    host.particles.explosion(this.cx, this.cy);
    host.particles.spawn({ kind: 'flash', x: this.cx, y: this.cy, life: 0.4, size: 520, color: '#fff3a0' });
    host.particles.spawn({ kind: 'ring', x: this.cx, y: this.cy, life: 0.7, size: 520, color: '#ffffff' });
    host.particles.debris(this.cx, this.cy, 46, '#ffd93b', 2.2, true);
    host.particles.debris(this.cx, this.cy, 18, '#f2b81c', 1.8, true);
    host.particles.debris(this.cx, this.cy, 10, '#5a3a1a', 1.5, false);
    host.sfx.explosion();
    host.sfx.bananaPop();
    host.shake(22);
    host.stamp('PEDRO... TUMBANG?!', this.cx, this.cy - 150, '#ffffff', 50, '#c77dff');
  }
}
