import { drawGun, type GunKind } from './character';
import { drawHaloIcon, isHaloId } from './halo';

const SCALE: Record<string, number> = { sniper: 0.5, bat: 0.62, ak47: 0.62, shotgun: 0.6, katana: 0.56, cricket: 1.6, sling: 1.15 };
const OFFSET: Record<string, number> = { sniper: -12, bat: -22, katana: -27, ak47: -6, shotgun: -6, cricket: -3, sling: 0 };

/** ikon senjata (lama maupun HALO) mendatar, pas di kotak w x h berpusat di (cx, cy) */
export function drawWeaponIcon(ctx: CanvasRenderingContext2D, id: string, cx: number, cy: number, w: number, h: number) {
  if (isHaloId(id)) {
    drawHaloIcon(ctx, id, cx, cy, w, h);
    return;
  }
  const k = Math.min(w / 46, h / 24) * (SCALE[id] ?? 0.95);
  ctx.save();
  ctx.translate(cx, cy + h * 0.08);
  ctx.scale(k, k);
  drawGun(ctx, id as GunKind, OFFSET[id] ?? -5, id === 'sling' ? 2 : 0, id === 'bat' ? -0.25 : id === 'katana' ? -0.32 : 0, 0);
  ctx.restore();
}
