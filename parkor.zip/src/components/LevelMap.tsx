import { useMemo } from 'react';
import type { LevelDef, RoomStyle, SolidKind } from '../game/level';

const ROOM_COLORS: Record<RoomStyle, string> = {
  basement: '#26313d', freezer: '#2a4b5a', alley: '#343c50', kitchen: '#4a3c38',
  stair: '#354153', warehouse: '#3e403c', penthouse: '#523a48', dream: '#493a62', dojo: '#57473b',
};

const SOLID_COLORS: Record<SolidKind, string> = {
  concrete: '#68727a', brick: '#865e56', tile: '#a9b8b8', metal: '#8fa1a9', wood: '#a77a50',
  crate: '#a77a50', dumpster: '#4e7775', counter: '#b18c72', roof: '#596475', duct: '#78969b',
  table: '#a47a5c', steeltable: '#9aaeb1', dream: '#85729b',
};

export default function LevelMap({ level, zoom = 1 }: { level: LevelDef; zoom?: number }) {
  const map = useMemo(() => {
    const rects = [level.bounds, ...level.rooms, ...level.solids, level.exit];
    const left = Math.min(...rects.map((r) => r.x));
    const top = Math.min(...rects.map((r) => r.y));
    const right = Math.max(...rects.map((r) => r.x + r.w));
    const bottom = Math.max(...rects.map((r) => r.y + r.h));
    const w = right - left;
    const h = bottom - top;
    const pad = w * 0.012;
    return { x: left - pad, y: top - pad, w: w + pad * 2, h: h + pad * 2, u: w / 100 };
  }, [level]);

  const u = map.u;
  return (
    <svg
      viewBox={`${map.x} ${map.y} ${map.w} ${map.h}`}
      preserveAspectRatio="xMidYMid meet"
      className="block h-full w-full"
      style={{ width: `${zoom * 100}%`, height: `${zoom * 100}%`, minWidth: `${zoom * 100}%`, minHeight: `${zoom * 100}%` }}
      role="img"
      aria-label={`Peta lengkap ${level.name}: ${level.subtitle}. Titik mulai, ruangan, platform, musuh, checkpoint, dan pintu keluar.`}
    >
      <defs>
        <pattern id="map-grid" width={u * 5} height={u * 5} patternUnits="userSpaceOnUse">
          <path d={`M ${u * 5} 0 L 0 0 0 ${u * 5}`} fill="none" stroke="#ffffff" strokeOpacity="0.06" strokeWidth={u * 0.08} />
        </pattern>
        <pattern id="map-hatch" width={u * 0.8} height={u * 0.8} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2={u * 0.8} stroke="#ffffff" strokeOpacity="0.15" strokeWidth={u * 0.09} />
        </pattern>
      </defs>
      <rect x={map.x} y={map.y} width={map.w} height={map.h} fill="#171d29" />
      {level.rooms.map((room, i) => (
        <g key={`room-${i}`}>
          <rect x={room.x} y={room.y} width={room.w} height={room.h} fill={ROOM_COLORS[room.style]} stroke="#73808b" strokeOpacity="0.32" strokeWidth={u * 0.14} />
          {room.w > map.w * 0.09 && <text x={room.x + u * 1.5} y={room.y + u * 2.4} fill="#ffffff" opacity="0.55" fontSize={u * 1.35} fontWeight="700" letterSpacing={u * 0.1}>{room.style.toUpperCase()}</text>}
        </g>
      ))}
      <rect x={map.x} y={map.y} width={map.w} height={map.h} fill="url(#map-grid)" />
      {level.solids.map((solid, i) => (
        <g key={`solid-${i}`}>
          <rect x={solid.x} y={solid.y} width={solid.w} height={solid.h} fill={SOLID_COLORS[solid.kind]} stroke="#c9d3d3" strokeOpacity="0.46" strokeWidth={u * 0.11} />
          {!solid.oneWay && solid.h > u * 2 && <rect x={solid.x} y={solid.y} width={solid.w} height={solid.h} fill="url(#map-hatch)" />}
          <title>{`${solid.kind}${solid.oneWay ? ' (platform)' : ''}`}</title>
        </g>
      ))}
      {level.decos.map((deco, i) => {
        if (deco.type === 'sign' || deco.type === 'graffiti' || deco.type === 'poster') {
          return <text key={`deco-${i}`} x={deco.x} y={deco.y} fill={deco.color || '#ffd48b'} fontSize={u * 1.15} fontWeight="800"><title>{deco.text || deco.type}</title>{(deco.text || deco.type).slice(0, 24)}</text>;
        }
        if (deco.type === 'pipe' || deco.type === 'rail' || deco.type === 'beam') {
          return <rect key={`deco-${i}`} x={deco.x} y={deco.y} width={deco.w || u * 6} height={Math.min(deco.h || u * 0.3, u * 1.4)} fill="#97aab2" fillOpacity="0.45"><title>{deco.type}</title></rect>;
        }
        if (deco.type === 'bgdoor' || deco.type === 'window' || deco.type === 'curtain' || deco.type === 'painting') {
          return <rect key={`deco-${i}`} x={deco.x} y={deco.y} width={deco.w || u * 3} height={deco.h || u * 4} fill={deco.color || '#697887'} fillOpacity="0.6" stroke="#b5bfc7" strokeWidth={u * 0.1}><title>{deco.type}</title></rect>;
        }
        return <circle key={`deco-${i}`} cx={deco.x} cy={deco.y - u * 0.5} r={u * 0.35} fill={deco.color || '#aeb8a7'} fillOpacity="0.8"><title>{deco.type}</title></circle>;
      })}
      {level.ziplines.map((line, i) => <line key={`zip-${i}`} x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2} stroke="#ffd23f" strokeWidth={u * 0.35} strokeDasharray={`${u * 0.7} ${u * 0.35}`} />)}
      {level.props.filter((prop) => prop.type === 'barrel' || prop.type === 'door' || prop.type === 'glassdoor').map((prop, i) => (
        <rect key={`prop-${i}`} x={prop.x - u * 0.45} y={prop.y - (prop.type === 'barrel' ? u : prop.h || u * 2.7)} width={prop.w || u * 0.9} height={prop.type === 'barrel' ? u : prop.h || u * 2.7} fill={prop.type === 'barrel' ? '#d47964' : '#9c8f79'} fillOpacity="0.9"><title>{prop.type}</title></rect>
      ))}
      {level.checkpoints.map((cp) => (
        <g key={`checkpoint-${cp.id}`}>
          <path d={`M ${cp.spawn.x} ${cp.spawn.y - u * 3} L ${cp.spawn.x} ${cp.spawn.y - u * 0.1}`} stroke="#74dff4" strokeWidth={u * 0.3} />
          <path d={`M ${cp.spawn.x} ${cp.spawn.y - u * 3} l ${u * 1.9} ${u * 0.55} l ${-u * 1.9} ${u * 0.55} Z`} fill="#74dff4" />
          <title>{`Checkpoint ${cp.id}`}</title>
        </g>
      ))}
      {level.enemies.map((enemy, i) => (
        <g key={`enemy-${i}`}>
          <circle cx={enemy.x} cy={enemy.y - u * 0.8} r={enemy.type === 'boss' ? u * 0.93 : u * 0.51} fill={enemy.type === 'boss' ? '#ffcf57' : '#f1716d'} stroke="#2b1722" strokeWidth={u * 0.14} />
          {enemy.type === 'boss' && <text x={enemy.x} y={enemy.y - u * 2.15} textAnchor="middle" fill="#ffcf57" fontWeight="800" fontSize={u * 1.4}>BOSS</text>}
          <title>{enemy.type === 'boss' ? 'Bos mafia' : `Musuh: ${enemy.type}`}</title>
        </g>
      ))}
      {level.props.filter((prop) => prop.type === 'weapon' || prop.type === 'shotgun' || prop.type === 'uzi').map((prop, i) => (
        <g key={`weapon-${i}`}>
          <rect x={prop.x - u * 0.6} y={prop.y - u * 1.35} width={u * 1.2} height={u * 0.7} rx={u * 0.18} fill="#c8afff" />
          <title>{`Senjata: ${prop.gun || prop.type}`}</title>
        </g>
      ))}
      <g>
        <circle cx={level.spawn.x} cy={level.spawn.y - u * 1.4} r={u * 0.75} fill="#78e3ad" stroke="#142d2a" strokeWidth={u * 0.18} />
        <text x={level.spawn.x} y={level.spawn.y - u * 2.8} textAnchor="middle" fill="#9ff5c5" fontWeight="800" fontSize={u * 1.45}>MULAI</text>
      </g>
      <g>
        <rect x={level.exit.x} y={level.exit.y} width={level.exit.w} height={level.exit.h} fill="#6bdcb0" fillOpacity="0.5" stroke="#a9ffce" strokeWidth={u * 0.26} />
        <text x={level.exit.x + level.exit.w / 2} y={level.exit.y - u * 0.9} textAnchor="middle" fill="#a9ffce" fontWeight="800" fontSize={u * 1.45}>KELUAR</text>
      </g>
    </svg>
  );
}