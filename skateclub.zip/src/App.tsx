import { useEffect, useRef, useState } from 'react';
import type { PointerEvent as RPointerEvent } from 'react';
import { Game } from './game/Game';
import type { GameResult, HudState, Phase } from './game/Game';
import { Hud, Popups } from './components/Hud';
import type { PopupItem } from './components/Hud';
import { GameOver, Menu, PauseOverlay, TouchControls } from './components/Screens';
import { SpeakerIcon } from './components/Icons';
import { PlacePicker, SkinPicker, TrickList } from './components/SkinPicker';
import { getPlace } from './game/themes';
import { getBoard, getChar } from './game/skins';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const popupId = useRef(0);
  const [phase, setPhase] = useState<Phase>('menu');
  const [hud, setHud] = useState<HudState>({ score: 0, distance: 0, coins: 0, combo: 1, best: 0, speed: 0 });
  const [result, setResult] = useState<GameResult | null>(null);
  const [popups, setPopups] = useState<PopupItem[]>([]);
  const [paused, setPaused] = useState(false);
  const [muted, setMuted] = useState(false);
  const [touch, setTouch] = useState(false);
  const [portrait, setPortrait] = useState(false);
  const [skin, setSkin] = useState({ charId: 'ayam', boardId: 'ayam' });
  const [showSkins, setShowSkins] = useState(false);
  const [showTricks, setShowTricks] = useState(false);
  const [showPlace, setShowPlace] = useState(false);
  const [placeId, setPlaceId] = useState('hijau');

  useEffect(() => {
    const coarse = window.matchMedia?.('(pointer: coarse)').matches ?? false;
    setTouch(coarse || 'ontouchstart' in window || navigator.maxTouchPoints > 0);
    const checkOrientation = () => setPortrait(window.innerHeight > window.innerWidth * 1.05);
    checkOrientation();
    window.addEventListener('resize', checkOrientation);

    const el = mountRef.current;
    if (!el) return;
    const timers = new Set<number>();
    const game = new Game(el, {
      onHud: (h) => setHud(h),
      onPhase: (p, r) => {
        setPhase(p);
        if (p !== 'menu') {
          setShowSkins(false);
          setShowPlace(false);
        }
        if (r) setResult(r);
        if (p === 'playing') setResult(null);
      },
      onPopup: (text, kind, sub) => {
        const id = ++popupId.current;
        setPopups((ps) => [...ps.slice(-3), { id, text, kind, sub }]);
        const t = window.setTimeout(
          () => {
            setPopups((ps) => ps.filter((x) => x.id !== id));
            timers.delete(t);
          },
          kind === 'crash' ? 2250 : 1550,
        );
        timers.add(t);
      },
      onPause: (p) => setPaused(p),
    });
    gameRef.current = game;
    setSkin(game.getSkin());
    setPlaceId(game.getPlaceId());
    if (window.location.hash === '#debug') (window as unknown as { __game?: Game }).__game = game;
    return () => {
      window.removeEventListener('resize', checkOrientation);
      timers.forEach((t) => window.clearTimeout(t));
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  const toggleMute = () => {
    setMuted((m) => {
      gameRef.current?.setMuted(!m);
      return !m;
    });
  };

  const onStagePointerDown = (e: RPointerEvent) => {
    // mouse: left click = freestyle (spam to cycle tricks), right click (hold) = boost 3x
    if (e.pointerType !== 'mouse' || paused) return;
    if (e.button === 2) {
      if (phase === 'playing') gameRef.current?.setControl('right', true);
    } else if (e.button === 0) {
      gameRef.current?.pressFreestyle();
    }
  };
  const onStagePointerUp = (e: RPointerEvent) => {
    if (e.pointerType !== 'mouse') return;
    if (e.button === 2) gameRef.current?.setControl('right', false);
    else if (e.button === 0) gameRef.current?.setControl('jump', false);
  };

  return (
    <div
      className="relative h-full w-full overflow-hidden"
      style={{ background: getPlace(placeId).skyCss }}
      onPointerDown={onStagePointerDown}
      onPointerUp={onStagePointerUp}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div ref={mountRef} className="absolute inset-0" />

      {(phase === 'playing' || phase === 'crashed') && (
        <Hud
          hud={hud}
          muted={muted}
          onMute={toggleMute}
          onPause={() => gameRef.current?.togglePause()}
          showPause={phase === 'playing'}
        />
      )}

      <Popups popups={popups} />

      {phase === 'menu' && (
        <>
          {!showSkins && (
            <Menu
              best={hud.best}
              touch={touch}
              onPlay={() => gameRef.current?.start()}
              onSkins={() => {
                setShowSkins(true);
                gameRef.current?.setPreview(true);
              }}
              onTricks={() => setShowTricks(true)}
              onPlace={() => {
                setShowPlace(true);
                gameRef.current?.setPreview(true);
              }}
              skinLabel={`${getChar(skin.charId).name} + ${getBoard(skin.boardId).name}`}
              placeLabel={getPlace(placeId).name}
            />
          )}
          {showPlace && (
            <PlacePicker
              placeId={placeId}
              onPick={(id) => {
                gameRef.current?.setPlace(id);
                setPlaceId(id);
              }}
              onClose={() => {
                setShowPlace(false);
                gameRef.current?.setPreview(false);
              }}
            />
          )}
          {showSkins && (
            <SkinPicker
              charId={skin.charId}
              boardId={skin.boardId}
              onPick={(c, b) => {
                gameRef.current?.setSkin(c, b);
                setSkin({ charId: c, boardId: b });
              }}
              onClose={() => {
                setShowSkins(false);
                gameRef.current?.setPreview(false);
              }}
            />
          )}
          <div className="absolute right-3 top-3 sm:right-5 sm:top-5">
            <button
              aria-label="Suara"
              onClick={toggleMute}
              onPointerDown={(e) => e.stopPropagation()}
              className="voxel-btn font-game flex h-12 w-12 items-center justify-center rounded-xl bg-white text-xl"
            >
              <SpeakerIcon muted={muted} />
            </button>
          </div>
        </>
      )}

      {phase === 'over' && result && (
        <GameOver
          result={result}
          touch={touch}
          onRetry={() => gameRef.current?.restart()}
          onMenu={() => gameRef.current?.toMenu()}
        />
      )}

      {paused && phase === 'playing' && (
        <PauseOverlay
          onResume={() => gameRef.current?.togglePause()}
          onRestart={() => gameRef.current?.restart()}
        />
      )}

      {touch && phase === 'playing' && !paused && (
        <TouchControls onControl={(name, down) => gameRef.current?.setControl(name, down)} />
      )}

      {showTricks && <TrickList touch={touch} onClose={() => setShowTricks(false)} />}

      {touch && portrait && phase !== 'over' && (
        <div className="font-game txt-outline-sm pointer-events-none absolute inset-x-0 bottom-36 text-center text-base text-white">
          Putar HP ke landscape biar lebih seru!
        </div>
      )}
    </div>
  );
}
