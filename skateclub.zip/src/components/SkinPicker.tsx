import { useState } from 'react';
import { BOARDS, CHARS, getChar } from '../game/skins';
import { boardThumb, charThumb } from '../game/thumbs';
import { FAMILY_KEY, FAMILY_LABEL, TRICKS } from '../game/tricks';
import type { TrickFamily } from '../game/tricks';
import { cn } from '../utils/cn';

const BADGE_COLOR: Record<string, string> = {
  ORIGINAL: 'bg-[#ffd23f] text-[#3d2a00]',
  'PIGEON SK8': 'bg-[#6d70a5] text-white',
  'VOXEL BUDDIES': 'bg-[#ff8fd1] text-[#4a0d33]',
  'LITTLE JAPAN FRIEND': 'bg-[#d69989] text-[#3b1a12]',
  STANDARD: 'bg-[#2ec4b6] text-[#063b36]',
  'VOXEL BOARD': 'bg-[#7fe3ff] text-[#0b3a4a]',
};

export function SkinPicker({
  charId,
  boardId,
  onPick,
  onClose,
}: {
  charId: string;
  boardId: string;
  onPick: (charId: string, boardId: string) => void;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<'char' | 'board'>('char');
  const items = tab === 'char' ? CHARS : BOARDS;
  const selected = tab === 'char' ? charId : boardId;
  const cur = tab === 'char' ? CHARS.find((c) => c.id === charId) : BOARDS.find((b) => b.id === boardId);
  return (
    <div
      className="font-game absolute inset-x-0 bottom-0 z-20 flex max-h-[58%] flex-col rounded-t-3xl border-t-4 border-[#1c1c28] bg-white/95 shadow-[0_-6px_0_rgba(0,0,0,0.15)] sm:inset-y-0 sm:left-auto sm:right-0 sm:max-h-none sm:w-[430px] sm:rounded-none sm:border-l-4 sm:border-t-0 short:max-h-[70%]"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="flex items-center gap-2 p-3 pb-2">
        <button
          onClick={() => setTab('char')}
          className={cn('voxel-btn flex-1 rounded-xl py-2 text-lg', tab === 'char' ? 'bg-[#ffd23f] text-[#3d2a00]' : 'bg-white text-slate-600')}
        >
          KARAKTER ({CHARS.length})
        </button>
        <button
          onClick={() => setTab('board')}
          className={cn('voxel-btn flex-1 rounded-xl py-2 text-lg', tab === 'board' ? 'bg-[#7fe3ff] text-[#0b3a4a]' : 'bg-white text-slate-600')}
        >
          SKATEBOARD ({BOARDS.length})
        </button>
        <button onClick={onClose} aria-label="Tutup" className="voxel-btn h-11 w-11 rounded-xl bg-[#ff5a36] text-xl text-white">
          ✕
        </button>
      </div>
      {cur && (
        <div className="mx-3 mb-2 rounded-xl bg-[#f1f7ff] px-3 py-2 text-slate-700">
          <div className="flex items-center gap-2 text-lg leading-tight">
            <span className="text-2xl">{cur.emoji}</span>
            <span className="truncate">{cur.name}</span>
            <span className={cn('ml-auto shrink-0 rounded-md px-1.5 py-0.5 text-[10px]', BADGE_COLOR[cur.badge] ?? 'bg-slate-200')}>
              {cur.badge}
            </span>
          </div>
          <div className="line-clamp-2 text-xs text-slate-500">{cur.desc}</div>
        </div>
      )}
      <div className="grid flex-1 grid-cols-3 gap-2 overflow-y-auto px-3 pb-4 sm:grid-cols-3">
        {items.map((it) => (
          <button
            key={it.id}
            onClick={() => (tab === 'char' ? onPick(it.id, boardId) : onPick(charId, it.id))}
            className={cn(
              'relative flex flex-col items-center rounded-xl border-[3px] px-1 pb-1.5 pt-2 text-center transition',
              selected === it.id
                ? 'border-[#1c1c28] bg-[#fff4c2] shadow-[0_4px_0_#1c1c28]'
                : 'border-slate-200 bg-white hover:border-slate-400',
            )}
          >
            <img
              src={tab === 'char' ? charThumb(it.id) : boardThumb(it.id, getChar(charId).deck)}
              alt={it.name}
              className="h-16 w-16 object-contain"
              draggable={false}
            />
            <span className="mt-1 line-clamp-2 text-[12px] leading-tight text-slate-800">{it.name}</span>
            <span className={cn('mt-1 rounded px-1 text-[8px] leading-4', BADGE_COLOR[it.badge] ?? 'bg-slate-200')}>{it.badge}</span>
            {selected === it.id && (
              <span className="absolute -right-1.5 -top-1.5 flex h-6 w-6 items-center justify-center rounded-full border-2 border-[#1c1c28] bg-[#5ee36a] text-xs">
                ✓
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

const FAMILY_COLOR: Record<TrickFamily, string> = {
  flip: 'bg-[#ffd60a] text-[#3d2a00]',
  grab: 'bg-[#ff5c8a] text-white',
  spin: 'bg-[#4cc9f0] text-[#05303d]',
};

export function TrickList({ onClose, touch }: { onClose: () => void; touch: boolean }) {
  const fams: TrickFamily[] = ['flip', 'grab', 'spin'];
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#1c1c28]/40 p-3" onPointerDown={(e) => e.stopPropagation()}>
      <div className="voxel-panel font-game flex max-h-full w-full max-w-3xl flex-col rounded-3xl p-4 text-slate-800">
        <div className="flex items-center gap-3">
          <div className="txt-outline-sm text-3xl text-[#ffd23f]">DAFTAR TRIK FREESTYLE</div>
          <button onClick={onClose} aria-label="Tutup" className="voxel-btn ml-auto h-11 w-11 rounded-xl bg-[#ff5a36] text-xl text-white">
            ✕
          </button>
        </div>
        <div className="mt-1 text-sm text-slate-500">
          {TRICKS.length} trik dari Pigeon SK8. Lompat dulu, lalu tekan{' '}
          {touch ? 'tombol FLIP / GRAB / SPIN' : 'Z (FLIP), X / S (GRAB), C (SPIN)'} di udara — tiap tekan memainkan trik berikutnya dalam keluarganya.
          Trik harus selesai sebelum mendarat! Tandai <b>BIG AIR</b> = cuma bisa saat lompatan tinggi (ramp/jurang).
        </div>
        <div className="mt-3 grid gap-3 overflow-y-auto pr-1 md:grid-cols-3">
          {fams.map((f) => (
            <div key={f} className="rounded-2xl border-[3px] border-[#1c1c28] bg-white p-2">
              <div className={cn('mb-2 flex items-center justify-between rounded-lg px-2 py-1 text-lg', FAMILY_COLOR[f])}>
                <span>{FAMILY_LABEL[f]}</span>
                <span className="key-cap text-slate-800">{touch ? FAMILY_LABEL[f] : FAMILY_KEY[f]}</span>
              </div>
              <ul className="space-y-1.5">
                {TRICKS.filter((t) => t.family === f).map((t) => (
                  <li key={t.kind} className="rounded-lg bg-slate-50 px-2 py-1">
                    <div className="flex items-center gap-1 text-[15px] leading-tight">
                      <span style={{ color: t.color }} className="drop-shadow-[0_1px_0_#1c1c28]">
                        {t.name}
                      </span>
                      {t.bigAirOnly && <span className="rounded bg-[#1c1c28] px-1 text-[9px] text-white">BIG AIR</span>}
                      <span className="ml-auto text-sm text-slate-500">+{t.pts}</span>
                    </div>
                    <div className="text-[11px] leading-tight text-slate-500">{t.desc}</div>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-2 text-center text-xs text-slate-500">
          Bonus: {touch ? '◀ ▶' : '← →'} di udara = BACKFLIP / FRONTFLIP (fisika) — bisa digabung dengan trik freestyle!
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Place picker (Bukit Hijau / Tokyo / Shibuya)                        */
/* ------------------------------------------------------------------ */

import { PLACES } from '../game/themes';

export function PlacePicker({
  placeId,
  onPick,
  onClose,
}: {
  placeId: string;
  onPick: (id: string) => void;
  onClose: () => void;
}) {
  const cur = PLACES.find((p) => p.id === placeId) ?? PLACES[0];
  return (
    <div
      className="font-game absolute inset-x-0 bottom-0 z-20 flex max-h-[58%] flex-col rounded-t-3xl border-t-4 border-[#1c1c28] bg-white/95 shadow-[0_-6px_0_rgba(0,0,0,0.15)] sm:inset-y-0 sm:left-auto sm:right-0 sm:max-h-none sm:w-[430px] sm:rounded-none sm:border-l-4 sm:border-t-0 short:max-h-[70%]"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="flex items-center gap-2 p-3 pb-2">
        <div className="voxel-btn flex-1 rounded-xl bg-[#ffd23f] py-2 text-center text-lg text-[#3d2a00]">PILIH TEMPAT</div>
        <button onClick={onClose} aria-label="Tutup" className="voxel-btn h-11 w-11 rounded-xl bg-[#ff5a36] text-xl text-white">
          ✕
        </button>
      </div>
      <div className="mx-3 mb-2 rounded-xl px-3 py-2 text-white" style={{ background: cur.skyCss }}>
        <div className="flex items-center gap-2 text-lg leading-tight drop-shadow-[0_2px_0_rgba(0,0,0,0.35)]">
          <span className="text-2xl">{cur.emoji}</span>
          <span className="truncate">{cur.name}</span>
          <span className="ml-auto shrink-0 rounded-md bg-white/85 px-1.5 py-0.5 text-[10px] text-slate-800">{cur.badge}</span>
        </div>
        <div className="text-xs text-white/90 drop-shadow-[0_1px_0_rgba(0,0,0,0.35)]">{cur.desc}</div>
      </div>
      <div className="grid flex-1 grid-cols-1 gap-2 overflow-y-auto px-3 pb-4">
        {PLACES.map((p) => (
          <button
            key={p.id}
            onClick={() => onPick(p.id)}
            className={cn(
              'relative flex items-center gap-3 rounded-xl border-[3px] px-3 py-3 text-left transition',
              placeId === p.id
                ? 'border-[#1c1c28] shadow-[0_4px_0_#1c1c28]'
                : 'border-slate-200 bg-white hover:border-slate-400',
            )}
            style={{ background: p.skyCss }}
          >
            <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-white/85 text-3xl">{p.emoji}</span>
            <span className="min-w-0">
              <span className="block truncate text-lg leading-tight text-white drop-shadow-[0_2px_0_rgba(0,0,0,0.35)]">{p.name}</span>
              <span className="block text-xs leading-tight text-white/90 drop-shadow-[0_1px_0_rgba(0,0,0,0.35)]">{p.desc}</span>
            </span>
            {placeId === p.id && (
              <span className="absolute -right-1.5 -top-1.5 flex h-6 w-6 items-center justify-center rounded-full border-2 border-[#1c1c28] bg-[#5ee36a] text-xs">
                ✓
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
