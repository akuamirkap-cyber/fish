import * as THREE from 'three';
import { Chain } from 'planck';
import type { Body, World } from 'planck';
import { BOTTOM_Y, COLORS, RAMP_HALF, ROAD_HALF, CURB_W, STEP, WATER_Y, Z_BACK, Z_FRONT } from './constants';
import {
  mergeColored,
  propBarrier,
  propBillboard,
  propBuilding,
  propBush,
  propCone,
  propFlowers,
  propLamp,
  propLily,
  propLog,
  propNeonSign,
  propPine,
  propPole,
  propRock,
  propShop,
  propSign,
  propTall,
  propTree,
  propVending,
  vbox,
} from './voxel';
import type { PropSet, TerrainPalette } from './themes';

export interface TPoint {
  x: number;
  y: number; // riding surface
  base: number; // ground level (differs from y on ramps)
  ramp: boolean;
}

export interface CoinSpot {
  x: number;
  y: number;
}

export type DecorKind =
  | 'tree'
  | 'pine'
  | 'tall'
  | 'bush'
  | 'flower'
  | 'rock'
  | 'lamp'
  | 'sign'
  | 'cone'
  | 'barrier'
  | 'debris'
  | 'log'
  | 'lily'
  | 'building'
  | 'shop'
  | 'vending'
  | 'neonsign'
  | 'billboard'
  | 'pole';

export interface Decor {
  kind: DecorKind;
  x: number;
  z: number;
  s?: number;
  c?: number;
}

export interface GapInfo {
  x0: number;
  x1: number;
  y0: number;
  y1: number;
}

export interface RailData {
  x0: number;
  x1: number;
  /** height above the riding surface */
  h: number;
  /** spans a gap: stays with this piece even if x1 > maxX */
  span?: boolean;
}

export interface RailInfo {
  x0: number;
  x1: number;
  pts: { x: number; y: number }[];
}

export interface PieceData {
  id: number;
  pts: TPoint[];
  startCliff: boolean;
  endCliff: boolean;
  coins: CoinSpot[];
  decor: Decor[];
  rails: RailData[];
  minX: number;
  maxX: number;
}

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const snap = (v: number) => Math.max(STEP, Math.round(v / STEP) * STEP);
const Y_MIN = -7.5;
const Y_MAX = 6.5;
/** lower target that never goes below Y_MIN and never rises above the current height */
const dropTo = (cur: number, target: number) => Math.max(target, Math.min(cur, Y_MIN));

/* ================================================================== */
/* Level generator                                                     */
/* ================================================================== */

export class LevelGen {
  propSet: PropSet = 'park';
  private rnd: () => number;
  private pts: TPoint[] = [];
  private startCliff = true;
  private coins: CoinSpot[] = [];
  private decor: Decor[] = [];
  private rails: RailData[] = [];
  private feature = 0;
  private nextId = 1;
  x = 0;
  y = 0;
  out: PieceData[] = [];
  gaps: GapInfo[] = [];

  constructor(seed: number) {
    this.rnd = mulberry32(seed);
    this.x = -46;
    this.y = 0;
    this.pts.push({ x: this.x, y: 0, base: 0, ramp: false });
    this.flat(46); // to x = 0
    this.flat(12);
    this.cosTo(this.x + 22, this.y - 2.5);
    this.flat(4);
  }

  private r(a: number, b: number) {
    return a + (b - a) * this.rnd();
  }

  private add(x: number, y: number, ramp = false, base = y) {
    this.pts.push({ x, y, base, ramp });
    this.x = x;
    this.y = base;
  }

  private flat(len: number) {
    const n = Math.max(1, Math.round(len / STEP));
    const x0 = this.x;
    const y0 = this.y;
    for (let i = 1; i <= n; i++) this.add(x0 + i * STEP, y0);
  }

  private cosTo(x1: number, y1: number) {
    const x0 = this.x;
    const y0 = this.y;
    const L = x1 - x0;
    const n = Math.max(2, Math.round(L / STEP));
    for (let i = 1; i <= n; i++) {
      const t = i / n;
      this.add(x0 + L * t, y0 + ((y1 - y0) * (1 - Math.cos(Math.PI * t))) / 2);
    }
  }

  private surf(x: number): number {
    const p = this.pts;
    for (let i = p.length - 1; i > 0; i--) {
      if (p[i - 1].x <= x && p[i].x >= x) {
        const dx = p[i].x - p[i - 1].x;
        if (dx < 1e-6) return Math.max(p[i].y, p[i - 1].y);
        return p[i - 1].y + ((p[i].y - p[i - 1].y) * (x - p[i - 1].x)) / dx;
      }
    }
    return this.y;
  }

  private coinsAlong(x0: number, x1: number, h: number) {
    const n = Math.max(2, Math.floor((x1 - x0) / 1.35));
    for (let i = 0; i <= n; i++) {
      const x = x0 + ((x1 - x0) * i) / n;
      this.coins.push({ x, y: this.surf(x) + h });
    }
  }

  private coinsArc(xa: number, ya: number, xb: number, yb: number, apex: number) {
    const n = Math.max(3, Math.round((xb - xa) / 1.3));
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      this.coins.push({ x: xa + (xb - xa) * t, y: ya + (yb - ya) * t + 4 * apex * t * (1 - t) });
    }
  }

  /* ------------------------- features ---------------------------- */

  private hills(count: number, amp: number) {
    let down = this.y > 1 ? true : this.y < -2 ? false : this.rnd() < 0.6;
    for (let i = 0; i < count; i++) {
      const dx = snap(this.r(13, 24));
      const maxDy = Math.min(dx * 0.31, 5.5) * amp;
      const dy = (down ? -1 : 1) * this.r(0.45, 1) * maxDy;
      let ty = this.y + dy;
      if (ty < Y_MIN) ty = Math.min(this.y + Math.abs(dy) * 0.8, Y_MAX);
      if (ty > Y_MAX) ty = Math.max(this.y - Math.abs(dy) * 0.8, Y_MIN);
      const x0 = this.x;
      const y0 = this.y;
      this.cosTo(this.x + dx, ty);
      const roll = this.rnd();
      if (roll < 0.4) {
        if (ty < y0) this.coinsAlong(x0 + dx * 0.3, x0 + dx * 0.92, 1.0);
        else this.coinsAlong(x0 + dx * 0.15, x0 + dx * 0.6, 1.0);
      } else if (roll < 0.6 && ty > y0) {
        // high coins on the crest -> needs a hop
        this.coinsArc(this.x - 3.5, this.y + 2.0, this.x + 0.5, this.y + 2.0, 0.6);
      }
      down = ty >= y0;
    }
  }

  private rollers(n: number, amp: number) {
    const y0 = this.y;
    for (let i = 0; i < n; i++) {
      const half = snap(this.r(3.5, 4.5));
      const a = this.r(0.5, 0.8) * amp;
      this.cosTo(this.x + half, y0 + a);
      if (i % 2 === 0) this.coins.push({ x: this.x, y: y0 + a + 1.1 });
      this.cosTo(this.x + half, y0);
    }
    this.flat(2);
  }

  private newLand(x: number, y: number) {
    this.pts = [{ x, y, base: y, ramp: false }];
    this.x = x;
    this.y = y;
    this.startCliff = true;
  }

  private waterDecor(x0: number, x1: number) {
    const n = 1 + Math.floor(this.rnd() * 3);
    for (let i = 0; i < n; i++) {
      const x = this.r(x0 + 0.6, x1 - 0.6);
      if (this.rnd() < 0.5) this.decor.push({ kind: 'log', x, z: this.r(-12, 0.5), c: this.rnd() });
      else this.decor.push({ kind: 'lily', x, z: this.r(-10, 1.5), c: this.rnd() });
    }
  }

  private gap(width: number, drop: number, approach = this.r(6, 8)) {
    this.flat(approach);
    const x0 = this.x;
    const y0 = this.y;
    this.decor.push({ kind: 'sign', x: x0 - 3.2, z: -2.7 });
    this.decor.push({ kind: 'cone', x: x0 - 0.45, z: 1.84 }, { kind: 'cone', x: x0 - 0.45, z: -1.84 });
    this.decor.push({ kind: 'debris', x: x0, z: 0, s: 1 });
    const x1 = x0 + width;
    const y1 = Math.min(dropTo(y0, y0 + drop), Y_MAX);
    this.coinsArc(x0 - 0.8, y0 + 1.3, x1 + 1.2, y1 + 1.1, 1.4 + width * 0.16);
    // sometimes a grind rail spans the gap — grind across instead of jumping!
    if (this.rnd() < 0.45) this.rails.push({ x0: x0 - 0.5, x1: x1 + 1.5, h: 1.15, span: true });
    this.flush(true);
    this.gaps.push({ x0, x1, y0, y1 });
    this.newLand(x1, y1);
    this.decor.push({ kind: 'cone', x: x1 + 0.45, z: 1.84 }, { kind: 'cone', x: x1 + 0.45, z: -1.84 });
    this.decor.push({ kind: 'debris', x: x1, z: 0, s: -1 });
    this.waterDecor(x0, x1);
    this.flat(this.r(5, 7));
  }

  private rampUp(h: number, angDeg: number) {
    const th = (angDeg * Math.PI) / 180;
    const R = h / (1 - Math.cos(th));
    const L = R * Math.sin(th);
    const n = Math.max(7, Math.ceil(L / 0.2));
    const x0 = this.x;
    const y0 = this.y;
    this.pts[this.pts.length - 1].ramp = true;
    for (let i = 1; i <= n; i++) {
      const t = (th * i) / n;
      this.add(x0 + R * Math.sin(t), y0 + R * (1 - Math.cos(t)), true, y0);
    }
    return { lipX: x0 + L, lipY: y0 + h, baseY: y0 };
  }

  private kicker(h: number, ang: number, landDrop: number) {
    this.flat(this.r(5, 7));
    this.decor.push({ kind: 'barrier', x: this.x - 1.5, z: -2.6 });
    const r = this.rampUp(h, ang);
    this.add(r.lipX, r.baseY); // vertical back side
    this.coinsArc(r.lipX + 0.4, r.lipY + 1.3, r.lipX + 8, r.baseY + landDrop * 0.35 + 1.2, 2.3);
    this.flat(1.5);
    this.cosTo(this.x + snap(this.r(12, 16)), dropTo(this.y, this.y + landDrop));
    this.flat(2);
  }

  private rampGap(width: number, drop: number) {
    if (this.y > -3.5) this.cosTo(this.x + snap(this.r(14, 18)), dropTo(this.y, this.y - this.r(2.5, 4)));
    else this.flat(8);
    this.flat(this.r(3, 4.5));
    this.decor.push({ kind: 'sign', x: this.x - 1.5, z: -2.7 });
    const r = this.rampUp(this.r(0.95, 1.25), this.r(28, 35));
    const x0 = r.lipX;
    const x1 = x0 + width;
    const y1 = dropTo(r.baseY, r.baseY + drop);
    this.coinsArc(x0 + 0.3, r.lipY + 1.1, x1 + 1.8, y1 + 1.1, 2.4 + width * 0.12);
    this.decor.push({ kind: 'debris', x: x0, z: 0, s: 1 });
    this.flush(true);
    this.gaps.push({ x0, x1, y0: r.baseY, y1 });
    this.newLand(x1, y1);
    this.decor.push({ kind: 'debris', x: x1, z: 0, s: -1 });
    this.decor.push({ kind: 'cone', x: x1 + 0.45, z: 1.84 }, { kind: 'cone', x: x1 + 0.45, z: -1.84 });
    this.waterDecor(x0, x1);
    this.flat(this.r(2.5, 3.5));
    this.cosTo(this.x + snap(this.r(12, 15)), dropTo(this.y, this.y - this.r(1, 2.5)));
    this.flat(2);
  }

  private railSection() {
    this.flat(this.r(4, 6));
    const x0 = this.x + 1;
    const len = this.r(9, 14);
    this.rails.push({ x0, x1: x0 + len, h: this.r(0.95, 1.2) });
    this.flat(len + 2);
  }

  private nextFeature() {
    const i = this.feature++;
    const d = clamp((this.x - 120) / 1400, 0, 1);
    switch (i) {
      case 0:
        this.hills(2, 0.7);
        return;
      case 1:
        this.gap(3.2, -0.2);
        return;
      case 2:
        this.hills(2, 0.8);
        return;
      case 3:
        this.kicker(1.0, 30, -2);
        return;
      case 4:
        this.rollers(4, 0.9);
        return;
      case 5:
        this.hills(2, 0.9);
        return;
      case 6:
        this.rampGap(7, -1.5);
        return;
      case 7:
        this.hills(2, 1);
        return;
      case 8:
        this.railSection();
        return;
    }
    if (this.y < -4.2) {
      // climb back up so drops/gaps stay possible
      this.cosTo(this.x + snap(this.r(16, 22)), Math.min(this.y + this.r(3.5, 5.5), Y_MAX));
      this.flat(2);
    }
    const roll = this.rnd() * 100;
    if (roll < 20) this.hills(1 + Math.floor(this.r(1, 3)), 0.85 + d * 0.45);
    else if (roll < 30) this.rollers(3 + Math.floor(this.r(0, 4)), 0.85 + d * 0.3);
    else if (roll < 46) this.gap(this.r(2.8, 4.0) + d * 2.2, -this.r(0, 0.6));
    else if (roll < 54) this.gap(this.r(4.5, 5.8) + d * 2, -this.r(1.5, 2.6));
    else if (roll < 66) this.kicker(this.r(0.9, 1.4), this.r(28, 38), -this.r(1.5, 3));
    else if (roll < 84) this.rampGap(this.r(6, 8) + d * 4, -this.r(1, 3));
    else if (roll < 92) this.railSection();
    else {
      this.gap(this.r(2.6, 3.6) + d * 1.5, -this.r(0, 0.5));
      this.gap(this.r(2.8, 4) + d * 1.8, -this.r(0, 0.8), 4.5);
    }
  }

  generateUntil(x: number) {
    let guard = 0;
    while (this.x < x && guard++ < 50) {
      this.nextFeature();
      if (this.pts.length > 90) this.flush(false);
    }
  }

  private scenery(x0: number, x1: number) {
    let x = x0 + this.r(0.5, 2.5);
    while (x < x1 - 1.2) {
      const r = this.rnd();
      if (this.propSet === 'park') {
        if (r < 0.3) this.decor.push({ kind: 'tree', x, z: -this.r(4, 15), s: this.r(0.8, 1.3), c: this.rnd() });
        else if (r < 0.48) this.decor.push({ kind: 'pine', x, z: -this.r(5, 16), s: this.r(0.8, 1.4) });
        else if (r < 0.58) this.decor.push({ kind: 'tall', x, z: -this.r(4, 14), s: this.r(0.9, 1.3) });
        else if (r < 0.74) this.decor.push({ kind: 'bush', x, z: -this.r(2.7, 4), s: this.r(0.7, 1.1) });
        else if (r < 0.88) this.decor.push({ kind: 'flower', x, z: -this.r(2.6, 7), c: this.rnd() });
        else this.decor.push({ kind: 'rock', x, z: -this.r(3, 12), s: this.r(0.6, 1.2) });
      } else if (this.propSet === 'city') {
        if (r < 0.34) this.decor.push({ kind: 'building', x, z: -this.r(6, 13), s: this.r(0.8, 1.5), c: this.rnd() });
        else if (r < 0.5) this.decor.push({ kind: 'shop', x, z: -this.r(3.4, 5), c: this.rnd() });
        else if (r < 0.62) this.decor.push({ kind: 'pole', x, z: -this.r(2.8, 4) });
        else if (r < 0.74) this.decor.push({ kind: 'vending', x, z: -this.r(2.7, 3.6) });
        else if (r < 0.86) this.decor.push({ kind: 'tree', x, z: -this.r(3, 8), s: this.r(0.7, 1.1), c: this.rnd() });
        else this.decor.push({ kind: 'cone', x, z: -this.r(2.6, 3.2) });
      } else {
        // neon (Shibuya)
        if (r < 0.36) this.decor.push({ kind: 'building', x, z: -this.r(6, 13), s: this.r(0.8, 1.6), c: this.rnd() });
        else if (r < 0.52) this.decor.push({ kind: 'neonsign', x, z: -this.r(3, 5), c: this.rnd() });
        else if (r < 0.64) this.decor.push({ kind: 'billboard', x, z: -this.r(7, 12), c: this.rnd() });
        else if (r < 0.78) this.decor.push({ kind: 'vending', x, z: -this.r(2.7, 3.6) });
        else if (r < 0.9) this.decor.push({ kind: 'pole', x, z: -this.r(2.8, 4) });
        else this.decor.push({ kind: 'cone', x, z: -this.r(2.6, 3.2) });
      }
      x += this.r(1.6, 4.2);
    }
    for (let lx = Math.ceil((x0 + 1) / 18) * 18; lx < x1 - 1.5; lx += 18) {
      this.decor.push({ kind: 'lamp', x: lx, z: -2.45 });
    }
  }

  private flush(endCliff: boolean) {
    const pts = this.pts;
    if (pts.length < 2) {
      this.pts = [];
      return;
    }
    const minX = pts[0].x;
    const maxX = pts[pts.length - 1].x;
    const uniqueStart = this.startCliff ? minX : pts[1].x;
    this.scenery(uniqueStart, maxX);
    // rails that run past this piece carry over to the next one (unless they span a gap)
    const mine: RailData[] = [];
    const keep: RailData[] = [];
    for (const r of this.rails) (r.span || r.x1 <= maxX + 0.01 ? mine : keep).push(r);
    this.rails = keep;
    this.out.push({
      id: this.nextId++,
      pts,
      startCliff: this.startCliff,
      endCliff,
      coins: this.coins,
      decor: this.decor,
      rails: mine,
      minX,
      maxX,
    });
    this.coins = [];
    this.decor = [];
    if (!endCliff) {
      this.pts = pts.slice(-2).map((p) => ({ ...p, ramp: false }));
      this.startCliff = false;
    } else {
      this.pts = [];
    }
  }
}

/* ================================================================== */
/* Piece builder (physics + meshes)                                    */
/* ================================================================== */

export interface CoinObj {
  mesh: THREE.Mesh;
  x: number;
  y: number;
  taken: boolean;
  phase: number;
}

export interface BuiltPiece {
  data: PieceData;
  body: Body;
  group: THREE.Group;
  coins: CoinObj[];
  waterMesh: THREE.Mesh | null;
  rails: RailInfo[];
}

export interface PieceMaterials {
  terrain: THREE.Material;
  voxel: THREE.Material;
  coin: THREE.Material;
}

export function baseAt(pts: TPoint[], x: number): number {
  const n = pts.length;
  if (x <= pts[0].x) return pts[0].base;
  if (x >= pts[n - 1].x) return pts[n - 1].base;
  let lo = 0;
  let hi = n - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (pts[mid].x <= x) lo = mid;
    else hi = mid;
  }
  const a = pts[lo];
  const b = pts[hi];
  const dx = b.x - a.x;
  if (dx < 1e-6) return Math.max(a.base, b.base);
  return a.base + ((b.base - a.base) * (x - a.x)) / dx;
}

export function surfAt(pts: TPoint[], x: number): number {
  const n = pts.length;
  if (x <= pts[0].x) return pts[0].y;
  if (x >= pts[n - 1].x) return pts[n - 1].y;
  let lo = 0;
  let hi = n - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (pts[mid].x <= x) lo = mid;
    else hi = mid;
  }
  const a = pts[lo];
  const b = pts[hi];
  const dx = b.x - a.x;
  if (dx < 1e-6) return Math.max(a.y, b.y);
  return a.y + ((b.y - a.y) * (x - a.x)) / dx;
}

const hash = (n: number) => {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
};

class GeoBuilder {
  pos: number[] = [];
  col: number[] = [];
  uv: number[] = [];
  private c = new THREE.Color();

  private v(x: number, y: number, z: number, u: number, w: number) {
    this.pos.push(x, y, z);
    this.col.push(this.c.r, this.c.g, this.c.b);
    this.uv.push(u, w);
  }

  /** a,b,c,d counter-clockwise when looking at the visible side */
  quad(
    a: [number, number, number],
    b: [number, number, number],
    c: [number, number, number],
    d: [number, number, number],
    color: number,
    mode: 'xy' | 'xz' | 'zy',
  ) {
    this.c.set(color);
    const uvOf = (p: [number, number, number]): [number, number] =>
      mode === 'xy' ? [p[0] * 0.5, p[1] * 0.5] : mode === 'xz' ? [p[0] * 0.5, p[2] * 0.5] : [p[2] * 0.5, p[1] * 0.5];
    const ua = uvOf(a);
    const ub = uvOf(b);
    const uc = uvOf(c);
    const ud = uvOf(d);
    this.v(a[0], a[1], a[2], ua[0], ua[1]);
    this.v(b[0], b[1], b[2], ub[0], ub[1]);
    this.v(c[0], c[1], c[2], uc[0], uc[1]);
    this.v(a[0], a[1], a[2], ua[0], ua[1]);
    this.v(c[0], c[1], c[2], uc[0], uc[1]);
    this.v(d[0], d[1], d[2], ud[0], ud[1]);
  }

  /** horizontal-ish strip following the segment, between depths zA<zB, facing up */
  top(x0: number, y0: number, x1: number, y1: number, zA: number, zB: number, color: number, lift = 0) {
    this.quad([x0, y0 + lift, zA], [x0, y0 + lift, zB], [x1, y1 + lift, zB], [x1, y1 + lift, zA], color, 'xz');
  }

  /** vertical band on the front face (z), from offsets o1 to o2 below the surface */
  front(x0: number, t0: number, b0: number, x1: number, t1: number, b1: number, z: number, color: number) {
    if (t0 - b0 < 1e-4 && t1 - b1 < 1e-4) return;
    this.quad([x0, t0, z], [x0, b0, z], [x1, b1, z], [x1, t1, z], color, 'xy');
  }

  /** end cap face (normal +x if dir=1, -x if dir=-1) */
  cap(x: number, yT: number, yB: number, zF: number, zBk: number, dir: number, color: number) {
    if (yT - yB < 1e-4) return;
    if (dir > 0) this.quad([x, yT, zF], [x, yB, zF], [x, yB, zBk], [x, yT, zBk], color, 'zy');
    else this.quad([x, yT, zF], [x, yT, zBk], [x, yB, zBk], [x, yB, zF], color, 'zy');
  }

  build(): THREE.BufferGeometry {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    g.computeVertexNormals();
    g.computeBoundingSphere();
    return g;
  }
}

const bands = (y: number) => {
  const a = y - 0.25;
  const b = y - 0.55;
  const c = y - 1.6;
  const d = Math.max(y - 4.2, BOTTOM_Y);
  return [y, a, b, c, d, BOTTOM_Y];
};

function buildTerrainGeometry(p: PieceData, pal: TerrainPalette): THREE.BufferGeometry {
  const g = new GeoBuilder();
  const pts = p.pts;
  const zCurbB = -ROAD_HALF - CURB_W;
  const zCurbF = ROAD_HALF + CURB_W;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    if (b.x - a.x < 1e-4) continue;
    const xm = (a.x + b.x) / 2;
    const stripe = ((Math.floor(xm) % 2) + 2) % 2 === 0;
    const grassStripe = ((Math.floor(xm / 2) % 2) + 2) % 2 === 0;
    const y0 = a.base;
    const y1 = b.base;
    const curb = stripe ? pal.curbR : pal.curbW;
    // top
    g.top(a.x, y0, b.x, y1, Z_BACK, zCurbB, grassStripe ? pal.grassA : pal.grassB);
    g.top(a.x, y0, b.x, y1, zCurbB, -ROAD_HALF, curb);
    g.top(a.x, y0, b.x, y1, -ROAD_HALF, ROAD_HALF, pal.asphalt);
    g.top(a.x, y0, b.x, y1, ROAD_HALF, zCurbF, curb);
    if (stripe) g.top(a.x, y0, b.x, y1, -0.08, 0.08, COLORS.dash, 0.006);
    // front face bands
    const A = bands(y0);
    const B = bands(y1);
    const cols = [curb, pal.asphaltEdge, pal.topsoil, pal.dirt, pal.rock];
    for (let k = 0; k < 5; k++) {
      g.front(a.x, A[k], A[k + 1], b.x, B[k], B[k + 1], Z_FRONT, cols[k]);
    }
    // foam on the water at the foot of the cliff
    g.top(a.x, WATER_Y, b.x, WATER_Y, Z_FRONT, Z_FRONT + 0.35, COLORS.foam, 0.03);
  }
  const caps: [TPoint, number][] = [];
  if (p.startCliff) caps.push([pts[0], -1]);
  if (p.endCliff) caps.push([pts[pts.length - 1], 1]);
  for (const [pt, dir] of caps) {
    const y = pt.base;
    const x = pt.x;
    g.cap(x, y, y - 0.55, Z_FRONT, -ROAD_HALF - CURB_W, dir, pal.asphaltEdge);
    g.cap(x, y, y - 0.55, -ROAD_HALF - CURB_W, Z_BACK, dir, pal.grassB);
    g.cap(x, y - 0.55, y - 1.6, Z_FRONT, Z_BACK, dir, pal.topsoil);
    const d = Math.max(y - 4.2, BOTTOM_Y);
    g.cap(x, y - 1.6, d, Z_FRONT, Z_BACK, dir, pal.dirt);
    g.cap(x, d, BOTTOM_Y, Z_FRONT, Z_BACK, dir, pal.rock);
    // foam strip in the gap
    const fx0 = dir > 0 ? x : x - 0.4;
    const fx1 = dir > 0 ? x + 0.4 : x;
    g.top(fx0, WATER_Y, fx1, WATER_Y, Z_BACK, Z_FRONT + 0.35, COLORS.foam, 0.03);
  }
  return g.build();
}

function buildRampGeometry(p: PieceData, extra: THREE.BufferGeometry[]): THREE.BufferGeometry | null {
  const pts = p.pts;
  const g = new GeoBuilder();
  let any = false;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    if (!a.ramp || !b.ramp) continue;
    if (b.x - a.x < 1e-4) continue;
    any = true;
    const col = i % 2 === 0 ? COLORS.woodTop : COLORS.woodTop2;
    g.top(a.x, a.y, b.x, b.y, -RAMP_HALF, RAMP_HALF, col);
    g.front(a.x, a.y, a.base, b.x, b.y, b.base, RAMP_HALF, COLORS.woodSide);
    // lip detection: next point not ramp (or end of piece)
    const next = pts[i + 2];
    if (!next || !next.ramp) {
      const h = b.y - b.base;
      g.cap(b.x, b.y, b.base, RAMP_HALF, -RAMP_HALF, 1, COLORS.woodDark);
      extra.push(vbox(0.1, 0.1, RAMP_HALF * 2 + 0.12, 0xb9c1ca, b.x - 0.04, b.y - 0.03, 0));
      // find ramp start (toe)
      let j = i;
      while (j > 0 && pts[j - 1].ramp) j--;
      const toeX = pts[j].x;
      // wooden supports on the front face
      for (let s = 1; s <= 4; s++) {
        const sx = b.x - s * 0.7;
        if (sx < toeX + 0.3) break;
        const sy = surfAt(pts, sx);
        const hh = sy - b.base;
        if (hh < 0.12) continue;
        extra.push(vbox(0.12, hh, 0.06, COLORS.woodDark, sx, b.base + hh / 2, RAMP_HALF + 0.03));
      }
      extra.push(vbox(0.12, h, 0.06, COLORS.woodDark, b.x - 0.06, b.base + h / 2, RAMP_HALF + 0.03));
      // arrow chevrons on the ramp surface side
      extra.push(vbox(0.5, 0.08, 0.07, 0xffd23f, b.x - 0.9, b.base + h * 0.45, RAMP_HALF + 0.04, 0, 0, 0.6));
    }
  }
  return any ? g.build() : null;
}

function addDecor(out: THREE.BufferGeometry[], water: THREE.BufferGeometry[], d: Decor, pts: TPoint[], pal: TerrainPalette) {
  const y = baseAt(pts, d.x);
  const s = d.s ?? 1;
  const c = d.c ?? 0.5;
  switch (d.kind) {
    case 'tree':
      propTree(out, d.x, y, d.z, s, c);
      break;
    case 'pine':
      propPine(out, d.x, y, d.z, s);
      break;
    case 'tall':
      propTall(out, d.x, y, d.z, s);
      break;
    case 'bush':
      propBush(out, d.x, y, d.z, s);
      break;
    case 'flower':
      propFlowers(out, d.x, y, d.z, c);
      break;
    case 'rock':
      propRock(out, d.x, y, d.z, s);
      break;
    case 'lamp':
      propLamp(out, d.x, y, d.z);
      break;
    case 'sign':
      propSign(out, d.x, y, d.z);
      break;
    case 'cone':
      propCone(out, d.x, y, d.z);
      break;
    case 'barrier':
      propBarrier(out, d.x, y, d.z);
      break;
    case 'log':
      propLog(water, d.x, WATER_Y, d.z, c * 1.2 - 0.6);
      break;
    case 'lily':
      propLily(water, d.x, WATER_Y, d.z, c);
      break;
    case 'building': {
      const walls = [0xd8cfc0, 0xc4b8a8, 0xb8c0cc, 0xd0b8a0, 0xc0c8d8, 0xe0d8c8];
      const wins = [0x9ad6ff, 0xffe9a8, 0xb8e6ff];
      const wall = walls[Math.floor(c * walls.length) % walls.length];
      const win = wins[Math.floor(c * 7) % wins.length];
      propBuilding(out, d.x, y, d.z, 4.5 * s, 5 + c * 7, 4, wall, win, 0.5, d.x * 0.13 + c * 9);
      break;
    }
    case 'shop': {
      const walls = [0xe8dcc8, 0xd8e0e8, 0xe8c8b8, 0xc8d8c8];
      const accents = [0xee4a3c, 0x2ec4b6, 0xffd23f, 0x4a90d9];
      propShop(out, d.x, y, d.z, walls[Math.floor(c * walls.length) % walls.length], accents[Math.floor(c * 5) % accents.length]);
      break;
    }
    case 'vending':
      propVending(out, d.x, y, d.z, true);
      break;
    case 'neonsign': {
      const neons = [0xff5ad2, 0x5ad2ff, 0xffe066, 0x7dff6a, 0xff8a5a];
      propNeonSign(out, d.x, y, d.z, neons[Math.floor(c * neons.length) % neons.length]);
      break;
    }
    case 'billboard': {
      const screens = [0x5ad2ff, 0xff5ad2, 0xfff2a6, 0x7dff6a];
      propBillboard(out, d.x, y, d.z, screens[Math.floor(c * screens.length) % screens.length]);
      break;
    }
    case 'pole':
      propPole(out, d.x, y, d.z);
      break;
    case 'debris': {
      // broken road chunks around a cliff edge (s = +1 end edge, -1 start edge)
      const dir = s;
      const edgeY = baseAt(pts, d.x);
      const cols = [pal.topsoil, pal.dirt, pal.rock, pal.asphaltEdge];
      for (let i = 0; i < 9; i++) {
        const h1 = hash(d.x * 3.1 + i * 7.7);
        const h2 = hash(d.x * 1.7 + i * 3.3);
        const h3 = hash(d.x * 5.3 + i * 1.9);
        const size = 0.25 + h1 * 0.4;
        out.push(
          vbox(
            size,
            size,
            size,
            cols[Math.floor(h2 * cols.length)],
            d.x + dir * (0.05 + h3 * 0.18),
            edgeY - 0.5 - h2 * 3.2,
            (h1 * 2 - 1) * 1.9 - h3 * 2,
            h1,
            h2,
            h3,
          ),
        );
      }
      // asphalt chunks lying on the road near the edge (away from the riding line)
      for (let i = 0; i < 3; i++) {
        const h1 = hash(d.x * 9.1 + i * 2.1);
        const zz = (i % 2 === 0 ? 1 : -1) * (0.9 + h1 * 0.7);
        const xx = d.x - dir * (0.4 + h1 * 1.2);
        const yy = baseAt(pts, xx);
        out.push(vbox(0.3 + h1 * 0.25, 0.12, 0.3, pal.asphaltEdge, xx, yy + 0.05, zz, 0, h1 * 3, (h1 - 0.5) * 0.4));
      }
      break;
    }
  }
}

export function buildPiece(
  data: PieceData,
  world: World,
  mats: PieceMaterials,
  coinGeo: THREE.BufferGeometry,
  scene: THREE.Scene,
  pal: TerrainPalette,
): BuiltPiece {
  // physics
  const body = world.createBody({ type: 'static' });
  const verts: { x: number; y: number }[] = [];
  const pushV = (x: number, y: number) => {
    const l = verts[verts.length - 1];
    if (l && (l.x - x) * (l.x - x) + (l.y - y) * (l.y - y) < 0.0004) return;
    verts.push({ x, y });
  };
  const pts = data.pts;
  if (data.startCliff) pushV(pts[0].x, BOTTOM_Y);
  for (const p of pts) pushV(p.x, p.y);
  if (data.endCliff) pushV(pts[pts.length - 1].x, BOTTOM_Y);
  body.createFixture({ shape: new Chain(verts, false), friction: 0.8, restitution: 0, userData: 'terrain' });

  // meshes
  const group = new THREE.Group();
  const terrain = new THREE.Mesh(buildTerrainGeometry(data, pal), mats.terrain);
  terrain.receiveShadow = true;
  group.add(terrain);

  const extra: THREE.BufferGeometry[] = [];
  const rampGeo = buildRampGeometry(data, extra);
  if (rampGeo) {
    const ramp = new THREE.Mesh(rampGeo, mats.terrain);
    ramp.receiveShadow = true;
    ramp.castShadow = true;
    group.add(ramp);
  }

  const waterGeoms: THREE.BufferGeometry[] = [];
  for (const d of data.decor) addDecor(extra, waterGeoms, d, pts, pal);
  if (extra.length) {
    const deco = new THREE.Mesh(mergeColored(extra), mats.voxel);
    deco.castShadow = true;
    deco.receiveShadow = true;
    group.add(deco);
  }
  let waterMesh: THREE.Mesh | null = null;
  if (waterGeoms.length) {
    waterMesh = new THREE.Mesh(mergeColored(waterGeoms), mats.voxel);
    waterMesh.receiveShadow = true;
    group.add(waterMesh);
  }

  // grind rails: metal bar + posts + physics chain (top face solid)
  const rails: RailInfo[] = [];
  for (const r of data.rails) {
    const n = Math.max(2, Math.ceil((r.x1 - r.x0) / 1));
    const rpts: { x: number; y: number }[] = [];
    for (let i = 0; i <= n; i++) {
      const x = r.x0 + ((r.x1 - r.x0) * i) / n;
      rpts.push({ x, y: surfAt(data.pts, x) + r.h });
    }
    // no physics fixture: the rail is a decoration you can't crash into; grinding mounts by proximity
    rails.push({ x0: r.x0, x1: r.x1, pts: rpts });
    const railGeos: THREE.BufferGeometry[] = [];
    for (let i = 0; i < rpts.length - 1; i++) {
      const a = rpts[i];
      const b = rpts[i + 1];
      const len = Math.hypot(b.x - a.x, b.y - a.y);
      railGeos.push(vbox(len + 0.06, 0.13, 0.13, 0xd7dde3, (a.x + b.x) / 2, (a.y + b.y) / 2 - 0.065, 0, 0, 0, Math.atan2(b.y - a.y, b.x - a.x)));
    }
    for (let x = r.x0 + 1; x < r.x1; x += 2.2) {
      if (x > data.maxX) continue; // no posts over a gap
      const y = surfAt(data.pts, x) + r.h;
      const gy = baseAt(data.pts, x);
      const hh = y - 0.13 - gy;
      if (hh > 0.15) railGeos.push(vbox(0.1, hh, 0.1, 0x8a939c, x, gy + hh / 2, 0));
    }
    railGeos.push(vbox(0.16, 0.16, 0.16, 0xff5a36, r.x0, rpts[0].y - 0.05, 0));
    railGeos.push(vbox(0.16, 0.16, 0.16, 0xff5a36, r.x1, rpts[rpts.length - 1].y - 0.05, 0));
    const railMesh = new THREE.Mesh(mergeColored(railGeos), mats.voxel);
    railMesh.castShadow = true;
    group.add(railMesh);
  }

  const coins: CoinObj[] = [];
  for (const c of data.coins) {
    const m = new THREE.Mesh(coinGeo, mats.coin);
    m.position.set(c.x, c.y, 0);
    group.add(m);
    coins.push({ mesh: m, x: c.x, y: c.y, taken: false, phase: c.x * 0.7 });
  }

  scene.add(group);
  return { data, body, group, coins, waterMesh, rails };
}

export function disposePiece(p: BuiltPiece, world: World, scene: THREE.Scene, coinGeo: THREE.BufferGeometry) {
  world.destroyBody(p.body);
  scene.remove(p.group);
  p.group.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh && m.geometry !== coinGeo) m.geometry.dispose();
  });
}
