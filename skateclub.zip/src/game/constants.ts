// World / physics tuning
export const GRAVITY = 15;
export const PHYS_DT = 1 / 120;

export const WATER_Y = -14;
export const BOTTOM_Y = -24;

// Track geometry (z axis = depth)
export const Z_FRONT = 2.0;
export const Z_BACK = -18;
export const ROAD_HALF = 1.7;
export const CURB_W = 0.3;
export const RAMP_HALF = 1.3;
export const STEP = 0.5;

// Skating
export const CRUISE_SPEED = 9.5;
export const BOOST_SPEED = 28.5; // 3x cruise speed
export const BRAKE_SPEED = 4;
export const PUSH_ACC = 7;
export const BOOST_ACC = 21; // 3x push momentum
export const BRAKE_ACC = 10;
export const JUMP_SPEED = 7.2;
export const ROT_SPEED = 8.6;

// Board dims (meters)
export const DECK_HW = 0.7;
export const DECK_HH = 0.05;
export const WHEEL_R = 0.12;
export const WHEEL_X = 0.62;
export const WHEEL_Y = -0.17;
export const LEG_LEN = 0.26;
export const RIDE_CLEAR = -(WHEEL_Y - WHEEL_R); // deck center height above ground (0.29)

export const COLORS = {
  grassA: 0x92d850,
  grassB: 0x86cc47,
  curbR: 0xee4a3c,
  curbW: 0xf4f4f4,
  asphalt: 0x5b606c,
  asphaltEdge: 0x464a54,
  dash: 0xf7f7f7,
  topsoil: 0xb57d47,
  dirt: 0x93613a,
  rock: 0x6e5b4d,
  woodTop: 0xe0aa68,
  woodTop2: 0xcf975a,
  woodSide: 0xab7343,
  woodDark: 0x7f5432,
  water: 0x4cbdf5,
  foam: 0xeefaff,
  trunk: 0x8a5a3b,
};
