/**
 * Place themes — Bukit Hijau (original), Tokyo (dusk city) & Shibuya (neon night),
 * inspired by the track modes of the Pigeon SK8 game.
 */
export type PlaceId = 'hijau' | 'tokyo' | 'shibuya';
export type PropSet = 'park' | 'city' | 'neon';
export type BgKind = 'mountains' | 'city' | 'neon';

export interface TerrainPalette {
  grassA: number;
  grassB: number;
  curbR: number;
  curbW: number;
  asphalt: number;
  asphaltEdge: number;
  topsoil: number;
  dirt: number;
  rock: number;
}

export interface PlaceTheme {
  id: PlaceId;
  name: string;
  emoji: string;
  desc: string;
  badge: string;
  /** CSS sky gradient for the page background */
  skyCss: string;
  fog: number;
  hemiSky: number;
  hemiGround: number;
  hemiIntensity: number;
  sunColor: number;
  sunIntensity: number;
  water: number;
  palette: TerrainPalette;
  bg: BgKind;
  props: PropSet;
}

export const PLACES: PlaceTheme[] = [
  {
    id: 'hijau',
    name: 'Bukit Hijau',
    emoji: '🌳',
    desc: 'Tempat asli: bukit rumput, pohon, sungai biru di jurang',
    badge: 'ORIGINAL',
    skyCss: 'linear-gradient(180deg, #47b8ff 0%, #8fdcff 38%, #cdefff 66%, #fff4d6 100%)',
    fog: 0xcdefff,
    hemiSky: 0xffffff,
    hemiGround: 0xa39780,
    hemiIntensity: 2.05,
    sunColor: 0xfff0d6,
    sunIntensity: 1.95,
    water: 0x4cbdf5,
    palette: {
      grassA: 0x92d850,
      grassB: 0x86cc47,
      curbR: 0xee4a3c,
      curbW: 0xf4f4f4,
      asphalt: 0x5b606c,
      asphaltEdge: 0x464a54,
      topsoil: 0xb57d47,
      dirt: 0x93613a,
      rock: 0x6e5b4d,
    },
    bg: 'mountains',
    props: 'park',
  },
  {
    id: 'tokyo',
    name: 'Tokyo Senja',
    emoji: '🗼',
    desc: 'Kota Tokyo sore hari: gedung, Tokyo Tower, plaza abu-abu',
    badge: 'PIGEON SK8',
    skyCss: 'linear-gradient(180deg, #3a4a7a 0%, #8a5a8a 38%, #ff9a5a 68%, #ffd6a5 100%)',
    fog: 0xe8b48a,
    hemiSky: 0xffd9b0,
    hemiGround: 0x6a5a6a,
    hemiIntensity: 1.7,
    sunColor: 0xffb070,
    sunIntensity: 1.75,
    water: 0x3a7ca5,
    palette: {
      grassA: 0xb7b2a6,
      grassB: 0xaaa596,
      curbR: 0xd8d3c5,
      curbW: 0xf0ece2,
      asphalt: 0x474f60,
      asphaltEdge: 0x3a4152,
      topsoil: 0x9a958c,
      dirt: 0x7a756c,
      rock: 0x5a564e,
    },
    bg: 'city',
    props: 'city',
  },
  {
    id: 'shibuya',
    name: 'Shibuya Malam',
    emoji: '🌃',
    desc: 'Shibuya malam neon: skyline menyala, papan iklan, Tokyo Tower',
    badge: 'PIGEON SK8',
    skyCss: 'linear-gradient(180deg, #0b0b2a 0%, #1b1838 40%, #3a2a5a 70%, #5a3a6a 100%)',
    fog: 0x2a2440,
    hemiSky: 0x8a7ab8,
    hemiGround: 0x2a2438,
    hemiIntensity: 1.35,
    sunColor: 0xaac4ff,
    sunIntensity: 1.0,
    water: 0x2a4a7a,
    palette: {
      grassA: 0x575d75,
      grassB: 0x4c5268,
      curbR: 0x9aa2b5,
      curbW: 0xc8cede,
      asphalt: 0x343a4c,
      asphaltEdge: 0x2a3040,
      topsoil: 0x3a3f52,
      dirt: 0x2e3342,
      rock: 0x232836,
    },
    bg: 'neon',
    props: 'neon',
  },
];

export const getPlace = (id: string): PlaceTheme => PLACES.find((p) => p.id === id) ?? PLACES[0];
