import * as THREE from 'three';
import raw from './skinData.json';
import { buildBoard, buildChicken, mergeColored, vbox } from './voxel';

/* ------------------------------------------------------------------ */
/* Data (extracted from the Pigeon SK8 repo models)                   */
/* ------------------------------------------------------------------ */

type Packed = number[];
interface RawChar {
  id: string;
  name: string;
  emoji: string;
  desc: string;
  source: string;
  facing: string;
  deck: string;
  hipY: number;
  piv: Record<string, number[]>;
  seg: Record<string, Packed[]>;
  pal: string[];
}
interface RawBoard {
  id: string;
  name: string;
  tagline: string;
  emoji: string;
  float: boolean;
  parts: Packed[];
  pal: string[];
}
const DATA = raw as unknown as { chars: RawChar[]; boards: RawBoard[] };

export type SegName = 'torso' | 'head' | 'armN' | 'armF' | 'legN' | 'legF';
export type PivName = Exclude<SegName, 'torso'>;
export const SEGS: SegName[] = ['torso', 'head', 'armN', 'armF', 'legN', 'legF'];

export interface CharDef {
  id: string;
  name: string;
  emoji: string;
  desc: string;
  badge: string;
  facing: 'x' | 'z';
  deck: string;
  /** crash burst colours (feathers / fur tufts) */
  fx: string[];
}

export interface BoardDef {
  id: string;
  name: string;
  desc: string;
  emoji: string;
  badge: string;
  float: boolean;
}

const BADGE: Record<string, string> = { pigeon: 'PIGEON SK8', friend: 'LITTLE JAPAN FRIEND', buddy: 'VOXEL BUDDIES' };

export const CHARS: CharDef[] = [
  {
    id: 'ayam',
    name: 'Ayam Skater',
    emoji: '🐔',
    desc: 'Karakter asli game ini — ayam voxel ala Crossy Road',
    badge: 'ORIGINAL',
    facing: 'x',
    deck: '#ff5a36',
    fx: ['#ffffff', '#f6f6ef', '#e9e9e0'],
  },
  ...DATA.chars.map((c) => ({
    id: c.id,
    name: c.name,
    emoji: c.emoji,
    desc: c.desc,
    badge: BADGE[c.source] ?? 'PIGEON SK8',
    facing: (c.facing === 'z' ? 'z' : 'x') as 'x' | 'z',
    deck: c.deck,
    fx: c.pal.filter((x) => x !== '#111111' && x !== '#000000').slice(0, 3).concat(['#ffffff']),
  })),
];

export const BOARDS: BoardDef[] = [
  { id: 'ayam', name: 'Papan Ayam Skater', desc: 'Papan asli game ini — oranye, kuning & biru', emoji: '🛹', badge: 'ORIGINAL', float: false },
  ...DATA.boards.map((b) => ({
    id: b.id === 'default' ? 'classic' : b.id,
    name: b.name,
    desc: b.tagline,
    emoji: b.emoji,
    badge: b.id === 'default' ? 'STANDARD' : b.float ? 'VOXEL BOARD' : 'PIGEON SK8',
    float: b.float,
  })),
];

export const getChar = (id: string) => CHARS.find((c) => c.id === id) ?? CHARS[0];
export const getBoard = (id: string) => BOARDS.find((b) => b.id === id) ?? BOARDS[0];

/* ------------------------------------------------------------------ */
/* Character rig                                                       */
/* ------------------------------------------------------------------ */

export interface PhysBox {
  hw: number;
  hh: number;
  cx: number;
  cy: number;
}

export interface CharRig {
  def: CharDef;
  meshes: Record<SegName, THREE.Mesh>;
  /** pivot positions relative to the hip origin (torso origin) */
  piv: Record<PivName, THREE.Vector3>;
  /** hip origin height above the deck top */
  legLen: number;
  height: number;
  boxes: Record<SegName, PhysBox>;
  eyes: THREE.Object3D | null;
  deadEyes: THREE.Object3D | null;
  dispose(): void;
}

const TARGET_H = 1.22;

function boxOf(geo: THREE.BufferGeometry): PhysBox {
  geo.computeBoundingBox();
  const b = geo.boundingBox;
  if (!b || !isFinite(b.min.x)) return { hw: 0.05, hh: 0.05, cx: 0, cy: 0 };
  return {
    hw: Math.max(0.04, ((b.max.x - b.min.x) / 2) * 0.9),
    hh: Math.max(0.04, ((b.max.y - b.min.y) / 2) * 0.9),
    cx: (b.max.x + b.min.x) / 2,
    cy: (b.max.y + b.min.y) / 2,
  };
}

function unpack(p: Packed, pal: string[], s: number, ox = 0, oy = 0, oz = 0): THREE.BufferGeometry {
  const col = new THREE.Color(pal[p[6]] ?? '#ffffff').getHex();
  return vbox(
    Math.max(0.004, p[3] * s),
    Math.max(0.004, p[4] * s),
    Math.max(0.004, p[5] * s),
    col,
    p[0] * s + ox,
    p[1] * s + oy,
    p[2] * s + oz,
    p[7] ?? 0,
    p[8] ?? 0,
    p[9] ?? 0,
  );
}

function chickenRig(mat: THREE.Material): CharRig {
  const c = buildChicken(mat);
  const meshes: Record<SegName, THREE.Mesh> = {
    torso: c.torso,
    head: c.head,
    armN: c.wingN,
    armF: c.wingF,
    legN: c.legN,
    legF: c.legF,
  };
  return {
    def: CHARS[0],
    meshes,
    piv: {
      head: new THREE.Vector3(0.06, 0.5, 0),
      armN: new THREE.Vector3(-0.02, 0.44, 0.29),
      armF: new THREE.Vector3(-0.02, 0.44, -0.29),
      legN: new THREE.Vector3(0.02, 0, 0.12),
      legF: new THREE.Vector3(0.02, 0, -0.12),
    },
    legLen: 0.26,
    height: 1.32,
    boxes: {
      torso: { hw: 0.28, hh: 0.25, cx: 0, cy: 0.25 },
      head: { hw: 0.22, hh: 0.21, cx: 0, cy: 0.21 },
      armN: { hw: 0.15, hh: 0.15, cx: -0.03, cy: -0.14 },
      armF: { hw: 0.15, hh: 0.15, cx: -0.03, cy: -0.14 },
      legN: { hw: 0.045, hh: 0.13, cx: 0, cy: -0.13 },
      legF: { hw: 0.045, hh: 0.13, cx: 0, cy: -0.13 },
    },
    eyes: c.eyes,
    deadEyes: c.deadEyes,
    dispose() {
      for (const m of c.all) m.geometry.dispose();
      c.eyes.geometry.dispose();
      c.deadEyes.geometry.dispose();
    },
  };
}

export function buildCharRig(id: string, mat: THREE.Material): CharRig {
  const rc = DATA.chars.find((c) => c.id === id);
  if (!rc) return chickenRig(mat);
  const def = getChar(id);
  const piv0: Record<PivName, number[]> = {
    head: rc.piv.head ?? [0, 0.5, 0],
    armN: rc.piv.armN ?? [0.3, 0.4, 0],
    armF: rc.piv.armF ?? [-0.3, 0.4, 0],
    legN: rc.piv.legN ?? [-0.15, 0, 0],
    legF: rc.piv.legF ?? [0.15, 0, 0],
  };
  // overall raw bounds in hip space → uniform scale
  let minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
  for (const seg of SEGS) {
    const o = seg === 'torso' ? [0, 0, 0] : piv0[seg as PivName];
    for (const p of rc.seg[seg] ?? []) {
      minX = Math.min(minX, o[0] + p[0] - p[3] / 2);
      maxX = Math.max(maxX, o[0] + p[0] + p[3] / 2);
      minY = Math.min(minY, o[1] + p[1] - p[4] / 2);
      maxY = Math.max(maxY, o[1] + p[1] + p[4] / 2);
    }
  }
  const H = Math.max(0.1, maxY - minY);
  const W = Math.max(0.1, maxX - minX);
  const s = Math.min(TARGET_H / H, 1.05 / W);

  const piv = {} as Record<PivName, THREE.Vector3>;
  for (const k of Object.keys(piv0) as PivName[]) piv[k] = new THREE.Vector3(piv0[k][0] * s, piv0[k][1] * s, piv0[k][2] * s);

  const geos = {} as Record<SegName, THREE.BufferGeometry>;
  for (const seg of SEGS) {
    let parts = rc.seg[seg] ?? [];
    let shiftY = 0;
    if (seg === 'legN' || seg === 'legF') {
      // legs must hang DOWN from their pivot (some source rigs grow legs upward from the foot node)
      let top = -1e9;
      for (const p of parts) top = Math.max(top, (p[1] + p[4] / 2) * s);
      if (parts.length && top > 0.01) {
        shiftY = -top;
        piv[seg].y += top;
      }
    }
    if (!parts.length) parts = [[0, seg === 'legN' || seg === 'legF' ? -0.05 / s : 0, 0, 0.02 / s, 0.02 / s, 0.02 / s, 0]];
    geos[seg] = mergeColored(parts.map((p) => unpack(p, rc.pal, s, 0, shiftY, 0)));
  }

  // Source models face the camera (+z); turn them mostly to +x (right) like the original
  // chicken, but keep a slight 3/4 angle toward the camera so the face stays visible
  if (rc.facing === 'z') {
    const M = new THREE.Matrix4().makeRotationY(1.15);
    for (const seg of SEGS) geos[seg].applyMatrix4(M);
    for (const k of Object.keys(piv) as PivName[]) piv[k].applyMatrix4(M);
    // after the turn, make armN/legN the camera-side (+z) limbs
    const ensureNear = (a: PivName, b: PivName) => {
      if (piv[a].z < piv[b].z) {
        const tg = geos[a];
        geos[a] = geos[b];
        geos[b] = tg;
        const tp = piv[a];
        piv[a] = piv[b];
        piv[b] = tp;
      }
    };
    ensureNear('armN', 'armF');
    ensureNear('legN', 'legF');
  }

  // sole height → hip origin above the deck
  let sole = 0;
  for (const leg of ['legN', 'legF'] as const) {
    geos[leg].computeBoundingBox();
    const bb = geos[leg].boundingBox;
    if (bb) sole = Math.min(sole, piv[leg].y + bb.min.y);
  }
  const legLen = Math.max(0, -sole);

  const meshes = {} as Record<SegName, THREE.Mesh>;
  const boxes = {} as Record<SegName, PhysBox>;
  let top = 0;
  for (const seg of SEGS) {
    const m = new THREE.Mesh(geos[seg], mat);
    m.castShadow = true;
    m.rotation.order = 'ZYX';
    meshes[seg] = m;
    boxes[seg] = boxOf(geos[seg]);
    const bb = geos[seg].boundingBox;
    if (bb) top = Math.max(top, (seg === 'torso' ? 0 : piv[seg as PivName].y) + bb.max.y);
  }
  return {
    def,
    meshes,
    piv,
    legLen,
    height: legLen + top,
    boxes,
    eyes: null,
    deadEyes: null,
    dispose() {
      for (const seg of SEGS) geos[seg].dispose();
    },
  };
}

/* ------------------------------------------------------------------ */
/* Boards                                                              */
/* ------------------------------------------------------------------ */

export interface BoardVisual {
  group: THREE.Group;
  wheels: THREE.Mesh[];
  float: boolean;
  dispose(): void;
}

function disposeGroup(g: THREE.Object3D) {
  const seen = new Set<THREE.BufferGeometry>();
  g.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh && !seen.has(m.geometry)) {
      seen.add(m.geometry);
      m.geometry.dispose();
    }
  });
}

/** Classic Street Deck: standard deck tinted with the character's colour */
function classicDeck(mat: THREE.Material, deckColor: string): BoardVisual {
  const col = new THREE.Color(deckColor);
  const dark = col.clone().multiplyScalar(0.7).getHex();
  const main = col.getHex();
  const group = new THREE.Group();
  const deck = new THREE.Mesh(
    mergeColored([
      vbox(1.12, 0.06, 0.42, main, 0, 0, 0),
      vbox(1.12, 0.016, 0.4, 0x23232b, 0, 0.037, 0),
      vbox(0.5, 0.064, 0.425, dark, 0, 0, 0),
      vbox(0.22, 0.06, 0.42, main, 0.66, 0.04, 0, 0, 0, 0.38),
      vbox(0.22, 0.06, 0.42, main, -0.66, 0.04, 0, 0, 0, -0.38),
      vbox(0.2, 0.016, 0.4, 0x23232b, 0.655, 0.075, 0, 0, 0, 0.38),
      vbox(0.2, 0.016, 0.4, 0x23232b, -0.655, 0.075, 0, 0, 0, -0.38),
      vbox(0.13, 0.08, 0.26, 0xa3acb6, 0.5, -0.07, 0),
      vbox(0.13, 0.08, 0.26, 0xa3acb6, -0.5, -0.07, 0),
      vbox(0.05, 0.05, 0.46, 0x6f767e, 0.5, -0.17, 0),
      vbox(0.05, 0.05, 0.46, 0x6f767e, -0.5, -0.17, 0),
    ]),
    mat,
  );
  deck.castShadow = true;
  group.add(deck);
  const wheels: THREE.Mesh[] = [];
  const wg = mergeColored([vbox(0.22, 0.22, 0.1, 0xfff1d6), vbox(0.08, 0.08, 0.11, dark)]);
  for (const x of [0.5, -0.5]) {
    for (const z of [0.19, -0.19]) {
      const w = new THREE.Mesh(wg, mat);
      w.position.set(x, -0.17, z);
      w.castShadow = true;
      group.add(w);
      wheels.push(w);
    }
  }
  return { group, wheels, float: false, dispose: () => disposeGroup(group) };
}

export function buildBoardVisual(id: string, deckColor: string, mat: THREE.Material): BoardVisual {
  if (id === 'classic') return classicDeck(mat, deckColor);
  const rb = DATA.boards.find((b) => b.id === id);
  if (!rb || !rb.parts.length) {
    const b = buildBoard(mat);
    return { group: b.group, wheels: b.wheels, float: false, dispose: () => disposeGroup(b.group) };
  }
  // merge source parts, orient along +x, scale to our deck length and sit the top on the deck plane
  const geo = mergeColored(rb.parts.map((p) => unpack(p, rb.pal, 1)));
  geo.computeBoundingBox();
  let bb = geo.boundingBox!;
  if (bb.max.z - bb.min.z > (bb.max.x - bb.min.x) * 1.15) {
    geo.rotateY(Math.PI / 2);
    geo.computeBoundingBox();
    bb = geo.boundingBox!;
  }
  const len = bb.max.x - bb.min.x;
  const sc = 1.5 / Math.max(0.1, len);
  geo.translate(-(bb.max.x + bb.min.x) / 2, -bb.max.y, -(bb.max.z + bb.min.z) / 2);
  geo.scale(sc, sc, sc);
  const group = new THREE.Group();
  const lift = rb.float ? 0.12 : 0;
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.05 + lift;
  mesh.castShadow = true;
  group.add(mesh);
  const wheels: THREE.Mesh[] = [];
  if (!rb.float) {
    const wg = mergeColored([vbox(0.22, 0.22, 0.1, 0xffe9a8), vbox(0.08, 0.08, 0.11, 0xc98a2b)]);
    const tg = mergeColored([vbox(0.13, 0.1, 0.26, 0xa3acb6, 0, 0.02, 0), vbox(0.05, 0.05, 0.46, 0x6f767e, 0, -0.05, 0)]);
    for (const x of [0.5, -0.5]) {
      const t = new THREE.Mesh(tg, mat);
      t.position.set(x, -0.12, 0);
      group.add(t);
      for (const z of [0.19, -0.19]) {
        const w = new THREE.Mesh(wg, mat);
        w.position.set(x, -0.17, z);
        w.castShadow = true;
        group.add(w);
        wheels.push(w);
      }
    }
  }
  return { group, wheels, float: rb.float, dispose: () => disposeGroup(group) };
}
