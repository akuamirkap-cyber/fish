import * as THREE from 'three';
import { buildBoardVisual, buildCharRig } from './skins';
import type { PivName } from './skins';

/**
 * Renders 3D thumbnails of every character & board for the skin picker.
 * One shared offscreen renderer, results cached as data URLs.
 */

let renderer: THREE.WebGLRenderer | null = null;
let scene: THREE.Scene | null = null;
let camera: THREE.PerspectiveCamera | null = null;
const cache = new Map<string, string>();

function setup() {
  if (renderer) return;
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
  renderer.setSize(220, 220);
  renderer.setPixelRatio(1);
  scene = new THREE.Scene();
  scene.add(new THREE.HemisphereLight(0xffffff, 0x8a7a5a, 2.2));
  const sun = new THREE.DirectionalLight(0xfff0d6, 2.0);
  sun.position.set(3, 5, 4);
  scene.add(sun);
  const fill = new THREE.DirectionalLight(0xbfe3ff, 0.7);
  fill.position.set(-4, 2, -3);
  scene.add(fill);
  camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
}

const PED = new THREE.BoxGeometry(1.5, 0.18, 1.5);
const PED_MAT = new THREE.MeshLambertMaterial({ color: 0xffffff });

function snapshot(): string {
  renderer!.render(scene!, camera!);
  return renderer!.domElement.toDataURL('image/png');
}

function clearScene() {
  if (!scene) return;
  const kids = [...scene.children];
  for (const k of kids) {
    if ((k as THREE.Light).isLight) continue;
    scene.remove(k);
    k.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh && m.geometry !== PED) m.geometry.dispose();
    });
  }
}

export function charThumb(id: string): string {
  const key = 'c:' + id;
  const hit = cache.get(key);
  if (hit) return hit;
  setup();
  clearScene();
  const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
  const rig = buildCharRig(id, mat);
  const root = new THREE.Group();
  const hip = new THREE.Group();
  hip.position.y = rig.legLen + 0.18;
  root.add(hip);
  hip.add(rig.meshes.torso);
  for (const k of ['head', 'armN', 'armF', 'legN', 'legF'] as PivName[]) {
    const g = new THREE.Group();
    g.position.copy(rig.piv[k]);
    g.add(rig.meshes[k]);
    hip.add(g);
  }
  rig.meshes.armN.rotation.x = -0.25;
  rig.meshes.armF.rotation.x = 0.25;
  const ped = new THREE.Mesh(PED, PED_MAT);
  ped.position.y = -0.09;
  root.add(ped);
  root.rotation.y = -0.6;
  scene!.add(root);
  const h = Math.max(1.2, rig.height + 0.3);
  camera!.position.set(h * 1.1, h * 0.95, h * 1.6);
  camera!.lookAt(0, h * 0.45, 0);
  const url = snapshot();
  cache.set(key, url);
  rig.dispose();
  mat.dispose();
  return url;
}

export function boardThumb(id: string, deckColor: string): string {
  const key = 'b:' + id;
  const hit = cache.get(key);
  if (hit) return hit;
  setup();
  clearScene();
  const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
  const vis = buildBoardVisual(id, deckColor, mat);
  const root = new THREE.Group();
  root.add(vis.group);
  vis.group.rotation.set(0.12, -0.55, 0.1);
  vis.group.position.y = 0.45;
  const ped = new THREE.Mesh(PED, PED_MAT);
  ped.position.y = -0.09;
  root.add(ped);
  scene!.add(root);
  camera!.position.set(1.9, 1.3, 2.4);
  camera!.lookAt(0, 0.35, 0);
  const url = snapshot();
  cache.set(key, url);
  vis.dispose();
  mat.dispose();
  return url;
}
