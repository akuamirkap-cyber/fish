type OscType = OscillatorType;

export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private rollGain: GainNode | null = null;
  private rollFilter: BiquadFilterNode | null = null;
  private windGain: GainNode | null = null;
  private windFilter: BiquadFilterNode | null = null;
  muted = false;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    const AC: typeof AudioContext | undefined =
      window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    const master = ctx.createGain();
    master.gain.value = this.muted ? 0 : 0.55;
    master.connect(ctx.destination);
    this.master = master;

    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      last = last * 0.6 + w * 0.4;
      d[i] = last * 1.6;
    }
    this.noise = buf;

    // rolling loop
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    const rf = ctx.createBiquadFilter();
    rf.type = 'lowpass';
    rf.frequency.value = 400;
    rf.Q.value = 2;
    const rg = ctx.createGain();
    rg.gain.value = 0;
    src.connect(rf).connect(rg).connect(master);
    src.start();
    this.rollFilter = rf;
    this.rollGain = rg;

    // wind loop
    const src2 = ctx.createBufferSource();
    src2.buffer = buf;
    src2.loop = true;
    src2.playbackRate.value = 0.7;
    const wf = ctx.createBiquadFilter();
    wf.type = 'bandpass';
    wf.frequency.value = 900;
    wf.Q.value = 0.6;
    const wg = ctx.createGain();
    wg.gain.value = 0;
    src2.connect(wf).connect(wg).connect(master);
    src2.start();
    this.windFilter = wf;
    this.windGain = wg;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.55, this.ctx.currentTime, 0.02);
  }

  update(speed: number, grounded: boolean, active: boolean) {
    const ctx = this.ctx;
    if (!ctx || !this.rollGain || !this.rollFilter || !this.windGain || !this.windFilter) return;
    const t = ctx.currentTime;
    const roll = active && grounded ? Math.min(0.32, 0.05 + speed * 0.022) : 0;
    this.rollGain.gain.setTargetAtTime(roll, t, 0.04);
    this.rollFilter.frequency.setTargetAtTime(160 + speed * 55, t, 0.08);
    const wind = active ? Math.min(0.22, Math.max(0, speed - 5) * 0.014) * (grounded ? 0.45 : 1) : 0;
    this.windGain.gain.setTargetAtTime(wind, t, 0.15);
    this.windFilter.frequency.setTargetAtTime(500 + speed * 60, t, 0.2);
  }

  private tone(freq: number, t0: number, dur: number, type: OscType, vol: number, endFreq?: number) {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(this.master);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }

  private noiseBurst(t0: number, dur: number, vol: number, type: BiquadFilterType, f0: number, f1?: number, q = 1) {
    const ctx = this.ctx;
    if (!ctx || !this.master || !this.noise) return;
    const s = ctx.createBufferSource();
    s.buffer = this.noise;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(f0, t0);
    if (f1) f.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    s.connect(f).connect(g).connect(this.master);
    s.start(t0, Math.random() * 1.5);
    s.stop(t0 + dur + 0.05);
  }

  pop() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.05, 0.5, 'highpass', 2500);
    this.tone(260, t, 0.08, 'square', 0.12, 90);
  }

  land(intensity: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = Math.min(1, 0.25 + intensity * 0.06);
    this.noiseBurst(t, 0.12, 0.6 * v, 'lowpass', 900, 200);
    this.tone(140, t, 0.14, 'sine', 0.5 * v, 45);
    this.noiseBurst(t + 0.01, 0.04, 0.25 * v, 'highpass', 3000);
  }

  coin(pitch = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(988 * pitch, t, 0.07, 'square', 0.09);
    this.tone(1319 * pitch, t + 0.065, 0.2, 'square', 0.09);
  }

  trick(level = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const notes = [523, 659, 784, 1047, 1319];
    const n = Math.min(notes.length, 3 + level);
    for (let i = 0; i < n; i++) this.tone(notes[i], t + i * 0.06, 0.16, 'triangle', 0.22);
  }

  perfect() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(1568, t, 0.12, 'sine', 0.2);
    this.tone(2093, t + 0.08, 0.25, 'sine', 0.18);
  }

  crash() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(110, t, 0.35, 'sine', 0.8, 35);
    this.noiseBurst(t, 0.35, 0.8, 'lowpass', 1400, 120);
    this.noiseBurst(t + 0.02, 0.15, 0.4, 'bandpass', 2400, 800, 2);
  }

  thud(intensity: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = Math.min(1, 0.15 + intensity * 0.12);
    this.tone(120 + Math.random() * 40, t, 0.12, 'sine', 0.5 * v, 50);
    this.noiseBurst(t, 0.08, 0.35 * v, 'lowpass', 700, 150);
  }

  squawk() {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const t = ctx.currentTime;
    for (let k = 0; k < 2; k++) {
      const t0 = t + 0.05 + k * 0.2;
      const f = 480 + Math.random() * 120;
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(f, t0);
      o.frequency.linearRampToValueAtTime(f * 1.9, t0 + 0.035);
      o.frequency.linearRampToValueAtTime(f * 1.35, t0 + 0.11);
      o.frequency.linearRampToValueAtTime(f * 0.75, t0 + 0.18);
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 42;
      const lg = ctx.createGain();
      lg.gain.value = 110;
      lfo.connect(lg).connect(o.frequency);
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = 1500;
      bp.Q.value = 2.2;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.55, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.19);
      o.connect(bp).connect(g).connect(this.master);
      o.start(t0);
      o.stop(t0 + 0.22);
      lfo.start(t0);
      lfo.stop(t0 + 0.22);
    }
  }

  splash() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.6, 0.7, 'lowpass', 4000, 250);
    this.noiseBurst(t + 0.05, 0.3, 0.3, 'bandpass', 1800, 600, 1.5);
    this.tone(300, t, 0.2, 'sine', 0.25, 90);
  }

  grindStart() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.25, 0.4, 'bandpass', 3200, 1400, 2);
    this.tone(1800, t, 0.15, 'square', 0.06, 900);
  }

  whoosh() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.25, 0.25, 'bandpass', 600, 1800, 1.2);
  }

  dispose() {
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
  }
}
