import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { COLORS } from './constants';

const tmpColor = new THREE.Color();
const tmpMat = new THREE.Matrix4();
const tmpEuler = new THREE.Euler();

/** A colored box geometry (vertex colors) ready for merging */
export function vbox(
  w: number,
  h: number,
  d: number,
  color: number,
  x = 0,
  y = 0,
  z = 0,
  rx = 0,
  ry = 0,
  rz = 0,
): THREE.BufferGeometry {
  const g = new THREE.BoxGeometry(w, h, d);
  g.deleteAttribute('uv');
  if (rx || ry || rz) {
    tmpEuler.set(rx, ry, rz);
    tmpMat.makeRotationFromEuler(tmpEuler);
    g.applyMatrix4(tmpMat);
  }
  g.translate(x, y, z);
  tmpColor.set(color);
  const n = g.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    arr[i * 3] = tmpColor.r;
    arr[i * 3 + 1] = tmpColor.g;
    arr[i * 3 + 2] = tmpColor.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}

export function mergeColored(geoms: THREE.BufferGeometry[]): THREE.BufferGeometry {
  if (geoms.length === 0) return new THREE.BufferGeometry();
  const merged = mergeGeometries(geoms, false);
  for (const g of geoms) g.dispose();
  return merged ?? new THREE.BufferGeometry();
}

/* ------------------------------------------------------------------ */
/* Chicken (Crossy-Road-ish)                                           */
/* ------------------------------------------------------------------ */

const CK = {
  white: 0xfafaf5,
  white2: 0xececE4,
  wing: 0xe9e9e1,
  wingTip: 0xd6d6cc,
  comb: 0xe8322a,
  beak: 0xffa51f,
  leg: 0xff9416,
  eye: 0x161616,
};

export interface ChickenParts {
  torso: THREE.Mesh;
  head: THREE.Mesh;
  wingN: THREE.Mesh;
  wingF: THREE.Mesh;
  legN: THREE.Mesh;
  legF: THREE.Mesh;
  eyes: THREE.Mesh;
  deadEyes: THREE.Mesh;
  all: THREE.Mesh[];
}

export function buildChicken(mat: THREE.Material): ChickenParts {
  // torso: origin at hip (bottom center)
  const torso = new THREE.Mesh(
    mergeColored([
      vbox(0.56, 0.5, 0.5, CK.white, 0, 0.25, 0),
      vbox(0.18, 0.26, 0.36, CK.white, -0.34, 0.4, 0),
      vbox(0.13, 0.15, 0.24, CK.white2, -0.44, 0.57, 0),
      vbox(0.4, 0.06, 0.4, CK.white2, 0.02, 0.0, 0),
    ]),
    mat,
  );

  // head: origin at neck (bottom center)
  const head = new THREE.Mesh(
    mergeColored([
      vbox(0.44, 0.42, 0.44, CK.white, 0, 0.21, 0),
      vbox(0.12, 0.11, 0.1, CK.comb, 0.08, 0.47, 0),
      vbox(0.12, 0.18, 0.1, CK.comb, -0.04, 0.5, 0),
      vbox(0.1, 0.09, 0.1, CK.comb, -0.15, 0.46, 0),
      vbox(0.17, 0.11, 0.18, CK.beak, 0.3, 0.23, 0),
      vbox(0.08, 0.13, 0.08, CK.comb, 0.25, 0.11, 0),
    ]),
    mat,
  );

  const eyes = new THREE.Mesh(
    mergeColored([
      vbox(0.075, 0.085, 0.02, CK.eye, 0.1, 0.29, 0.226),
      vbox(0.075, 0.085, 0.02, CK.eye, 0.1, 0.29, -0.226),
    ]),
    mat,
  );
  head.add(eyes);

  const deadEyes = new THREE.Mesh(
    mergeColored([
      vbox(0.12, 0.028, 0.02, CK.eye, 0.1, 0.29, 0.227, 0, 0, 0.785),
      vbox(0.12, 0.028, 0.02, CK.eye, 0.1, 0.29, 0.227, 0, 0, -0.785),
      vbox(0.12, 0.028, 0.02, CK.eye, 0.1, 0.29, -0.227, 0, 0, 0.785),
      vbox(0.12, 0.028, 0.02, CK.eye, 0.1, 0.29, -0.227, 0, 0, -0.785),
    ]),
    mat,
  );
  deadEyes.visible = false;
  head.add(deadEyes);

  const wingGeo = () =>
    mergeColored([
      vbox(0.3, 0.3, 0.06, CK.wing, -0.03, -0.14, 0),
      vbox(0.24, 0.07, 0.065, CK.wingTip, -0.06, -0.3, 0),
    ]);
  const wingN = new THREE.Mesh(wingGeo(), mat);
  const wingF = new THREE.Mesh(wingGeo(), mat);

  const legGeo = () =>
    mergeColored([
      vbox(0.07, 0.24, 0.07, CK.leg, 0, -0.12, 0),
      vbox(0.2, 0.04, 0.13, CK.leg, 0.05, -0.24, 0),
    ]);
  const legN = new THREE.Mesh(legGeo(), mat);
  const legF = new THREE.Mesh(legGeo(), mat);

  const all = [torso, head, wingN, wingF, legN, legF];
  for (const m of all) {
    m.castShadow = true;
    m.receiveShadow = false;
    m.rotation.order = 'ZYX';
  }
  eyes.castShadow = false;
  deadEyes.castShadow = false;
  return { torso, head, wingN, wingF, legN, legF, eyes, deadEyes, all };
}

/* ------------------------------------------------------------------ */
/* Skateboard                                                          */
/* ------------------------------------------------------------------ */

export interface BoardParts {
  group: THREE.Group;
  wheels: THREE.Mesh[];
}

export function buildBoard(mat: THREE.Material): BoardParts {
  const group = new THREE.Group();
  const deck = new THREE.Mesh(
    mergeColored([
      vbox(1.12, 0.06, 0.42, 0xff5a36, 0, 0, 0),
      vbox(1.12, 0.016, 0.4, 0x2a2a35, 0, 0.037, 0),
      vbox(0.34, 0.064, 0.425, 0xffd23f, 0, 0, 0),
      vbox(0.1, 0.064, 0.425, 0x3fb6ff, 0.28, 0, 0),
      vbox(0.1, 0.064, 0.425, 0x3fb6ff, -0.28, 0, 0),
      vbox(0.22, 0.06, 0.42, 0xff5a36, 0.66, 0.04, 0, 0, 0, 0.38),
      vbox(0.22, 0.06, 0.42, 0xff5a36, -0.66, 0.04, 0, 0, 0, -0.38),
      vbox(0.2, 0.016, 0.4, 0x2a2a35, 0.655, 0.075, 0, 0, 0, 0.38),
      vbox(0.2, 0.016, 0.4, 0x2a2a35, -0.655, 0.075, 0, 0, 0, -0.38),
      vbox(0.13, 0.08, 0.26, 0xa3acb6, 0.5, -0.07, 0),
      vbox(0.13, 0.08, 0.26, 0xa3acb6, -0.5, -0.07, 0),
      vbox(0.05, 0.05, 0.46, 0x6f767e, 0.5, -0.17, 0),
      vbox(0.05, 0.05, 0.46, 0x6f767e, -0.5, -0.17, 0),
    ]),
    mat,
  );
  deck.castShadow = true;
  group.add(deck);

  const wheels: THREE.Mesh[] = [];
  const wg = new THREE.CylinderGeometry(0.12, 0.12, 0.1, 8);
  wg.rotateX(Math.PI / 2);
  wg.deleteAttribute('uv');
  {
    tmpColor.set(0xf5e7c2);
    const n = wg.attributes.position.count;
    const arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      arr[i * 3] = tmpColor.r;
      arr[i * 3 + 1] = tmpColor.g;
      arr[i * 3 + 2] = tmpColor.b;
    }
    wg.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  }
  const hub = vbox(0.07, 0.07, 0.11, 0xff5a36);
  const wheelGeo = mergeColored([wg.toNonIndexed(), hub.toNonIndexed()]);
  wg.dispose();
  hub.dispose();
  for (const x of [0.5, -0.5]) {
    for (const z of [0.19, -0.19]) {
      const w = new THREE.Mesh(wheelGeo, mat);
      w.position.set(x, -0.17, z);
      w.castShadow = true;
      group.add(w);
      wheels.push(w);
    }
  }
  return { group, wheels };
}

/* ------------------------------------------------------------------ */
/* Coins                                                               */
/* ------------------------------------------------------------------ */

export function buildCoinGeometry(): THREE.BufferGeometry {
  return mergeColored([
    vbox(0.5, 0.5, 0.1, 0xffcf2e),
    vbox(0.6, 0.3, 0.1, 0xffcf2e),
    vbox(0.3, 0.6, 0.1, 0xffcf2e),
    vbox(0.26, 0.26, 0.13, 0xffa800),
    vbox(0.07, 0.22, 0.14, 0xfff3b0, -0.05, 0.05, 0),
  ]);
}

/* ------------------------------------------------------------------ */
/* Scenery props (pushed into a geometry list for merging)             */
/* ------------------------------------------------------------------ */

const GREENS = [0x5cc04a, 0x4db340, 0x6fcf55, 0x3fa65a];
const FLOWER = [0xff5a5a, 0xffd23f, 0xffffff, 0xff8fd1, 0x9b7bff];

export function propTree(out: THREE.BufferGeometry[], x: number, y: number, z: number, s: number, c: number) {
  const g1 = GREENS[Math.floor(c * GREENS.length) % GREENS.length];
  const g2 = GREENS[(Math.floor(c * GREENS.length) + 2) % GREENS.length];
  out.push(vbox(0.38 * s, 1.5 * s, 0.38 * s, COLORS.trunk, x, y + 0.25 * s, z));
  out.push(vbox(1.5 * s, 1.1 * s, 1.5 * s, g1, x, y + 1.55 * s, z));
  out.push(vbox(1.0 * s, 0.7 * s, 1.0 * s, g2, x, y + 2.4 * s, z));
}

export function propPine(out: THREE.BufferGeometry[], x: number, y: number, z: number, s: number) {
  out.push(vbox(0.32 * s, 1.2 * s, 0.32 * s, 0x7a4f33, x, y + 0.2 * s, z));
  out.push(vbox(1.6 * s, 0.6 * s, 1.6 * s, 0x2f9e5b, x, y + 1.0 * s, z));
  out.push(vbox(1.2 * s, 0.6 * s, 1.2 * s, 0x37ad64, x, y + 1.6 * s, z));
  out.push(vbox(0.8 * s, 0.6 * s, 0.8 * s, 0x2f9e5b, x, y + 2.2 * s, z));
  out.push(vbox(0.4 * s, 0.4 * s, 0.4 * s, 0x37ad64, x, y + 2.7 * s, z));
}

export function propTall(out: THREE.BufferGeometry[], x: number, y: number, z: number, s: number) {
  out.push(vbox(0.34 * s, 1.0 * s, 0.34 * s, COLORS.trunk, x, y + 0.1 * s, z));
  out.push(vbox(0.95 * s, 2.0 * s, 0.95 * s, 0x58b94a, x, y + 1.55 * s, z));
  out.push(vbox(0.5 * s, 0.4 * s, 0.5 * s, 0x6fcf55, x + 0.25 * s, y + 1.2 * s, z + 0.3 * s));
}

export function propBush(out: THREE.BufferGeometry[], x: number, y: number, z: number, s: number) {
  out.push(vbox(0.9 * s, 0.7 * s, 0.8 * s, 0x4fb543, x, y + 0.2 * s, z));
  out.push(vbox(0.6 * s, 0.5 * s, 0.6 * s, 0x63c64f, x + 0.45 * s, y + 0.1 * s, z + 0.1));
}

export function propFlowers(out: THREE.BufferGeometry[], x: number, y: number, z: number, c: number) {
  for (let i = 0; i < 3; i++) {
    const ox = (i - 1) * 0.35 + Math.sin(c * 50 + i) * 0.1;
    const oz = Math.cos(c * 30 + i * 2) * 0.3;
    const col = FLOWER[Math.floor((c * 7 + i) * 13) % FLOWER.length];
    out.push(vbox(0.05, 0.35, 0.05, 0x3f9a3a, x + ox, y + 0.12, z + oz));
    out.push(vbox(0.16, 0.16, 0.16, col, x + ox, y + 0.34, z + oz));
  }
}

export function propRock(out: THREE.BufferGeometry[], x: number, y: number, z: number, s: number) {
  out.push(vbox(0.9 * s, 0.6 * s, 0.8 * s, 0x9aa0a8, x, y + 0.15 * s, z, 0, 0.3, 0));
  out.push(vbox(0.5 * s, 0.4 * s, 0.5 * s, 0xb4bac2, x + 0.45 * s, y + 0.05 * s, z + 0.2, 0, 0.6, 0));
}

export function propLamp(out: THREE.BufferGeometry[], x: number, y: number, z: number) {
  out.push(vbox(0.14, 3.8, 0.14, 0x60666e, x, y + 1.6, z));
  out.push(vbox(0.3, 0.2, 0.3, 0x50555c, x, y - 0.1, z));
  out.push(vbox(0.95, 0.12, 0.12, 0x60666e, x + 0.4, y + 3.45, z));
  out.push(vbox(0.42, 0.16, 0.32, 0x50555c, x + 0.8, y + 3.4, z));
  out.push(vbox(0.34, 0.06, 0.26, 0xfff2a6, x + 0.8, y + 3.31, z));
}

export function propSign(out: THREE.BufferGeometry[], x: number, y: number, z: number) {
  out.push(vbox(0.12, 2.0, 0.12, 0x70767e, x, y + 0.6, z));
  out.push(vbox(0.72, 0.72, 0.06, 0x222222, x, y + 1.75, z + 0.06, 0, 0, Math.PI / 4));
  out.push(vbox(0.62, 0.62, 0.07, 0xffd23f, x, y + 1.75, z + 0.07, 0, 0, Math.PI / 4));
  out.push(vbox(0.09, 0.3, 0.08, 0x222222, x, y + 1.8, z + 0.1));
  out.push(vbox(0.09, 0.09, 0.08, 0x222222, x, y + 1.56, z + 0.1));
}

export function propCone(out: THREE.BufferGeometry[], x: number, y: number, z: number) {
  out.push(vbox(0.42, 0.06, 0.42, 0xff7a1a, x, y + 0.03, z));
  out.push(vbox(0.28, 0.22, 0.28, 0xff7a1a, x, y + 0.17, z));
  out.push(vbox(0.29, 0.08, 0.29, 0xffffff, x, y + 0.3, z));
  out.push(vbox(0.18, 0.18, 0.18, 0xff7a1a, x, y + 0.42, z));
}

export function propBarrier(out: THREE.BufferGeometry[], x: number, y: number, z: number) {
  out.push(vbox(0.1, 0.8, 0.1, 0x70767e, x - 0.5, y + 0.4, z));
  out.push(vbox(0.1, 0.8, 0.1, 0x70767e, x + 0.5, y + 0.4, z));
  for (let i = 0; i < 5; i++) {
    out.push(vbox(0.24, 0.22, 0.08, i % 2 ? 0xffffff : 0xee4a3c, x - 0.48 + i * 0.24, y + 0.65, z + 0.06));
  }
}

export function propLog(out: THREE.BufferGeometry[], x: number, y: number, z: number, rot: number) {
  out.push(vbox(2.2, 0.42, 0.5, 0x8a5a3b, x, y + 0.12, z, 0, rot, 0));
  out.push(vbox(2.24, 0.3, 0.38, 0xc49466, x, y + 0.12, z, 0, rot, 0));
}

export function propLily(out: THREE.BufferGeometry[], x: number, y: number, z: number, c: number) {
  out.push(vbox(0.8, 0.06, 0.8, 0x3fae4a, x, y + 0.03, z, 0, c * 3, 0));
  if (c > 0.5) out.push(vbox(0.18, 0.18, 0.18, 0xff8fd1, x + 0.1, y + 0.15, z));
}

/* ------------------------------------------------------------------ */
/* Background                                                          */
/* ------------------------------------------------------------------ */

export function buildCloudGeometry(seed: number): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const n = 3 + Math.floor(seed * 3);
  for (let i = 0; i < n; i++) {
    const w = 2.5 + ((seed * 97 + i * 31) % 1) * 3;
    const h = 1.4 + ((seed * 53 + i * 17) % 1) * 1.4;
    parts.push(vbox(w, h, 2.5, i % 2 ? 0xffffff : 0xf3f8ff, i * 2.2 - n, ((i * 37) % 3) * 0.4, ((i * 13) % 3) * 0.5));
  }
  return mergeColored(parts);
}

export function buildMountainGeometry(w: number, h: number, base: number, snow: boolean): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const layers = 5;
  const lh = h / layers;
  const palette = [0x7fc28a, 0x86c991, 0x8fd09a, 0x9ad6a4, 0xa7dcae];
  for (let i = 0; i < layers; i++) {
    const lw = w * (1 - i * 0.18);
    const col = snow && i === layers - 1 ? 0xffffff : palette[i];
    parts.push(vbox(lw, lh + (i === 0 ? base : 0), lw * 0.7, col, (i % 2) * w * 0.04, i * lh + lh / 2 - (i === 0 ? base / 2 : 0), 0));
  }
  return mergeColored(parts);
}

/* ------------------------------------------------------------------ */
/* City props (Tokyo / Shibuya)                                        */
/* ------------------------------------------------------------------ */

const hashN = (n: number) => {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
};

/** window grid on the front (+z) face of a building box */
function windows(
  out: THREE.BufferGeometry[],
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  win: number,
  lit: number,
  seed: number,
) {
  const cols = Math.max(1, Math.floor(w / 1.1));
  const rows = Math.max(1, Math.floor(h / 1.5));
  const dark = new THREE.Color(win).multiplyScalar(0.35).getHex();
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const on = hashN(seed + r * 31 + c * 7) < lit;
      out.push(
        vbox(
          0.55,
          0.7,
          0.06,
          on ? win : dark,
          x - w / 2 + ((c + 0.5) * w) / cols,
          y - h / 2 + ((r + 0.5) * h) / rows,
          z + d / 2 + 0.03,
        ),
      );
    }
  }
}

export function propBuilding(
  out: THREE.BufferGeometry[],
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  wall: number,
  win: number,
  lit: number,
  seed: number,
) {
  out.push(vbox(w, h, d, wall, x, y + h / 2, z));
  out.push(vbox(w * 1.06, 0.35, d * 1.06, new THREE.Color(wall).multiplyScalar(0.8).getHex(), x, y + h + 0.15, z));
  windows(out, x, y + h / 2, z, w, h, d, win, lit, seed);
}

export function propShop(out: THREE.BufferGeometry[], x: number, y: number, z: number, wall: number, accent: number) {
  out.push(vbox(2.6, 2.2, 2.2, wall, x, y + 1.1, z));
  out.push(vbox(2.9, 0.25, 2.5, accent, x, y + 2.3, z));
  out.push(vbox(2.2, 0.9, 0.08, 0xfff2a6, x, y + 0.7, z + 1.14));
  out.push(vbox(2.9, 0.5, 0.1, accent, x, y + 1.85, z + 1.16));
}

export function propVending(out: THREE.BufferGeometry[], x: number, y: number, z: number, glow: boolean) {
  out.push(vbox(0.9, 1.7, 0.7, 0xd63a2e, x, y + 0.85, z));
  out.push(vbox(0.7, 1.1, 0.06, glow ? 0xfff6c8 : 0xdfe8ee, x, y + 0.95, z + 0.38));
  out.push(vbox(0.7, 0.18, 0.06, 0x8a2020, x, y + 0.28, z + 0.38));
}

export function propNeonSign(out: THREE.BufferGeometry[], x: number, y: number, z: number, color: number) {
  out.push(vbox(0.12, 3.2, 0.12, 0x3a3f4a, x, y + 1.4, z));
  out.push(vbox(1.5, 0.55, 0.18, color, x, y + 3.1, z));
  out.push(vbox(1.3, 0.35, 0.2, new THREE.Color(color).multiplyScalar(1.4).getHex(), x, y + 3.1, z));
}

export function propBillboard(out: THREE.BufferGeometry[], x: number, y: number, z: number, color: number) {
  out.push(vbox(0.25, 4.2, 0.25, 0x4a4f5a, x, y + 1.9, z));
  out.push(vbox(3.4, 2.0, 0.25, 0x1c1e26, x, y + 4.6, z));
  out.push(vbox(3.1, 1.7, 0.28, color, x, y + 4.6, z));
}

export function propPole(out: THREE.BufferGeometry[], x: number, y: number, z: number) {
  out.push(vbox(0.16, 5.2, 0.16, 0x6a5a48, x, y + 2.4, z));
  out.push(vbox(1.4, 0.12, 0.12, 0x6a5a48, x, y + 4.9, z));
  out.push(vbox(1.0, 0.12, 0.12, 0x6a5a48, x, y + 4.4, z));
}

/* ------------------------------------------------------------------ */
/* Background skylines                                                 */
/* ------------------------------------------------------------------ */

export function buildTowerGeometry(w: number, h: number, wall: number, win: number, lit: number, seed: number): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  parts.push(vbox(w, h, w * 0.8, wall, 0, h / 2, 0));
  parts.push(vbox(w * 1.05, 0.6, w * 0.85, new THREE.Color(wall).multiplyScalar(0.75).getHex(), 0, h + 0.3, 0));
  windows(parts, 0, h / 2, 0, w, h, w * 0.8, win, lit, seed);
  return mergeColored(parts);
}

export function buildTokyoTowerGeometry(color: number): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const segs = 6;
  const H = 46;
  for (let i = 0; i < segs; i++) {
    const t = i / segs;
    const w = 9 * (1 - t * 0.75);
    const y = (H * i) / segs;
    parts.push(vbox(w, H / segs + 0.4, w * 0.7, color, 0, y + H / segs / 2, 0));
  }
  parts.push(vbox(0.5, 6, 0.5, color, 0, H + 2.5, 0));
  parts.push(vbox(3.2, 2.2, 2.6, color, 0, H * 0.62, 0));
  return mergeColored(parts);
}

export function buildNeonTowerGeometry(w: number, h: number, seed: number): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const wall = 0x232838;
  parts.push(vbox(w, h, w * 0.8, wall, 0, h / 2, 0));
  const neons = [0xff5ad2, 0x5ad2ff, 0xffe066, 0x7dff6a];
  const nc = neons[Math.floor(hashN(seed) * neons.length)];
  parts.push(vbox(w * 0.9, 0.5, w * 0.85, nc, 0, h + 0.2, 0));
  parts.push(vbox(0.3, h * 0.7, 0.3, nc, w / 2 + 0.1, h / 2, 0));
  const wins = [0xffe9a8, 0xa8e6ff, 0xffc8e6, 0xffffff];
  const wc = wins[Math.floor(hashN(seed * 3) * wins.length)];
  windows(parts, 0, h / 2, 0, w, h, w * 0.8, wc, 0.55, seed);
  return mergeColored(parts);
}
