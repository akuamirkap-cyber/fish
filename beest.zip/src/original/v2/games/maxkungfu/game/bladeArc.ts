import { pcircle, pline, px, type Ctx } from './pixel';
import type { Vec } from './types';

export interface SlashArc { x: number; y: number; r: number; from: number; to: number; t: number; max: number; c: string; lift: number; vertical: number }
interface BladeSample { base: Vec; tip: Vec; age: number; max: number; color: string }
interface BladeImpact { x: number; y: number; angle: number; age: number; max: number; color: string }
interface CutMark { x: number; y: number; angle: number; age: number; max: number; strong: boolean }

/** Yamato-style curved blade, sampled swing ribbon and brief cut marks. No scabbard. */
export class Katana {
  readonly len = 21;
  arcs: SlashArc[] = [];
  trail: BladeSample[] = [];
  impacts: BladeImpact[] = [];
  cuts: CutMark[] = [];
  prevBase: Vec | null = null;
  prevTip: Vec | null = null;
  sheen = 0;
  private time = 0;

  /** Takamura geometry: full horizontal reach, vertical component squashed 0.6 so the blade never looks overlong. */
  blade(hand: Vec, angle: number, lift = 0): { base: Vec; tip: Vec } {
    const tip = { x: hand.x + Math.cos(angle) * this.len, y: hand.y + Math.sin(angle) * this.len * 0.6 - lift * 10 };
    return { base: hand, tip };
  }

  addArc(x: number, y: number, r: number, from: number, to: number, c: string, lift = 0, life = 0.22, vertical = 0.6) {
    this.arcs.push({ x, y, r, from, to, t: 0, max: life, c, lift, vertical });
    if (this.arcs.length > 10) this.arcs.shift();
  }

  record(base: Vec, tip: Vec, color: string, strong = false) {
    const last = this.trail[this.trail.length - 1];
    if (last && Math.hypot(last.tip.x - tip.x, last.tip.y - tip.y) < 0.85) return;
    this.trail.push({ base: { ...base }, tip: { ...tip }, age: 0, max: strong ? 0.32 : 0.21, color });
    if (this.trail.length > 26) this.trail.shift();
  }

  impact(x: number, y: number, angle: number, color: string) {
    this.impacts.push({ x, y, angle, age: 0, max: 0.16, color });
    if (this.impacts.length > 12) this.impacts.shift();
    this.sheen = 0.25;
  }

  cut(x: number, y: number, angle: number, strong: boolean) {
    this.cuts.push({ x, y, angle, age: 0, max: strong ? 0.33 : 0.19, strong });
    if (this.cuts.length > 18) this.cuts.shift();
  }

  clear() { this.arcs = []; this.trail = []; this.impacts = []; this.cuts = []; }

  update(dt: number) {
    for (let i = this.arcs.length - 1; i >= 0; i--) { this.arcs[i].t += dt; if (this.arcs[i].t >= this.arcs[i].max) this.arcs.splice(i, 1); }
    for (let i = this.trail.length - 1; i >= 0; i--) { this.trail[i].age += dt; if (this.trail[i].age >= this.trail[i].max) this.trail.splice(i, 1); }
    for (let i = this.impacts.length - 1; i >= 0; i--) { this.impacts[i].age += dt; if (this.impacts[i].age >= this.impacts[i].max) this.impacts.splice(i, 1); }
    for (let i = this.cuts.length - 1; i >= 0; i--) { this.cuts[i].age += dt; if (this.cuts[i].age >= this.cuts[i].max) this.cuts.splice(i, 1); }
    if (this.sheen > 0) this.sheen -= dt;
    this.time += dt;
  }

  drawArcs(ctx: Ctx) {
    // Successive real blade-tip positions form the swing ribbon: a wide translucent body, a hot inner band near the
    // edge and a crisp white cutting line.
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const at = (s: BladeSample, k: number) => ({ x: s.base.x + (s.tip.x - s.base.x) * k, y: s.base.y + (s.tip.y - s.base.y) * k });
    for (let i = 1; i < this.trail.length; i++) {
      const a = this.trail[i - 1], b = this.trail[i];
      const fade = Math.min(1 - a.age / a.max, 1 - b.age / b.max);
      if (fade <= 0) continue;
      const ai = at(a, 0.26), bi = at(b, 0.26), am = at(a, 0.7), bm = at(b, 0.7);
      ctx.fillStyle = b.color;
      ctx.globalAlpha = fade * fade * 0.36;                 // quadratic falloff: a comet tail, not a lingering dome
      ctx.beginPath();
      ctx.moveTo(ai.x, ai.y); ctx.lineTo(a.tip.x, a.tip.y);
      ctx.lineTo(b.tip.x, b.tip.y); ctx.lineTo(bi.x, bi.y);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.globalAlpha = fade * fade * fade * 0.36;
      ctx.beginPath();
      ctx.moveTo(am.x, am.y); ctx.lineTo(a.tip.x, a.tip.y);
      ctx.lineTo(b.tip.x, b.tip.y); ctx.lineTo(bm.x, bm.y);
      ctx.closePath(); ctx.fill();
      ctx.globalAlpha = Math.pow(fade, 1.5) * 0.85;
      pline(ctx, a.tip.x, a.tip.y, b.tip.x, b.tip.y, '#f4fbff', 1);
    }
    // Crescent-moon slash: tapered at both tips, thickest just behind the leading edge, drifting outward as it fades.
    for (const a of this.arcs) {
      const k = 1 - a.t / a.max, span = a.to - a.from;
      const n = Math.max(8, Math.ceil(Math.abs(span) * a.r * 0.5));
      const R = a.r * (1 + 0.1 * (1 - k)), W = Math.min(7.5, a.r * 0.32) * (0.5 + 0.5 * k);
      const pt = (u: number, rad: number) => ({ x: a.x + Math.cos(a.from + span * u) * rad, y: a.y + Math.sin(a.from + span * u) * rad * a.vertical - a.lift * 10 });
      const belly = (u: number) => Math.pow(Math.sin(Math.PI * Math.min(1, u * 1.12)), 0.75) * (0.3 + 0.7 * u);
      const crescent = (thick: number) => {
        ctx.beginPath();
        for (let i = 0; i <= n; i++) { const p = pt(i / n, R); if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y); }
        for (let i = n; i >= 0; i--) { const u = i / n, p = pt(u, R - thick * belly(u)); ctx.lineTo(p.x, p.y); }
        ctx.closePath(); ctx.fill();
      };
      ctx.fillStyle = a.c; ctx.globalAlpha = k * 0.4; crescent(W);
      ctx.fillStyle = '#ffffff'; ctx.globalAlpha = k * k * 0.5; crescent(W * 0.42);
    }
    ctx.restore();
    // a crisp pixel rim keeps the pixel-art read: brightest at the leading edge
    for (const a of this.arcs) {
      const k = 1 - a.t / a.max, span = a.to - a.from;
      const n = Math.max(6, Math.ceil(Math.abs(span) * a.r * 0.6)), R = a.r * (1 + 0.1 * (1 - k));
      for (let i = 0; i < n; i++) {
        const f0 = a.from + (span * i) / n, f1 = a.from + (span * (i + 1)) / n;
        ctx.globalAlpha = k * 0.78 * (0.25 + 0.75 * ((i + 1) / n));
        pline(ctx, a.x + Math.cos(f0) * R, a.y + Math.sin(f0) * R * a.vertical - a.lift * 10, a.x + Math.cos(f1) * R, a.y + Math.sin(f1) * R * a.vertical - a.lift * 10, '#ffffff', 1);
      }
    }
    for (const hit of this.impacts) {
      const k = 1 - hit.age / hit.max, r = 3 + (1 - k) * 5;
      const dx = Math.cos(hit.angle), dy = Math.sin(hit.angle);
      ctx.globalAlpha = k * 0.85;
      pline(ctx, hit.x - dx * r, hit.y - dy * r, hit.x + dx * r, hit.y + dy * r, '#fffaf0', 1);
      pline(ctx, hit.x - dy * r * 0.55, hit.y + dx * r * 0.55, hit.x + dy * r * 0.55, hit.y - dx * r * 0.55, hit.color, 1);
      pcircle(ctx, hit.x, hit.y, 1.2 * k, '#ffffff');
    }
    for (const cut of this.cuts) {
      const fade = 1 - cut.age / cut.max;
      const length = cut.strong ? 10 : 6;
      const dx = Math.cos(cut.angle) * length, dy = Math.sin(cut.angle) * length;
      ctx.globalAlpha = fade * (cut.strong ? 0.9 : 0.6);
      pline(ctx, cut.x - dx, cut.y - dy, cut.x + dx, cut.y + dy, '#851f20', 2);
      ctx.globalAlpha = fade;
      pline(ctx, cut.x - dx, cut.y - dy - 1, cut.x + dx, cut.y + dy - 1, '#fff5df', 1);
    }
    ctx.globalAlpha = 1;
  }

  /** Takamura katana shape: pixel-outline blade, cream tsuka, gold tsuba and a sliding hamon glint. */
  drawBlade(ctx: Ctx, base: Vec, tip: Vec, _sheathed = false, depth = false) {
    const dx = tip.x - base.x, dy = tip.y - base.y, l = Math.hypot(dx, dy) || 1;
    const nx = -dy / l, ny = dx / l;
    ctx.save();
    ctx.lineCap = 'round';
    if (depth) { ctx.shadowColor = 'rgba(190,225,255,.5)'; ctx.shadowBlur = 2.5; }
    // tsuka: cream wrap behind the hand, gold pommel cap
    const bx = base.x - (dx / l) * 4.2, by = base.y - (dy / l) * 4.2;
    pline(ctx, base.x, base.y, bx, by, '#000000', 3);
    pline(ctx, base.x, base.y, bx, by, '#e8e0d0', 1);
    pcircle(ctx, bx, by, 1, '#c9a033');
    // blade: black outline, steel core, shaded spine (mune), white cutting edge (ha)
    pline(ctx, base.x, base.y, tip.x, tip.y, '#000000', 3);
    pline(ctx, base.x - nx * 0.5, base.y - ny * 0.5, tip.x - nx * 0.3, tip.y - ny * 0.3, '#8a93a0', 1);
    pline(ctx, base.x, base.y, tip.x, tip.y, '#eef2f8', 1);
    pline(ctx, base.x + nx * 0.7, base.y + ny * 0.7, tip.x + nx * 0.2, tip.y + ny * 0.2, '#ffffff', 1);
    pcircle(ctx, tip.x, tip.y, 0.6, '#ffffff');
    // gold tsuba at the guard
    pline(ctx, base.x + nx * 2, base.y + ny * 2, base.x - nx * 2, base.y - ny * 2, '#c9a033', 2);
    // sliding hamon glint along the blade
    const gt = (this.time * 2.4) % 1;
    px(ctx, base.x + dx * gt, base.y + dy * gt, '#ffffff');
    if (this.sheen > 0) {
      ctx.globalAlpha = Math.min(1, this.sheen / 0.25);
      pline(ctx, tip.x - 3, tip.y, tip.x + 3, tip.y, '#fff8e8', 1);
      pline(ctx, tip.x, tip.y - 3, tip.x, tip.y + 3, '#fff8e8', 1);
    }
    ctx.restore();
  }
}
