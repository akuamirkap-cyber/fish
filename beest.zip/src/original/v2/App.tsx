import { useState } from 'react';
import { Settings2, Volume2, VolumeX } from 'lucide-react';
import { ATMO_LIST, type AtmoId } from '../shared/office/atmo';
import { loadV2Atmo, loadV2HitFx, loadV2Glow } from '../shared/office/look';
import { loadAuraColor, type AuraColor } from './games/maxkungfu/game/eightGates';
import MaxkungfuGame from './games/maxkungfu/App';
import type { Game, UIState } from './games/maxkungfu/game/game';
import { SOUND_VERSIONS, type SoundVersion } from './games/maxkungfu/game/soundPacks';

function initialVersion(): SoundVersion {
  const param = new URLSearchParams(window.location.search).get('v');
  return SOUND_VERSIONS.find((item) => item.id === `v${param}`)?.id ?? 'v2';
}

const handle = () => (window as unknown as { __kf?: Game }).__kf;

function Group({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="sound-bar__unit">
      <span className="sound-bar__label">{label}</span>
      <div className="sound-bar__group" role="group" aria-label={label}>{children}</div>
    </div>
  );
}

export default function App() {
  const [version, setVersion] = useState<SoundVersion>(initialVersion);
  const [ui, setUi] = useState<UIState | null>(null);
  const [atmo, setAtmo] = useState<'auto' | AtmoId>(loadV2Atmo);
  const [hitFx, setHitFx] = useState<'v1' | 'v2'>(loadV2HitFx);
  const [glow, setGlow] = useState<boolean>(loadV2Glow);
  const [aura, setAura] = useState<AuraColor>(loadAuraColor);
  const [advanced, setAdvanced] = useState(false);
  const selectAtmo = (value: 'auto' | AtmoId) => { setAtmo(value); handle()?.setOfficeAtmo(value); };
  const selectWalk = (value: 'normal' | 'kenjutsu' | 'ronin') => handle()?.setWalkStyle(value);
  const walk = ui?.walkStyle ?? 'ronin';
  const isOffice = ui?.arena === 'office';
  const katanaAvailable = Boolean(handle()?.player.hasKatana && handle()?.weaponAllowed('katana'));

  return (
    <div className={`v2-frame flex h-full w-full flex-col bg-black ${!ui || ui.state === 'menu' ? 'v2-native-menu' : ''}`}>
      <div className="game-shell">
        <MaxkungfuGame key={version} soundVersion={version} onState={setUi} />
      </div>

      <div id="sound-bar" className="sound-bar sound-bar--v2" onClickCapture={(event) => {
        if ((event.target as HTMLElement).closest('button')) handle()?.input.focus();
      }}>
        {advanced && (
          <div className="sound-bar__advanced" role="region" aria-label="Opsi permainan lanjutan">
            <Group label="SUASANA LENGKAP">
              <button type="button" className="sound-bar__btn" aria-pressed={atmo === 'auto'} onClick={() => selectAtmo('auto')}>AUTO</button>
              {ATMO_LIST.map((item) => <button key={item.id} type="button" className="sound-bar__btn" aria-pressed={atmo === item.id} onClick={() => selectAtmo(item.id)}>{item.id.toUpperCase()}</button>)}
            </Group>
            <Group label="EFEK HIT">
              {(['v1', 'v2'] as const).map((value) => <button key={value} type="button" className="sound-bar__btn" aria-pressed={hitFx === value} onClick={() => { setHitFx(value); handle()?.setHitFx(value); }}>{value.toUpperCase()}</button>)}
            </Group>
            <Group label="GLOW">
              <button type="button" className="sound-bar__btn" aria-pressed={glow} onClick={() => { setGlow(true); handle()?.setGlow(true); }}>ON</button>
              <button type="button" className="sound-bar__btn" aria-pressed={!glow} onClick={() => { setGlow(false); handle()?.setGlow(false); }}>OFF</button>
            </Group>
            <Group label="AURA">
              {(['red', 'green', 'blue'] as const).map((value) => <button key={value} type="button" className="sound-bar__btn" aria-pressed={aura === value} onClick={() => { setAura(value); handle()?.setAuraColor(value); }}>{value === 'red' ? 'MERAH' : value === 'green' ? 'HIJAU' : 'BIRU'}</button>)}
            </Group>
            <Group label="SUARA">
              {SOUND_VERSIONS.map((item) => <button key={item.id} type="button" className="sound-bar__btn" title={item.hint} aria-pressed={version === item.id} onClick={() => { setVersion(item.id); setAdvanced(false); }}>{item.label}</button>)}
            </Group>
            <Group label="NUNCHAKU">
              {(['v1', 'v2', 'v3'] as const).map((value) => <button key={value} type="button" className="sound-bar__btn" aria-pressed={ui?.nunStyle === value} onClick={() => handle()?.selectNunStyle(value)}>{value === 'v3' ? 'API' : value.toUpperCase()}</button>)}
            </Group>
            <Group label="BOXING">
              {(['ali', 'tyson', 'ippo'] as const).map((value) => <button key={value} type="button" className="sound-bar__btn" aria-pressed={ui?.weapon === 'boxing' && ui?.boxStance === value} onClick={() => handle()?.selectBoxStance(value)}>{value.toUpperCase()}</button>)}
            </Group>
            <Group label="MODE">
              <button type="button" className="sound-bar__btn" aria-pressed={ui?.mode === 'survival' && !ui?.campaign} onClick={() => handle()?.startWaveMode()}>WAVE</button>
              <button type="button" className="sound-bar__btn" aria-pressed={Boolean(ui?.campaign)} onClick={() => handle()?.startStoryMode()}>STORY</button>
            </Group>
            <Group label="ARENA">
              <button type="button" className="sound-bar__btn" aria-pressed={ui?.arena === 'meadow'} onClick={() => handle()?.setArena('meadow')}>PADANG</button>
              <button type="button" className="sound-bar__btn" aria-pressed={isOffice} onClick={() => handle()?.startOfficeMode()}>KANTOR</button>
            </Group>
            <Group label="TEMPO">
              {([[1, 'NORMAL'], [0.5, 'NATURAL'], [0.35, 'PELAN'], [0.25, 'SANTAI']] as const).map(([value, label]) => <button key={label} type="button" className="sound-bar__btn" aria-pressed={(ui?.tempo ?? 1) === value} onClick={() => handle()?.setTempo(value)}>{label}</button>)}
            </Group>
            <Group label="MODEL">
              <button type="button" className="sound-bar__btn" aria-pressed={ui?.tall ?? false} onClick={() => handle()?.toggleTall()}>PANJANG</button>
              <button type="button" className="sound-bar__btn" aria-pressed={ui?.smooth ?? false} onClick={() => handle()?.toggleSmooth()}>3D HALUS</button>
            </Group>
            <Group label="BOT">
              <button type="button" className="sound-bar__btn" aria-pressed={ui?.botOn ?? false} onClick={() => handle()?.toggleBot()}>BOT</button>
              <button type="button" className="sound-bar__btn" aria-pressed={ui?.mirrorOn ?? false} onClick={() => handle()?.spawnMirror()}>MIRROR</button>
            </Group>
            <Group label="FILTER">
              <button type="button" className="sound-bar__btn" aria-pressed={ui?.filters ?? false} onClick={() => handle()?.setFilters(!(ui?.filters ?? false))}>{ui?.filters ? 'RETRO ON' : 'RETRO OFF'}</button>
            </Group>
          </div>
        )}
        <div className="sound-bar__main">
          <div className="dock-identity"><span className="dock-identity__mark">S<span>/</span>F</span><span className="dock-identity__copy"><strong>STIKFICK</strong><small>MENARA KANTOR V2</small></span></div>
          <Group label="SENJATA">
            <button type="button" className="sound-bar__btn sound-bar__btn--katana" disabled={!katanaAvailable} title="Pilih Katana (5)" aria-pressed={ui?.weapon === 'katana'} onClick={() => handle()?.setWeapon('katana')}>KATANA <kbd>5</kbd></button>
            <button type="button" className="sound-bar__btn" title="Tangan kosong (1)" aria-pressed={!ui?.ultraMix && ui?.weapon === 'fist'} onClick={() => handle()?.setWeapon('fist')}>FIST</button>
            <button type="button" className="sound-bar__btn" title="Kapak Leviathan (6): lempar, lalu tendang balik saat kembali" aria-pressed={ui?.weapon === 'axe'} onClick={() => handle()?.setWeapon('axe')}>AXE <kbd>6</kbd></button>
            <button type="button" className="sound-bar__btn sound-bar__btn--ultra" title="Ultra Mix: Fist Mode + Foot Mode (Shift+O)" aria-pressed={ui?.ultraMix ?? false} onClick={() => handle()?.setUltraMix(true)}>ULTRA MIX</button>
          </Group>
          <Group label="GAYA JALAN">
            <button type="button" className="sound-bar__btn" aria-pressed={walk === 'normal'} onClick={() => selectWalk('normal')}>NORMAL</button>
            <button type="button" className="sound-bar__btn sound-bar__btn--katana" aria-pressed={walk === 'kenjutsu'} onClick={() => selectWalk('kenjutsu')}>KENJUTSU</button>
            <button type="button" className="sound-bar__btn sound-bar__btn--katana" title="Gaya jalan dari Stickman Katana Combat Simulation" aria-pressed={walk === 'ronin'} onClick={() => selectWalk('ronin')}>RONIN</button>
          </Group>
          {isOffice && <Group label="CAHAYA">
            <button type="button" className="sound-bar__btn" aria-pressed={atmo === 'malam'} onClick={() => selectAtmo('malam')}>MALAM</button>
            <button type="button" className="sound-bar__btn" aria-pressed={atmo === 'hujan'} onClick={() => selectAtmo('hujan')}>HUJAN</button>
            <button type="button" className="sound-bar__btn" aria-pressed={atmo === 'auto'} onClick={() => selectAtmo('auto')}>AUTO</button>
          </Group>}
          <div className="dock-actions">
            <button type="button" className="dock-actions__button" title="Ganti tampilan pixel / 2D halus" aria-label={ui?.view2d ? 'Gunakan gambar pixel' : 'Gunakan gambar 2D halus'} onClick={() => handle()?.toggle2D()}>{ui?.view2d ? '2D' : 'PIXEL'}</button>
            <button type="button" className="dock-actions__button" title="Model stickman dan katana dengan kedalaman halus" aria-label="Model 3D halus" aria-pressed={ui?.smooth ?? false} onClick={() => handle()?.toggleSmooth()}>{ui?.smooth ? '3D ON' : '3D'}</button>
            <button type="button" className="dock-actions__button dock-actions__icon" title="Suara on/off" aria-label={ui?.muted ? 'Nyalakan suara' : 'Matikan suara'} onClick={() => handle()?.toggleMute()}>{ui?.muted ? <VolumeX size={16} /> : <Volume2 size={16} />}</button>
            <button type="button" className="dock-actions__button dock-actions__icon" aria-label={advanced ? 'Tutup opsi lanjutan' : 'Buka opsi lanjutan'} aria-expanded={advanced} onClick={() => setAdvanced(!advanced)}><Settings2 size={17} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}
