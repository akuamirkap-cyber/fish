import { CarCtx, type CarBuild } from "../voxel/CarCtx";
import { P } from "../voxel/palette";
import { Vox } from "../voxel/Vox";

const SIGN_FONT = '"Russo One", "Arial Black", Impact, sans-serif';

// ───────── NYC Yellow Cab — Ford Crown Victoria, checker band + roof sign ─────────
export function taxiNY(): CarBuild {
  const c = new CarCtx({ body: 0xf7c400, rim: 0x8d9299 });
  c.profile([
    "......RRRRRRRR...........",
    ".....GGGGGGGGGG..........",
    "....GGGGGGGGGGGG.........",
    "....GGGGGGGGGGGGG........",
    "BBBBBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.sideFill(10, 10, 5, 7, P.BLACK);
  c.wheels([4, 18]);
  c.side([".....KWKWKWKWKWKW........"], 3); // checker band
  c.front(["......h....", ".......h...", "...........", "BHHHSSSHHHB", "BOKKKKKKKOB", "KKKKKKKKKKK"], 6);
  c.rear(["...........", "TTT.....TTT", "....LLL....", "KKKKKKKKKKK"], 4);
  c.box(-2, 2, 9, 9, 9, 11, P.LIGHT_W); // roof sign
  c.box(3, 3, 1, 1, -1, -1, P.CHROME);
  c.mirrors(15, 5);
  c.decal({ text: "TAXI", face: "front", y: 9.5, len: 4.6, h: 0.85, color: "#111214", font: SIGN_FONT });
  c.decal({ text: "TAXI", face: "rear", y: 9.5, len: 4.6, h: 0.85, color: "#111214", font: SIGN_FONT });
  c.decal({ text: "NYC TAXI", z: 13.5, y: 4.45, len: 5, h: 0.8, color: "#111214", font: SIGN_FONT });
  return c.done();
}

// ───────── Blue Bird — Toyota Transmover, the iconic Indonesian taxi ─────────
export function bluebird(): CarBuild {
  const c = new CarCtx({ body: 0x48a9e0, rim: 0xc9ced4 });
  c.profile([
    ".....RRRRRRR..........",
    "....GGGGGGGGG.........",
    "...GGGGGGGGGGG........",
    "...GGGGGGGGGGGG.......",
    "BBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.sideFill(8, 8, 5, 7, P.BLACK);
  c.wheels([3, 15]);
  c.front(["......h....", ".......h...", "...........", "BHHHKSKHHHB", "B.KKKKKKK.B", "KKKKKKKKKKK"], 6);
  c.rear(["...........", "TTT.....TTT", "....LLL....", "KKKKKKKKKKK"], 4);
  c.box(-2, 2, 9, 9, 7, 9, P.LIGHT_W); // "TAKSI" roof lamp
  c.box(3, 3, 1, 1, -1, -1, P.CHROME);
  c.mirrors(13, 5);
  c.decal({ text: "TAKSI", face: "front", y: 9.5, len: 4.6, h: 0.8, color: "#1a56b0", font: SIGN_FONT });
  c.decal({ text: "TAKSI", face: "rear", y: 9.5, len: 4.6, h: 0.8, color: "#1a56b0", font: SIGN_FONT });
  c.decal({ text: "BLUE BIRD", z: 11, y: 3.4, len: 6.5, h: 1.0, color: "#0f3a7a", font: SIGN_FONT });
  return c.done();
}

// ───────── American fire engine — cab-over, chrome everywhere, raisable aerial ladder ─────────
export function firetruck(): CarBuild {
  const c = new CarCtx({ body: 0xc8102e, roof: 0xf3f4f6, rim: 0xdfe3e8 }, { hw: 6, cw: 6 });
  c.profile([
    "...........................RRRRRRRRR",
    "...........................GGGGGGGGG",
    "...........................GGGGGGGGG",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBGGGGGGGGG",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
    "kBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBk",
  ]);
  c.wheels([3, 9, 28], { size: 5 });
  c.side(
    [
      ".SSSS.SSSS.SSSS.SSSS.SSSS..........",
      ".SSSS.SSSS.SSSS.SSSS.SSSS..........",
      ".SSSS.SSSS.SSSS.SSSS.SSSS..........",
      "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
      "...............SSSS.SSSS............",
      "...............SSSS.SSSS............",
    ].map((r) => r.padEnd(36, ".")),
    7
  );
  c.front(
    [
      "......K......",
      "......K......",
      "......K......",
      "SSSSSSSSSSSSS",
      "...SSSSSSS...",
      "HH.SSSSSSS.HH",
      "HH.SSSSSSS.HH",
      "OO.SSSSSSS.OO",
      "SSSSSSSSSSSSS",
      "SSSSSSSSSSSSS",
    ],
    10
  );
  c.rear([".............", ".............", "TT.........TT", "TT.........TT", "OO.........OO", ".............", "SSSSSSSSSSSSS", "KKKKKKKKKKKKK"], 8);
  c.box(-2, 2, 9, 11, 3, 6, P.SILVER); // ladder turntable
  // red light bar on the cab roof
  c.box(-6, -1, 12, 12, 34, 35, P.SIREN_R).box(0, 0, 12, 12, 34, 35, P.LIGHT_W).box(1, 6, 12, 12, 34, 35, P.SIREN_R);
  c.siren = true;
  c.sym(7, 7, 8, 9, 34, 34, P.BLACK); // big mirrors
  // aerial ladder (raises when lights are on)
  const lad = new Vox();
  lad.box(2, 2, 12, 12, 4, 32, P.SILVER).box(-2, -2, 12, 12, 4, 32, P.SILVER);
  for (let z = 5; z <= 31; z += 2) lad.box(-1, 1, 12, 12, z, z, P.SILVER);
  c.part(lad, [0.5, 12, 4.5], "ladder");
  c.decal({ text: "FIRE DEPT", z: 31, y: 5.9, len: 7, h: 1.1, color: "#ffcc33", font: SIGN_FONT });
  return c.done();
}

// ───────── American school bus (Type C) — yellow, black rub rails, stop arm ─────────
export function schoolbus(): CarBuild {
  const c = new CarCtx({ body: 0xffb000, rim: 0xe6e8eb }, { hw: 6, cw: 6 });
  c.profile([
    "bbbbbbbbbbbbbbbbbbbbbbbbbbbbb.......",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBB.......",
    "GGGGGGGGGGGGGGGGGGGGGGGGGGGGG.......",
    "GGGGGGGGGGGGGGGGGGGGGGGGGGGGG.......",
    "GGGGGGGGGGGGGGGGGGGGGGGGGGGGG.......",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBbbbb...",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBbbbbbb.",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBb",
    "kBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBk",
  ]);
  for (const z of [3, 6, 9, 12, 15, 18, 21, 24]) c.sideFill(z, z, 7, 9, P.BLACK); // window frames
  c.wheels([6, 27], { size: 5 });
  c.side(
    [
      "KKKKKKKKKKKKKKKKKKKKKKKKKKKKK.......",
      "....................................",
      "KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK.",
      "....................................",
      "KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK.",
    ],
    6
  );
  c.front(
    [
      ".............",
      ".rO.......Or.",
      "......K......",
      "......K......",
      "......K......",
      ".............",
      ".H.KKKKKKK.H.",
      ".H.KKKKKKK.H.",
      ".............",
      "KKKKKKKKKKKKK",
      "KKKKKKKKKKKKK",
    ],
    11
  );
  c.rear(
    [
      ".............",
      ".rO.......Or.",
      "...K.....K...",
      "...K.....K...",
      "...K.....K...",
      "KKKKKKKKKKKKK",
      "T..K.....K..T",
      "T..K.....K..T",
      ".....LLL.....",
      "KKKKKKKKKKKKK",
      "KKKKKKKKKKKKK",
    ],
    11
  );
  c.siren = true;
  c.box(-2, 2, 12, 12, 7, 9, P.WHITE).box(-2, 2, 12, 12, 19, 21, P.WHITE); // roof hatches
  c.sym(6, 6, 6, 6, 31, 31, P.BLACK).sym(7, 7, 7, 8, 31, 31, P.BLACK); // mirrors on stalks
  // STOP arm on the driver (left, +x) side — swings out when lights are on
  const stop = new Vox();
  for (let dy = 0; dy < 3; dy++) for (let dz = 0; dz < 3; dz++) stop.set(7, 5 + dy, 22 + dz, dy === 1 && dz === 1 ? P.WHITE : P.RED);
  stop.set(7, 6, 25, P.BLACK);
  c.part(stop, [7, 5, 26], "swing", -1);
  c.decal({ text: "SCHOOL BUS", face: "front", y: 10.5, len: 7, h: 0.85, color: "#111214", font: SIGN_FONT });
  c.decal({ text: "SCHOOL BUS", face: "rear", y: 10.5, len: 7, h: 0.85, color: "#111214", font: SIGN_FONT });
  c.decal({ text: "SCHOOL DISTRICT", z: 15, y: 5.5, len: 12, h: 0.85, color: "#111214", font: SIGN_FONT });
  return c.done();
}

// ───────── M1 Abrams-style tank — tracks, rotating turret ─────────
export function tank(): CarBuild {
  const OL = 0x5e6e34;
  const DO = 0x48552a;
  const c = new CarCtx({ body: OL }, { hw: 7, cw: 5 });
  c.box(-4, 4, 1, 3, 1, 28, OL); // lower hull
  c.box(-7, 7, 4, 4, 0, 29, OL); // fenders over the tracks
  c.box(-6, 6, 5, 5, 1, 25, OL); // deck
  for (const z of [2, 4, 6]) c.box(-4, 4, 5, 5, z, z, DO); // engine grilles
  c.tracks(1, 28, 5, 7);
  c.sym(6, 6, 4, 4, 29, 29, P.HEAD); // headlights
  c.sym(6, 6, 4, 4, 0, 0, P.TAIL);
  c.box(-3, 3, 2, 3, 1, 1, P.DARK); // rear grille
  const t = new Vox();
  t.box(-5, 5, 6, 8, 9, 20, OL); // turret
  t.box(-4, 4, 6, 8, 21, 22, OL); // angled front
  t.box(-4, 4, 6, 8, 6, 8, OL); // bustle
  t.box(2, 3, 9, 9, 12, 14, DO); // commander cupola
  t.box(3, 3, 10, 10, 13, 17, P.BLACK); // machine gun
  t.box(-3, -2, 9, 9, 12, 13, DO); // loader hatch
  t.box(-1, 1, 6, 8, 23, 23, DO); // mantlet
  t.box(0, 0, 7, 7, 24, 36, 0x56653a); // main gun
  t.box(-1, 1, 6, 8, 29, 30, 0x3f4a26); // fume extractor
  for (const s of [5, -5]) {
    t.box(s, s, 7, 7, 14, 16, P.WHITE); // white star (cute plus)
    t.box(s, s, 6, 8, 15, 15, P.WHITE);
  }
  t.box(-4, -4, 9, 12, 7, 7, P.BLACK).box(4, 4, 9, 11, 7, 7, P.BLACK); // antennas
  c.part(t, [0.5, 6, 15], "turret");
  return c.done();
}

// ───────── Subaru Impreza WRC "555" — raised rally stance, gold wheels, light pod, mud flaps ─────────
export function rally(): CarBuild {
  const c = new CarCtx({ body: 0x1d3fa8, A: 0xffd100, wing: 0x1d3fa8, rim: 0xd4af37 });
  c.profile([
    "WWW...RRRRRRR.........",
    ".w...GGGGGGGGG........",
    ".w..GGGGGGGGGGG.......",
    ".w..GGGGGGGGGGGG......",
    "BBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBBBBBBBb",
    "......................",
  ]);
  c.sideFill(10, 10, 6, 8, P.BLACK);
  c.wheels([3, 15]);
  c.side(["AAAAAAAAAAAAAAAAAAAAAA", "..A.A.................", "...A.................."], 5);
  c.front(["......h....", ".......h...", "...........", "...........", "BHHHKSKHHHB", "A.........A", "KKKKKKKKKKK"], 8);
  c.rear(["...........", "TTT.....TTT", "....LLL....", "KKKKKKKKKKK"], 5);
  c.box(-4, 4, 3, 3, 22, 22, P.BLACK); // rally light pod
  for (const x of [-3, -1, 1, 3]) c.box(x, x, 3, 3, 22, 22, P.XENON);
  c.box(-1, 1, 6, 6, 17, 18, c.l.body); // hood scoop
  c.box(-1, 1, 10, 10, 9, 10, c.l.body); // roof vent
  for (const zc of [3, 15]) c.sym(5, 6, 0, 1, zc - 1, zc - 1, P.RED); // mud flaps
  c.box(-3, -3, 2, 2, -1, -1, P.CHROME);
  c.endplates(0, 2, 8, 8);
  c.mirrors(14, 6);
  c.decal({ text: "555", z: 10, y: 3.6, len: 4, h: 1.5, color: "#ffd100", font: SIGN_FONT });
  return c.done();
}

// ───────── Mr. Bean's Mini 1000 — citron green, black bonnet, padlock, tiny wheels ─────────
function mini(chair: boolean): CarBuild {
  const c = new CarCtx({ body: 0x9cb53a, rim: 0xc9ced4 }, { hw: 4, cw: 3 });
  c.profile([
    ".RRRRRRRRR......",
    "GGGGGGGGGGG.....",
    "GGGGGGGGGGGG....",
    "BBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBb",
  ]);
  c.wheels([1, 12], { size: 3 });
  c.top(Array.from({ length: 9 }, () => "............KKKK")); // matte black bonnet
  c.front([".....h...", "......h..", ".........", "HH.SSS.HH", "O.SSSSS.O", "SSSSSSSSS"], 6);
  c.rear(["T.......T", "T.......T", "...LLL...", "SSSSSSSSS"], 4);
  c.box(-5, -5, 3, 3, 9, 9, P.SILVER).box(-5, -5, 4, 4, 9, 9, P.DARK); // the famous padlock
  c.box(-2, -2, 1, 1, -1, -1, P.CHROME);
  c.mirrors(10, 5, P.CHROME);
  if (chair) {
    const CH = 0x7b4a2a;
    c.box(-2, 2, 8, 8, 3, 6, CH); // armchair on the roof (DIY episode!)
    c.box(-2, 2, 9, 9, 3, 6, 0x9a6036);
    c.box(-2, 2, 9, 11, 2, 2, CH);
    c.sym(3, 3, 8, 10, 2, 6, CH);
    c.box(0, 0, 10, 11, 4, 4, 0x8b5a2b).box(-1, -1, 12, 12, 4, 4, 0x8b5a2b).box(1, 1, 12, 12, 4, 4, 0x8b5a2b); // Teddy
  }
  return c.done();
}
export const mrbean = () => mini(false);
export const mrbeanChair = () => mini(true);
