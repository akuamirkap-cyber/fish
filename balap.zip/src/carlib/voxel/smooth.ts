import type { Hex, Vox } from './Vox';
import type { RawMesh } from './mesher';

/**
 * Mesh mulus ala hypercasual dari data voxel (Surface Nets):
 * voxel di-upsample (S× per sumbu) → medan kepadatan di-blur → permukaan iso diekstrak.
 * Hasilnya bodi membulat tanpa blok kotak, tapi siluet & livery asli tetap terjaga.
 * - normal halus dari gradien kepadatan
 * - AO lembut dari medan kepadatan yang lebih lebar (lekukan sedikit lebih gelap)
 * - warna per segitiga diambil dari voxel terdekat → garis livery tetap tegas
 */
export interface SmoothOpts {
  S?: number;       // subdivisi per voxel
  passes?: number;  // jumlah blur [1,2,1] per sumbu (makin besar makin bulat)
  iso?: number;     // ambang permukaan (di bawah 0.5 = sedikit menggembung)
  ao?: number;      // kekuatan AO
}

const s2l = (c: number) => (c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4));

function blurAxis(src: Float32Array, dst: Float32Array, nx: number, ny: number, nz: number, axis: 0 | 1 | 2, a: number, b: number, c: number) {
  const stride = axis === 0 ? 1 : axis === 1 ? nx : nx * ny;
  const len = axis === 0 ? nx : axis === 1 ? ny : nz;
  let idx = 0;
  for (let k = 0; k < nz; k++)
    for (let j = 0; j < ny; j++)
      for (let i = 0; i < nx; i++, idx++) {
        const t = axis === 0 ? i : axis === 1 ? j : k;
        let v = src[idx] * b;
        if (t > 0) v += src[idx - stride] * a;
        if (t < len - 1) v += src[idx + stride] * c;
        dst[idx] = v;
      }
}

function blurField(f: Float32Array, nx: number, ny: number, nz: number, passes: number, a: number, b: number, c: number): Float32Array {
  let cur: Float32Array = f;
  let tmp: Float32Array = new Float32Array(f.length);
  for (let p = 0; p < passes; p++)
    for (const axis of [0, 1, 2] as const) {
      blurAxis(cur, tmp, nx, ny, nz, axis, a, b, c);
      const t = cur; cur = tmp; tmp = t;
    }
  return cur;
}

const EMPTY: RawMesh = { positions: new Float32Array(0), normals: new Float32Array(0), colors: new Float32Array(0), groups: [] };

export function meshSmooth(
  vox: Vox,
  scale: number,
  off: [number, number, number],
  kindOf: (c: Hex) => number,
  kinds = 5,
  opt: SmoothOpts = {}
): RawMesh {
  if (!vox.size) return EMPTY;
  const S = opt.S ?? 3, passes = opt.passes ?? 3, iso = opt.iso ?? 0.44, aoK = opt.ao ?? 1.5;
  const { min, max } = vox.bounds();
  const pad = 2;
  const vx0 = min[0] - pad, vy0 = min[1] - pad, vz0 = min[2] - pad;
  const vnx = max[0] - min[0] + 1 + 2 * pad, vny = max[1] - min[1] + 1 + 2 * pad, vnz = max[2] - min[2] + 1 + 2 * pad;
  const nx = vnx * S, ny = vny * S, nz = vnz * S;

  let D: Float32Array = new Float32Array(nx * ny * nz);
  const colorGrid = new Int32Array(vnx * vny * vnz).fill(-1);
  vox.forEach((x, y, z, c) => {
    const ax = x - vx0, ay = y - vy0, az = z - vz0;
    colorGrid[ax + vnx * (ay + vny * az)] = c;
    for (let k = 0; k < S; k++)
      for (let j = 0; j < S; j++) {
        const row = ax * S + nx * ((ay * S + j) + ny * (az * S + k));
        for (let i = 0; i < S; i++) D[row + i] = 1;
      }
  });
  D = blurField(D, nx, ny, nz, passes, 0.25, 0.5, 0.25);
  const A = blurField(D.slice(), nx, ny, nz, 8, 1 / 3, 1 / 3, 1 / 3); // medan lebar untuk AO

  // ---- Surface Nets ----
  const cx = nx - 1, cy = ny - 1, cz = nz - 1;
  const cellIdx = new Int32Array(cx * cy * cz).fill(-1);
  const vp: number[] = [], vn: number[] = [], vao: number[] = [];
  const cOff = [0, 1, nx, 1 + nx, nx * ny, 1 + nx * ny, nx + nx * ny, 1 + nx + nx * ny];
  const cv = new Float32Array(8);
  const pairs: [number, number][] = [];
  for (let c = 0; c < 8; c++) for (const a of [1, 2, 4]) if (!(c & a)) pairs.push([c, c | a]);

  for (let k = 0; k < cz; k++)
    for (let j = 0; j < cy; j++)
      for (let i = 0; i < cx; i++) {
        const base = i + nx * (j + ny * k);
        let mask = 0;
        for (let c = 0; c < 8; c++) { const v = D[base + cOff[c]]; cv[c] = v; if (v > iso) mask |= 1 << c; }
        if (mask === 0 || mask === 255) continue;
        let sx = 0, sy = 0, sz = 0, n = 0;
        for (const [c0, c1] of pairs) {
          const va = cv[c0], vb = cv[c1];
          if (va > iso !== vb > iso) {
            const t = (iso - va) / (vb - va);
            sx += (c0 & 1) + (((c1 & 1) - (c0 & 1)) * t);
            sy += ((c0 >> 1) & 1) + ((((c1 >> 1) & 1) - ((c0 >> 1) & 1)) * t);
            sz += ((c0 >> 2) & 1) + ((((c1 >> 2) & 1) - ((c0 >> 2) & 1)) * t);
            n++;
          }
        }
        const px = vx0 + (i + sx / n + 0.5) / S, py = vy0 + (j + sy / n + 0.5) / S, pz = vz0 + (k + sz / n + 0.5) / S;
        let gx = 0, gy = 0, gz = 0, av = 0;
        for (let c = 0; c < 8; c++) {
          gx += (c & 1 ? 1 : -1) * cv[c]; gy += (c & 2 ? 1 : -1) * cv[c]; gz += (c & 4 ? 1 : -1) * cv[c];
          av += A[base + cOff[c]];
        }
        let nxn = -gx, nyn = -gy, nzn = -gz;
        const l = Math.hypot(nxn, nyn, nzn);
        if (l > 1e-6) { nxn /= l; nyn /= l; nzn /= l; } else { nxn = 0; nyn = 1; nzn = 0; }
        vp.push(px, py, pz); vn.push(nxn, nyn, nzn);
        vao.push(Math.min(1, Math.max(0.5, 1 - aoK * Math.max(0, av / 8 - 0.5))));
        cellIdx[i + cx * (j + cy * k)] = vp.length / 3 - 1;
      }

  const tris: number[] = [];
  const cell = (i: number, j: number, k: number) => cellIdx[i + cx * (j + cy * k)];
  const quad = (v0: number, v1: number, v2: number, v3: number, flip: boolean) => {
    if (v0 < 0 || v1 < 0 || v2 < 0 || v3 < 0) return;
    if (flip) { const t = v1; v1 = v3; v3 = t; }
    const d02 = Math.hypot(vp[v0 * 3] - vp[v2 * 3], vp[v0 * 3 + 1] - vp[v2 * 3 + 1], vp[v0 * 3 + 2] - vp[v2 * 3 + 2]);
    const d13 = Math.hypot(vp[v1 * 3] - vp[v3 * 3], vp[v1 * 3 + 1] - vp[v3 * 3 + 1], vp[v1 * 3 + 2] - vp[v3 * 3 + 2]);
    if (d02 <= d13) tris.push(v0, v1, v2, v0, v2, v3); else tris.push(v1, v2, v3, v1, v3, v0);
  };
  for (let k = 0; k < nz; k++)
    for (let j = 0; j < ny; j++)
      for (let i = 0; i < nx; i++) {
        const idx = i + nx * (j + ny * k);
        const a = D[idx] > iso;
        if (i < nx - 1 && j > 0 && k > 0 && j < ny - 1 && k < nz - 1 && a !== D[idx + 1] > iso)
          quad(cell(i, j - 1, k - 1), cell(i, j, k - 1), cell(i, j, k), cell(i, j - 1, k), !a);
        if (j < ny - 1 && i > 0 && k > 0 && i < nx - 1 && k < nz - 1 && a !== D[idx + nx] > iso)
          quad(cell(i - 1, j, k - 1), cell(i - 1, j, k), cell(i, j, k), cell(i, j, k - 1), !a);
        if (k < nz - 1 && i > 0 && j > 0 && i < nx - 1 && j < ny - 1 && a !== D[idx + nx * ny] > iso)
          quad(cell(i - 1, j - 1, k), cell(i, j - 1, k), cell(i, j, k), cell(i - 1, j, k), !a);
      }

  // ---- warna & material per segitiga (voxel terdekat dari titik pusat segitiga) ----
  const buckets = Array.from({ length: kinds }, () => ({ p: [] as number[], n: [] as number[], c: [] as number[] }));
  const colAt = (x: number, y: number, z: number): Hex => {
    const fx = Math.floor(x), fy = Math.floor(y), fz = Math.floor(z);
    let best = -1, bd = Infinity;
    for (let dz = -1; dz <= 1; dz++)
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          const ax = fx + dx - vx0, ay = fy + dy - vy0, az = fz + dz - vz0;
          if (ax < 0 || ay < 0 || az < 0 || ax >= vnx || ay >= vny || az >= vnz) continue;
          const c = colorGrid[ax + vnx * (ay + vny * az)];
          if (c < 0) continue;
          const ex = fx + dx + 0.5 - x, ey = fy + dy + 0.5 - y, ez = fz + dz + 0.5 - z;
          const d = ex * ex + ey * ey + ez * ez;
          if (d < bd) { bd = d; best = c; }
        }
    return best < 0 ? 0x888888 : best;
  };
  for (let t = 0; t < tris.length; t += 3) {
    const a = tris[t], b = tris[t + 1], c = tris[t + 2];
    const mx = (vp[a * 3] + vp[b * 3] + vp[c * 3]) / 3, my = (vp[a * 3 + 1] + vp[b * 3 + 1] + vp[c * 3 + 1]) / 3, mz = (vp[a * 3 + 2] + vp[b * 3 + 2] + vp[c * 3 + 2]) / 3;
    const hex = colAt(mx, my, mz);
    const bk = buckets[kindOf(hex)];
    const r = s2l(((hex >> 16) & 255) / 255), g = s2l(((hex >> 8) & 255) / 255), bl = s2l((hex & 255) / 255);
    const lit = kindOf(hex) === 0 || kindOf(hex) === 4;
    for (const v of [a, b, c]) {
      bk.p.push((vp[v * 3] - off[0]) * scale, (vp[v * 3 + 1] - off[1]) * scale, (vp[v * 3 + 2] - off[2]) * scale);
      bk.n.push(vn[v * 3], vn[v * 3 + 1], vn[v * 3 + 2]);
      const k = lit ? vao[v] : 1;
      bk.c.push(r * k, g * k, bl * k);
    }
  }
  const total = buckets.reduce((s, bk) => s + bk.p.length, 0);
  const positions = new Float32Array(total), normals = new Float32Array(total), colors = new Float32Array(total);
  const groups: RawMesh['groups'] = [];
  let o = 0;
  buckets.forEach((bk, kind) => {
    if (!bk.p.length) return;
    positions.set(bk.p, o); normals.set(bk.n, o); colors.set(bk.c, o);
    groups.push({ start: o / 3, count: bk.p.length / 3, kind });
    o += bk.p.length;
  });
  return { positions, normals, colors, groups };
}
