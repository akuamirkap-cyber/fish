export type Hex = number;

const OFF = 128;
const key = (x: number, y: number, z: number) => (x + OFF) | ((y + OFF) << 8) | ((z + OFF) << 16);

/** Sparse voxel grid. Voxel (x,y,z) occupies the unit cube [x,x+1]x[y,y+1]x[z,z+1]. y = up, +z = front of the car. */
export class Vox {
  map = new Map<number, Hex>();

  set(x: number, y: number, z: number, c: Hex) {
    this.map.set(key(x, y, z), c);
    return this;
  }
  get(x: number, y: number, z: number) {
    return this.map.get(key(x, y, z));
  }
  has(x: number, y: number, z: number) {
    return this.map.has(key(x, y, z));
  }
  del(x: number, y: number, z: number) {
    this.map.delete(key(x, y, z));
    return this;
  }
  get size() {
    return this.map.size;
  }

  /** Fill an inclusive box. */
  box(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, c: Hex) {
    const [ax, bx] = x0 <= x1 ? [x0, x1] : [x1, x0];
    const [ay, by] = y0 <= y1 ? [y0, y1] : [y1, y0];
    const [az, bz] = z0 <= z1 ? [z0, z1] : [z1, z0];
    for (let x = ax; x <= bx; x++) for (let y = ay; y <= by; y++) for (let z = az; z <= bz; z++) this.set(x, y, z, c);
    return this;
  }
  /** Box + its mirror across x=0 (x0..x1 should be >= 0). */
  sym(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, c: Hex) {
    this.box(x0, x1, y0, y1, z0, z1, c);
    this.box(-x0, -x1, y0, y1, z0, z1, c);
    return this;
  }
  clear(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number) {
    const [ax, bx] = x0 <= x1 ? [x0, x1] : [x1, x0];
    const [ay, by] = y0 <= y1 ? [y0, y1] : [y1, y0];
    const [az, bz] = z0 <= z1 ? [z0, z1] : [z1, z0];
    for (let x = ax; x <= bx; x++) for (let y = ay; y <= by; y++) for (let z = az; z <= bz; z++) this.del(x, y, z);
    return this;
  }
  clearSym(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number) {
    this.clear(x0, x1, y0, y1, z0, z1);
    this.clear(-x0, -x1, y0, y1, z0, z1);
    return this;
  }
  /** Recolor only existing voxels inside a box. */
  paint(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, c: Hex, only?: Hex[]) {
    const [ax, bx] = x0 <= x1 ? [x0, x1] : [x1, x0];
    const [ay, by] = y0 <= y1 ? [y0, y1] : [y1, y0];
    const [az, bz] = z0 <= z1 ? [z0, z1] : [z1, z0];
    for (let x = ax; x <= bx; x++)
      for (let y = ay; y <= by; y++)
        for (let z = az; z <= bz; z++) {
          const cur = this.get(x, y, z);
          if (cur === undefined) continue;
          if (only && !only.includes(cur)) continue;
          this.set(x, y, z, c);
        }
    return this;
  }
  paintSym(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, c: Hex, only?: Hex[]) {
    this.paint(x0, x1, y0, y1, z0, z1, c, only);
    this.paint(-x0, -x1, y0, y1, z0, z1, c, only);
    return this;
  }

  forEach(cb: (x: number, y: number, z: number, c: Hex) => void) {
    for (const [k, c] of this.map) cb((k & 255) - OFF, ((k >> 8) & 255) - OFF, ((k >> 16) & 255) - OFF, c);
  }

  bounds() {
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    this.forEach((x, y, z) => {
      if (x < min[0]) min[0] = x;
      if (y < min[1]) min[1] = y;
      if (z < min[2]) min[2] = z;
      if (x > max[0]) max[0] = x;
      if (y > max[1]) max[1] = y;
      if (z > max[2]) max[2] = z;
    });
    if (!isFinite(min[0])) return { min: [0, 0, 0], max: [0, 0, 0] };
    return { min, max };
  }

  clone() {
    const v = new Vox();
    for (const [k, c] of this.map) v.map.set(k, c);
    return v;
  }
  merge(o: Vox, dx = 0, dy = 0, dz = 0) {
    o.forEach((x, y, z, c) => this.set(x + dx, y + dy, z + dz, c));
    return this;
  }

  // ---- outermost surface queries (search window +-40) ----
  maxX(y: number, z: number): number | null {
    for (let x = 40; x >= -40; x--) if (this.has(x, y, z)) return x;
    return null;
  }
  minX(y: number, z: number): number | null {
    for (let x = -40; x <= 40; x++) if (this.has(x, y, z)) return x;
    return null;
  }
  maxZ(x: number, y: number): number | null {
    for (let z = 60; z >= -40; z--) if (this.has(x, y, z)) return z;
    return null;
  }
  minZ(x: number, y: number): number | null {
    for (let z = -40; z <= 60; z++) if (this.has(x, y, z)) return z;
    return null;
  }
  maxY(x: number, z: number): number | null {
    for (let y = 40; y >= -10; y--) if (this.has(x, y, z)) return y;
    return null;
  }
}
