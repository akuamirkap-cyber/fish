// ============================================================================
//  SLING DRIFT 3D — 20 LINTASAN TERBAIK + HOT WHEELS RARE EDITION
//  Tepat 20 level pilihan terbaik: setiap track punya tema visual, boost pad
//  di jalan, jalur split 2-arah (Lurus = Ngenos / Belok = Ngedrift), lompatan
//  stunt, dan spiral keong khas Hot Wheels.
// ============================================================================
import type { Step } from './game';

export type ThemeName =
  | 'violet' | 'candy' | 'sunset' | 'night' | 'desert'
  | 'forest' | 'snow' | 'volcano' | 'ocean'
  | 'hotwheels' | 'skyhw' | 'cyberhw' | 'magmahw';

export type TrackFeature = 'boost' | 'split' | 'jump' | 'spiral' | 'wave';
export type Rarity = 'rare' | 'epic' | 'legendary';

export type Theme = {
  label: string;
  fog: number;
  sky: [string, string, string];
  road: number; roadSide: number; roadBottom: number; line: number;
  dust: [number, number, number];
  bld: [number, number, number, number];
  bldCap: number; bldBeacon: number;
  cloud: number; cloudEm: number; street: number;
};

export const THEMES: Record<ThemeName, Theme> = {
  violet: {
    label: 'Senja Violet',
    fog: 0xc9b8ff, sky: ['#6c5ce7', '#b69cff', '#efe6ff'],
    road: 0x3b3b4e, roadSide: 0x9aa0c8, roadBottom: 0x5c6082, line: 0xf8f8ff,
    dust: [0x9aa0b8, 0xffffff, 0xff6b81],
    bld: [0x8f93c9, 0x7d84c2, 0xa5a8d8, 0x6f76b8], bldCap: 0xe8e6f5, bldBeacon: 0xff4455,
    cloud: 0xffffff, cloudEm: 0x333344, street: 0x35314a,
  },
  candy: {
    label: 'Permen Langit',
    fog: 0xcfe8ff, sky: ['#4dc3ff', '#bde4ff', '#ffd6ee'],
    road: 0xfdf8ff, roadSide: 0xc4b3f2, roadBottom: 0x9d8ae0, line: 0xff9ec8,
    dust: [0xd9ccff, 0xffffff, 0xff8fb0],
    bld: [0xffc2e0, 0xb3e5ff, 0xd6c2ff, 0xffe6a8], bldCap: 0xffffff, bldBeacon: 0xff6fa5,
    cloud: 0xffffff, cloudEm: 0x3a3a55, street: 0x4a3f5e,
  },
  sunset: {
    label: 'Sunset Tropis',
    fog: 0xffb27d, sky: ['#ff516b', '#ff9466', '#ffe0a8'],
    road: 0x463644, roadSide: 0xe68a5c, roadBottom: 0x8a5440, line: 0xffe8c9,
    dust: [0xffc27a, 0xffffff, 0xff5f6d],
    bld: [0x6b4a5e, 0x7d5468, 0x5a3f52, 0x8a5a6e], bldCap: 0xffd9a0, bldBeacon: 0xffe066,
    cloud: 0xffe0c8, cloudEm: 0x442200, street: 0x3f2f35,
  },
  night: {
    label: 'Kota Neon',
    fog: 0x1d1448, sky: ['#08041a', '#1e1348', '#39256e'],
    road: 0x202032, roadSide: 0x404068, roadBottom: 0x262640, line: 0x00e5ff,
    dust: [0xff71ce, 0x00e5ff, 0xfffb96],
    bld: [0x2b264e, 0x36315e, 0x211e40, 0x433d70], bldCap: 0x00e5ff, bldBeacon: 0xff5cc8,
    cloud: 0x302a56, cloudEm: 0x120a2e, street: 0x0d0a22,
  },
  desert: {
    label: 'Canyon Gurun',
    fog: 0xf7d49e, sky: ['#f58a4b', '#f8c36c', '#fef0cc'],
    road: 0x826544, roadSide: 0xe2bc76, roadBottom: 0xa47d50, line: 0xfff6d8,
    dust: [0xe8cf9a, 0xffffff, 0xd88a3a],
    bld: [0xc98b4e, 0xb87a6a, 0xa88c5c, 0xd9b470], bldCap: 0xfff0c8, bldBeacon: 0xff5a2a,
    cloud: 0xffffff, cloudEm: 0x443a22, street: 0x8a6a3f,
  },
  forest: {
    label: 'Hutan Zamrud',
    fog: 0xa8deb2, sky: ['#1f7a54', '#6ec994', '#daf7d4'],
    road: 0x37473e, roadSide: 0x5c806c, roadBottom: 0x2a3830, line: 0xe6ffe8,
    dust: [0xa8e8c0, 0xffffff, 0x3a8a5c],
    bld: [0x2a5a42, 0x356b4e, 0x234a36, 0x457c5a], bldCap: 0xa8f0c2, bldBeacon: 0xffc93c,
    cloud: 0xf2fff2, cloudEm: 0x1e3a2a, street: 0x24382c,
  },
  snow: {
    label: 'Puncak Salju',
    fog: 0xe4f1ff, sky: ['#6c9ed6', '#bddaff', '#ffffff'],
    road: 0x525d72, roadSide: 0xeaf0ff, roadBottom: 0x8390ab, line: 0xffffff,
    dust: [0xe8eefc, 0xffffff, 0x7ea8d8],
    bld: [0x8295b8, 0xa4b7d6, 0x6c7fa4, 0xc2d0e4], bldCap: 0xffffff, bldBeacon: 0xff5c5c,
    cloud: 0xffffff, cloudEm: 0x334455, street: 0x6a7086,
  },
  volcano: {
    label: 'Kaldera Lava',
    fog: 0x5a221c, sky: ['#260a0a', '#78281c', '#d44828'],
    road: 0x2c2024, roadSide: 0x663a30, roadBottom: 0x402d28, line: 0xffb338,
    dust: [0xff7a1a, 0xffc93c, 0xff4455],
    bld: [0x3a2826, 0x4c302a, 0x2e201e, 0x5c3c32], bldCap: 0xff6a2a, bldBeacon: 0xffc93c,
    cloud: 0x5a3028, cloudEm: 0x1a0a06, street: 0x241412,
  },
  ocean: {
    label: 'Laguna Tropis',
    fog: 0x99ebe4, sky: ['#0a93b8', '#42d4dc', '#d8fffa'],
    road: 0x2b4854, roadSide: 0x5aa0ac, roadBottom: 0x243942, line: 0xe0fffa,
    dust: [0x9fe8e0, 0xffffff, 0x0e9bb5],
    bld: [0xe8f6f6, 0x9fd0d8, 0x6ab0c0, 0xffe8b0], bldCap: 0xffffff, bldBeacon: 0xff6a5c,
    cloud: 0xffffff, cloudEm: 0x0e3a44, street: 0x1e4a54,
  },
  // ---- EDISI LANGKA HOT WHEELS (default aspal karbon gelap elegan; aspal oranye tersedia sebagai opsi!) ----
  hotwheels: {
    label: 'Hot Wheels Arena',
    fog: 0x82c7f5, sky: ['#0d52b5', '#34a0f5', '#d9f3ff'],
    road: 0x333748, roadSide: 0xff8a24, roadBottom: 0x1e2233, line: 0xfff5d6,
    dust: [0xffc93c, 0xffffff, 0xff6a14],
    bld: [0xff8a24, 0xffd23f, 0x1e88e5, 0xffffff], bldCap: 0xffffff, bldBeacon: 0xff3b4e,
    cloud: 0xffffff, cloudEm: 0x255a88, street: 0x0d47a1,
  },
  skyhw: {
    label: 'HW Sky Loop',
    fog: 0x9ce2ff, sky: ['#0077cc', '#38d3ff', '#f0fbff'],
    road: 0x2e394e, roadSide: 0x00e5ff, roadBottom: 0x19253b, line: 0xffffff,
    dust: [0x00e5ff, 0xffffff, 0xff9f1c],
    bld: [0x00b4d8, 0xff9f1c, 0x90e0ef, 0xffffff], bldCap: 0x00e5ff, bldBeacon: 0xffc93c,
    cloud: 0xffffff, cloudEm: 0x1a5f82, street: 0x023e8a,
  },
  cyberhw: {
    label: 'HW Cyber Loop',
    fog: 0x220c4a, sky: ['#09021c', '#2b0d5e', '#62148a'],
    road: 0x23203b, roadSide: 0x00f5ff, roadBottom: 0x3a1460, line: 0xfff200,
    dust: [0x00f5ff, 0xff2a85, 0xffd23f],
    bld: [0x2d1259, 0x45187a, 0x1e0d42, 0x621b91], bldCap: 0x00f5ff, bldBeacon: 0xff2a85,
    cloud: 0x3b186e, cloudEm: 0x14062b, street: 0x0f0426,
  },
  magmahw: {
    label: 'HW Inferno',
    fog: 0x661a0e, sky: ['#1f0404', '#8f220e', '#ff6b1a'],
    road: 0x2d2228, roadSide: 0xff9f1c, roadBottom: 0x521810, line: 0xffe69c,
    dust: [0xffd23f, 0xff5500, 0xffffff],
    bld: [0x4a1912, 0x6e2314, 0x33100c, 0x8a3016], bldCap: 0xffd23f, bldBeacon: 0xff3322,
    cloud: 0x6b2416, cloudEm: 0x260804, street: 0x240906,
  },
};

// ---------------------------------------------------------------------------
//  Helper penyusun seksi (Step) — lintasan tangan yang unik & seru!
// ---------------------------------------------------------------------------
const PI = Math.PI;
const S = (len: number): Step => ({ k: 's', len });
const B = (len = 16): Step => ({ k: 'b', len }); // Boost Pad Turbo Runway!
const F = (R = 8.2, side?: 1 | -1): Step => ({ k: 'f', R, side }); // 2-Jalur Split (Lurus=NOS vs Belok=Drift)!
const W = (len = 22): Step => ({ k: 'w', len }); // Hot Wheels Rollercoaster Wave!
const A = (sweep: number, R: number, dir?: 'flip' | 'same'): Step => ({
  k: 'a', sweep, R, flip: dir === 'flip', same: dir === 'same',
});
const J = (rings = 1): Step => ({ k: 'j', rings }); // 1 Ring = Normal Jump, 5 Ring = Mega Boost Jump (Wajib NOS!)
const P = (): Step => ({ k: 'p' }); // Hot Wheels Spiral Keong!

type Part = Step | Step[];
const seq = (...parts: Part[]): Step[] => parts.flat() as Step[];

const easy = (r = 8): Step[] => [S(9), A(PI / 3, r)];
const classic = (r = 7): Step[] => [S(6), A(PI / 2, r)];
const fast = (r = 12): Step[] => [B(14), A(PI / 2, r)];
const sweeper = (r = 9.5): Step[] => [S(7), A((2 * PI) / 3, r)];
const sCurve = (r = 6.8): Step[] => [S(5), A(PI / 2, r), A(PI / 2, r, 'flip')];
const double = (r = 7.0): Step[] => [S(5), A(PI / 3, r), A(PI / 3, r + 2.4, 'same')];
const esses = (r = 6.5): Step[] => [S(5), A(PI / 2, r), A(PI / 2, r, 'flip'), A(PI / 2, r, 'flip')];
const slalom = (r = 9.0): Step[] => [S(4), A(PI / 3, r), A(PI / 3, r, 'flip'), A(PI / 3, r, 'flip')];
const hook = (r = 6.2): Step[] => [S(5), A(PI / 2, r), S(3), A(PI / 2, r, 'flip')];
const hairpin = (r = 6.1): Step[] => [S(6), A(PI / 2, r), S(4), A(PI / 2, r, 'flip'), S(3), A(PI / 2, r, 'flip')];
const jumpRun = (): Step[] => [S(10), J(1), S(8)];     // 1 Ring Fire (Normal, tanpa wajib boost)
const megaJump = (): Step[] => [S(12), J(5), S(10)];   // 5 Ring Fire (Wajib tekan NOS / Boost!)
const spiral = (): Step[] => [B(18), S(8), P()];
const splitRun = (r = 8.4, side?: 1 | -1): Step[] => [S(10), F(r, side), S(8)];

export type LevelDef = {
  id: number;
  tier: 1 | 2 | 3 | 4;
  name: string;
  theme: ThemeName;
  tag: string;
  desc: string;
  diff: number; // 1..5
  dist: number; // meter
  seed: number;
  hotwheels?: boolean;
  rarity?: Rarity;
  features: TrackFeature[];
  build: () => Step[];
};

export const TIERS: { id: 1 | 2 | 3 | 4; icon: string; name: string; sub: string; accent: string }[] = [
  { id: 1, icon: '⚡', name: 'TURBO START', sub: 'Level 1–5 • Boost Pad & 2-Jalur', accent: '#38bdf8' },
  { id: 2, icon: '🔥', name: 'STUNT ARENA', sub: 'Level 6–10 • Hot Wheels & Lompatan', accent: '#fb923c' },
  { id: 3, icon: '💎', name: 'HYPER PRO', sub: 'Level 11–15 • Spiral & Cyber Track', accent: '#c084fc' },
  { id: 4, icon: '👑', name: 'LEGENDARY GP', sub: 'Level 16–20 • Lintasan Terlangka', accent: '#fbbf24' },
];

export const LEVELS: LevelDef[] = [
  // ===================== TIER 1: TURBO START (1–5) =====================
  {
    id: 1, tier: 1, name: 'Sunset Booster', theme: 'sunset', tag: 'BOOST PAD',
    desc: 'Injak strip turbo menyala di jalan & rasakan lonjakan kecepatan di bawah langit jingga!',
    diff: 1, dist: 700, seed: 4101, features: ['boost', 'wave'],
    build: () => seq(S(34), B(16), easy(8.2), W(22), classic(7.6), B(18), sCurve(7.6), easy(7.5)),
  },
  {
    id: 2, tier: 1, name: 'Twin Fork Laguna', theme: 'ocean', tag: '2-JALUR SPLIT',
    desc: 'Pilih jalurmu di persimpangan: lurus = otomatis NGENOS, belok = NGEDRIFT berhadiah!',
    diff: 1, dist: 820, seed: 4102, features: ['split', 'boost'],
    build: () => seq(S(34), easy(8.0), splitRun(8.4, 1), B(16), sCurve(7.4), splitRun(8.4, -1), easy(7.4)),
  },
  {
    id: 3, tier: 1, name: 'HW: Fire Ring Launch', theme: 'hotwheels', tag: 'HOT WHEELS 🔥',
    desc: 'Lintasan ikonik Hot Wheels! Lompatan 1 Ring normal, 5 Ring Fire wajib NOS & jalur split!',
    diff: 2, dist: 920, seed: 4103, hotwheels: true, rarity: 'rare', features: ['boost', 'jump', 'split'],
    build: () => seq(S(34), jumpRun(), sweeper(9.4), splitRun(8.4), B(16), megaJump(), classic(7.2)),
  },
  {
    id: 4, tier: 1, name: 'Neon Split Highway', theme: 'night', tag: 'NEON DRIFT',
    desc: 'Jalan raya neon tengah malam dengan tikungan S-curve bercahaya & dua jalur turbo.',
    diff: 2, dist: 980, seed: 4104, features: ['split', 'boost'],
    build: () => seq(S(34), B(14), sCurve(7.2), splitRun(8.2, 1), fast(11.6), hook(6.8), splitRun(8.2, -1)),
  },
  {
    id: 5, tier: 1, name: 'Candy Corkscrew', theme: 'candy', tag: 'SPIRAL SKY',
    desc: 'Dunia awan pastel dengan menara spiral keong pertama & ombak rollercoaster manis.',
    diff: 2, dist: 1050, seed: 4105, features: ['spiral', 'wave', 'boost'],
    build: () => seq(S(34), W(22), slalom(9.2), spiral(), B(16), sCurve(7.2), W(20), easy(7.0)),
  },

  // ===================== TIER 2: STUNT ARENA (6–10) =====================
  {
    id: 6, tier: 2, name: 'Canyon 5-Ring Jump', theme: 'desert', tag: '5× RING NOS',
    desc: 'Terbang melintasi jurang gurun menembus 5 Cincin Api — tekan NOS sebelum ramp!',
    diff: 2, dist: 1120, seed: 4206, features: ['jump', 'boost', 'split'],
    build: () => seq(S(34), jumpRun(), splitRun(8.2, -1), megaJump(), sweeper(9.2), B(16), megaJump()),
  },
  {
    id: 7, tier: 2, name: 'HW: Volcano Loop', theme: 'hotwheels', tag: 'LANGKA 🔥',
    desc: 'Edisi langka Hot Wheels! Spiral keong, 5-Ring Fire wajib boost & jalur split.',
    diff: 3, dist: 1200, seed: 4207, hotwheels: true, rarity: 'rare', features: ['spiral', 'jump', 'split', 'boost'],
    build: () => seq(S(34), B(18), spiral(), megaJump(), splitRun(8.2, 1), hairpin(6.4), jumpRun()),
  },
  {
    id: 8, tier: 2, name: 'Glacier Twin Apex', theme: 'snow', tag: 'DOUBLE APEX',
    desc: 'Es pegunungan dengan tikungan double-apex, boost pad kilat & percabangan drift lebar.',
    diff: 3, dist: 1240, seed: 4208, features: ['split', 'boost', 'wave'],
    build: () => seq(S(34), double(6.8), splitRun(8.0, 1), W(24), esses(6.6), B(16), double(6.5)),
  },
  {
    id: 9, tier: 2, name: 'Emerald Split GP', theme: 'forest', tag: 'TRIPLE SPLIT',
    desc: 'Sirkuit hutan cepat dengan 3 zona 2-jalur! Berani ambil lurus NGENOS atau belok DRIFT?',
    diff: 3, dist: 1300, seed: 4209, features: ['split', 'boost'],
    build: () => seq(S(34), splitRun(8.0, 1), esses(6.6), splitRun(8.0, -1), B(18), slalom(8.4), splitRun(8.0, 1)),
  },
  {
    id: 10, tier: 2, name: 'HW: Sky Loop 360', theme: 'skyhw', tag: 'HOT WHEELS ⚡',
    desc: 'Lintasan Hot Wheels melayang di atas awan biru! Ombak rollercoaster, spiral & 5-Ring langit.',
    diff: 3, dist: 1380, seed: 4210, hotwheels: true, rarity: 'epic', features: ['spiral', 'wave', 'jump', 'boost'],
    build: () => seq(S(34), W(24), spiral(), megaJump(), splitRun(8.2, -1), sweeper(9.0), jumpRun()),
  },

  // ===================== TIER 3: HYPER PRO (11–15) =====================
  {
    id: 11, tier: 3, name: 'Midnight Twin-Turbo', theme: 'night', tag: 'HYPER SPEED',
    desc: 'Kecepatan gila di kota neon: rangkaian boost pad, lompatan 5-Ring NOS & split express.',
    diff: 4, dist: 1450, seed: 4311, features: ['boost', 'split', 'jump'],
    build: () => seq(S(34), B(18), hook(6.1), splitRun(8.0, 1), megaJump(), hairpin(6.0), splitRun(8.0, -1)),
  },
  {
    id: 12, tier: 3, name: 'Lava Spine Coaster', theme: 'volcano', tag: 'COASTER JUMP',
    desc: 'Rollercoaster di atas kaldera menyala: ombak lava, 1-Ring & 5-Ring Fire wajib NOS!',
    diff: 4, dist: 1520, seed: 4312, features: ['wave', 'jump', 'boost'],
    build: () => seq(S(34), W(22), jumpRun(), esses(6.2), W(24), megaJump(), hook(6.0), B(16), megaJump()),
  },
  {
    id: 13, tier: 3, name: 'HW: Cyclone Tower', theme: 'hotwheels', tag: 'LANGKA 🔥',
    desc: 'Dua menara spiral Hot Wheels raksasa dihubungkan boost pad & persimpangan split cepat!',
    diff: 4, dist: 1600, seed: 4313, hotwheels: true, rarity: 'epic', features: ['spiral', 'split', 'boost'],
    build: () => seq(S(34), spiral(), splitRun(8.0, 1), esses(6.1), spiral(), B(18), sCurve(6.2), splitRun(8.0, -1)),
  },
  {
    id: 14, tier: 3, name: 'Tropical Hurricane', theme: 'ocean', tag: 'MEGA SWEEPER',
    desc: 'Sapuan 120° di atas lautan biru, ombak cepat, boost pad & jalur cabang tak terduga.',
    diff: 4, dist: 1650, seed: 4314, features: ['split', 'wave', 'boost', 'jump'],
    build: () => seq(S(34), sweeper(9.0), splitRun(8.0, -1), W(22), jumpRun(), esses(6.0), sweeper(8.6), splitRun(8.0, 1)),
  },
  {
    id: 15, tier: 3, name: 'HW: Cyber Hyperloop', theme: 'cyberhw', tag: 'ULTRA LANGKA 💎',
    desc: 'Arena stunt Hot Wheels futuristik! Boost berantai, 5-Ring Fire wajib NOS, split lane & spiral.',
    diff: 4, dist: 1750, seed: 4315, hotwheels: true, rarity: 'epic', features: ['boost', 'split', 'spiral', 'jump'],
    build: () => seq(S(34), B(18), splitRun(8.0, 1), megaJump(), spiral(), B(18), hook(5.9), splitRun(8.0, -1), jumpRun()),
  },

  // ===================== TIER 4: LEGENDARY GP (16–20) =====================
  {
    id: 16, tier: 4, name: 'Dragon Hairpin', theme: 'volcano', tag: 'PRO DRIFT',
    desc: 'Tikungan jepit naga di atas magma, diselingi boost pad kilat, 5-Ring Fire & jalur split.',
    diff: 5, dist: 1800, seed: 4416, features: ['split', 'boost', 'jump'],
    build: () => seq(S(34), hairpin(5.8), B(16), splitRun(7.8, 1), hook(5.8), megaJump(), hairpin(5.7), splitRun(7.8, -1)),
  },
  {
    id: 17, tier: 4, name: 'Starlight Skyway', theme: 'violet', tag: 'SKY COASTER',
    desc: 'Jalan tol langit senja dengan ombak rollercoaster tinggi, spiral awan & 5-Ring bintang.',
    diff: 5, dist: 1880, seed: 4417, features: ['spiral', 'wave', 'jump', 'split'],
    build: () => seq(S(34), W(24), spiral(), splitRun(8.0, 1), megaJump(), double(6.0), spiral(), W(22)),
  },
  {
    id: 18, tier: 4, name: 'HW: Firestorm Split', theme: 'magmahw', tag: 'ULTRA LANGKA 🔥',
    desc: 'Arena api Hot Wheels! 3 zona split penuh tekanan, 5-Ring Fire wajib NOS & boost tanpa rem.',
    diff: 5, dist: 1950, seed: 4418, hotwheels: true, rarity: 'legendary', features: ['split', 'jump', 'boost', 'wave'],
    build: () => seq(S(34), B(18), splitRun(7.8, 1), megaJump(), hairpin(5.8), splitRun(7.8, -1), W(22), megaJump(), splitRun(7.8, 1)),
  },
  {
    id: 19, tier: 4, name: 'HW: Mega Stunt Arena', theme: 'hotwheels', tag: 'MITOS 🌟',
    desc: 'Semua stunt Hot Wheels terliar: double spiral, wave coaster, 5-Ring Fire & 2-Jalur split!',
    diff: 5, dist: 2050, seed: 4419, hotwheels: true, rarity: 'legendary', features: ['spiral', 'jump', 'split', 'wave', 'boost'],
    build: () => seq(S(34), W(22), spiral(), splitRun(7.8, -1), megaJump(), esses(5.9), B(18), spiral(), jumpRun(), splitRun(7.8, 1)),
  },
  {
    id: 20, tier: 4, name: 'HW: ULTIMATE CHAMPION', theme: 'cyberhw', tag: 'LEGENDARY 👑',
    desc: 'Grand Finale pamungkas! 2200m lintasan Hot Wheels: boost pad, 3 split lane, spiral & 5-Ring Fire!',
    diff: 5, dist: 2200, seed: 4420, hotwheels: true, rarity: 'legendary', features: ['boost', 'split', 'spiral', 'jump', 'wave'],
    build: () => seq(
      S(34), B(18), splitRun(8.0, 1), megaJump(), spiral(),
      W(24), hairpin(5.7), splitRun(8.0, -1), B(18),
      megaJump(), sweeper(8.6), spiral(), splitRun(8.0, 1), esses(5.8),
    ),
  },
];

export const LEVEL_COUNT = LEVELS.length; // tepat 20!
export const TOTAL_STARS = LEVEL_COUNT * 3;
export const levelById = (id: number): LevelDef | undefined => LEVELS.find((l) => l.id === id);

// ---------------------------------------------------------------------------
//  Progres pemain (localStorage): bintang, skor terbaik, level terbuka
// ---------------------------------------------------------------------------
export type LevelProgress = {
  stars: Record<number, number>;
  best: Record<number, number>;
  unlocked: number;
};

export const UNLOCK_ALL = true;

const KEY = 'slingdrift3d-levels-v2';
const fresh = (): LevelProgress => ({ stars: {}, best: {}, unlocked: LEVEL_COUNT });

export function loadProgress(): LevelProgress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return fresh();
    const p = JSON.parse(raw) as Partial<LevelProgress>;
    return {
      stars: p?.stars && typeof p.stars === 'object' ? p.stars : {},
      best: p?.best && typeof p.best === 'object' ? p.best : {},
      unlocked: UNLOCK_ALL ? LEVEL_COUNT : Math.min(LEVEL_COUNT, Math.max(1, Number(p?.unlocked) || 1)),
    };
  } catch {
    return fresh();
  }
}

export function resetProgress(): LevelProgress {
  const p = fresh();
  try { localStorage.setItem(KEY, JSON.stringify(p)); } catch { /* abaikan */ }
  return p;
}

export function totalStars(p: LevelProgress): number {
  return Object.values(p.stars).reduce((m, s) => m + (s || 0), 0);
}

export function levelsCleared(p: LevelProgress): number {
  return Object.values(p.stars).filter((s) => (s || 0) > 0).length;
}

export function recordLevelResult(id: number, score: number, falls: number) {
  const p = loadProgress();
  const earned = falls === 0 ? 3 : falls <= 2 ? 2 : 1;
  const prevStars = p.stars[id] ?? 0;
  p.stars[id] = Math.max(prevStars, earned);
  const prevBest = p.best[id] ?? 0;
  const newBest = score > prevBest;
  if (newBest) p.best[id] = score;
  if (id >= p.unlocked && id < LEVEL_COUNT) p.unlocked = id + 1;
  try { localStorage.setItem(KEY, JSON.stringify(p)); } catch { /* abaikan */ }
  return { earned, stars: p.stars[id], newBest, progress: p, totalStars: totalStars(p) };
}
