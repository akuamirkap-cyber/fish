// ============================================================================
//  TRACK PREVIEW — kompilasi deterministik lintasan level untuk minimap SVG.
//  Porting 1:1 dari generator di game.ts (tanpa mesh): seed → polyline + fork.
//  Karena RNG & urutannya identik, bentuk preview = persis lintasan in-game.
// ============================================================================
import { buildCum, sample } from './game';
import type { Step } from './game';
import type { LevelDef } from './levels';

const TAU = Math.PI * 2;
const FLOOR_H = 7.6;
const CLEAR_Y = 3.6;

const wrap = (a: number) => {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
};

type PSeg = {
  type: 's' | 'a' | 'r';
  jmp?: number; launch?: number; spiral?: boolean; boost?: boolean; wave?: boolean;
  forkAlt?: PSeg[];
  dR?: number;
  cum?: Float32Array;
  y0: number; y1: number; len: number; d0: number;
  sx: number; sz: number; h: number;
  cx: number; cz: number; R: number; a0: number; s: number; sweep: number;
};

export type TrackPreview = {
  pts: { x: number; y: number; z: number }[];
  /** jalur belok drift (2-jalur split) untuk digambar sebagai garis bercabang di minimap */
  forkPaths: { x: number; z: number }[][];
  /** segmen boost pad lurus */
  boostPaths: { x: number; z: number }[][];
  length: number;
};

export function compileTrack(def: LevelDef): TrackPreview {
  let rngState = def.seed >>> 0 || 1;
  const leg = () => {
    let t = (rngState += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const randG = (a: number, b: number) => a + leg() * (b - a);

  const gen = { x: 0, z: 0, h: 0, y: 0, d: 0 };
  let lastArcS = 0, lastSpiralN = -99, lastJumpN = -99;
  const segs: PSeg[] = [];
  const ptsAll: { x: number; y: number; z: number; d: number }[] = [];
  const forkPaths: { x: number; z: number }[][] = [];
  const boostPaths: { x: number; z: number }[][] = [];

  let dry = false;
  let dryList: PSeg[] = [];

  const segPts = (sg: PSeg) => {
    const out: { x: number; z: number; y: number; d: number }[] = [];
    const n = Math.max(2, Math.ceil(sg.len / 2.5));
    for (let i = 0; i <= n; i++) {
      const t = i / n, q = sample(sg as Parameters<typeof sample>[0], t);
      out.push({ x: q.x, z: q.z, y: q.y, d: sg.d0 + sg.len * t });
    }
    if (sg.forkAlt) {
      for (let ai = 0; ai < sg.forkAlt.length; ai++) {
        const asg = sg.forkAlt[ai];
        const an = Math.max(2, Math.ceil(asg.len / 2.5));
        const f0 = ai === 0 ? 0 : ai === 1 ? 0.25 : 0.75;
        const fw = ai === 1 ? 0.5 : 0.25;
        for (let i = 0; i <= an; i++) {
          const t = i / an, q = sample(asg as Parameters<typeof sample>[0], t);
          out.push({ x: q.x, z: q.z, y: q.y, d: sg.d0 + (f0 + t * fw) * sg.len });
        }
      }
    }
    return out;
  };

  const overlaps = (list: PSeg[]) => {
    for (const sg of list) {
      for (const p of segPts(sg)) {
        for (const q of ptsAll) {
          if (p.d - q.d < 14) continue;
          const dx = p.x - q.x, dz = p.z - q.z;
          if (dx * dx + dz * dz < 5.8 * 5.8 && Math.abs(p.y - q.y) < CLEAR_Y) return true;
        }
      }
    }
    return false;
  };

  const addSeg = (seg: PSeg) => {
    if (dry) { dryList.push(seg); return; }
    const n = Math.max(2, Math.ceil(seg.len / 2.5));
    const mainPts: { x: number; y: number; z: number; d: number }[] = [];
    for (let i = 0; i <= n; i++) {
      const t = i / n, q = sample(seg as Parameters<typeof sample>[0], t);
      mainPts.push({ x: q.x, z: q.z, y: q.y, d: seg.d0 + seg.len * t });
    }
    ptsAll.push(...mainPts);
    if (seg.boost) {
      boostPaths.push(mainPts.map(({ x, z }) => ({ x, z })));
    }
    if (seg.forkAlt) {
      const fp: { x: number; z: number }[] = [];
      for (const asg of seg.forkAlt) {
        const an = Math.max(3, Math.ceil(asg.len / 2.0));
        for (let i = 0; i <= an; i++) {
          const q = sample(asg as Parameters<typeof sample>[0], i / an);
          fp.push({ x: q.x, z: q.z });
        }
      }
      forkPaths.push(fp);
    }
    segs.push(seg);
  };

  const genChecked = (fn: () => void, force = false): boolean => {
    const g0 = { ...gen }, lj = lastJumpN, ls = lastSpiralN, la = lastArcS;
    dry = true; dryList = [];
    fn();
    dry = false;
    const list = dryList;
    if (!force && overlaps(list)) {
      gen.x = g0.x; gen.z = g0.z; gen.h = g0.h; gen.y = g0.y; gen.d = g0.d;
      lastJumpN = lj; lastSpiralN = ls; lastArcS = la;
      return false;
    }
    for (const sg of list) addSeg(sg);
    return true;
  };

  const genStraight = (len: number, boost = false, wave = false) => {
    const y1 = gen.y - len * 0.03;
    addSeg({ type: 's', boost, wave, y0: gen.y, y1, len, d0: gen.d, sx: gen.x, sz: gen.z, h: gen.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0 });
    gen.x += Math.sin(gen.h) * len; gen.z += Math.cos(gen.h) * len; gen.y = y1; gen.d += len;
  };

  const genFork = (R = 8.2, prefSide?: 1 | -1) => {
    const theta = Math.PI / 3;
    const straightLen = 4 * R * Math.sin(theta);
    const y1 = gen.y - straightLen * 0.03;
    const side: 1 | -1 = prefSide ?? (leg() < 0.5 ? 1 : -1);
    const alt: PSeg[] = [];
    let cx0 = gen.x, cz0 = gen.z, ch = gen.h, cy = gen.y, cd = gen.d;
    const dy = y1 - gen.y;
    const spec: [1 | -1, number, number][] = [
      [side, theta, 0.25],
      [(side === 1 ? -1 : 1) as 1 | -1, theta * 2, 0.5],
      [side, theta, 0.25],
    ];
    for (const [sd, sw, yf] of spec) {
      const fx = Math.sin(ch), fz = Math.cos(ch);
      const nx = sd * -fz, nz = sd * fx;
      const acx = cx0 + nx * R, acz = cz0 + nz * R;
      const a0 = Math.atan2(-nz, -nx);
      const len = R * sw;
      const ny = cy + dy * yf;
      alt.push({ type: 'a', y0: cy, y1: ny, len, d0: cd, sx: 0, sz: 0, h: 0, cx: acx, cz: acz, R, a0, s: sd, sweep: sw });
      const a1 = a0 + sd * sw;
      cx0 = acx + R * Math.cos(a1); cz0 = acz + R * Math.sin(a1);
      ch = wrap(ch - sd * sw); cy = ny; cd += len;
    }
    addSeg({
      type: 's', boost: true, forkAlt: alt, y0: gen.y, y1, len: straightLen, d0: gen.d,
      sx: gen.x, sz: gen.z, h: gen.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0,
    });
    gen.x += Math.sin(gen.h) * straightLen; gen.z += Math.cos(gen.h) * straightLen; gen.y = y1; gen.d += straightLen;
  };

  const genJump = (n: number, rings = 1) => {
    lastJumpN = n;
    const mega = rings >= 5;
    const g = gen;
    const fx = Math.sin(g.h), fz = Math.cos(g.h);
    const appLen = mega ? 13 : 9;
    const yA = g.y - appLen * 0.03;
    addSeg({ type: 's', y0: g.y, y1: yA, len: appLen, d0: g.d, sx: g.x, sz: g.z, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0, jmp: 1 });
    g.x += fx * appLen; g.z += fz * appLen; g.y = yA; g.d += appLen;
    const rampLen = mega ? 7.5 : 6, rise = mega ? 2.0 : 1.3;
    const lip = (2 * rise / rampLen) / Math.hypot(1, (2 * rise) / rampLen);
    addSeg({ type: 'r', y0: g.y, y1: g.y + rise, len: rampLen, d0: g.d, sx: g.x, sz: g.z, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0, jmp: 2, launch: lip });
    g.x += fx * rampLen; g.z += fz * rampLen; g.y += rise; g.d += rampLen;
    const gap = mega ? 19.5 : 9, landLen = mega ? 20 : 17;
    const lx = g.x + fx * gap, lz = g.z + fz * gap;
    const ly0 = g.y - 0.6, ly1 = ly0 - landLen * 0.03;
    addSeg({ type: 's', y0: ly0, y1: ly1, len: landLen, d0: g.d + gap, sx: lx, sz: lz, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0, jmp: 3 });
    g.x = lx + fx * landLen; g.z = lz + fz * landLen; g.y = ly1; g.d += gap + landLen;
  };

  const genSpiral = () => {
    const g = gen;
    lastSpiralN = segs.length;
    const sweep = TAU * 1.25;
    const R0 = randG(5.8, 6.4);
    const dR = 7.2 / TAU;
    const after = (sd: number) => wrap(g.h - sd * sweep);
    const opts = [1, -1].filter((sd) => Math.abs(after(sd)) <= Math.PI / 2 + 0.05);
    const s = opts.length ? opts[Math.floor(leg() * opts.length)] : Math.abs(after(1)) < Math.abs(after(-1)) ? 1 : -1;
    lastArcS = s;
    const d0a = Math.atan(dR / R0);
    const hc0 = g.h - s * d0a;
    const a0 = Math.PI / 2 - (s * Math.PI) / 2 - hc0;
    const cx = g.x - R0 * Math.cos(a0), cz = g.z - R0 * Math.sin(a0);
    const { cum, len } = buildCum(R0, dR, sweep);
    const y1 = g.y + 1.25 * FLOOR_H;
    addSeg({ type: 'a', y0: g.y, y1, len, d0: g.d, sx: 0, sz: 0, h: 0, cx, cz, R: R0, a0, s, sweep, spiral: true, dR, cum });
    const Rend = R0 + dR * sweep;
    g.x = cx + Rend * Math.cos(a0 + s * sweep);
    g.z = cz + Rend * Math.sin(a0 + s * sweep);
    g.h = wrap(g.h - s * sweep - s * d0a + s * Math.atan(dR / Rend));
    g.y = y1; g.d += len;
  };

  const genArc = (o: { sweep?: number; R?: number; flip?: boolean; same?: boolean; soft?: boolean } = {}) => {
    const g = gen;
    const diff = Math.min(1, segs.length / 40);
    let sweep = o.sweep;
    if (sweep === undefined) { const r = leg(); sweep = r < 0.55 - diff * 0.2 ? Math.PI / 2 : r < 0.85 ? Math.PI : Math.PI * 1.5; }
    if (o.soft && sweep > Math.PI / 2) sweep = Math.PI / 2;
    const R = o.R ?? randG(5.8, 8.5) - diff;
    const ok = (s: number) => Math.abs(wrap(g.h - s * sweep!)) <= Math.PI / 2 + 0.01;
    let opts = [1, -1].filter(ok);
    if (!opts.length) { sweep = Math.PI / 2; opts = [1, -1].filter(ok); }
    let s = opts[Math.floor(leg() * opts.length)];
    if (o.flip && lastArcS !== 0 && opts.includes(-lastArcS)) s = -lastArcS;
    else if (o.same && lastArcS !== 0 && opts.includes(lastArcS)) s = lastArcS;
    else if (opts.length === 2 && Math.abs(g.x) > 25) {
      s = opts.find((o2) => Math.sign(Math.sin(wrap(g.h - o2 * sweep!))) === -Math.sign(g.x)) ?? s;
    }
    lastArcS = s;
    const fx = Math.sin(g.h), fz = Math.cos(g.h);
    const nx = s * -fz, nz = s * fx;
    const cx = g.x + nx * R, cz = g.z + nz * R;
    const a0 = Math.atan2(-nz, -nx);
    const y1 = g.y - sweep * 1.7;
    const len = R * sweep;
    addSeg({ type: 'a', y0: g.y, y1, len, d0: g.d, sx: 0, sz: 0, h: 0, cx, cz, R, a0, s, sweep });
    const a1 = a0 + s * sweep;
    g.x = cx + R * Math.cos(a1); g.z = cz + R * Math.sin(a1);
    g.h = wrap(g.h - s * sweep); g.y = y1; g.d += len;
  };

  const genStep = (st: Step, n: number, attempt: number) => {
    if (st.k === 's') genStraight(st.len ?? 8);
    else if (st.k === 'b') genStraight(st.len ?? 16, true, false);
    else if (st.k === 'w') genStraight(st.len ?? 22, false, true);
    else if (st.k === 'f') {
      if (attempt < 3) genFork(st.R ?? 8.2, st.side);
      else if (attempt < 6) genFork(st.R ?? 8.2, st.side ? (st.side === 1 ? -1 : 1) : undefined);
      else genStraight(18, true, false);
    }
    else if (st.k === 'j') { if (attempt < 3) genJump(n, st.rings ?? 1); else genStraight(14, true, false); }
    else if (st.k === 'p') { if (attempt < 4) genSpiral(); else genArc(); }
    else genArc({ sweep: st.sweep, R: st.R, flip: st.flip, same: st.same, soft: attempt >= 3 });
  };

  const TARGET = Math.min(def.dist + 80, 3200);
  const script = def.build();
  let idx = 0, iter = 0;
  while (gen.d < TARGET && iter++ < 800) {
    const st = script[idx++ % script.length];
    const n = segs.length;
    let ok = false;
    for (let attempt = 0; attempt < 8 && !ok; attempt++) ok = genChecked(() => genStep(st, n, attempt));
    if (!ok) genChecked(() => genStep(st, n, 99), true);
  }

  return { pts: ptsAll.map(({ x, y, z }) => ({ x, y, z })), forkPaths, boostPaths, length: gen.d };
}

const cache = new Map<number, TrackPreview>();
export function trackPreview(def: LevelDef): TrackPreview {
  let p = cache.get(def.id);
  if (!p) {
    p = compileTrack(def);
    cache.set(def.id, p);
  }
  return p;
}
