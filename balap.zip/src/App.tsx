import { useEffect, useMemo, useRef, useState, type ReactNode, type RefObject } from 'react';
import {
  Game, CAM_NAMES, NOS, RESPAWN_T,
  type BotMode, type CamMode, type CarName, type EdgeName, type FxName, type JumpZoneInfo, type Mode, type NosColor,
  type RaceEnd, type RaceInfo, type RoadBuild, type SkinName, type SpeedName, type SplitZoneInfo, type Telemetry,
} from './game';
import type { MusicStyle } from './audio';
import { GARAGE, CATEGORIES, CATEGORY_LABEL, carInfo, validCar, renderThumb, disposeThumbRenderer, type Category } from './carmodel';
import {
  LEVELS, LEVEL_COUNT, TOTAL_STARS, THEMES, TIERS,
  loadProgress, recordLevelResult, resetProgress, totalStars, levelsCleared, levelById,
  type LevelDef, type LevelProgress, type ThemeName, type TrackFeature,
} from './levels';
import { trackPreview } from './trackpreview';
import { cn } from './utils/cn';
import { Flame, Settings, Volume2, VolumeX, Trophy, Star, Car, Flag, Play, RotateCcw, ChevronRight, X, Sparkles, Camera, Square } from 'lucide-react';

type Screen = 'menu' | 'play' | 'over';
type ModalKind = null | 'levels' | 'garage' | 'settings';
type SettingsTab = 'race' | 'look' | 'audio';
type LevelFilter = 'all' | 'hotwheels' | 'split';
type EndLevel = { id: number; name: string; theme: ThemeName; earned: number; stars: number; newBest: boolean; finished: boolean };
type End = { kind: 'run'; score: number; falls: number } | { kind: 'race'; r: RaceEnd; level?: EndLevel };

const CAM_ICON = ['🎥', '🏎️', '🛸'];
const MODES: { id: Mode; icon: string; label: string; sub: string }[] = [
  { id: 'drift', icon: '🏎️', label: 'Drift', sub: 'Kait tiang' },
  { id: 'free', icon: '💨', label: 'Bebas', sub: 'Tanpa tali' },
  { id: 'spidey', icon: '🕷️', label: 'Spidey', sub: 'Ayun jaring' },
];
const BOTS: { id: BotMode; icon: string; label: string; sub: string; badge?: string }[] = [
  { id: 'off', icon: '🚫', label: 'Solo', sub: 'Tanpa lawan' },
  { id: 'ghost', icon: '👻', label: 'Ghost', sub: '1 bot tembus' },
  { id: 'solid', icon: '🧱', label: 'Solid', sub: '1 bot senggol' },
  { id: 'ghost5', icon: '👻', label: 'Ghost ×5', sub: '5 bot hantu', badge: 'SERU' },
];
const SKIN_OPTS: { id: SkinName; label: string; sub: string; dot: string }[] = [
  { id: 'asphalt', label: 'Aspal', sub: 'Default gelap', dot: 'linear-gradient(135deg,#2e3142,#636b8e)' },
  { id: 'candy', label: 'Candy', sub: 'Pastel cerah', dot: 'linear-gradient(135deg,#fdf8ff,#ff9ec8)' },
  { id: 'orange', label: 'Oranye HW', sub: 'Hot Wheels 🔥', dot: 'linear-gradient(135deg,#ff8a1f,#ff4d00)' },
];
const EDGES: { id: EdgeName; icon: string; label: string }[] = [
  { id: 'hidden', icon: '🙈', label: 'Hidden' },
  { id: 'flat', icon: '▬', label: 'Flat' },
  { id: 'rail', icon: '🛡️', label: 'Rail' },
];
const FXS: { id: FxName; icon: string; label: string; sub: string }[] = [
  { id: 'V1', icon: '🧃', label: 'Juicer', sub: 'Berhamburan' },
  { id: 'V2', icon: '🧱', label: 'Rapi', sub: 'Jatuh teratur' },
];
const ROADBUILDS: { id: RoadBuild; icon: string; label: string; sub: string }[] = [
  { id: 'instant', icon: '✨', label: 'Langsung', sub: 'Muncul instan' },
  { id: 'wave', icon: '🌊', label: 'Bangun', sub: 'Naik bergelombang' },
];
const MUSICS: { id: MusicStyle; icon: string; label: string }[] = [
  { id: 'off', icon: '🔇', label: 'Off' },
  { id: 'ceria', icon: '🌈', label: 'Ceria' },
  { id: 'ngebut', icon: '🔥', label: 'Ngebut' },
];
const NOSS: { id: NosColor; label: string }[] = [
  { id: 'blue', label: 'Biru' },
  { id: 'purple', label: 'Ungu' },
  { id: 'green', label: 'Hijau' },
];
const GOALS: { id: string; icon: string; label: string; sub: string }[] = [
  { id: '600', icon: '⚡', label: '600 m', sub: 'Sprint' },
  { id: '1100', icon: '🏁', label: '1100 m', sub: 'Normal' },
  { id: '2000', icon: '🛣️', label: '2000 m', sub: 'Maraton' },
  { id: '0', icon: '♾️', label: 'Endless', sub: 'Tanpa finish' },
];
const SPEED_OPTS: { id: SpeedName; icon: string; label: string; sub: string }[] = [
  { id: 'santai', icon: '🐢', label: 'Santai', sub: 'Pemula' },
  { id: 'normal', icon: '🏎️', label: 'Normal', sub: 'Seimbang' },
  { id: 'kencang', icon: '🚀', label: 'Kencang', sub: 'Pro' },
];
const FEATURE_META: Record<TrackFeature, { icon: string; label: string; cls: string }> = {
  boost: { icon: '⚡', label: 'BOOST', cls: 'bg-cyan-400/20 text-cyan-200 border-cyan-300/35' },
  split: { icon: '⑂', label: '2-JALUR', cls: 'bg-amber-400/20 text-amber-200 border-amber-300/40' },
  jump: { icon: '🔥', label: 'JUMP', cls: 'bg-orange-500/25 text-orange-200 border-orange-400/40' },
  spiral: { icon: '🌀', label: 'SPIRAL', cls: 'bg-fuchsia-500/25 text-fuchsia-200 border-fuchsia-400/40' },
  wave: { icon: '🌊', label: 'WAVE', cls: 'bg-pink-500/20 text-pink-200 border-pink-400/35' },
};

const hex = (n: number) => '#' + n.toString(16).padStart(6, '0');
const bestKey = (m: Mode) => (m === 'spidey' ? 'slingdrift3d-best-spidey' : m === 'free' ? 'slingdrift3d-best-free' : 'slingdrift3d-best');
const load = <T extends string>(key: string, def: T): T => (localStorage.getItem(key) as T) || def;

// ---------- UI primitives ----------
function Section({ label, children, cols = 3 }: { label: string; children: ReactNode; cols?: 2 | 3 }) {
  return (
    <div>
      <div className="font-hud mb-2 flex items-center gap-2 text-[10px] font-bold tracking-[0.26em] text-white/55">
        <span>{label}</span><span className="h-px flex-1 bg-gradient-to-r from-white/20 to-transparent" />
      </div>
      <div className={cn('grid gap-2', cols === 2 ? 'grid-cols-2' : 'grid-cols-3')}>{children}</div>
    </div>
  );
}

function Choice({ active, onClick, icon, label, sub, badge, dot }: {
  active: boolean; onClick: () => void; icon?: ReactNode; label: string; sub?: string; badge?: string; dot?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'font-hud relative flex min-w-0 flex-col items-center justify-center gap-0.5 rounded-2xl border px-1.5 py-2.5 text-center transition-all duration-150 active:scale-95',
        active
          ? 'border-amber-300/90 bg-gradient-to-b from-amber-300/30 via-amber-300/12 to-orange-500/20 text-white shadow-[0_0_0_1px_rgba(252,211,77,.35),0_10px_24px_-8px_rgba(251,191,36,.55)]'
          : 'border-white/10 bg-white/[0.06] text-white/70 hover:bg-white/[0.12] hover:text-white',
      )}
    >
      {badge && <span className="absolute -right-1 -top-2 rounded-full bg-gradient-to-r from-pink-500 to-orange-400 px-1.5 py-px text-[9px] font-bold tracking-wider text-white shadow">{badge}</span>}
      {dot ? <span className="mb-0.5 h-5 w-5 rounded-md border border-white/40" style={{ background: dot }} /> : <span className="text-xl leading-none">{icon}</span>}
      <span className="max-w-full truncate text-[12px] font-bold leading-tight">{label}</span>
      {sub && <span className="max-w-full truncate text-[10px] font-medium leading-tight text-white/45">{sub}</span>}
    </button>
  );
}

// ---------- Speedometer Gauge ----------
function Gauge({ tele }: { tele: RefObject<Telemetry> }) {
  const arc = useRef<SVGPathElement>(null);
  const kmh = useRef<HTMLDivElement>(null);
  const gear = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let raf = 0, sm = 0;
    const loop = () => {
      const t = tele.current;
      sm += (t.rpm - sm) * 0.4;
      arc.current?.setAttribute('stroke-dasharray', `${(Math.min(1, Math.max(0, sm)) * 100).toFixed(1)} 100`);
      arc.current?.setAttribute('stroke', t.padBoost ? '#00f5ff' : sm > 0.92 ? '#fb3b5f' : 'url(#gg)');
      if (kmh.current) kmh.current.textContent = String(Math.round(t.kmh));
      if (gear.current) gear.current.textContent = t.gear > 0 ? String(t.gear) : 'N';
      if (ring.current) {
        ring.current.style.boxShadow = t.padBoost
          ? '0 0 28px rgba(0,245,255,0.65), inset 0 0 14px rgba(0,245,255,0.28)'
          : t.boost
            ? '0 0 24px rgba(251,191,36,0.45)'
            : '';
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [tele]);
  const A = 'M 53.33 146.67 A 66 66 0 1 1 146.67 146.67';
  return (
    <div ref={ring} className="glass-soft pointer-events-none absolute bottom-3 right-3 h-[126px] w-[126px] rounded-full transition-shadow sm:bottom-4 sm:right-4 sm:h-[158px] sm:w-[158px]">
      <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full">
        <defs>
          <linearGradient id="gg" x1="0" y1="1" x2="1" y2="0">
            <stop offset="0" stopColor="#22d3ee" /><stop offset=".55" stopColor="#fbbf24" /><stop offset="1" stopColor="#f43f5e" />
          </linearGradient>
        </defs>
        <path d={A} pathLength={100} fill="none" stroke="rgba(255,255,255,.13)" strokeWidth="12" strokeLinecap="round" />
        <path d={A} pathLength={100} fill="none" stroke="rgba(255,255,255,.32)" strokeWidth="5" strokeDasharray="0.35 4.65" transform="translate(100 100) scale(.82) translate(-100 -100)" />
        <path ref={arc} d={A} pathLength={100} fill="none" stroke="url(#gg)" strokeWidth="12" strokeLinecap="round" strokeDasharray="0 100" />
      </svg>
      <div className="font-hud absolute inset-0 flex flex-col items-center justify-center pt-1">
        <div ref={kmh} className="font-display text-[36px] leading-none text-white sm:text-[46px]">0</div>
        <div className="text-[9px] font-bold tracking-[0.28em] text-white/50">KM/H</div>
      </div>
      <div className="font-hud absolute inset-x-0 bottom-[7%] flex justify-center">
        <div className="flex items-center gap-1 rounded-full bg-black/45 px-2.5 py-0.5 text-[10px] font-bold tracking-widest text-white/65">
          G <div ref={gear} className="min-w-[1ch] text-center text-amber-300">N</div>
        </div>
      </div>
    </div>
  );
}

// ---------- 3D Garage Thumbnails ----------
function useThumbs(first: string) {
  const [t, setT] = useState<Record<string, string>>({});
  useEffect(() => {
    let alive = true, raf = 0, i = 0;
    const ids = [first, ...GARAGE.map((c) => c.id).filter((id) => id !== first)];
    const timer = window.setTimeout(() => {
      const step = () => {
        if (!alive) return;
        const batch: Record<string, string> = {};
        for (let k = 0; k < 2 && i < ids.length; k++, i++) { const u = renderThumb(ids[i]); if (u) batch[ids[i]] = u; }
        setT((prev) => ({ ...prev, ...batch }));
        if (i < ids.length) raf = requestAnimationFrame(step); else disposeThumbRenderer();
      };
      raf = requestAnimationFrame(step);
    }, 450);
    return () => { alive = false; window.clearTimeout(timer); cancelAnimationFrame(raf); disposeThumbRenderer(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return t;
}

function Thumb({ src, className }: { src?: string; className?: string }) {
  return (
    <div className={cn('relative overflow-hidden bg-gradient-to-br from-indigo-400/25 via-violet-500/15 to-pink-400/25', className)}>
      {src ? <img src={src} alt="" draggable={false} className="absolute inset-0 h-full w-full object-contain" /> : <div className="absolute inset-0 animate-pulse bg-white/5" />}
    </div>
  );
}

function StatBar({ label, v, c }: { label: string; v: number; c: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="font-hud w-[58px] text-[9px] font-bold tracking-[0.14em] text-white/55">{label}</span>
      <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
        <span className="block h-full rounded-full" style={{ width: `${v * 10}%`, background: c }} />
      </span>
      <span className="font-hud w-4 text-right text-[10px] font-bold text-white/80">{v}</span>
    </div>
  );
}

// ---------- Minimap SVG Presisi (dengan cabang 2-jalur & boost pad!) ----------
function TrackMap({ def, accent, compact = false }: { def: LevelDef; accent: string; compact?: boolean }) {
  const d = useMemo(() => {
    const p = trackPreview(def);
    if (!p.pts.length) return null;
    let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
    const expand = (x: number, z: number) => {
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
    };
    for (const q of p.pts) expand(q.x, q.z);
    for (const fp of p.forkPaths) for (const q of fp) expand(q.x, q.z);
    const spanX = Math.max(1, maxX - minX), spanZ = Math.max(1, maxZ - minZ);
    const padX = spanX * 0.14, padZ = spanZ * 0.12;
    minX -= padX; maxX += padX; minZ -= padZ; maxZ += padZ;
    const toPath = (arr: { x: number; z: number }[]) => arr.map((q, i) => `${i ? 'L' : 'M'}${q.x.toFixed(1)} ${q.z.toFixed(1)}`).join(' ');
    const sx = (p.pts[0].x - minX) / (maxX - minX), sy = (p.pts[0].z - minZ) / (maxZ - minZ);
    const last = p.pts[p.pts.length - 1];
    const ex = (last.x - minX) / (maxX - minX), ey = (last.z - minZ) / (maxZ - minZ);
    return {
      vb: `${minX.toFixed(1)} ${minZ.toFixed(1)} ${(maxX - minX).toFixed(1)} ${(maxZ - minZ).toFixed(1)}`,
      path: toPath(p.pts),
      forks: p.forkPaths.map(toPath),
      boosts: p.boostPaths.map(toPath),
      sx, sy, ex, ey,
    };
  }, [def]);
  if (!d) return <div className="absolute inset-0 animate-pulse bg-white/5" />;
  return (
    <>
      <svg viewBox={d.vb} preserveAspectRatio="xMidYMid meet" className="absolute inset-0 h-full w-full p-1" aria-hidden>
        {/* cabang 2-jalur drift (emas menyala!) */}
        {d.forks.map((fp, i) => (
          <g key={'f' + i}>
            <path d={fp} fill="none" stroke="rgba(0,0,0,.85)" strokeWidth={compact ? 4.5 : 6} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
            <path d={fp} fill="none" stroke="#ff9f1c" strokeWidth={compact ? 2 : 2.6} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
          </g>
        ))}
        {/* lintasan utama */}
        <path d={d.path} fill="none" stroke="rgba(5,3,22,.92)" strokeWidth={compact ? 5.5 : 7} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <path d={d.path} fill="none" stroke={accent} strokeWidth={compact ? 2.1 : 2.5} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" style={{ filter: `drop-shadow(0 0 4px ${accent})` }} />
        {/* strip boost pad / jalur lurus NOS (cyan neon!) */}
        {d.boosts.map((bp, i) => (
          <path key={'b' + i} d={bp} fill="none" stroke="#00f5ff" strokeWidth={compact ? 2.2 : 2.8} strokeLinecap="round" vectorEffect="non-scaling-stroke" />
        ))}
      </svg>
      {!compact && (
        <>
          <span className="absolute h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-black/70 bg-emerald-400 shadow-[0_0_7px_#5cff9d]" style={{ left: `${d.sx * 100}%`, top: `${d.sy * 100}%` }} />
          <span className="absolute h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-black/70 bg-amber-300 shadow-[0_0_7px_#ffd23f]" style={{ left: `${d.ex * 100}%`, top: `${d.ey * 100}%` }} />
        </>
      )}
    </>
  );
}

// ---------- Kartu Level Kolektor ----------
function LevelCard({ def, earned, best, selected, onPick }: {
  def: LevelDef; earned: number; best: number; selected: boolean; onPick: (id: number) => void;
}) {
  const th = THEMES[def.theme];
  const accent = def.hotwheels ? '#ff8a1f' : '#fde047';
  const rarityCls = def.rarity === 'legendary'
    ? 'from-amber-400 via-orange-500 to-rose-500 text-white'
    : def.rarity === 'epic'
      ? 'from-fuchsia-500 via-purple-500 to-cyan-400 text-white'
      : 'from-orange-500 to-amber-400 text-slate-950';
  return (
    <button
      onClick={() => onPick(def.id)}
      className={cn(
        'group relative flex flex-col overflow-hidden rounded-[1.35rem] border text-left transition-all duration-150 hover:-translate-y-0.5 active:scale-[0.97]',
        def.hotwheels
          ? 'hw-card border-orange-400/80 bg-gradient-to-b from-orange-950/90 via-[#1d123a]/95 to-[#120b28]/95'
          : selected
            ? 'border-amber-300 bg-gradient-to-b from-indigo-900/85 to-slate-950/95 shadow-[0_0_0_1px_rgba(252,211,77,.5)]'
            : 'border-white/15 bg-gradient-to-b from-[#1f1848]/85 to-[#100c2c]/92 hover:border-white/35',
      )}
    >
      {/* Header visual tema + minimap */}
      <div
        className="relative h-[106px] w-full overflow-hidden border-b border-white/10"
        style={{ background: `linear-gradient(155deg, ${th.sky[0]}cc, ${th.sky[1]}88 60%, #0b0720 100%)` }}
      >
        <TrackMap def={def} accent={accent} />
        <div className="font-hud absolute left-2 top-2 flex items-center gap-1 rounded-lg bg-black/65 px-2 py-0.5 text-[11px] font-bold text-white backdrop-blur-sm">
          <span>LV {String(def.id).padStart(2, '0')}</span>
        </div>
        {def.hotwheels && (
          <div className={cn('font-hud absolute right-2 top-2 rounded-full bg-gradient-to-r px-2 py-0.5 text-[9px] font-extrabold tracking-wider shadow', rarityCls)}>
            {def.tag}
          </div>
        )}
        {!def.hotwheels && (
          <div className="font-hud absolute right-2 top-2 rounded-full bg-black/55 px-2 py-0.5 text-[9px] font-bold tracking-wider text-white/85">
            {def.tag}
          </div>
        )}
        <div className="font-hud absolute bottom-1.5 left-2 rounded-md bg-black/55 px-1.5 py-0.5 text-[9px] font-bold text-white/80">
          🏁 {def.dist}m
        </div>
        <div className="absolute bottom-1.5 right-2 flex gap-0.5">
          {[0, 1, 2].map((i) => (
            <span key={i} className={cn('text-sm leading-none', i < earned ? 'text-yellow-300 drop-shadow-[0_1px_3px_rgba(0,0,0,.9)]' : 'text-white/25')}>★</span>
          ))}
        </div>
      </div>

      {/* Info bawah kartu */}
      <div className="flex flex-1 flex-col justify-between p-2.5">
        <div>
          <div className="font-display truncate text-[16px] leading-tight text-white">{def.name}</div>
          <p className="font-hud mt-0.5 line-clamp-2 text-[10px] leading-snug text-white/60">{def.desc}</p>
        </div>
        <div className="mt-2 flex flex-wrap items-center justify-between gap-1">
          <div className="flex flex-wrap gap-1">
            {def.features.slice(0, 3).map((f) => (
              <span key={f} className={cn('font-hud rounded-md border px-1.5 py-px text-[8px] font-bold tracking-wider', FEATURE_META[f].cls)}>
                {FEATURE_META[f].icon} {FEATURE_META[f].label}
              </span>
            ))}
          </div>
          {best > 0 && <span className="font-hud text-[10px] font-bold text-amber-300">🏆 {best}</span>}
        </div>
      </div>
    </button>
  );
}

// ---------- Race Mini Leaderboard ----------
function Board({ race }: { race: RaceInfo }) {
  return (
    <div className="glass-soft font-hud pointer-events-none absolute left-4 top-20 hidden w-52 rounded-2xl p-2.5 lg:block">
      <div className="mb-1.5 flex items-center justify-between px-1 text-[10px] font-bold tracking-[0.22em] text-white/55">
        <span>POSISI</span><span>🏁 {race.rem}m</span>
      </div>
      <div className="space-y-1">
        {race.rows.map((r, i) => (
          <div key={r.id} className={cn('flex items-center gap-2 rounded-lg px-2 py-1', r.me ? 'bg-amber-300 text-slate-900' : 'bg-white/[0.07] text-white')}>
            <span className="w-3 text-center text-xs font-bold">{i + 1}</span>
            <span className="h-2.5 w-2.5 shrink-0 rounded-full border border-white/80" style={{ background: r.color }} />
            <span className="flex-1 truncate text-xs font-bold">{r.name}</span>
            <span className="h-1.5 w-10 overflow-hidden rounded-full bg-black/25">
              <span className="block h-full rounded-full" style={{ width: `${Math.round(r.p * 100)}%`, background: r.me ? '#1b1640' : r.color }} />
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- Garage Panel ----------
function GaragePanel({ car, onPick, thumbs }: { car: string; onPick: (id: string) => void; thumbs: Record<string, string> }) {
  const [cat, setCat] = useState<'all' | Category>('all');
  const info = carInfo(car);
  const list = GARAGE.filter((c) => cat === 'all' || c.category === cat);
  const chips: { id: 'all' | Category; label: string; n: number }[] = [
    { id: 'all', label: 'Semua', n: GARAGE.length },
    ...CATEGORIES.map((c) => ({ id: c, label: CATEGORY_LABEL[c], n: GARAGE.filter((g) => g.category === c).length })).filter((c) => c.n > 0),
  ];
  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-amber-300/45 bg-gradient-to-br from-amber-300/15 via-white/[0.03] to-orange-500/15 p-3">
        <div className="flex gap-3">
          <Thumb src={thumbs[info.id]} className="h-[88px] w-[132px] shrink-0 rounded-xl border border-white/15" />
          <div className="font-hud min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-[0.18em] text-amber-200">
              {info.rank && <span className="rounded bg-amber-300 px-1.5 py-px text-slate-900">#{info.rank}</span>}
              <span className="truncate">{CATEGORY_LABEL[info.category].toUpperCase()}</span>
            </div>
            <div className="mt-0.5 text-[16px] font-bold leading-tight text-white">{info.name}</div>
            <div className="mt-0.5 truncate text-[11px] text-white/60">{info.driver}</div>
            <div className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-black/35 px-2.5 py-0.5 text-[10px] font-bold text-cyan-200">🔊 {info.engine}</div>
          </div>
        </div>
        <div className="mt-3 space-y-1.5">
          <StatBar label="SPEED" v={info.stats[0]} c="linear-gradient(90deg,#22d3ee,#60a5fa)" />
          <StatBar label="AKSEL" v={info.stats[1]} c="linear-gradient(90deg,#fbbf24,#fb923c)" />
          <StatBar label="HANDLING" v={info.stats[2]} c="linear-gradient(90deg,#34d399,#a3e635)" />
        </div>
      </div>

      <div className="thin-scroll font-hud flex gap-1.5 overflow-x-auto pb-1">
        {chips.map((c) => (
          <button
            key={c.id}
            onClick={() => setCat(c.id)}
            className={cn(
              'shrink-0 rounded-full border px-3 py-1 text-[11px] font-bold transition-all active:scale-95',
              cat === c.id ? 'border-amber-300 bg-amber-300 text-slate-900' : 'border-white/15 bg-white/[0.07] text-white/75 hover:bg-white/15',
            )}
          >
            {c.label} <span className="opacity-60">{c.n}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
        {list.map((c) => (
          <button
            key={c.id}
            onClick={() => onPick(c.id)}
            className={cn(
              'font-hud group relative overflow-hidden rounded-xl border text-left transition-all duration-150 active:scale-95',
              car === c.id ? 'border-amber-300 shadow-[0_0_0_1px_rgba(252,211,77,.55),0_10px_22px_-8px_rgba(251,191,36,.65)]' : 'border-white/12 hover:border-white/35',
            )}
          >
            <Thumb src={thumbs[c.id]} className="aspect-[3/2] w-full" />
            <div className={cn('px-1.5 py-1 text-[11px] font-bold leading-tight', car === c.id ? 'bg-amber-300 text-slate-900' : 'bg-black/40 text-white/90')}>
              <span className="block truncate">{c.short}</span>
            </div>
            {c.rank && <span className="absolute left-1 top-1 rounded bg-black/60 px-1 text-[9px] font-bold text-amber-200">#{c.rank}</span>}
          </button>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
//  APP UTAMA
// ============================================================================
export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const game = useRef<Game | null>(null);
  const [screen, setScreen] = useState<Screen>('menu');
  const screenRef = useRef<Screen>('menu');
  const [modal, setModal] = useState<ModalKind>(null);
  const [settingsTab, setSettingsTab] = useState<SettingsTab>('race');
  const [levelFilter, setLevelFilter] = useState<LevelFilter>('all');

  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [mode, setMode] = useState<Mode>(() => load<Mode>('slingdrift3d-mode', 'drift'));
  const modeRef = useRef<Mode>(load<Mode>('slingdrift3d-mode', 'drift'));
  const [best, setBest] = useState(() => Number(localStorage.getItem(bestKey(modeRef.current)) || 0));
  const [popup, setPopup] = useState<{ text: string; color: string; id: number } | null>(null);
  const [bump, setBump] = useState(0);
  const [hint, setHint] = useState('');
  const [boosting, setBoosting] = useState(false);
  const [splitZone, setSplitZone] = useState<SplitZoneInfo | null>(null);
  const [jumpZone, setJumpZone] = useState<JumpZoneInfo | null>(null);
  const [race, setRace] = useState<RaceInfo | null>(null);
  const [end, setEnd] = useState<End | null>(null);
  const [resp, setResp] = useState<{ n: number; id: number } | null>(null);
  const respId = useRef(0);
  const [grid, setGrid] = useState<number | null>(null);

  const [progress, setProgress] = useState<LevelProgress>(() => loadProgress());
  const [selectedLevel, setSelectedLevel] = useState<number>(() => {
    const p = loadProgress();
    const firstUnclear = LEVELS.find((l) => !(p.stars[l.id] > 0))?.id ?? 1;
    return firstUnclear;
  });
  const [activeLevel, setActiveLevel] = useState<number | null>(null);

  const [goal, setGoal] = useState<string>(() => load<string>('slingdrift3d-goal', '1100'));
  const tele = useRef<Telemetry>({ kmh: 0, rpm: 0, gear: 0, boost: false, drift: false, padBoost: false });
  const [skin, setSkin] = useState<SkinName>(() => load<SkinName>('slingdrift3d-skin', 'asphalt'));
  const [cam, setCam] = useState<CamMode>(() => Number(localStorage.getItem('slingdrift3d-cam') || 0) as CamMode);
  const [edge, setEdge] = useState<EdgeName>(() => load<EdgeName>('slingdrift3d-edge', 'hidden'));
  const [car, setCar] = useState<CarName>(() => validCar(localStorage.getItem('slingdrift3d-car') ?? 'vx-most-wanted'));
  const [fx, setFx] = useState<FxName>(() => load<FxName>('slingdrift3d-fx', 'V2'));
  const [roadBuild, setRoadBuild] = useState<RoadBuild>(() => load<RoadBuild>('slingdrift3d-roadbuild', 'instant'));
  const [musik, setMusik] = useState<MusicStyle>(() => load<MusicStyle>('slingdrift3d-music', 'ceria'));
  const [nos, setNos] = useState<NosColor>(() => load<NosColor>('slingdrift3d-nos', 'blue'));
  const [nosFire, setNosFire] = useState<'hold' | 'toggle'>(() => load<'hold' | 'toggle'>('slingdrift3d-nosfire', 'hold'));
  const [speed, setSpeed] = useState<SpeedName>(() => load<SpeedName>('slingdrift3d-speed', 'normal'));
  const [bot, setBot] = useState<BotMode>(() => load<BotMode>('slingdrift3d-bot', 'ghost5'));

  const canRestart = useRef(true);
  const nosBtn = useRef(false);
  const nosBtnUp = () => { if (nosBtn.current) { nosBtn.current = false; game.current?.nosUp(); } };

  const go = (s: Screen) => { screenRef.current = s; setScreen(s); };

  const startQuickPlay = () => {
    if (screenRef.current === 'play' || !canRestart.current) return;
    const g = game.current; if (!g) return;
    g.setLevel(null);
    setActiveLevel(null);
    setModal(null);
    setEnd(null); setRace(null); setResp(null); setGrid(null); setSplitZone(null); setJumpZone(null); setScore(0); setCombo(0);
    g.unlockAudio(); g.start(); go('play');
  };

  const startLevel = (id: number) => {
    if (screenRef.current === 'play' || !canRestart.current) return;
    const g = game.current; if (!g) return;
    setSelectedLevel(id);
    setMode('drift'); modeRef.current = 'drift';
    setBest(Number(localStorage.getItem(bestKey('drift')) || 0));
    g.setMode('drift');
    g.setLevel(id);
    setActiveLevel(id);
    setModal(null);
    setEnd(null); setRace(null); setResp(null); setGrid(null); setSplitZone(null); setJumpZone(null); setScore(0); setCombo(0);
    g.unlockAudio(); g.start(); go('play');
  };

  const toMenu = () => {
    const g = game.current;
    setActiveLevel(null);
    setModal(null);
    const m = load<Mode>('slingdrift3d-mode', 'drift');
    if (m !== modeRef.current) { modeRef.current = m; setMode(m); g?.setMode(m); }
    setBest(Number(localStorage.getItem(bestKey(m)) || 0));
    // Tampilkan tema level terpilih di latar menu 3D agar langsung keren!
    g?.setLevel(selectedLevel);
    setEnd(null); setRace(null); setSplitZone(null); go('menu');
  };

  const saveBest = (s: number) => {
    const k = bestKey(modeRef.current);
    setBest((b) => { const nb = Math.max(b, s); localStorage.setItem(k, String(nb)); return nb; });
    canRestart.current = false;
    setTimeout(() => (canRestart.current = true), 550);
  };

  useEffect(() => {
    const g = new Game(mount.current!, {
      onScore: (s, c) => { setScore(s); setCombo(c); setBump((b) => b + 1); },
      onPopup: (text, color) => setPopup({ text, color, id: Math.random() }),
      onHint: (h) => setHint(h),
      onBoost: (on) => setBoosting(on),
      onSplitZone: (info) => setSplitZone(info),
      onJumpZone: (info) => setJumpZone(info),
      onRace: (info) => setRace(info),
      onRespawn: (n) => { if (n === RESPAWN_T) respId.current++; setResp(n > 0 ? { n, id: respId.current } : null); },
      onGrid: (n) => setGrid(n > 0 ? n : null),
      onTelemetry: (t) => { tele.current = t; },
      onRaceEnd: (r) => {
        setSplitZone(null);
        const lvl = game.current?.levelId ?? null;
        if (lvl != null) {
          const def = levelById(lvl);
          const base = { id: lvl, name: def?.name ?? `Level ${lvl}`, theme: (def?.theme ?? 'violet') as ThemeName };
          if (r.finished) {
            const res = recordLevelResult(lvl, r.score, r.falls);
            setProgress(res.progress);
            if (lvl < LEVEL_COUNT) setSelectedLevel(lvl + 1);
            setEnd({ kind: 'race', r, level: { ...base, earned: res.earned, stars: res.stars, newBest: res.newBest, finished: true } });
          } else {
            const p = loadProgress();
            setEnd({ kind: 'race', r, level: { ...base, earned: 0, stars: p.stars[lvl] ?? 0, newBest: false, finished: false } });
          }
          go('over');
          return;
        }
        saveBest(r.score); setEnd({ kind: 'race', r }); go('over');
      },
      onGameOver: (s, falls) => { setSplitZone(null); saveBest(s); setEnd({ kind: 'run', score: s, falls }); go('over'); },
    });
    g.setSkin(load<SkinName>('slingdrift3d-skin', 'asphalt'));
    g.setCam(Number(localStorage.getItem('slingdrift3d-cam') || 0) as CamMode);
    g.setEdge(load<EdgeName>('slingdrift3d-edge', 'hidden'));
    g.setCar(validCar(localStorage.getItem('slingdrift3d-car') ?? 'vx-most-wanted'));
    g.setFx(load<FxName>('slingdrift3d-fx', 'V2'));
    g.setRoadBuild(load<RoadBuild>('slingdrift3d-roadbuild', 'instant'));
    g.setMusicStyle(load<MusicStyle>('slingdrift3d-music', 'ceria'));
    g.setNos(load<NosColor>('slingdrift3d-nos', 'blue'));
    g.setNosMode(load<string>('slingdrift3d-nosfire', 'hold') === 'toggle');
    g.setGoal(Number(load<string>('slingdrift3d-goal', '1100')));
    g.setSpeed(load<SpeedName>('slingdrift3d-speed', 'normal'));
    g.setMode(load<Mode>('slingdrift3d-mode', 'drift'));
    g.setBot(g.mode === 'spidey' ? 'off' : load<BotMode>('slingdrift3d-bot', 'ghost5'));
    g.setLevel(selectedLevel);
    game.current = g;

    const prewarm = () => { try { LEVELS.forEach((def) => trackPreview(def)); } catch { /* abaikan */ } };
    const wIdle = window as unknown as { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number };
    if (wIdle.requestIdleCallback) wIdle.requestIdleCallback(prewarm, { timeout: 3000 });
    else window.setTimeout(prewarm, 1400);

    let driftPtr: number | null = null;
    const down = (e: PointerEvent) => {
      if ((e.target as HTMLElement)?.closest?.('[data-ui]')) return;
      if (screenRef.current !== 'play') return;
      if (e.button === 2) { g.nosDown(); return; }
      if (driftPtr !== null) { g.nosDown(); return; }
      driftPtr = e.pointerId;
      g.press();
    };
    const up = (e: PointerEvent) => {
      if (e.button === 2) { g.nosUp(); return; }
      if (e.pointerId === driftPtr) { driftPtr = null; g.release(); }
      else g.nosUp();
    };
    const kd = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !e.repeat) {
        e.preventDefault();
        (document.activeElement as HTMLElement)?.blur?.();
        if (screenRef.current === 'play') g.comboDown();
      }
      if ((e.code === 'ArrowUp' || e.code === 'KeyW') && !e.repeat && screenRef.current === 'play') {
        g.chooseFork('nos');
      }
      if ((e.code === 'ArrowLeft' || e.code === 'ArrowRight' || e.code === 'KeyA' || e.code === 'KeyD') && !e.repeat && screenRef.current === 'play') {
        g.chooseFork('drift');
      }
      if (e.code === 'KeyC' && !e.repeat) {
        const m = g.cycleCam();
        localStorage.setItem('slingdrift3d-cam', String(m));
        setCam(m);
      }
      if (e.code === 'Escape' && screenRef.current === 'play') g.endRun();
      if ((e.code === 'ShiftLeft' || e.code === 'ShiftRight' || e.code === 'KeyN') && !e.repeat) g.nosKeyDown();
    };
    const ku = (e: KeyboardEvent) => {
      if (e.code === 'Space') g.comboUp();
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight' || e.code === 'KeyN') g.nosKeyUp();
    };
    const ctx = (e: Event) => e.preventDefault();
    window.addEventListener('pointerdown', down);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);
    window.addEventListener('contextmenu', ctx);
    return () => {
      window.removeEventListener('pointerdown', down);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      window.removeEventListener('contextmenu', ctx);
      g.dispose();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickMode = (m: Mode) => {
    setMode(m); modeRef.current = m;
    localStorage.setItem('slingdrift3d-mode', m);
    setBest(Number(localStorage.getItem(bestKey(m)) || 0));
    if (m === 'spidey' && bot !== 'off') { setBot('off'); localStorage.setItem('slingdrift3d-bot', 'off'); game.current?.setBot('off'); }
    game.current?.setMode(m);
  };
  const pickSpeed = (v: SpeedName) => { setSpeed(v); localStorage.setItem('slingdrift3d-speed', v); game.current?.setSpeed(v); };
  const pickGoal = (v: string) => { setGoal(v); localStorage.setItem('slingdrift3d-goal', v); game.current?.setGoal(Number(v)); };
  const pickBot = (b: BotMode) => { setBot(b); localStorage.setItem('slingdrift3d-bot', b); game.current?.setBot(b); };
  const pickNosFire = (f: 'hold' | 'toggle') => { setNosFire(f); localStorage.setItem('slingdrift3d-nosfire', f); game.current?.setNosMode(f === 'toggle'); };
  const pickSkin = (v: SkinName) => { setSkin(v); localStorage.setItem('slingdrift3d-skin', v); game.current?.setSkin(v); };
  const cycleSkinQuick = () => {
    const order: SkinName[] = ['asphalt', 'orange', 'candy'];
    const next = order[(order.indexOf(skin) + 1) % order.length];
    pickSkin(next);
  };
  const pickEdge = (v: EdgeName) => { setEdge(v); localStorage.setItem('slingdrift3d-edge', v); game.current?.setEdge(v); };
  const pickFx = (v: FxName) => { setFx(v); localStorage.setItem('slingdrift3d-fx', v); game.current?.setFx(v); };
  const pickRoad = (v: RoadBuild) => { setRoadBuild(v); localStorage.setItem('slingdrift3d-roadbuild', v); game.current?.setRoadBuild(v); };
  const pickMusic = (v: MusicStyle) => { setMusik(v); localStorage.setItem('slingdrift3d-music', v); game.current?.setMusicStyle(v); };
  const pickNos = (v: NosColor) => { setNos(v); localStorage.setItem('slingdrift3d-nos', v); game.current?.setNos(v); };
  const pickCam = (v: CamMode) => { setCam(v); localStorage.setItem('slingdrift3d-cam', String(v)); game.current?.setCam(v); };
  const pickCar = (v: CarName) => { setCar(v); localStorage.setItem('slingdrift3d-car', v); game.current?.setCar(v); };
  const toggleMusicQuick = () => pickMusic(musik === 'off' ? 'ceria' : 'off');

  const thumbs = useThumbs(car);
  const info = carInfo(car);
  const selDef = levelById(selectedLevel) ?? LEVELS[0];
  const selStars = progress.stars[selDef.id] ?? 0;
  const totalS = totalStars(progress);
  const clearedN = levelsCleared(progress);

  const filteredLevels = useMemo(() => {
    if (levelFilter === 'hotwheels') return LEVELS.filter((l) => l.hotwheels);
    if (levelFilter === 'split') return LEVELS.filter((l) => l.features.includes('split'));
    return LEVELS;
  }, [levelFilter]);

  const levelEnd = end?.kind === 'race' ? end.level : undefined;
  const levelFalls = end?.kind === 'race' ? end.r.falls : 99;
  let title = 'RUN SELESAI', place = '', stats: [string, string][] = [], newBest = false, sc = 0;
  if (end?.kind === 'race') {
    const { r } = end; sc = r.score;
    if (r.total === 1) title = r.finished ? '🏁 FINISH!' : '🏁 SELESAI';
    else if (r.finished) title = r.win ? '🏆 JUARA 1!' : `🏅 POSISI ${r.place}`;
    else title = r.place >= r.total ? '😅 KALAH' : '🏁 SELESAI';
    place = r.total > 1 ? `#${r.place} / ${r.total}` : '';
    stats = [['JATUH', String(r.falls)]];
    newBest = r.score >= best && r.score > 0;
  } else if (end?.kind === 'run') {
    sc = end.score; stats = [['JATUH', String(end.falls)]];
    newBest = end.score >= best && end.score > 0;
  }

  return (
    <div className="fixed inset-0 select-none overflow-hidden touch-none font-display">
      {/* Live 3D WebGL Canvas */}
      <div ref={mount} className="absolute inset-0" />

      {/* Efek Boost / NOS Vignette + Speedlines */}
      <div
        className="pointer-events-none absolute inset-0 transition-opacity duration-200"
        style={{
          opacity: boosting && screen === 'play' ? 1 : 0,
          background: `radial-gradient(ellipse at center, transparent 48%, rgba(${tele.current.padBoost ? '0,245,255' : NOS[nos].css},0.48) 100%)`,
        }}
      />
      <div className="speedlines pointer-events-none absolute inset-0 transition-opacity duration-200" style={{ opacity: boosting && screen === 'play' ? 0.58 : 0 }} />

      {/* ================================================================= */}
      {/*  IN-GAME HUD                                                      */}
      {/* ================================================================= */}
      {screen === 'play' && (
        <>
          {/* Top-Center: Score + Combo + Progress */}
          <div className="pointer-events-none absolute inset-x-0 top-2.5 flex flex-col items-center gap-1 sm:top-3.5">
            <div key={bump} className="score-pop font-display text-5xl leading-none text-white sm:text-6xl" style={{ WebkitTextStroke: '3px #18113c', paintOrder: 'stroke fill', textShadow: '0 5px 0 #18113c, 0 12px 24px rgba(0,0,0,.4)' }}>
              {score}
            </div>
            {combo > 1 && (
              <div key={'c' + combo} className="score-pop font-hud rounded-full bg-gradient-to-b from-yellow-200 to-amber-400 px-3.5 py-0.5 text-sm font-bold text-rose-800 shadow-[0_3px_0_#a85a00]">
                🔥 COMBO ×{combo}
              </div>
            )}
            {race && mode !== 'spidey' && (
              <div className="glass-soft font-hud mt-1 w-[min(78vw,320px)] rounded-2xl px-3 py-1.5">
                <div className="mb-1.5 flex items-center justify-between text-[11px] font-bold">
                  {race.total > 1
                    ? <span className="rounded-md bg-amber-300 px-1.5 py-px text-slate-950">P{race.place}<span className="opacity-60">/{race.total}</span></span>
                    : <span className="text-[10px] tracking-[0.22em] text-white/65">PROGRESS</span>}
                  <span className="text-white/90">🏁 {race.rem} m</span>
                </div>
                <div className="relative mx-1 h-2 rounded-full bg-white/15">
                  <div className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-amber-300 to-orange-500 transition-[width] duration-200" style={{ width: `${Math.round((race.rows.find((x) => x.me)?.p ?? 0) * 100)}%` }} />
                  {race.rows.slice().reverse().map((r) => (
                    <span
                      key={r.id}
                      className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white transition-[left] duration-200"
                      style={{ left: `${Math.round(r.p * 100)}%`, width: r.me ? 15 : 9, height: r.me ? 15 : 9, background: r.color, zIndex: r.me ? 5 : 1, boxShadow: r.me ? '0 0 12px #fde047' : undefined }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 2-Jalur Split — pill mungil & rapi (kontrol tetap: TAHAN = drift, LEPAS = NOS) */}
          {splitZone && !splitZone.chosen && !resp && !grid && (
            <div className="split-banner pointer-events-none absolute inset-x-0 top-[150px] flex justify-center px-3 sm:top-[140px]">
              <div className="glass-soft font-hud flex items-center gap-1.5 rounded-full border border-amber-300/60 px-3.5 py-1 text-[10px] font-bold tracking-wider text-white sm:text-[11px]">
                <span className="text-amber-300">⑂ 2 JALUR</span>
                <span className="text-white/40">|</span>
                <span className="text-cyan-300">LURUS = ⚡NOS</span>
                <span className="text-white/40">•</span>
                <span className="text-amber-300">BELOK = 🔥DRIFT</span>
              </div>
            </div>
          )}

          {/* Top-Left: Active Level Pill */}
          {activeLevel && (
            <div className="pointer-events-none absolute left-3 top-3 sm:left-4 sm:top-4">
              <div className={cn('glass-soft font-hud rounded-2xl px-3 py-1.5', levelById(activeLevel)?.hotwheels && 'border-orange-400/60')}>
                <div className="flex items-center gap-1.5 text-[9px] font-bold tracking-[0.26em] text-amber-200">
                  <span>{levelById(activeLevel)?.hotwheels ? '🔥' : '🏁'}</span>
                  LEVEL {activeLevel}/{LEVEL_COUNT}
                </div>
                <div className="max-w-[140px] truncate text-xs font-bold leading-tight text-white sm:max-w-[180px]">
                  {levelById(activeLevel)?.name}
                </div>
              </div>
            </div>
          )}

          {race && race.total > 1 && <Board race={race} />}

          {/* Top-Right: Camera & Exit */}
          <div data-ui className="absolute right-3 top-3 flex items-center gap-2 sm:right-4 sm:top-4">
            <button
              onClick={() => { const m = game.current?.cycleCam(); if (m !== undefined) { setCam(m); localStorage.setItem('slingdrift3d-cam', String(m)); } }}
              className="glass-soft font-hud flex h-10 items-center gap-1.5 rounded-xl px-3 text-xs font-bold text-white active:scale-90"
              title="Ganti Kamera (C)"
            >
              <Camera className="h-4 w-4 text-cyan-300" />
              <span className="hidden sm:inline">{CAM_NAMES[cam]}</span>
            </button>
            <button
              onClick={() => game.current?.endRun()}
              className="glass-soft font-hud flex h-10 items-center gap-1.5 rounded-xl px-3 text-xs font-bold text-rose-200 active:scale-90"
              title="Keluar (Esc)"
            >
              <Square className="h-3.5 w-3.5 fill-current" />
              <span className="hidden sm:inline">STOP</span>
            </button>
          </div>

          {/* Bottom-Left: Tactile NOS Button */}
          <div data-ui className="absolute bottom-4 left-3 flex flex-col items-center gap-1 sm:bottom-5 sm:left-4">
            <button
              onPointerDown={(e) => { e.stopPropagation(); if (!nosBtn.current) { nosBtn.current = true; game.current?.nosDown(); } }}
              onPointerUp={nosBtnUp}
              onPointerCancel={nosBtnUp}
              onPointerLeave={nosBtnUp}
              onContextMenu={(e) => e.preventDefault()}
              className={cn(
                'flex h-[78px] w-[78px] items-center justify-center rounded-full border-[3px] text-3xl transition-transform active:translate-y-1 active:scale-95 sm:h-[86px] sm:w-[86px] sm:text-4xl',
                (boosting || jumpZone?.needBoost) && 'pulse',
                jumpZone?.needBoost && !boosting ? 'border-amber-300 ring-4 ring-orange-500/70' : 'border-white/85',
              )}
              style={{
                background: jumpZone?.needBoost && !boosting
                  ? 'radial-gradient(circle at 32% 26%, #fff3a0, #ff6a14 62%, #6e1200 130%)'
                  : `radial-gradient(circle at 32% 26%, ${hex(NOS[nos].mid)}, ${hex(NOS[nos].outer)} 62%, #10163a 130%)`,
                boxShadow: jumpZone?.needBoost && !boosting
                  ? '0 6px 0 rgba(0,0,0,0.45), 0 0 42px #ff7a14'
                  : `0 6px 0 rgba(0,0,0,0.45), 0 0 ${boosting ? 38 : 18}px ${hex(NOS[nos].outer)}`,
              }}
            >
              🔥
            </button>
            <div className="glass-soft font-hud rounded-full px-3 py-0.5 text-[10px] font-bold tracking-[0.25em] text-white">NOS</div>
          </div>

          {mode !== 'spidey' && <Gauge tele={tele} />}

          {/* Action Hint */}
          {hint && !resp && !grid && !splitZone && (
            <div className="pointer-events-none absolute inset-x-0 bottom-[152px] flex justify-center sm:bottom-9">
              <div key={hint + bump} className="hint-pop font-display text-4xl text-yellow-300 sm:text-5xl" style={{ WebkitTextStroke: '2px #18113c', paintOrder: 'stroke fill', textShadow: '0 5px 0 #18113c' }}>
                {hint}
              </div>
            </div>
          )}

          {/* Grid Countdown */}
          {grid && (
            <div className="pointer-events-none absolute inset-x-0 top-[35%] flex flex-col items-center gap-2">
              <div className="glass-soft flex gap-3 rounded-full px-5 py-3">
                {[3, 2, 1].map((k) => (
                  <span key={k} className="h-9 w-9 rounded-full border-2 border-white/40 transition-all duration-150" style={{ background: grid <= k ? '#ff2d4d' : '#2b1a3f', boxShadow: grid <= k ? '0 0 24px #ff2d4d' : 'none' }} />
                ))}
              </div>
              <div className="glass-soft font-hud rounded-full px-4 py-1 text-xs font-bold tracking-[0.28em] text-white/90">SIAP DI GARIS START</div>
            </div>
          )}

          {/* Respawn Countdown */}
          {resp && (
            <div className="resp-vignette pointer-events-none absolute inset-0">
              <div className="absolute inset-x-0 bottom-[164px] flex justify-center px-3 sm:bottom-6">
                <div className="popin glass flex items-center gap-4 rounded-full py-2.5 pl-2.5 pr-6">
                  <div className="relative flex h-[72px] w-[72px] shrink-0 items-center justify-center">
                    <svg viewBox="0 0 120 120" className="absolute inset-0 h-full w-full -rotate-90">
                      <defs>
                        <linearGradient id="rg" x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0" stopColor="#fde047" /><stop offset="1" stopColor="#fb3b7a" />
                        </linearGradient>
                      </defs>
                      <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,.14)" strokeWidth="9" />
                      <circle key={resp.id} className="ring-run" cx="60" cy="60" r="52" fill="none" stroke="url(#rg)" strokeWidth="9" strokeLinecap="round" strokeDasharray="327" strokeDashoffset="0" style={{ animationDuration: `${RESPAWN_T}s` }} />
                    </svg>
                    <div key={resp.n} className="count-pop font-display text-5xl leading-none text-white" style={{ textShadow: '0 4px 0 #18113c' }}>{resp.n}</div>
                  </div>
                  <div className="text-left">
                    <div className="font-display text-2xl leading-tight text-white sm:text-3xl" style={{ WebkitTextStroke: '2px #18113c', paintOrder: 'stroke fill', textShadow: '0 4px 0 #18113c' }}>JATUH! RESPAWN…</div>
                    <div className="font-hud text-xs font-semibold text-white/75">Kembali ke aspal dalam {resp.n} detik</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* Floating Score / Stunt Popups */}
      {popup && screen === 'play' && !resp && (
        <div key={popup.id} className="popup pointer-events-none absolute inset-x-0 top-[30%] text-center font-display text-4xl sm:text-5xl" style={{ color: popup.color, WebkitTextStroke: '2.5px #18113c', paintOrder: 'stroke fill', textShadow: '0 6px 0 #18113c' }}>
          {popup.text}
        </div>
      )}

      {/* ================================================================= */}
      {/*  PUBLISH-READY HYPERCASUAL HOME MENU                              */}
      {/* ================================================================= */}
      {screen === 'menu' && (
        <div className="home-scrim absolute inset-0 flex flex-col justify-between p-4 sm:p-6">
          {/* Top Bar */}
          <div data-ui className="mx-auto flex w-full max-w-5xl items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setModal('levels')}
                className="glass-soft font-hud flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-bold text-yellow-300 transition hover:bg-white/15 active:scale-95 sm:text-sm"
              >
                <Star className="h-4 w-4 fill-yellow-300 text-yellow-300" />
                <span>{totalS}<span className="text-white/45">/{TOTAL_STARS}</span></span>
              </button>
              {best > 0 && (
                <div className="glass-soft font-hud hidden items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-bold text-amber-200 sm:flex sm:text-sm">
                  <Trophy className="h-3.5 w-3.5 text-amber-300" />
                  <span>{best}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={cycleSkinQuick}
                title="Ganti Warna Aspal (Aspal / Oranye HW / Candy)"
                className="glass-soft font-hud flex h-10 items-center gap-1.5 rounded-2xl px-3 text-xs font-bold text-white transition hover:bg-white/15 active:scale-90"
              >
                <span
                  className="h-4 w-4 rounded-full border border-white/60 shadow-inner"
                  style={{ background: SKIN_OPTS.find((s) => s.id === skin)?.dot }}
                />
                <span className="hidden sm:inline">{SKIN_OPTS.find((s) => s.id === skin)?.label}</span>
              </button>
              <button
                onClick={toggleMusicQuick}
                aria-label="Toggle Musik"
                className="glass-soft flex h-10 w-10 items-center justify-center rounded-2xl text-white transition hover:bg-white/15 active:scale-90"
              >
                {musik === 'off' ? <VolumeX className="h-5 w-5 text-white/55" /> : <Volume2 className="h-5 w-5 text-cyan-300" />}
              </button>
              <button
                onClick={() => setModal('settings')}
                aria-label="Pengaturan"
                className="glass-soft flex h-10 items-center gap-1.5 rounded-2xl px-3.5 text-xs font-bold text-white transition hover:bg-white/15 active:scale-90"
              >
                <Settings className="h-4 w-4 text-amber-300" />
                <span className="font-hud hidden sm:inline">ATUR</span>
              </button>
            </div>
          </div>

          {/* Upper-Center Hero Branding (leaves center open for live 3D voxel car!) */}
          <div className="pointer-events-none flex flex-col items-center text-center -mt-2 sm:-mt-4">
            <div className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-orange-300/55 bg-gradient-to-r from-orange-500/85 via-amber-500/85 to-rose-500/85 px-3.5 py-1 shadow-[0_6px_20px_rgba(255,106,20,.45)]">
              <Flame className="h-3.5 w-3.5 fill-yellow-200 text-yellow-200" />
              <span className="font-hud text-[10px] font-extrabold tracking-[0.24em] text-white sm:text-[11px]">
                HOT WHEELS • 20 TRACK EDITION
              </span>
            </div>
            <h1 className="logo font-display">
              SLING <span className="logo-accent">DRIFT</span>
            </h1>
            <div className="font-hud mt-2 flex flex-wrap items-center justify-center gap-2 text-[11px] font-bold text-white/85">
              <span className="rounded-full bg-black/40 px-2.5 py-0.5 backdrop-blur-sm">⚡ Boost Pad</span>
              <span className="rounded-full bg-black/40 px-2.5 py-0.5 backdrop-blur-sm">⑂ 2-Jalur (Lurus NOS / Belok Drift)</span>
              <span className="rounded-full bg-black/40 px-2.5 py-0.5 backdrop-blur-sm">🌀 Spiral &amp; Jump</span>
            </div>
          </div>

          {/* Spacer letting the live 3D showcase car breathe */}
          <div className="flex-1" />

          {/* Bottom-Center Publish-Ready Hypercasual Dock */}
          <div data-ui className="mx-auto flex w-full max-w-[440px] flex-col gap-2.5">
            {/* Active Selected Track Mini Card */}
            <button
              onClick={() => setModal('levels')}
              className={cn(
                'glass group flex w-full items-center gap-3 rounded-2xl p-2 text-left transition hover:brightness-110 active:scale-[0.98]',
                selDef.hotwheels && 'border-orange-400/70',
              )}
            >
              <div
                className="relative h-[58px] w-[78px] shrink-0 overflow-hidden rounded-xl border border-white/15"
                style={{ background: `linear-gradient(155deg, ${THEMES[selDef.theme].sky[0]}, ${THEMES[selDef.theme].sky[1]} 65%, #0d0824)` }}
              >
                <TrackMap def={selDef} accent={selDef.hotwheels ? '#ff8a1f' : '#fde047'} compact />
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-hud flex items-center gap-1.5 text-[10px] font-extrabold tracking-[0.2em] text-amber-300">
                  <span>LEVEL {selDef.id} / {LEVEL_COUNT}</span>
                  {selDef.hotwheels && <span className="rounded bg-orange-500 px-1.5 py-px text-[8px] text-white">HOT WHEELS 🔥</span>}
                </div>
                <div className="font-display truncate text-lg leading-tight text-white">{selDef.name}</div>
                <div className="font-hud mt-0.5 flex items-center gap-2 text-[10px] font-bold text-white/65">
                  <span>🏁 {selDef.dist}m</span>
                  <span>•</span>
                  <span className="text-yellow-300">{'★'.repeat(selStars)}{'☆'.repeat(3 - selStars)}</span>
                </div>
              </div>
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/10 text-white/80 group-hover:bg-amber-300 group-hover:text-slate-950">
                <ChevronRight className="h-5 w-5" />
              </div>
            </button>

            {/* Primary Giant Tactile PLAY Button */}
            <button
              onClick={() => startLevel(selDef.id)}
              className="cta pulse flex w-full items-center justify-center gap-2.5 rounded-2xl py-4 text-2xl tracking-wide sm:text-3xl"
            >
              <Play className="h-7 w-7 fill-current" />
              <span>MAIN LEVEL {selDef.id}</span>
            </button>

            {/* Clean 3-Tile Bottom Row */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setModal('levels')}
                className="btn-hw flex flex-col items-center justify-center gap-0.5 rounded-2xl px-2 py-2.5 text-white"
              >
                <Flag className="h-5 w-5" />
                <span className="font-display text-sm leading-none tracking-wide">20 LEVEL</span>
                <span className="font-hud text-[9px] font-bold text-amber-100/90">{clearedN}/20 TAMAT</span>
              </button>

              <button
                onClick={() => setModal('garage')}
                className="btn-tile flex flex-col items-center justify-center gap-0.5 rounded-2xl px-2 py-2.5 text-white"
              >
                <Car className="h-5 w-5 text-cyan-300" />
                <span className="font-display text-sm leading-none tracking-wide">GARASI</span>
                <span className="font-hud max-w-full truncate text-[9px] font-bold text-white/70">{info.short}</span>
              </button>

              <button
                onClick={startQuickPlay}
                className="btn-tile flex flex-col items-center justify-center gap-0.5 rounded-2xl px-2 py-2.5 text-white"
              >
                <Sparkles className="h-5 w-5 text-amber-300" />
                <span className="font-display text-sm leading-none tracking-wide">BEBAS</span>
                <span className="font-hud text-[9px] font-bold text-white/70">QUICK RACE</span>
              </button>
            </div>

            {/* Subtle Desktop Key Hint */}
            <div className="font-hud pointer-events-none hidden items-center justify-center gap-3 pt-0.5 text-[10px] font-semibold text-white/55 sm:flex">
              <span><kbd className="rounded bg-white/15 px-1.5 py-0.5 text-white">KLIK</kbd> Drift / Belok</span>
              <span>•</span>
              <span><kbd className="rounded bg-white/15 px-1.5 py-0.5 text-white">SPACE</kbd> NOS</span>
              <span>•</span>
              <span><kbd className="rounded bg-white/15 px-1.5 py-0.5 text-white">C</kbd> Kamera</span>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/*  MODAL 1: PILIH 20 LEVEL TERBAIK + HOT WHEELS                     */}
      {/* ================================================================= */}
      {screen === 'menu' && modal === 'levels' && (
        <div data-ui className="modal-scrim absolute inset-0 z-30 flex flex-col">
          {/* Header */}
          <div className="mx-auto flex w-full max-w-6xl items-center gap-3 px-4 pt-4 pb-2 sm:px-6 sm:pt-5">
            <button onClick={() => setModal(null)} className="btn-ghost flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl">
              <X className="h-5 w-5" />
            </button>
            <div className="min-w-0 flex-1">
              <div className="font-display text-2xl leading-none text-white sm:text-3xl">20 LINTASAN TERBAIK</div>
              <div className="font-hud mt-0.5 text-[10px] font-bold tracking-[0.22em] text-amber-200/85">
                HOT WHEELS STUNT • BOOST PAD • 2-JALUR SPLIT
              </div>
            </div>
            <div className="glass-soft font-hud hidden items-center gap-1.5 rounded-2xl px-3.5 py-2 text-sm font-bold text-yellow-300 sm:flex">
              <Star className="h-4 w-4 fill-yellow-300" /> {totalS}/{TOTAL_STARS}
            </div>
            <button
              onClick={() => { if (window.confirm('Reset semua bintang & rekor level?')) setProgress(resetProgress()); }}
              className="btn-ghost flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-white/70"
              title="Reset Progres"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          {/* Filter Pills */}
          <div className="mx-auto flex w-full max-w-6xl items-center gap-2 px-4 pb-3 sm:px-6">
            {([
              ['all', '🏁 Semua (20)'],
              ['hotwheels', '🔥 Hot Wheels (8)'],
              ['split', '⑂ 2-Jalur Split'],
            ] as [LevelFilter, string][]).map(([id, label]) => (
              <button
                key={id}
                onClick={() => setLevelFilter(id)}
                className={cn(
                  'font-hud rounded-full border px-3.5 py-1.5 text-xs font-bold transition active:scale-95',
                  levelFilter === id
                    ? 'border-amber-300 bg-gradient-to-r from-amber-300 to-orange-400 text-slate-950 shadow'
                    : 'border-white/15 bg-white/[0.07] text-white/75 hover:bg-white/15',
                )}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Grid 20 Track */}
          <div className="thin-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-6 sm:px-6">
            <div className="mx-auto max-w-6xl space-y-5">
              {levelFilter === 'all' ? (
                TIERS.map((tier) => (
                  <div key={tier.id}>
                    <div className="mb-2.5 flex items-center gap-2.5">
                      <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-white/10 text-lg">{tier.icon}</span>
                      <div>
                        <div className="font-display text-lg leading-none text-white">{tier.name}</div>
                        <div className="font-hud text-[10px] font-bold tracking-[0.2em]" style={{ color: tier.accent }}>{tier.sub}</div>
                      </div>
                      <span className="h-px flex-1 bg-gradient-to-r from-white/20 to-transparent" />
                    </div>
                    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-5">
                      {LEVELS.filter((l) => l.tier === tier.id).map((def) => (
                        <LevelCard
                          key={def.id}
                          def={def}
                          earned={progress.stars[def.id] ?? 0}
                          best={progress.best[def.id] ?? 0}
                          selected={selectedLevel === def.id}
                          onPick={(id) => startLevel(id)}
                        />
                      ))}
                    </div>
                  </div>
                ))
              ) : (
                <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
                  {filteredLevels.map((def) => (
                    <LevelCard
                      key={def.id}
                      def={def}
                      earned={progress.stars[def.id] ?? 0}
                      best={progress.best[def.id] ?? 0}
                      selected={selectedLevel === def.id}
                      onPick={(id) => startLevel(id)}
                    />
                  ))}
                </div>
              )}

              {/* Legenda Minimap */}
              <div className="glass-soft font-hud flex flex-wrap items-center justify-center gap-x-4 gap-y-1 rounded-2xl px-4 py-2.5 text-[10px] font-bold text-white/70">
                <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-emerald-400" /> START</span>
                <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-amber-300" /> FINISH</span>
                <span className="flex items-center gap-1.5"><span className="h-1.5 w-4 rounded-full bg-cyan-400" /> BOOST / LURUS NOS</span>
                <span className="flex items-center gap-1.5"><span className="h-1.5 w-4 rounded-full bg-orange-400" /> CABANG BELOK DRIFT</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/*  MODAL 2: GARASI 3D                                               */}
      {/* ================================================================= */}
      {screen === 'menu' && modal === 'garage' && (
        <div data-ui className="modal-scrim absolute inset-0 z-30 flex items-center justify-center p-3 sm:p-6">
          <div className="popin glass flex max-h-[88vh] w-full max-w-2xl flex-col overflow-hidden rounded-[1.8rem]">
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-3.5">
              <div>
                <div className="font-display text-2xl leading-none text-white">GARASI MOBIL</div>
                <div className="font-hud mt-0.5 text-[10px] font-bold tracking-[0.24em] text-cyan-300">{GARAGE.length} MOBIL VOXEL SIAP BALAP</div>
              </div>
              <button onClick={() => setModal(null)} className="btn-ghost flex h-10 w-10 items-center justify-center rounded-xl"><X className="h-5 w-5" /></button>
            </div>
            <div className="thin-scroll flex-1 overflow-y-auto p-4 sm:p-5">
              <GaragePanel car={car} onPick={pickCar} thumbs={thumbs} />
            </div>
            <div className="border-t border-white/10 p-3.5">
              <button onClick={() => setModal(null)} className="cta w-full rounded-xl py-3 text-xl">✓ PAKAI {info.short.toUpperCase()}</button>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/*  MODAL 3: PENGATURAN RINGKAS                                      */}
      {/* ================================================================= */}
      {screen === 'menu' && modal === 'settings' && (
        <div data-ui className="modal-scrim absolute inset-0 z-30 flex items-center justify-center p-3 sm:p-6">
          <div className="popin glass flex max-h-[88vh] w-full max-w-md flex-col overflow-hidden rounded-[1.8rem]">
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-3.5">
              <div className="font-display text-2xl leading-none text-white">PENGATURAN</div>
              <button onClick={() => setModal(null)} className="btn-ghost flex h-10 w-10 items-center justify-center rounded-xl"><X className="h-5 w-5" /></button>
            </div>
            <div className="px-4 pt-3">
              <div className="font-hud grid grid-cols-3 gap-1 rounded-2xl bg-black/35 p-1">
                {([
                  ['race', '🏁 Balap'],
                  ['look', '🎨 Visual'],
                  ['audio', '🔊 Audio & NOS'],
                ] as [SettingsTab, string][]).map(([id, label]) => (
                  <button
                    key={id}
                    onClick={() => setSettingsTab(id)}
                    className={cn('rounded-xl py-2 text-xs font-bold transition', settingsTab === id ? 'bg-gradient-to-b from-amber-300 to-orange-400 text-slate-950 shadow' : 'text-white/65 hover:text-white')}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
            <div className="thin-scroll flex-1 space-y-4 overflow-y-auto p-4">
              {settingsTab === 'race' && (
                <>
                  <Section label="🎮 MODE QUICK PLAY">
                    {MODES.map((m) => <Choice key={m.id} active={mode === m.id} onClick={() => pickMode(m.id)} icon={m.icon} label={m.label} sub={m.sub} />)}
                  </Section>
                  {mode !== 'spidey' && (
                    <Section label="🤖 LAWAN BOT" cols={2}>
                      {BOTS.map((b) => <Choice key={b.id} active={bot === b.id} onClick={() => pickBot(b.id)} icon={b.icon} label={b.label} sub={b.sub} badge={b.badge} />)}
                    </Section>
                  )}
                  <Section label="⚡ KECEPATAN">
                    {SPEED_OPTS.map((o) => <Choice key={o.id} active={speed === o.id} onClick={() => pickSpeed(o.id)} icon={o.icon} label={o.label} sub={o.sub} />)}
                  </Section>
                  {mode !== 'spidey' && (
                    <Section label="🏁 JARAK QUICK PLAY" cols={2}>
                      {GOALS.map((g) => <Choice key={g.id} active={goal === g.id} onClick={() => pickGoal(g.id)} icon={g.icon} label={g.label} sub={g.sub} />)}
                    </Section>
                  )}
                </>
              )}
              {settingsTab === 'look' && (
                <>
                  <Section label="🎥 KAMERA">
                    {([0, 1, 2] as CamMode[]).map((m) => <Choice key={m} active={cam === m} onClick={() => pickCam(m)} icon={CAM_ICON[m]} label={CAM_NAMES[m]} />)}
                  </Section>
                  <Section label="🛣️ WARNA ASPAL (SEMUA LEVEL)">
                    {SKIN_OPTS.map((s) => <Choice key={s.id} active={skin === s.id} onClick={() => pickSkin(s.id)} dot={s.dot} label={s.label} sub={s.sub} />)}
                  </Section>
                  <Section label="🧱 PINGGIRAN JALAN">
                    {EDGES.map((e) => <Choice key={e.id} active={edge === e.id} onClick={() => pickEdge(e.id)} icon={e.icon} label={e.label} />)}
                  </Section>
                  <Section label="✨ EFEK RUNTUH" cols={2}>
                    {FXS.map((f) => <Choice key={f.id} active={fx === f.id} onClick={() => pickFx(f.id)} icon={f.icon} label={f.label} sub={f.sub} />)}
                  </Section>
                  <Section label="🛤️ MUNCUL JALAN" cols={2}>
                    {ROADBUILDS.map((r) => <Choice key={r.id} active={roadBuild === r.id} onClick={() => pickRoad(r.id)} icon={r.icon} label={r.label} sub={r.sub} />)}
                  </Section>
                </>
              )}
              {settingsTab === 'audio' && (
                <>
                  <Section label="🎵 MUSIK">
                    {MUSICS.map((m) => <Choice key={m.id} active={musik === m.id} onClick={() => pickMusic(m.id)} icon={m.icon} label={m.label} />)}
                  </Section>
                  <Section label="💨 WARNA API NOS">
                    {NOSS.map((n) => (
                      <Choice key={n.id} active={nos === n.id} onClick={() => pickNos(n.id)} label={n.label} dot={`radial-gradient(circle at 30% 30%, ${hex(NOS[n.id].mid)}, ${hex(NOS[n.id].outer)})`} />
                    ))}
                  </Section>
                  <Section label="🔥 KONTROL NOS" cols={2}>
                    <Choice active={nosFire === 'hold'} onClick={() => pickNosFire('hold')} icon="💨" label="Tahan" sub="Lepas = mati" />
                    <Choice active={nosFire === 'toggle'} onClick={() => pickNosFire('toggle')} icon="🔒" label="Toggle" sub="Tekan on/off" />
                  </Section>
                </>
              )}
            </div>
            <div className="border-t border-white/10 p-3.5">
              <button onClick={() => setModal(null)} className="cta w-full rounded-xl py-2.5 text-lg">SELESAI</button>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/*  LAYAR HASIL / PODIUM                                             */}
      {/* ================================================================= */}
      {screen === 'over' && levelEnd && (
        <div className="modal-scrim absolute inset-0 z-30 flex flex-col items-center justify-center gap-5 p-4">
          <div className="popin glass relative w-full max-w-sm rounded-[2rem] px-6 pb-6 pt-12 text-center">
            <div className={cn('absolute -top-5 left-1/2 -translate-x-1/2 -rotate-2 whitespace-nowrap rounded-2xl px-6 py-1.5 text-xl shadow-[0_5px_0_#18113c] sm:text-2xl', levelEnd.finished ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950' : 'bg-gradient-to-r from-rose-500 to-orange-400 text-white')}>
              {levelEnd.finished ? (levelEnd.earned >= 3 ? '⭐ SEMPURNA!' : '🏁 LEVEL CLEAR!') : '⛔ BELUM FINISH'}
            </div>
            <div className="font-hud text-[10px] font-bold tracking-[0.35em] text-amber-200/85">LEVEL {levelEnd.id} / {LEVEL_COUNT}</div>
            <div className="font-display mt-0.5 text-3xl leading-tight text-white" style={{ textShadow: '0 3px 0 #18113c' }}>{levelEnd.name}</div>
            <div className="mt-2 flex items-center justify-center gap-3">
              {[0, 1, 2].map((i) => (
                <span key={i} className={cn('star-pop font-display text-6xl leading-none', i < levelEnd.earned ? 'star-on' : 'text-white/15')} style={{ animationDelay: `${0.2 + i * 0.2}s` }}>★</span>
              ))}
            </div>
            <div className="font-hud mt-3 text-[10px] font-bold tracking-[0.4em] text-white/50">SKOR AKHIR</div>
            <div className="font-display text-7xl leading-none text-white" style={{ textShadow: '0 6px 0 #18113c' }}>{end?.kind === 'race' ? end.r.score : 0}</div>
            <div className="font-hud mt-3 flex items-center justify-center gap-2 text-[10px] font-bold text-white/55">
              <span className={levelEnd.finished ? 'text-yellow-300' : ''}>⭐ Finish</span>
              <span>•</span>
              <span className={levelEnd.finished && levelFalls <= 2 ? 'text-yellow-300' : ''}>⭐⭐ ≤2× Jatuh</span>
              <span>•</span>
              <span className={levelEnd.earned >= 3 ? 'text-yellow-300' : ''}>⭐⭐⭐ 0× Jatuh</span>
            </div>
            {levelEnd.newBest && <div className="font-hud mt-2.5 inline-block rounded-full bg-yellow-300/20 px-4 py-1 text-xs font-bold text-yellow-200">⭐ REKOR BARU! ⭐</div>}
            {levelEnd.finished && levelEnd.id >= LEVEL_COUNT && <div className="font-hud mt-2.5 rounded-full bg-amber-300/20 px-4 py-1 text-xs font-bold text-amber-200">👑 JUARA SEMUA 20 LINTASAN!</div>}
          </div>

          <div data-ui className="flex w-full max-w-sm items-stretch gap-2.5">
            <button onClick={toMenu} className="btn-tile font-display flex-1 rounded-2xl py-3.5 text-lg text-white">☰ MENU</button>
            {levelEnd.finished ? (
              <>
                <button onClick={() => startLevel(levelEnd.id)} className="btn-tile font-display flex-1 rounded-2xl py-3.5 text-lg text-amber-200">↻ ULANG</button>
                {levelEnd.id < LEVEL_COUNT
                  ? <button onClick={() => startLevel(levelEnd.id + 1)} className="cta pulse font-display flex-[1.45] rounded-2xl py-3.5 text-xl">LV {levelEnd.id + 1} ▶</button>
                  : <button onClick={toMenu} className="cta pulse font-display flex-[1.45] rounded-2xl py-3.5 text-xl">🏆 TAMAT!</button>}
              </>
            ) : (
              <button onClick={() => startLevel(levelEnd.id)} className="cta pulse font-display flex-[1.6] rounded-2xl py-3.5 text-2xl">↻ COBA LAGI</button>
            )}
          </div>
        </div>
      )}

      {screen === 'over' && !levelEnd && (
        <div className="modal-scrim absolute inset-0 z-30 flex flex-col items-center justify-center gap-5 p-4">
          <div className="popin glass relative w-full max-w-sm rounded-[2rem] px-6 pb-6 pt-10 text-center">
            <div className="absolute -top-5 left-1/2 -translate-x-1/2 -rotate-2 whitespace-nowrap rounded-2xl bg-gradient-to-r from-rose-500 to-orange-400 px-6 py-1.5 text-2xl text-white shadow-[0_5px_0_#18113c]">{title}</div>
            {place && <div className="font-display text-5xl text-amber-300" style={{ textShadow: '0 4px 0 #18113c' }}>{place}</div>}
            <div className="font-hud mt-1 text-[10px] font-bold tracking-[0.35em] text-white/55">SKOR</div>
            <div className="font-display text-7xl leading-none text-white" style={{ textShadow: '0 6px 0 #18113c' }}>{sc}</div>
            <div className="font-hud mt-4 grid grid-cols-2 gap-2">
              <div className="rounded-2xl bg-white/10 px-3 py-2"><div className="text-[10px] font-bold tracking-[0.22em] text-white/50">TERBAIK</div><div className="text-2xl font-bold text-yellow-300">🏆 {best}</div></div>
              {stats.map(([k, v]) => (
                <div key={k} className="rounded-2xl bg-white/10 px-3 py-2"><div className="text-[10px] font-bold tracking-[0.22em] text-white/50">{k}</div><div className="text-2xl font-bold text-rose-300">{v}×</div></div>
              ))}
            </div>
            {newBest && <div className="font-hud mt-3 inline-block rounded-full bg-yellow-300/20 px-4 py-1 text-xs font-bold text-yellow-200">⭐ NEW BEST! ⭐</div>}
          </div>
          <div data-ui className="flex w-full max-w-sm items-stretch gap-3">
            <button onClick={toMenu} className="btn-tile font-display flex-1 rounded-2xl py-3.5 text-xl text-white">☰ MENU</button>
            <button onClick={startQuickPlay} className="cta pulse font-display flex-[1.55] rounded-2xl py-3.5 text-2xl">↻ MAIN LAGI</button>
          </div>
        </div>
      )}
    </div>
  );
}
