import * as THREE from 'three';
import { CARS as LIB, CATEGORY_LABEL, type Category } from './carlib/cars';
import type { CarBuild, Decal, PartKind } from './carlib/voxel/CarCtx';
import type { RawMesh } from './carlib/voxel/mesher';
import { meshSmooth } from './carlib/voxel/smooth';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { GLOW, kindOf, P } from './carlib/voxel/palette';
import type { Hex } from './carlib/voxel/Vox';
import { buildVoxelChassis, buildVoxelHeadlightRig, voxelSkinById, type VoxelBeam } from './voxelbmw';

export { CATEGORY_LABEL };
export type { Category };

/** Ukuran 1 voxel (unit dunia, sebelum skala grup mobil 0.85). */
export const VOXEL = 0.095;
/** Kerapatan mesh halus: S=2 ≈ 2× lebih sedikit segitiga dari S=3, tetap membulat berkat blur. */
const SMOOTH_Q = { S: 2, passes: 2 };
export const DEFAULT_CAR = 'vx-most-wanted';

// ───────────────────────── katalog garasi ─────────────────────────
export type VoiceKey = 'v10' | 'v8' | 'v12' | 'i6' | 'flat6' | 'rotary' | 'i4' | 'i4t' | 'i4hi' | 'diesel' | 'turbine' | 'boxer';

const META: Record<string, { voice: VoiceKey; engine: string }> = {
  m3gtr: { voice: 'v8', engine: 'V8 • GTR' },
  slr: { voice: 'v8', engine: 'V8 Supercharged' },
  db9: { voice: 'v12', engine: 'V12 • GT' },
  viper: { voice: 'v10', engine: 'V10 • NA' },
  corvette: { voice: 'v8', engine: 'V8 • LS' },
  gallardo: { voice: 'v10', engine: 'V10 • 8.000 rpm' },
  clk: { voice: 'v8', engine: 'V8 • AMG' },
  mustang: { voice: 'v8', engine: 'V8 • Muscle' },
  evo: { voice: 'i4t', engine: 'I4 Turbo' },
  cayman: { voice: 'flat6', engine: 'Flat-6' },
  eclipse: { voice: 'i6', engine: 'V6 • GT' },
  rx8: { voice: 'rotary', engine: 'Rotary' },
  supra: { voice: 'i6', engine: 'I6 Twin-Turbo' },
  is300: { voice: 'i6', engine: 'I6 • 2JZ' },
  golf: { voice: 'i4t', engine: 'I4 Turbo' },
  'razor-mustang': { voice: 'v8', engine: 'V8 • Muscle' },
  police: { voice: 'v8', engine: 'V8 • Interceptor' },
  cross: { voice: 'v8', engine: 'V8 • Pursuit' },
  ae86: { voice: 'i4hi', engine: 'I4 • 7.8K rpm' },
  fd3s: { voice: 'rotary', engine: 'Rotary Turbo' },
  taxi: { voice: 'v8', engine: 'V8 • Sedan' },
  bluebird: { voice: 'i4', engine: 'I4 • Taksi' },
  firetruck: { voice: 'diesel', engine: 'Diesel Turbo' },
  schoolbus: { voice: 'diesel', engine: 'Diesel' },
  tank: { voice: 'turbine', engine: 'Turbin Gas' },
  rally: { voice: 'i4t', engine: 'Boxer Turbo' },
  mrbean: { voice: 'boxer', engine: 'I4 • 1000cc' },
  'mrbean-chair': { voice: 'boxer', engine: 'I4 • 1000cc' },
};

export interface GarageCar {
  id: string;
  name: string;
  short: string;
  driver: string;
  rank?: number;
  bounty?: number;
  category: Category;
  /** kecepatan, akselerasi, handling (1-10) */
  stats: [number, number, number];
  desc: string;
  engine: string;
  voice: VoiceKey;
}

// ───────────────────────── 8 SKIN VOXEL BMW (dari asset customizable-voxel-bmw) ─────────────────────────
export const VOXEL_GARAGE: GarageCar[] = [
  { id: 'vx-most-wanted', name: "BMW M3 GTR 'Most Wanted'", short: 'M3 GTR MW', driver: 'Razor • Hero', category: 'special', stats: [9, 9, 8], desc: 'Bodi voxel BMW M3 GTR E46 ikonik: silver + livery biru royal, GT wing, grille ginjal. Lampu sorot 100% menyala!', engine: 'V8 • GTR', voice: 'v8' },
  { id: 'vx-sakura-cute', name: 'BMW M3 GTR Sakura', short: 'M3 Sakura', driver: 'Cute Edition', category: 'special', stats: [9, 8, 8], desc: 'M3 GTR voxel putih susu dengan livery pink pastel & velg putih — manis tapi tetap ngebut!', engine: 'V8 • GTR', voice: 'v8' },
  { id: 'vx-sonny-gti', name: 'VW Golf GTI Sonny #15', short: 'GTI #15', driver: 'Sonny • Blacklist', category: 'special', stats: [8, 8, 9], desc: 'Golf GTI voxel Sonny: putih, stripe biru, decal merah #15. Handling lincah seperti standarnya!', engine: 'I4 Turbo', voice: 'i4t' },
  { id: 'vx-takumi-ae86', name: 'AE86 Trueno Panda', short: 'AE86', driver: 'Takumi • Initial D', category: 'special', stats: [7, 8, 10], desc: 'AE86 Trueno voxel panda putih-hitam dengan pop-up headlights menyala & underglow kuning!', engine: 'I4 • 7.8K rpm', voice: 'i4hi' },
  { id: 'vx-razor-mustang', name: 'Mustang GT Razor #1', short: 'Mustang R1', driver: 'Razor • #1', category: 'special', stats: [10, 9, 7], desc: 'Mustang GT voxel hitam pekat dengan livery api kuning-merah — mobil #1 Blacklist yang buas!', engine: 'V8 • Muscle', voice: 'v8' },
  { id: 'vx-rwb-nakai-green', name: 'RWB 964 Nakai Green', short: 'RWB Hijau', driver: 'Akira Nakai', category: 'special', stats: [8, 8, 9], desc: 'RWB 964 voxel hijau signal dengan widebody rapi & velg silver — karya tangan Akira Nakai!', engine: 'Flat-6', voice: 'flat6' },
  { id: 'vx-rwb-oren-biru', name: 'RWB 964 Oren Biru', short: 'RWB Oren', driver: 'Gulf Edition', category: 'special', stats: [8, 9, 9], desc: 'RWB 964 voxel oren cerah dengan strip biru Gulf — livery balap paling nazar di grid!', engine: 'Flat-6', voice: 'flat6' },
  { id: 'vx-rwb-biru-oren', name: 'RWB 964 Biru Oren', short: 'RWB Biru', driver: 'Gulf Edition', category: 'special', stats: [8, 9, 9], desc: 'RWB 964 voxel biru Gulf dengan aksen oranye menyala — widebody voxel yang agresif!', engine: 'Flat-6', voice: 'flat6' },
];

export const GARAGE: GarageCar[] = [
  ...LIB.map((c) => ({
    id: c.id, name: c.name, short: c.short, driver: c.driver, rank: c.rank, bounty: c.bounty,
    category: c.category, stats: c.stats, desc: c.desc,
    engine: META[c.id]?.engine ?? 'I4',
    voice: META[c.id]?.voice ?? 'i4',
  })),
  ...VOXEL_GARAGE,
];
export const CATEGORIES: Category[] = ['blacklist', 'bonus', 'police', 'initiald', 'city', 'special'];
export const carInfo = (id: string) => GARAGE.find((c) => c.id === id) ?? GARAGE.find((c) => c.id === DEFAULT_CAR) ?? GARAGE[0];
export const validCar = (id: string | null | undefined) => (id && GARAGE.some((c) => c.id === id) ? id : DEFAULT_CAR);
export const voiceOf = (id: string): VoiceKey => carInfo(id).voice;

// ───────────────────────── material ─────────────────────────
export interface CarMats {
  std: THREE.Material;
  glow: THREE.MeshBasicMaterial;
  sirenR: THREE.MeshBasicMaterial;
  sirenB: THREE.MeshBasicMaterial;
  glass: THREE.Material;
  /** semua material milik set ini (untuk efek hantu) */
  list: THREE.Material[];
  col: (c: number) => THREE.Material;
  /** array slot material (sesuai group geometry: 0 cat, 1 lampu, 2/3 sirene, 4 kaca) */
  slots: THREE.Material[];
}

export function makeMats(cheap = false): CarMats {
  // cat mengkilap ala hypercasual: kasar rendah → highlight lembut di bodi membulat
  // cheap (bot): Lambert tanpa highlight PBR → jauh lebih ringan di GPU, tetap mulus
  const std: THREE.Material = cheap ? new THREE.MeshLambertMaterial({ vertexColors: true }) : new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.34, metalness: 0.1 });
  const glow = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });
  const sirenR = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });
  const sirenB = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });
  const glass: THREE.Material = cheap ? new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0x1a2a46 }) : new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.08, metalness: 0.45, emissive: 0x1a2a46, emissiveIntensity: 0.55 });
  const list: THREE.Material[] = [std, glow, sirenR, sirenB, glass];
  const cache = new Map<number, THREE.Material>();
  const col = (c: number) => {
    let m = cache.get(c);
    if (!m) { m = cheap ? new THREE.MeshLambertMaterial({ color: c }) : new THREE.MeshStandardMaterial({ color: c, roughness: 0.42, metalness: 0.12 }); cache.set(c, m); list.push(m); }
    return m;
  };
  return { std, glow, sirenR, sirenB, glass, list, col, slots: [std, glow, sirenR, sirenB, glass] };
}
/** Material milik mobil pemain (tidak transparan). */
export const SHARED_MATS = makeMats();

export function tickSirens(mats: CarMats, t: number) {
  const ph = Math.floor(t * 8) % 8;
  mats.sirenR.color.setScalar(ph === 0 || ph === 2 ? 1 : 0.12);
  mats.sirenB.color.setScalar(ph === 4 || ph === 6 ? 1 : 0.12);
}

// ───────────────────────── geometri ─────────────────────────
function rawToGeometry(m: RawMesh) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(m.positions, 3));
  g.setAttribute('normal', new THREE.BufferAttribute(m.normals, 3));
  g.setAttribute('color', new THREE.BufferAttribute(m.colors, 3));
  for (const gr of m.groups) g.addGroup(gr.start, gr.count, gr.kind);
  g.computeBoundingBox();
  g.computeBoundingSphere();
  return g;
}

// ───────────────────────── decal (stiker teks) ─────────────────────────
interface DecalPlane { position: [number, number, number]; rotationY: number }
interface DecalAsset { width: number; height: number; planes: DecalPlane[]; texture: THREE.CanvasTexture }

function decalTexture(d: Decal): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  const H = 160;
  const W = Math.max(8, Math.round((H * d.len) / d.h));
  canvas.width = W; canvas.height = H;
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  const font = d.font ?? '"Russo One", "Chakra Petch", "Arial Black", Impact, sans-serif';
  const draw = () => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, W, H);
    const sub = 0.56, gap = 0.06;
    const measure = (s: number) => {
      ctx.font = `900 ${s}px ${font}`;
      let w = ctx.measureText(d.text).width;
      if (d.sub) { ctx.font = `900 ${s * sub}px ${font}`; w += ctx.measureText(d.sub).width + s * gap; }
      return w;
    };
    let size = H * 0.84;
    let w = measure(size);
    if (w > W * 0.97) { size *= (W * 0.97) / w; w = measure(size); }
    let x = (W - w) / 2;
    const base = H / 2 + size * 0.36;
    ctx.fillStyle = d.color;
    ctx.font = `900 ${size}px ${font}`;
    ctx.fillText(d.text, x, base);
    if (d.sub) {
      x += ctx.measureText(d.text).width + size * gap;
      ctx.font = `900 ${size * sub}px ${font}`;
      ctx.fillText(d.sub, x, base);
    }
    tex.needsUpdate = true;
  };
  draw();
  if (document.fonts) {
    document.fonts.load(`900 64px ${font}`, d.text + (d.sub ?? '')).then(draw).catch(() => {});
    document.fonts.ready.then(draw).catch(() => {});
  }
  return tex;
}

function makeDecal(d: Decal, build: CarBuild, off: [number, number, number]): DecalAsset {
  const vox = build.vox, hw = build.hw;
  const face = d.face ?? 'side';
  const y0 = Math.floor(d.y - d.h / 2);
  const y1 = Math.floor(d.y + d.h / 2 - 0.001);
  const yw = (d.y - off[1]) * VOXEL;
  const planes: DecalPlane[] = [];
  if (face === 'side') {
    const zc = d.z ?? 0;
    const z0 = Math.floor(zc - d.len / 2);
    const z1 = Math.floor(zc + d.len / 2 - 0.001);
    let xr = -Infinity, xl = Infinity;
    for (let y = y0; y <= y1; y++)
      for (let z = z0; z <= z1; z++) {
        const a = vox.maxX(y, z), b = vox.minX(y, z);
        if (a !== null && a <= hw) xr = Math.max(xr, a);
        if (b !== null && b >= -hw) xl = Math.min(xl, b);
      }
    const zw = (zc - off[2]) * VOXEL;
    if (d.sides !== 'left' && isFinite(xr)) planes.push({ position: [(xr + 1 - off[0]) * VOXEL + 0.014, yw, zw], rotationY: Math.PI / 2 });
    if (d.sides !== 'right' && isFinite(xl)) planes.push({ position: [(xl - off[0]) * VOXEL - 0.014, yw, zw], rotationY: -Math.PI / 2 });
  } else {
    const xc = d.x ?? 0.5;
    const x0 = Math.floor(xc - d.len / 2);
    const x1 = Math.floor(xc + d.len / 2 - 0.001);
    let zf = -Infinity, zr = Infinity;
    for (let y = y0; y <= y1; y++)
      for (let x = x0; x <= x1; x++) {
        const a = vox.maxZ(x, y), b = vox.minZ(x, y);
        if (a !== null) zf = Math.max(zf, a);
        if (b !== null) zr = Math.min(zr, b);
      }
    const xw = (xc - off[0]) * VOXEL;
    if (face === 'front' && isFinite(zf)) planes.push({ position: [xw, yw, (zf + 1 - off[2]) * VOXEL + 0.014], rotationY: 0 });
    if (face === 'rear' && isFinite(zr)) planes.push({ position: [xw, yw, (zr - off[2]) * VOXEL - 0.014], rotationY: Math.PI });
  }
  return { width: d.len * VOXEL, height: d.h * VOXEL, planes, texture: decalTexture(d) };
}

// ───────────────────────── aset mobil (di-cache per id) ─────────────────────────
export interface WheelPlace { x: number; y: number; z: number; d: number; w: number; front: boolean; side: number; rim: number; tire: number }
export interface CarAsset {
  id: string;
  geometry: THREE.BufferGeometry;
  parts: { geometry: THREE.BufferGeometry; pivot: [number, number, number]; kind: PartKind; dir: number }[];
  decals: DecalAsset[];
  wheels: WheelPlace[];
  length: number; width: number; height: number;
  /** ujung belakang (z negatif), roda belakang (untuk asap & bekas ban) */
  rearZ: number; rearWheel: { x: number; z: number };
  siren: boolean;
  swatches: string[];
}

const SKIP = new Set<Hex>([P.TIRE, P.ARCH, P.GLASS, P.GLASS_HI, P.PLATE, P.CHROME, P.DARK, P.SIREN_R, P.SIREN_B, ...GLOW]);
const hexStr = (c: number) => '#' + c.toString(16).padStart(6, '0');
const cache = new Map<string, CarAsset>();

function buildAsset(id: string): CarAsset {
  const spec = LIB.find((c) => c.id === id)!;
  const build = spec.build();
  const b = build.vox.bounds();
  const min = [...b.min], max = [...b.max];
  for (const w of build.wheels) {
    min[0] = Math.min(min[0], -(w.hw + 1)); max[0] = Math.max(max[0], w.hw + 1);
    min[2] = Math.min(min[2], w.zc); max[2] = Math.max(max[2], w.zc + w.n - 1);
  }
  const off: [number, number, number] = [(min[0] + max[0] + 1) / 2, 0, (min[2] + max[2] + 1) / 2];
  const glassSet = new Set<Hex>(build.glass);
  const kind = (c: Hex) => (glassSet.has(c) ? 4 : kindOf(c));
  const geometry = rawToGeometry(meshSmooth(build.vox, VOXEL, off, kind, 5, SMOOTH_Q));
  const parts = build.parts.map((p) => ({
    geometry: rawToGeometry(meshSmooth(p.vox, VOXEL, off, kind, 5, SMOOTH_Q)),
    pivot: [(p.pivot[0] - off[0]) * VOXEL, (p.pivot[1] - off[1]) * VOXEL, (p.pivot[2] - off[2]) * VOXEL] as [number, number, number],
    kind: p.kind,
    dir: p.dir ?? 1,
  }));
  const decals = build.decals.map((d) => makeDecal(d, build, off));

  const zmax = Math.max(...build.wheels.map((w) => w.zc), -Infinity);
  const wheels: WheelPlace[] = [];
  for (const w of build.wheels) {
    for (const side of [1, -1]) {
      wheels.push({
        x: (side > 0 ? w.hw + 1 - off[0] : -w.hw - off[0]) * VOXEL,
        y: (w.n / 2) * VOXEL,
        z: (w.zc + w.n / 2 - off[2]) * VOXEL,
        d: w.n * VOXEL, w: 2 * VOXEL * 0.96,
        front: w.zc === zmax, side, rim: w.rim, tire: w.tire,
      });
    }
  }
  const rearW = build.wheels.length ? build.wheels.reduce((m, w) => (w.zc < m.zc ? w : m)) : null;

  let top = max[1];
  build.parts.forEach((p) => { top = Math.max(top, p.vox.bounds().max[1]); });
  const counts = new Map<Hex, number>();
  build.vox.forEach((_x, _y, _z, c) => { if (!SKIP.has(c)) counts.set(c, (counts.get(c) ?? 0) + 1); });
  const swatches = [...counts.entries()].filter(([, n]) => n > 6).sort((a, c) => c[1] - a[1]).slice(0, 4).map(([c]) => hexStr(c));
  let siren = build.siren;
  build.vox.forEach((_x, _y, _z, c) => { if (c === P.SIREN_B || c === P.SIREN_R) siren = true; });

  const asset: CarAsset = {
    id, geometry, parts, decals, wheels,
    length: (max[2] - min[2] + 1) * VOXEL,
    width: (max[0] - min[0] + 1 + 2) * VOXEL,
    height: (top + 1) * VOXEL,
    rearZ: (min[2] - off[2]) * VOXEL,
    rearWheel: rearW
      ? { x: (rearW.hw + 0.5) * VOXEL, z: (rearW.zc + rearW.n / 2 - off[2]) * VOXEL }
      : { x: 0.55, z: (min[2] + 4 - off[2]) * VOXEL },
    siren, swatches,
  };
  return asset;
}
export function getCarAsset(rawId: string): CarAsset {
  const id = validCar(rawId);
  const hit = cache.get(id);
  if (hit) return hit;
  const a = buildAsset(id);
  cache.set(id, a);
  return a;
}
function disposeAsset(a: CarAsset) {
  a.geometry.dispose();
  a.parts.forEach((p) => p.geometry.dispose());
  a.decals.forEach((d) => d.texture.dispose());
}

// ───────────────────────── instance (Group siap pakai) ─────────────────────────
export interface WheelRig { steer: THREE.Group; camber: THREE.Group; spin: THREE.Group; front: boolean; side: number }
export interface PartRig { group: THREE.Group; pivotY: number; kind: PartKind; dir: number; k: number }
export interface CarModel {
  group: THREE.Group;
  asset: CarAsset;
  rigs: WheelRig[];
  parts: PartRig[];
  decalMats: THREE.Material[];
  /** uniform shader beam lampu sorot voxel (di-tick tiap frame) */
  beams?: VoxelBeam[];
}

const tireCache = new Map<string, THREE.BufferGeometry>();
/** Ban gemuk dengan sidewall membulat (Lathe), poros di sumbu X. */
function tireGeo(d: number, w: number) {
  const key = `t${d.toFixed(3)}_${w.toFixed(3)}`;
  let g = tireCache.get(key);
  if (!g) {
    const R = (d / 2) * 1.06, hw = w / 2, br = Math.min(hw * 0.95, R * 0.3);
    const pts: THREE.Vector2[] = [new THREE.Vector2(R * 0.5, -hw), new THREE.Vector2(R - br, -hw)];
    for (let i = 1; i <= 6; i++) { const a = (i / 6) * (Math.PI / 2); pts.push(new THREE.Vector2(R - br + Math.sin(a) * br, -hw + br - Math.cos(a) * br)); }
    for (let i = 0; i <= 6; i++) { const a = (i / 6) * (Math.PI / 2); pts.push(new THREE.Vector2(R - br + Math.cos(a) * br, hw - br + Math.sin(a) * br)); }
    pts.push(new THREE.Vector2(R * 0.5, hw));
    g = new THREE.LatheGeometry(pts, 20);
    g.rotateZ(Math.PI / 2);
    tireCache.set(key, g);
  }
  return g;
}
const rimCache = new Map<string, { disc: THREE.BufferGeometry; spokes: THREE.BufferGeometry }>();
/** Velg: cakram terang + 5 jari gelap + tutup tengah (jari terlihat berputar saat roda jalan). */
function rimGeo(d: number, w: number) {
  const key = `r${d.toFixed(3)}_${w.toFixed(3)}`;
  let r = rimCache.get(key);
  if (!r) {
    const R = (d / 2) * 1.06;
    const disc = new THREE.CylinderGeometry(R * 0.7, R * 0.7, w * 1.02, 24); disc.rotateZ(Math.PI / 2);
    const parts: THREE.BufferGeometry[] = [];
    for (let i = 0; i < 5; i++) {
      const b = new THREE.BoxGeometry(w * 1.08, R * 0.15, R * 0.6);
      b.translate(0, 0, R * 0.34);
      b.rotateX((i / 5) * Math.PI * 2);
      parts.push(b);
    }
    const hub = new THREE.CylinderGeometry(R * 0.2, R * 0.2, w * 1.14, 14); hub.rotateZ(Math.PI / 2);
    parts.push(hub);
    r = { disc, spokes: mergeGeometries(parts)! };
    parts.forEach((p) => p.dispose());
    rimCache.set(key, r);
  }
  return r;
}

/** Roda: ban membulat + velg berjari. Grup steer → camber → spin (setir, kemiringan, putaran). */
function makeWheel(parent: THREE.Group, w: WheelPlace, mats: CarMats, shadow: boolean): WheelRig {
  const steer = new THREE.Group();
  steer.position.set(w.x, w.y, w.z);
  steer.userData.wheel = { front: w.front, side: w.side };
  const camber = new THREE.Group(); steer.add(camber);
  const spin = new THREE.Group(); camber.add(spin);
  const tire = new THREE.Mesh(tireGeo(w.d, w.w), mats.col(w.tire)); tire.castShadow = shadow; spin.add(tire);
  const rg = rimGeo(w.d, w.w);
  spin.add(new THREE.Mesh(rg.disc, mats.col(w.rim)));
  spin.add(new THREE.Mesh(rg.spokes, mats.col(0x2a2b31)));
  parent.add(steer);
  return { steer, camber, spin, front: w.front, side: w.side };
}

// ───────────────────────── mobil VOXEL BMW (dari asset customizable-voxel-bmw) ─────────────────────────
// Bodi voxel 100% dari asset (5 model × 8 skin preset) + LAMPU SOROT 100% + roda pakai sistem game yg ada.
// Skala mobil voxel baru: 0.62 × 0.6 ≈ 0.37 (≈40% lebih kecil dari sebelumnya).
// Skala seragam (bukan squash) supaya voxel tetap KUBIK sempurna.
const VX_SCALE = 0.37;

function buildVoxelBMWCar(id: string, mats: CarMats, shadow: boolean): CarModel {
  const preset = voxelSkinById(id.slice(3));
  const full = mats.std instanceof THREE.MeshStandardMaterial; // pemain = PBR + spotlight real; bot = hemat
  const chassis = buildVoxelChassis(preset.carModel, preset.skin, !full);

  const group = new THREE.Group();
  const bodyGroup = new THREE.Group();
  bodyGroup.scale.setScalar(VX_SCALE);
  bodyGroup.add(chassis.group);

  // Roda: WAJIB pakai roda existing game (ban Lathe gemuk + velg berjari) — bukan roda asset!
  const rimCol = parseInt(preset.skin.rimColor.slice(1), 16);
  const wheels: WheelPlace[] = [];
  const wy = 1.36 * 0.25; // pusat roda voxel (1.36 * VOXEL_SIZE)
  const wd = 0.68; // diameter ban voxel (4 sub-voxel × 0.68 × VOXEL_SIZE)
  const ww = 0.3;
  for (const side of [1, -1]) {
    wheels.push({ x: side * chassis.wheelX * 0.25, y: wy, z: chassis.frontZ * 0.25, d: wd, w: ww, front: true, side, rim: rimCol, tire: 0x1d212a });
    wheels.push({ x: side * chassis.wheelX * 0.25, y: wy, z: chassis.rearZ * 0.25, d: wd, w: ww, front: false, side, rim: rimCol, tire: 0x1d212a });
  }
  const rigs = wheels.map((w) => makeWheel(bodyGroup, w, mats, shadow));

  // Lampu sorot (spotlight) 100% + volumetric beam + flare + light pool + underglow
  const rig = buildVoxelHeadlightRig(chassis, preset.skin, full);
  bodyGroup.add(rig.group);
  group.add(bodyGroup);

  const asset: CarAsset = {
    id,
    geometry: new THREE.BufferGeometry(),
    parts: [],
    decals: [],
    wheels,
    length: chassis.length * VX_SCALE,
    width: chassis.width * VX_SCALE,
    height: chassis.height * VX_SCALE,
    rearZ: chassis.tailZ * 0.25 * VX_SCALE,
    rearWheel: { x: chassis.wheelX * 0.25 * VX_SCALE, z: chassis.rearZ * 0.25 * VX_SCALE },
    siren: false,
    swatches: [preset.skin.bodyColor, preset.skin.liveryColor, preset.skin.decalColor, preset.skin.rimColor],
  };
  return { group, asset, rigs, parts: [], decalMats: chassis.matList, beams: rig.beams };
}

export function buildCarModel(id: string, mats: CarMats = SHARED_MATS, shadow = true, assetOverride?: CarAsset): CarModel {
  if (id.startsWith('vx-')) return buildVoxelBMWCar(id, mats, shadow);
  const asset = assetOverride ?? getCarAsset(id);
  const group = new THREE.Group();
  const body = new THREE.Mesh(asset.geometry, mats.slots);
  body.castShadow = shadow;
  group.add(body);

  const parts: PartRig[] = [];
  for (const p of asset.parts) {
    const g = new THREE.Group();
    g.position.set(p.pivot[0], p.pivot[1], p.pivot[2]);
    const m = new THREE.Mesh(p.geometry, mats.slots);
    m.position.set(-p.pivot[0], -p.pivot[1], -p.pivot[2]);
    m.castShadow = shadow;
    g.add(m);
    group.add(g);
    parts.push({ group: g, pivotY: p.pivot[1], kind: p.kind, dir: p.dir, k: 0 });
  }

  const decalMats: THREE.MeshStandardMaterial[] = [];
  for (const d of asset.decals) {
    for (const pl of d.planes) {
      const mat = new THREE.MeshStandardMaterial({ map: d.texture, transparent: true, roughness: 0.6, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4 });
      decalMats.push(mat);
      const m = new THREE.Mesh(new THREE.PlaneGeometry(d.width, d.height), mat);
      m.position.set(pl.position[0], pl.position[1], pl.position[2]);
      m.rotation.y = pl.rotationY;
      m.renderOrder = 2;
      group.add(m);
    }
  }

  const rigs = asset.wheels.map((w) => makeWheel(group, w, mats, shadow));
  return { group, asset, rigs, parts, decalMats };
}

/** Animasi part: lampu pop-up, tangga damkar, lengan STOP bus, turret tank. */
export function animateParts(parts: PartRig[], dt: number, t: number, s: { open: boolean; boost: boolean; drift: boolean }) {
  for (const p of parts) {
    const target = p.kind === 'popup' ? (s.open ? 1 : 0) : p.kind === 'ladder' ? (s.boost ? 1 : 0) : p.kind === 'swing' ? (s.drift ? 1 : 0) : 0;
    p.k = THREE.MathUtils.damp(p.k, target, p.kind === 'ladder' ? 2.5 : 6, dt);
    const g = p.group;
    if (p.kind === 'popup') { g.rotation.x = -0.32 * p.k; g.position.y = p.pivotY + 0.16 * p.k; }
    else if (p.kind === 'ladder') g.rotation.x = -0.5 * p.k;
    else if (p.kind === 'swing') g.rotation.y = p.dir * (Math.PI / 2) * p.k;
    else if (p.kind === 'turret') g.rotation.y = Math.sin(t * 0.6) * 0.75;
  }
}

// ───────────────────────── thumbnail garasi ─────────────────────────
let tr: THREE.WebGLRenderer | null = null;
let tScene: THREE.Scene | null = null;
let tCam: THREE.PerspectiveCamera | null = null;
const TW = 288, TH = 188;

export function renderThumb(id: string): string | null {
  try {
    if (!tr) {
      tr = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
      tr.setPixelRatio(1); tr.setSize(TW, TH, false); tr.setClearColor(0x000000, 0);
      tScene = new THREE.Scene();
      tScene.add(new THREE.HemisphereLight(0xffffff, 0x9a90c8, 2.1));
      const dl = new THREE.DirectionalLight(0xfff4e8, 2.4); dl.position.set(3, 6, 4); tScene.add(dl);
      tCam = new THREE.PerspectiveCamera(26, TW / TH, 0.1, 60);
    }
    const mats = makeMats();
    const vid = validCar(id);
    const isVoxel = vid.startsWith('vx-');
    const pinned = cache.get(vid);
    const asset = isVoxel ? undefined : pinned ?? buildAsset(vid);
    const m = buildCarModel(vid, mats, false, asset);
    const a = m.asset;
    for (const r of m.rigs) { r.camber.rotation.z = r.side * 0.1; r.steer.rotation.y = r.front ? 0.28 : 0; }
    const shadow = new THREE.Mesh(new THREE.CircleGeometry(1, 28), new THREE.MeshBasicMaterial({ color: 0x120c34, transparent: true, opacity: 0.32, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2; shadow.position.y = 0.01; shadow.scale.set(a.width * 0.78, a.length * 0.56, 1);
    tScene!.add(m.group, shadow);
    const r = 0.5 * Math.hypot(a.length, a.width, a.height);
    const dist = (r / Math.sin((26 * Math.PI) / 360)) * 0.98;
    const az = (-38 * Math.PI) / 180, el = (21 * Math.PI) / 180;
    tCam!.position.set(Math.sin(az) * Math.cos(el) * dist, a.height * 0.45 + Math.sin(el) * dist, Math.cos(az) * Math.cos(el) * dist);
    tCam!.lookAt(0, a.height * 0.42, 0);
    tr.render(tScene!, tCam!);
    const url = tr.domElement.toDataURL('image/png');
    tScene!.remove(m.group, shadow);
    shadow.geometry.dispose(); (shadow.material as THREE.Material).dispose();
    mats.list.forEach((x) => x.dispose());
    m.decalMats.forEach((x) => x.dispose());
    if (!isVoxel && !pinned && asset) disposeAsset(asset);
    return url;
  } catch {
    return null;
  }
}
export function disposeThumbRenderer() {
  if (tr) { tr.dispose(); tr.forceContextLoss(); tr = null; tScene = null; tCam = null; }
}
