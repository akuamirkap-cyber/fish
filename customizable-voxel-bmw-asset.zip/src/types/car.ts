export type CarModelId =
  | 'bmw-m3-gtr'
  | 'vw-golf-gti'
  | 'ae86-trueno'
  | 'mustang-gt'
  | 'rwb-964';

export type LiveryPattern = 'most-wanted' | 'm-stripe' | 'clean';

export type HeadlightMode = 'off' | 'low' | 'high';

export type LightingMood = 'midnight' | 'studio';

export type CameraPresetId = 'hero' | 'front' | 'side' | 'rear' | 'top';

export interface CarConfig {
  carModel: CarModelId;
  bodyColor: string;
  liveryColor: string;
  decalColor: string;
  rimColor: string;
  liveryPattern: LiveryPattern;
  headlightMode: HeadlightMode;
  headlightColor: string;
  beamIntensity: number; // 0.35 to 1.6
  underglowEnabled: boolean;
  underglowColor: string;
  lightingMood: LightingMood;
  autoRotate: boolean;
  wheelSpin: boolean;
}

export interface CarPreset {
  id: string;
  carModel?: CarModelId;
  name: string;
  subtitle: string;
  bodyColor: string;
  liveryColor: string;
  decalColor: string;
  rimColor: string;
  liveryPattern: LiveryPattern;
  headlightColor: string;
  underglowColor: string;
}

export interface CameraPreset {
  id: CameraPresetId;
  label: string;
  shortcut: string;
  position: [number, number, number];
  target: [number, number, number];
}
