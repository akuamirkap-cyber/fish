import { CameraPreset, CarConfig, CarModelId, CarPreset } from '../types/car';

export const CAR_MODELS: Array<{
  id: CarModelId;
  name: string;
  tag: string;
  subtitle: string;
  headlightZOffset: number;
  taillightZOffset: number;
}> = [
  {
    id: 'bmw-m3-gtr',
    name: 'BMW M3 GTR',
    tag: 'E46 HERO',
    subtitle: 'Most Wanted Cute 3D',
    headlightZOffset: 7.5,
    taillightZOffset: -7.5,
  },
  {
    id: 'vw-golf-gti',
    name: 'VW Golf GTI',
    tag: 'SONNY #15',
    subtitle: 'Ho Seun Most Wanted 3D',
    headlightZOffset: 6.5,
    taillightZOffset: -6.5,
  },
  {
    id: 'ae86-trueno',
    name: 'AE86 Trueno',
    tag: 'INITIAL D',
    subtitle: 'Panda White Pop-Up 3D',
    headlightZOffset: 6.5,
    taillightZOffset: -7.5,
  },
  {
    id: 'mustang-gt',
    name: 'Mustang GT',
    tag: 'RAZOR #1',
    subtitle: 'Most Wanted Flame 3D',
    headlightZOffset: 7.5,
    taillightZOffset: -7.5,
  },
  {
    id: 'rwb-964',
    name: 'RWB 964',
    tag: 'AKIRA NAKAI',
    subtitle: 'RAUH-Welt Widebody 3D',
    headlightZOffset: 6.5,
    taillightZOffset: -7.5,
  },
];

export const DEFAULT_CAR_CONFIG: CarConfig = {
  carModel: 'bmw-m3-gtr',
  bodyColor: '#e2e8f0',
  liveryColor: '#2563eb',
  decalColor: '#ef4444',
  rimColor: '#f1f5f9',
  liveryPattern: 'most-wanted',
  headlightMode: 'high',
  headlightColor: '#fff6d6',
  beamIntensity: 1.15,
  underglowEnabled: false,
  underglowColor: '#38bdf8',
  lightingMood: 'midnight',
  autoRotate: false,
  wheelSpin: false,
};

export const BMW_M3_DEFAULTS: Partial<CarConfig> = {
  carModel: 'bmw-m3-gtr',
  bodyColor: '#e2e8f0',
  liveryColor: '#2563eb',
  decalColor: '#ef4444',
  rimColor: '#f1f5f9',
  liveryPattern: 'most-wanted',
  headlightColor: '#fff6d6',
  underglowColor: '#38bdf8',
};

export const SONNY_GOLF_DEFAULTS: Partial<CarConfig> = {
  carModel: 'vw-golf-gti',
  bodyColor: '#f8fafc',
  liveryColor: '#1d4ed8',
  decalColor: '#dc2626',
  rimColor: '#e2e8f0',
  liveryPattern: 'most-wanted',
  headlightColor: '#e6f3ff',
  underglowColor: '#2563eb',
};

export const AE86_DEFAULTS: Partial<CarConfig> = {
  carModel: 'ae86-trueno',
  bodyColor: '#f8fafc',
  liveryColor: '#171b24',
  decalColor: '#111827',
  rimColor: '#242933',
  liveryPattern: 'most-wanted',
  headlightColor: '#fff3c4',
  underglowColor: '#facc15',
};

export const MUSTANG_DEFAULTS: Partial<CarConfig> = {
  carModel: 'mustang-gt',
  bodyColor: '#161a22',
  liveryColor: '#facc15',
  decalColor: '#ef4444',
  rimColor: '#e2e8f0',
  liveryPattern: 'most-wanted',
  headlightColor: '#e6f3ff',
  underglowColor: '#ef4444',
};

export const RWB_DEFAULTS: Partial<CarConfig> = {
  carModel: 'rwb-964',
  bodyColor: '#66c433',
  liveryColor: '#f97316',
  decalColor: '#0284c7',
  rimColor: '#e2e8f0',
  liveryPattern: 'clean',
  headlightColor: '#fff6d6',
  underglowColor: '#66c433',
};

export const CAR_PRESETS: CarPreset[] = [
  {
    id: 'rwb-nakai-green',
    carModel: 'rwb-964',
    name: 'RWB Nakai Green',
    subtitle: 'Hijau Signal & Velg Silver',
    bodyColor: '#66c433',
    liveryColor: '#1e242d',
    decalColor: '#f8fafc',
    rimColor: '#e2e8f0',
    liveryPattern: 'clean',
    headlightColor: '#fff6d6',
    underglowColor: '#66c433',
  },
  {
    id: 'rwb-oren-biru',
    carModel: 'rwb-964',
    name: 'RWB Oren Biru',
    subtitle: 'Oren Cerah & Strip Biru',
    bodyColor: '#f97316',
    liveryColor: '#0284c7',
    decalColor: '#38bdf8',
    rimColor: '#f8fafc',
    liveryPattern: 'most-wanted',
    headlightColor: '#e6f3ff',
    underglowColor: '#0ea5e9',
  },
  {
    id: 'rwb-biru-oren',
    carModel: 'rwb-964',
    name: 'RWB Biru Oren',
    subtitle: 'Biru Gulf & Aksen Oren',
    bodyColor: '#0ea5e9',
    liveryColor: '#f97316',
    decalColor: '#f97316',
    rimColor: '#f8fafc',
    liveryPattern: 'most-wanted',
    headlightColor: '#fff6d6',
    underglowColor: '#f97316',
  },
  {
    id: 'razor-mustang',
    carModel: 'mustang-gt',
    name: 'Razor Mustang',
    subtitle: 'Hitam & Api Kuning-Merah',
    bodyColor: '#161a22',
    liveryColor: '#facc15',
    decalColor: '#ef4444',
    rimColor: '#e2e8f0',
    liveryPattern: 'most-wanted',
    headlightColor: '#e6f3ff',
    underglowColor: '#ef4444',
  },
  {
    id: 'takumi-ae86',
    carModel: 'ae86-trueno',
    name: 'AE86 Panda',
    subtitle: 'Putih Kap Putih & Hitam',
    bodyColor: '#f8fafc',
    liveryColor: '#171b24',
    decalColor: '#111827',
    rimColor: '#242933',
    liveryPattern: 'most-wanted',
    headlightColor: '#fff3c4',
    underglowColor: '#facc15',
  },
  {
    id: 'sonny-gti',
    carModel: 'vw-golf-gti',
    name: 'Sonny GTI #15',
    subtitle: 'Putih, Biru & Decal Merah',
    bodyColor: '#f8fafc',
    liveryColor: '#1d4ed8',
    decalColor: '#dc2626',
    rimColor: '#e2e8f0',
    liveryPattern: 'most-wanted',
    headlightColor: '#e6f3ff',
    underglowColor: '#2563eb',
  },
  {
    id: 'most-wanted',
    carModel: 'bmw-m3-gtr',
    name: "Most Wanted '05",
    subtitle: 'Silver & Biru Royal',
    bodyColor: '#e2e8f0',
    liveryColor: '#2563eb',
    decalColor: '#ef4444',
    rimColor: '#f1f5f9',
    liveryPattern: 'most-wanted',
    headlightColor: '#fff6d6',
    underglowColor: '#38bdf8',
  },
  {
    id: 'sakura-cute',
    name: 'Sakura Cute',
    subtitle: 'Putih Susu & Pink Pastel',
    bodyColor: '#fff5f7',
    liveryColor: '#f472b6',
    decalColor: '#fb7185',
    rimColor: '#ffffff',
    liveryPattern: 'most-wanted',
    headlightColor: '#fff6d6',
    underglowColor: '#f472b6',
  },
];

export const BODY_SWATCHES = [
  { name: 'Hijau RWB', hex: '#66c433' },
  { name: 'Oren Gulf', hex: '#f97316' },
  { name: 'Biru Gulf', hex: '#0ea5e9' },
  { name: 'Biru Royal', hex: '#1d4ed8' },
  { name: 'Putih Susu', hex: '#f8fafc' },
  { name: 'Silver MW', hex: '#e2e8f0' },
  { name: 'Hitam Razor', hex: '#161a22' },
  { name: 'Kuning Sunny', hex: '#facc15' },
];

export const LIVERY_SWATCHES = [
  { name: 'Biru Gulf', hex: '#0284c7' },
  { name: 'Oren Racing', hex: '#f97316' },
  { name: 'MW Royal Blue', hex: '#1d4ed8' },
  { name: 'Hitam Panda', hex: '#171b24' },
  { name: 'Kuning Api', hex: '#facc15' },
  { name: 'Merah Racing', hex: '#ef4444' },
  { name: 'Hijau Lime', hex: '#66c433' },
  { name: 'Putih Bersih', hex: '#f8fafc' },
];

export const DECAL_SWATCHES = [
  { name: 'Biru Cerah', hex: '#0ea5e9' },
  { name: 'Oren Bara', hex: '#f97316' },
  { name: 'Merah Api', hex: '#ef4444' },
  { name: 'Hitam Tofu', hex: '#111827' },
  { name: 'Kuning Emas', hex: '#facc15' },
  { name: 'Putih', hex: '#f8fafc' },
];

export const RIM_SWATCHES = [
  { name: 'Alloy Putih', hex: '#f1f5f9' },
  { name: 'Hitam Watanabe', hex: '#242933' },
  { name: 'Emas BBS', hex: '#fbbf24' },
  { name: 'Oren Track', hex: '#f97316' },
  { name: 'Biru Ice', hex: '#38bdf8' },
  { name: 'Abu Satin', hex: '#64748b' },
];

export const HEADLIGHT_SWATCHES = [
  { name: 'Hangat Cute', hex: '#fff6d6' },
  { name: 'Xenon Putih', hex: '#e6f3ff' },
  { name: 'Kuning GT', hex: '#ffd24c' },
  { name: 'Ice Cyan', hex: '#67e8f9' },
];

export const CAMERA_PRESETS: CameraPreset[] = [
  {
    id: 'hero',
    label: '3/4 Cute',
    shortcut: '1',
    position: [6.4, 4.7, 6.8],
    target: [0, 0.72, 0.2],
  },
  {
    id: 'front',
    label: 'Depan',
    shortcut: '2',
    position: [0.0, 2.2, 8.6],
    target: [0, 0.72, 0.2],
  },
  {
    id: 'side',
    label: 'Samping',
    shortcut: '3',
    position: [8.6, 2.5, 0.1],
    target: [0, 0.72, 0.0],
  },
  {
    id: 'rear',
    label: 'Belakang',
    shortcut: '4',
    position: [-5.8, 4.2, -6.6],
    target: [0, 0.72, -0.1],
  },
  {
    id: 'top',
    label: 'Atas',
    shortcut: '5',
    position: [0.1, 10.2, 3.0],
    target: [0, 0.4, 0.2],
  },
];
