import React from 'react';
import {
  Car,
  ChevronRight,
  Palette,
  SlidersHorizontal,
  Sparkles,
  Sun,
} from 'lucide-react';
import {
  BODY_SWATCHES,
  CAR_MODELS,
  CAR_PRESETS,
  DECAL_SWATCHES,
  HEADLIGHT_SWATCHES,
  LIVERY_SWATCHES,
  RIM_SWATCHES,
} from '../data/presets';
import {
  CarConfig,
  CarModelId,
  CarPreset,
  HeadlightMode,
  LiveryPattern,
} from '../types/car';

interface ControlPanelProps {
  config: CarConfig;
  open: boolean;
  onToggleOpen: () => void;
  onSelectCarModel: (modelId: CarModelId) => void;
  onUpdate: (patch: Partial<CarConfig>) => void;
  onApplyPreset: (preset: CarPreset) => void;
}

const LIVERY_OPTIONS: Array<{ id: LiveryPattern; label: string }> = [
  { id: 'most-wanted', label: 'Most Wanted' },
  { id: 'm-stripe', label: 'Racing Stripe' },
  { id: 'clean', label: 'Polos' },
];

const HEADLIGHT_MODES: Array<{ id: HeadlightMode; label: string }> = [
  { id: 'off', label: 'Mati' },
  { id: 'low', label: 'Redup' },
  { id: 'high', label: 'Sorot' },
];

interface SwatchRowProps {
  label: string;
  value: string;
  swatches: Array<{ name: string; hex: string }>;
  onChange: (hex: string) => void;
  disabled?: boolean;
}

const SwatchRow: React.FC<SwatchRowProps> = ({
  label,
  value,
  swatches,
  onChange,
  disabled = false,
}) => {
  return (
    <div className={disabled ? 'opacity-40 pointer-events-none' : ''}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-medium uppercase tracking-wider text-slate-300">
          {label}
        </span>
        <label className="flex items-center gap-1.5 cursor-pointer group">
          <span className="font-mono-tech text-[10px] uppercase text-slate-400 group-hover:text-slate-200 transition-colors">
            {value}
          </span>
          <span
            className="relative w-5 h-5 rounded-md border border-white/25 overflow-hidden shadow-inner block"
            style={{ backgroundColor: value }}
            title="Pilih warna bebas"
          >
            <input
              type="color"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              className="opacity-0 absolute inset-0 w-full h-full cursor-pointer"
            />
          </span>
        </label>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {swatches.map((s) => {
          const active = value.toLowerCase() === s.hex.toLowerCase();
          return (
            <button
              key={s.hex}
              type="button"
              onClick={() => onChange(s.hex)}
              title={s.name}
              className={`w-6 h-6 rounded-md transition-all cursor-pointer border ${
                active
                  ? 'border-sky-400 ring-2 ring-sky-400/50 scale-110'
                  : 'border-white/20 hover:scale-105 hover:border-white/50'
              }`}
              style={{ backgroundColor: s.hex }}
            />
          );
        })}
      </div>
    </div>
  );
};

export const ControlPanel: React.FC<ControlPanelProps> = ({
  config,
  open,
  onToggleOpen,
  onSelectCarModel,
  onUpdate,
  onApplyPreset,
}) => {
  if (!open) {
    return (
      <button
        type="button"
        onClick={onToggleOpen}
        className="fixed top-4 right-4 z-30 flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-950/75 hover:bg-slate-900/90 backdrop-blur-xl border border-white/12 text-slate-100 text-xs font-semibold tracking-wide shadow-2xl transition-all cursor-pointer"
      >
        <SlidersHorizontal className="w-4 h-4 text-sky-400" />
        <span>Kustomisasi</span>
      </button>
    );
  }

  return (
    <aside className="fixed top-4 right-4 bottom-20 z-30 w-[300px] sm:w-[320px] flex flex-col rounded-2xl bg-slate-950/78 backdrop-blur-xl border border-white/12 shadow-[0_20px_60px_rgba(0,0,0,0.65)] overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-sky-400" />
          <h2 className="text-xs font-bold uppercase tracking-widest text-slate-100">
            Garage Customizer
          </h2>
        </div>
        <button
          type="button"
          onClick={onToggleOpen}
          title="Sembunyikan Panel"
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Scrollable Body */}
      <div className="flex-1 overflow-y-auto panel-scroll p-4 space-y-5">
        {/* Section 0: Car Switcher (BMW M3 GTR vs Sonny's VW Golf GTI) */}
        <section>
          <div className="flex items-center gap-1.5 mb-2.5">
            <Car className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-300">
              Pilih Mobil Voxel
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {CAR_MODELS.map((m) => {
              const active = config.carModel === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onSelectCarModel(m.id)}
                  className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                    active
                      ? 'bg-sky-500/20 border-sky-400/75 shadow-[0_0_20px_rgba(56,189,248,0.2)]'
                      : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.07] hover:border-white/25'
                  }`}
                >
                  <span className="font-mono-tech text-[9px] font-bold px-1.5 py-0.5 rounded bg-white/10 text-sky-300 mb-1">
                    {m.tag}
                  </span>
                  <span className="text-xs font-bold text-white leading-tight">
                    {m.name}
                  </span>
                  <span className="text-[10px] text-slate-400 mt-0.5 truncate w-full">
                    {m.subtitle}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Section 1: Curated Presets */}
        <section className="pt-4 border-t border-white/8">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Preset Warna Ikonik
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {CAR_PRESETS.map((preset) => {
              const isSelected =
                (!preset.carModel || preset.carModel === config.carModel) &&
                config.bodyColor.toLowerCase() === preset.bodyColor.toLowerCase() &&
                config.liveryColor.toLowerCase() === preset.liveryColor.toLowerCase() &&
                config.liveryPattern === preset.liveryPattern;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => onApplyPreset(preset)}
                  className={`group flex flex-col items-start p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-sky-500/15 border-sky-400/70 shadow-[0_0_20px_rgba(56,189,248,0.16)]'
                      : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.07] hover:border-white/25'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <span
                      className="w-4 h-4 rounded-full border border-white/30"
                      style={{ backgroundColor: preset.bodyColor }}
                    />
                    <span
                      className="w-4 h-4 rounded-full border border-white/30 -ml-2"
                      style={{ backgroundColor: preset.liveryColor }}
                    />
                    <span
                      className="w-3 h-3 rounded-full border border-white/25 -ml-1.5"
                      style={{ backgroundColor: preset.decalColor }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-slate-100 leading-tight">
                    {preset.name}
                  </span>
                  <span className="text-[10px] text-slate-400 truncate w-full mt-0.5">
                    {preset.subtitle}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Section 2: Livery Style */}
        <section className="pt-4 border-t border-white/8">
          <span className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-2">
            Pola Livery
          </span>
          <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-white/[0.04] border border-white/8">
            {LIVERY_OPTIONS.map((opt) => {
              const active = config.liveryPattern === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onUpdate({ liveryPattern: opt.id })}
                  className={`py-1.5 px-2 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                    active
                      ? 'bg-sky-500 text-slate-950 shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </section>

        {/* Section 3: Paint & Rim Colors */}
        <section className="pt-4 border-t border-white/8 space-y-4">
          <SwatchRow
            label={
              config.carModel === 'vw-golf-gti'
                ? 'Warna Body / Pintu'
                : config.carModel === 'ae86-trueno'
                ? 'Warna Atas & Kap'
                : config.carModel === 'rwb-964'
                ? 'Warna Body RWB'
                : 'Warna Body'
            }
            value={config.bodyColor}
            swatches={BODY_SWATCHES}
            onChange={(hex) => onUpdate({ bodyColor: hex })}
          />
          <SwatchRow
            label={
              config.carModel === 'vw-golf-gti'
                ? 'Warna Depan & Belakang'
                : config.carModel === 'mustang-gt'
                ? 'Warna Api (Kuning)'
                : config.carModel === 'ae86-trueno'
                ? 'Warna Bumper Bawah'
                : config.carModel === 'rwb-964'
                ? 'Warna Strip / Sayap RWB'
                : 'Warna Livery / Strip'
            }
            value={config.liveryColor}
            swatches={LIVERY_SWATCHES}
            onChange={(hex) => onUpdate({ liveryColor: hex })}
            disabled={config.liveryPattern === 'clean'}
          />
          {(config.carModel === 'vw-golf-gti' ||
            config.carModel === 'mustang-gt') &&
            config.liveryPattern === 'most-wanted' && (
              <SwatchRow
                label={
                  config.carModel === 'mustang-gt'
                    ? 'Warna Ujung Api (Merah)'
                    : 'Warna Decal Kanji'
                }
                value={config.decalColor}
                swatches={DECAL_SWATCHES}
                onChange={(hex) => onUpdate({ decalColor: hex })}
              />
            )}
          <SwatchRow
            label="Warna Velg (Rim)"
            value={config.rimColor}
            swatches={RIM_SWATCHES}
            onChange={(hex) => onUpdate({ rimColor: hex })}
          />
        </section>

        {/* Section 4: Lampu Sorot (Headlight Spotlight Controls) */}
        <section className="pt-4 border-t border-white/8 space-y-3.5">
          <div className="flex items-center gap-1.5">
            <Sun className="w-3.5 h-3.5 text-amber-300" />
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-300">
              Lampu Sorot (Headlights)
            </span>
          </div>

          {/* Mode Toggle */}
          <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-white/[0.04] border border-white/8">
            {HEADLIGHT_MODES.map((m) => {
              const active = config.headlightMode === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onUpdate({ headlightMode: m.id })}
                  className={`py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                    active
                      ? m.id === 'off'
                        ? 'bg-slate-600 text-white'
                        : 'bg-amber-400 text-slate-950 shadow-[0_0_16px_rgba(251,191,36,0.45)]'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {m.label}
                </button>
              );
            })}
          </div>

          {/* Headlight Beam Color */}
          <SwatchRow
            label="Warna Cahaya Sorot"
            value={config.headlightColor}
            swatches={HEADLIGHT_SWATCHES}
            onChange={(hex) => onUpdate({ headlightColor: hex })}
            disabled={config.headlightMode === 'off'}
          />

          {/* Intensity Slider */}
          <div
            className={
              config.headlightMode === 'off' ? 'opacity-40 pointer-events-none' : ''
            }
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-medium text-slate-300">
                Intensitas Sorot
              </span>
              <span className="font-mono-tech text-[11px] text-sky-300">
                {Math.round(config.beamIntensity * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0.35}
              max={1.6}
              step={0.05}
              value={config.beamIntensity}
              onChange={(e) =>
                onUpdate({ beamIntensity: parseFloat(e.target.value) })
              }
              className="studio-slider w-full"
            />
          </div>

          {/* Neon Underglow Toggle */}
          <div className="pt-2 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() =>
                onUpdate({ underglowEnabled: !config.underglowEnabled })
              }
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
                config.underglowEnabled
                  ? 'bg-sky-500/20 border-sky-400/60 text-sky-200'
                  : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Neon Underglow</span>
            </button>

            {config.underglowEnabled && (
              <label className="flex items-center gap-1.5 cursor-pointer">
                <span className="font-mono-tech text-[10px] text-slate-400 uppercase">
                  Warna
                </span>
                <span
                  className="relative w-6 h-6 rounded-md border border-white/30 overflow-hidden block shadow-md"
                  style={{ backgroundColor: config.underglowColor }}
                >
                  <input
                    type="color"
                    value={config.underglowColor}
                    onChange={(e) =>
                      onUpdate({ underglowColor: e.target.value })
                    }
                    className="opacity-0 absolute inset-0 w-full h-full cursor-pointer"
                  />
                </span>
              </label>
            )}
          </div>
        </section>
      </div>
    </aside>
  );
};
