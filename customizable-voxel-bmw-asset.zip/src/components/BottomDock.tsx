import React from 'react';
import {
  Camera,
  Disc3,
  Download,
  Lightbulb,
  Moon,
  RotateCw,
  Sun,
} from 'lucide-react';
import { CAMERA_PRESETS } from '../data/presets';
import { CameraPreset, CameraPresetId, CarConfig } from '../types/car';

interface BottomDockProps {
  config: CarConfig;
  activeCamera: CameraPresetId;
  exporting: boolean;
  onCycleHeadlights: () => void;
  onSelectCamera: (preset: CameraPreset) => void;
  onUpdate: (patch: Partial<CarConfig>) => void;
  onExportGLB: () => void;
}

export const BottomDock: React.FC<BottomDockProps> = ({
  config,
  activeCamera,
  exporting,
  onCycleHeadlights,
  onSelectCamera,
  onUpdate,
  onExportGLB,
}) => {
  const lightLabel =
    config.headlightMode === 'high'
      ? 'Sorot High'
      : config.headlightMode === 'low'
      ? 'Sorot Low'
      : 'Lampu Mati';

  const lightActive = config.headlightMode !== 'off';

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-30 max-w-[96vw] flex items-center gap-1.5 px-2.5 py-2 rounded-2xl bg-slate-950/78 backdrop-blur-xl border border-white/12 shadow-[0_14px_45px_rgba(0,0,0,0.65)] overflow-x-auto">
      {/* Quick Spotlight Cycle Button */}
      <button
        type="button"
        onClick={onCycleHeadlights}
        title="Ganti Mode Lampu Sorot (Shortcut: L)"
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
          lightActive
            ? 'bg-amber-400/20 border-amber-300/60 text-amber-200 shadow-[0_0_18px_rgba(251,191,36,0.28)]'
            : 'bg-white/[0.04] border-white/10 text-slate-300 hover:bg-white/10'
        }`}
      >
        <Lightbulb
          className={`w-3.5 h-3.5 ${
            lightActive ? 'text-amber-300 fill-amber-300/40' : 'text-slate-400'
          }`}
        />
        <span>{lightLabel}</span>
      </button>

      <div className="w-px h-5 bg-white/10 mx-0.5 shrink-0" />

      {/* Camera Presets */}
      <div className="flex items-center gap-1">
        <Camera className="w-3.5 h-3.5 text-slate-500 ml-1 mr-0.5 hidden sm:block shrink-0" />
        {CAMERA_PRESETS.map((cam) => {
          const isSelected = activeCamera === cam.id;
          return (
            <button
              key={cam.id}
              type="button"
              onClick={() => onSelectCamera(cam)}
              title={`Kamera ${cam.label} (Tombol ${cam.shortcut})`}
              className={`px-2.5 py-1.5 rounded-xl text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-sky-500/25 text-sky-200 border border-sky-400/40'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-white/[0.06] border border-transparent'
              }`}
            >
              {cam.label}
            </button>
          );
        })}
      </div>

      <div className="w-px h-5 bg-white/10 mx-0.5 shrink-0" />

      {/* Utility Toggles */}
      <button
        type="button"
        onClick={() => onUpdate({ autoRotate: !config.autoRotate })}
        title="Auto-Putar Kamera (Shortcut: R)"
        className={`p-2 rounded-xl border transition-all cursor-pointer ${
          config.autoRotate
            ? 'bg-sky-500/20 border-sky-400/50 text-sky-300'
            : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
        }`}
      >
        <RotateCw
          className={`w-3.5 h-3.5 ${config.autoRotate ? 'animate-spin' : ''}`}
          style={config.autoRotate ? { animationDuration: '5s' } : undefined}
        />
      </button>

      <button
        type="button"
        onClick={() => onUpdate({ wheelSpin: !config.wheelSpin })}
        title="Jalankan Mobil di Jalanan Crossy"
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-[11px] font-semibold whitespace-nowrap transition-all cursor-pointer ${
          config.wheelSpin
            ? 'bg-emerald-500/25 border-emerald-400/60 text-emerald-200'
            : 'bg-white/[0.03] border-white/10 text-slate-300 hover:text-white hover:bg-white/10'
        }`}
      >
        <Disc3
          className={`w-3.5 h-3.5 ${config.wheelSpin ? 'animate-spin' : ''}`}
          style={config.wheelSpin ? { animationDuration: '0.9s' } : undefined}
        />
        <span>{config.wheelSpin ? 'Jalan!' : 'Jalan'}</span>
      </button>

      <button
        type="button"
        onClick={() =>
          onUpdate({
            lightingMood:
              config.lightingMood === 'midnight' ? 'studio' : 'midnight',
          })
        }
        title={
          config.lightingMood === 'midnight'
            ? 'Ganti ke Suasana Siang Cerah'
            : 'Ganti ke Suasana Malam Cozy'
        }
        className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white/[0.04] border border-white/10 text-[11px] font-medium text-slate-200 hover:text-white hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
      >
        {config.lightingMood === 'midnight' ? (
          <>
            <Moon className="w-3.5 h-3.5 text-indigo-300" />
            <span className="hidden sm:inline">Malam</span>
          </>
        ) : (
          <>
            <Sun className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden sm:inline">Siang</span>
          </>
        )}
      </button>

      <div className="w-px h-5 bg-white/10 mx-0.5 shrink-0" />

      {/* Export 3D .GLB Asset */}
      <button
        type="button"
        onClick={onExportGLB}
        disabled={exporting}
        title="Download 3D Asset sebagai file .GLB"
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-400 active:scale-95 text-slate-950 text-xs font-bold whitespace-nowrap transition-all cursor-pointer disabled:opacity-60 shadow-[0_0_20px_rgba(56,189,248,0.35)]"
      >
        <Download className="w-3.5 h-3.5" />
        <span>{exporting ? 'Export...' : '.GLB'}</span>
      </button>
    </div>
  );
};
