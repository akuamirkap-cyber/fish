import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { BMWSceneManager } from '../three/bmwSceneManager';
import { CameraPreset, CarConfig } from '../types/car';

export interface Viewport3DHandle {
  goToCameraPreset: (preset: CameraPreset) => void;
  exportGLB: () => Promise<void>;
}

interface Viewport3DProps {
  config: CarConfig;
  onVoxelCountChange: (count: number) => void;
}

export const Viewport3D = forwardRef<Viewport3DHandle, Viewport3DProps>(
  ({ config, onVoxelCountChange }, ref) => {
    const containerRef = useRef<HTMLDivElement | null>(null);
    const managerRef = useRef<BMWSceneManager | null>(null);
    const initialConfigRef = useRef(config);
    const countCallbackRef = useRef(onVoxelCountChange);
    countCallbackRef.current = onVoxelCountChange;

    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;

      const manager = new BMWSceneManager(
        container,
        initialConfigRef.current,
        (count) => countCallbackRef.current(count)
      );
      managerRef.current = manager;

      return () => {
        manager.dispose();
        managerRef.current = null;
      };
    }, []);

    useEffect(() => {
      managerRef.current?.updateConfig(config);
    }, [config]);

    useImperativeHandle(ref, () => ({
      goToCameraPreset: (preset: CameraPreset) => {
        managerRef.current?.goToCameraPreset(preset);
      },
      exportGLB: async () => {
        if (managerRef.current) {
          await managerRef.current.exportGLB();
        }
      },
    }));

    return (
      <div
        ref={containerRef}
        className="fixed inset-0 w-full h-full cursor-grab active:cursor-grabbing touch-none"
        aria-label="3D Voxel BMW M3 GTR Interactive Viewport"
      />
    );
  }
);

Viewport3D.displayName = 'Viewport3D';
