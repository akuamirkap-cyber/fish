import { useCallback, useEffect, useRef, useState } from 'react';
import { Box, CheckCircle2 } from 'lucide-react';
import { BottomDock } from './components/BottomDock';
import { ControlPanel } from './components/ControlPanel';
import { Viewport3D, Viewport3DHandle } from './components/Viewport3D';
import {
  AE86_DEFAULTS,
  BMW_M3_DEFAULTS,
  CAMERA_PRESETS,
  CAR_MODELS,
  DEFAULT_CAR_CONFIG,
  MUSTANG_DEFAULTS,
  RWB_DEFAULTS,
  SONNY_GOLF_DEFAULTS,
} from './data/presets';
import {
  CameraPreset,
  CameraPresetId,
  CarConfig,
  CarModelId,
  CarPreset,
  HeadlightMode,
} from './types/car';

export function App() {
  const viewportRef = useRef<Viewport3DHandle | null>(null);
  const [config, setConfig] = useState<CarConfig>(DEFAULT_CAR_CONFIG);
  const [voxelCount, setVoxelCount] = useState<number>(0);
  const [panelOpen, setPanelOpen] = useState<boolean>(true);
  const [activeCamera, setActiveCamera] = useState<CameraPresetId>('hero');
  const [exporting, setExporting] = useState<boolean>(false);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (window.innerWidth < 768) {
      setPanelOpen(false);
    }
  }, []);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    const id = window.setTimeout(() => setToast(null), 2600);
    return () => window.clearTimeout(id);
  }, []);

  const handleUpdate = useCallback((patch: Partial<CarConfig>) => {
    setConfig((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleSelectCarModel = useCallback((modelId: CarModelId) => {
    setConfig((prev) => {
      if (prev.carModel === modelId) return prev;
      const defaults =
        modelId === 'vw-golf-gti'
          ? SONNY_GOLF_DEFAULTS
          : modelId === 'ae86-trueno'
          ? AE86_DEFAULTS
          : modelId === 'mustang-gt'
          ? MUSTANG_DEFAULTS
          : modelId === 'rwb-964'
          ? RWB_DEFAULTS
          : BMW_M3_DEFAULTS;
      return {
        ...prev,
        ...defaults,
        carModel: modelId,
      };
    });
  }, []);

  const handleApplyPreset = useCallback((preset: CarPreset) => {
    setConfig((prev) => ({
      ...prev,
      carModel: preset.carModel ?? prev.carModel,
      bodyColor: preset.bodyColor,
      liveryColor: preset.liveryColor,
      decalColor: preset.decalColor,
      rimColor: preset.rimColor,
      liveryPattern: preset.liveryPattern,
      headlightColor: preset.headlightColor,
      underglowColor: preset.underglowColor,
    }));
  }, []);

  const handleCycleHeadlights = useCallback(() => {
    setConfig((prev) => {
      const order: HeadlightMode[] = ['off', 'low', 'high'];
      const next = order[(order.indexOf(prev.headlightMode) + 1) % order.length];
      return { ...prev, headlightMode: next };
    });
  }, []);

  const handleSelectCamera = useCallback((preset: CameraPreset) => {
    setActiveCamera(preset.id);
    viewportRef.current?.goToCameraPreset(preset);
  }, []);

  const handleExportGLB = useCallback(async () => {
    if (exporting) return;
    setExporting(true);
    try {
      await viewportRef.current?.exportGLB();
      showToast('Asset 3D (.GLB) berhasil didownload!');
    } catch {
      showToast('Gagal mengekspor file .GLB');
    } finally {
      setExporting(false);
    }
  }, [exporting, showToast]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return;
      }
      const key = e.key.toLowerCase();
      if (key === 'l') {
        handleCycleHeadlights();
      } else if (key === 'r') {
        setConfig((prev) => ({ ...prev, autoRotate: !prev.autoRotate }));
      } else {
        const cam = CAMERA_PRESETS.find((c) => c.shortcut === key);
        if (cam) {
          handleSelectCamera(cam);
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleCycleHeadlights, handleSelectCamera]);

  const activeModelMeta =
    CAR_MODELS.find((m) => m.id === config.carModel) ?? CAR_MODELS[0];

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#141b33]">
      {/* Full-bleed 3D Voxel Viewport */}
      <Viewport3D
        ref={viewportRef}
        config={config}
        onVoxelCountChange={setVoxelCount}
      />

      {/* Top-Left Automotive Title & Quick Car Switcher */}
      <header className="fixed top-4 left-4 z-20 flex flex-col gap-2 select-none">
        <div className="pointer-events-none flex items-start gap-3 px-4 py-3 rounded-2xl bg-slate-950/65 backdrop-blur-xl border border-white/12 shadow-2xl">
          {/* Iconic Motorsport tricolor stripe */}
          <div className="flex gap-[2px] h-9 pt-0.5 shrink-0">
            <span className="w-[3px] rounded-full bg-[#38bdf8]" />
            <span className="w-[3px] rounded-full bg-[#2563eb]" />
            <span className="w-[3px] rounded-full bg-[#ef4444]" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm sm:text-base font-bold tracking-tight text-white leading-none">
                {activeModelMeta.name}
              </h1>
              <span className="font-mono-tech text-[10px] font-semibold px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-400/30">
                {activeModelMeta.tag}
              </span>
            </div>
            <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-300">
              <span>{activeModelMeta.subtitle}</span>
              <span className="text-slate-500">•</span>
              <span className="font-mono-tech inline-flex items-center gap-1 text-sky-200">
                <Box className="w-3 h-3 text-sky-400" />
                {voxelCount.toLocaleString('id-ID')} blok
              </span>
            </div>
          </div>
        </div>

        {/* Quick Car Switcher Pill */}
        <div className="inline-flex flex-wrap max-w-[92vw] w-fit items-center gap-1 p-1 rounded-xl bg-slate-950/70 backdrop-blur-xl border border-white/12 shadow-xl">
          {CAR_MODELS.map((m) => {
            const active = config.carModel === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => handleSelectCarModel(m.id)}
                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                  active
                    ? 'bg-sky-500 text-slate-950 shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                {m.name}
              </button>
            );
          })}
        </div>

        <p className="pointer-events-none hidden md:block ml-1 text-[11px] text-slate-200/75 font-mono-tech drop-shadow">
          Drag putar • Scroll zoom • [L] Lampu Sorot
        </p>
      </header>

      {/* Collapsible Right-Side Customizer Panel */}
      <ControlPanel
        config={config}
        open={panelOpen}
        onToggleOpen={() => setPanelOpen((o) => !o)}
        onSelectCarModel={handleSelectCarModel}
        onUpdate={handleUpdate}
        onApplyPreset={handleApplyPreset}
      />

      {/* Compact Floating Bottom Action Dock */}
      <BottomDock
        config={config}
        activeCamera={activeCamera}
        exporting={exporting}
        onCycleHeadlights={handleCycleHeadlights}
        onSelectCamera={handleSelectCamera}
        onUpdate={handleUpdate}
        onExportGLB={handleExportGLB}
      />

      {/* Export Toast Notification */}
      {toast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900/95 border border-sky-400/40 text-xs font-semibold text-sky-100 shadow-2xl backdrop-blur-lg">
          <CheckCircle2 className="w-4 h-4 text-sky-400" />
          <span>{toast}</span>
        </div>
      )}
    </div>
  );
}

export default App;
