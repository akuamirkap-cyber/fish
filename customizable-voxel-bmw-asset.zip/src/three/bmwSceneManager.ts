import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { CameraPreset, CarConfig, CarModelId, LiveryPattern } from '../types/car';
import { BMWCarAsset, buildBMWVoxelCar, VOXEL_SIZE } from './bmwVoxelBuilder';

interface BeamUniforms {
  [uniform: string]: THREE.IUniform<unknown>;
  uColor: THREE.IUniform<THREE.Color>;
  uOpacity: THREE.IUniform<number>;
  uTime: THREE.IUniform<number>;
  uSoftness: THREE.IUniform<number>;
}

/**
 * Generates a soft circular glow texture for headlight flares, street lamp glow, & underglow.
 */
function createRadialGlowTexture(size = 256): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const half = size / 2;

  const grad = ctx.createRadialGradient(half, half, 0, half, half, half);
  grad.addColorStop(0.0, 'rgba(255, 255, 255, 1.0)');
  grad.addColorStop(0.22, 'rgba(255, 255, 255, 0.72)');
  grad.addColorStop(0.5, 'rgba(255, 255, 255, 0.2)');
  grad.addColorStop(0.8, 'rgba(255, 255, 255, 0.03)');
  grad.addColorStop(1.0, 'rgba(255, 255, 255, 0.0)');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

/**
 * Custom GLSL Volumetric Headlight Cone Shader:
 * Softly fades along length, feathers silhouette edges via Fresnel, and blends softly into the road.
 */
function createVolumetricBeamMaterial(
  colorHex: string,
  opacity: number,
  softness = 1.65
): { material: THREE.ShaderMaterial; uniforms: BeamUniforms } {
  const uniforms: BeamUniforms = {
    uColor: { value: new THREE.Color(colorHex) },
    uOpacity: { value: opacity },
    uTime: { value: 0 },
    uSoftness: { value: softness },
  };

  const material = new THREE.ShaderMaterial({
    uniforms,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.FrontSide,
    vertexShader: `
      varying vec2 vUv;
      varying vec3 vNormalView;
      varying vec3 vViewPos;
      varying float vWorldY;

      void main() {
        vUv = uv;
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldY = worldPos.y;
        vec4 mvPosition = viewMatrix * worldPos;
        vViewPos = -mvPosition.xyz;
        vNormalView = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      uniform float uOpacity;
      uniform float uTime;
      uniform float uSoftness;

      varying vec2 vUv;
      varying vec3 vNormalView;
      varying vec3 vViewPos;
      varying float vWorldY;

      void main() {
        float along = vUv.y;
        float distFade = pow(smoothstep(0.0, 0.9, along), 1.55);
        float apexFade = smoothstep(1.0, 0.93, along);

        vec3 viewDir = normalize(vViewPos);
        float ndotv = abs(dot(normalize(vNormalView), viewDir));
        float edgeFade = pow(ndotv, uSoftness);

        float floorFade = smoothstep(-0.02, 0.3, vWorldY);
        float shimmer = 0.95 + 0.05 * sin(vUv.y * 10.0 - uTime * 1.5);

        float alpha = distFade * apexFade * edgeFade * floorFade * shimmer * uOpacity;
        gl_FragColor = vec4(uColor, alpha);
      }
    `,
  });

  return { material, uniforms };
}

/**
 * Helper to create a cute Crossy Road blocky tree (brown trunk + stacked green voxel cubes).
 */
function createCuteCrossyTree(heightVariant: number): THREE.Group {
  const tree = new THREE.Group();

  const trunkMat = new THREE.MeshStandardMaterial({
    color: '#7c5338',
    roughness: 0.85,
    metalness: 0.02,
  });
  const leafLightMat = new THREE.MeshStandardMaterial({
    color: '#6ad152',
    roughness: 0.72,
    metalness: 0.02,
  });
  const leafMidMat = new THREE.MeshStandardMaterial({
    color: '#4fb83d',
    roughness: 0.74,
    metalness: 0.02,
  });

  const trunkH = 0.75 + heightVariant * 0.25;
  const trunk = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, trunkH, 0.42),
    trunkMat
  );
  trunk.position.y = trunkH / 2;
  trunk.castShadow = true;
  trunk.receiveShadow = true;
  tree.add(trunk);

  // Stacked chunky Crossy Road foliage blocks
  const crown1 = new THREE.Mesh(
    new THREE.BoxGeometry(1.18, 0.85, 1.18),
    leafMidMat
  );
  crown1.position.y = trunkH + 0.36;
  crown1.castShadow = true;
  crown1.receiveShadow = true;
  tree.add(crown1);

  const crown2 = new THREE.Mesh(
    new THREE.BoxGeometry(0.92, 0.65, 0.92),
    leafLightMat
  );
  crown2.position.y = trunkH + 0.96;
  crown2.castShadow = true;
  crown2.receiveShadow = true;
  tree.add(crown2);

  if (heightVariant > 0.5) {
    const crown3 = new THREE.Mesh(
      new THREE.BoxGeometry(0.58, 0.42, 0.58),
      leafLightMat
    );
    crown3.position.y = trunkH + 1.42;
    crown3.castShadow = true;
    crown3.receiveShadow = true;
    tree.add(crown3);
  }

  return tree;
}

/**
 * Helper to create a cute tiny voxel bush.
 */
function createCuteBush(): THREE.Group {
  const bush = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: '#52bd40',
    roughness: 0.75,
    metalness: 0.02,
  });
  const main = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.46, 0.68), mat);
  main.position.y = 0.23;
  main.castShadow = true;
  main.receiveShadow = true;
  bush.add(main);

  const top = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.22, 0.42), mat);
  top.position.set(0.08, 0.52, -0.04);
  top.castShadow = true;
  bush.add(top);
  return bush;
}

/**
 * Helper to create a cozy voxel street lamp for the Crossy Road sidewalk!
 */
function createCuteStreetLamp(): {
  group: THREE.Group;
  bulbMat: THREE.MeshStandardMaterial;
  lampLight: THREE.PointLight;
} {
  const group = new THREE.Group();
  const poleMat = new THREE.MeshStandardMaterial({
    color: '#3b4254',
    roughness: 0.6,
    metalness: 0.25,
  });
  const bulbMat = new THREE.MeshStandardMaterial({
    color: '#fff6d6',
    emissive: '#ffd573',
    emissiveIntensity: 2.2,
    roughness: 0.2,
  });

  // Base
  const base = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.2, 0.32), poleMat);
  base.position.y = 0.1;
  base.castShadow = true;
  group.add(base);

  // Pole
  const pole = new THREE.Mesh(new THREE.BoxGeometry(0.16, 2.55, 0.16), poleMat);
  pole.position.y = 1.38;
  pole.castShadow = true;
  group.add(pole);

  // Arm leaning slightly over sidewalk
  const arm = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.14, 0.16), poleMat);
  arm.position.set(0.28, 2.6, 0);
  arm.castShadow = true;
  group.add(arm);

  // Cute glowing lantern voxel
  const bulb = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.22, 0.28), bulbMat);
  bulb.position.set(0.54, 2.46, 0);
  group.add(bulb);

  const lampLight = new THREE.PointLight('#ffd573', 2.4, 7.5, 1.8);
  lampLight.position.set(0.54, 2.25, 0);
  group.add(lampLight);

  return { group, bulbMat, lampLight };
}

export class BMWSceneManager {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;

  private car: BMWCarAsset;
  private currentModel: CarModelId;
  private currentPattern: LiveryPattern;
  private currentHeadlightsOpen: boolean;
  private config: CarConfig;

  // Lighting & Diorama
  private ambientLight: THREE.AmbientLight;
  private hemiLight: THREE.HemisphereLight;
  private sunLight: THREE.DirectionalLight;
  private fillLight: THREE.DirectionalLight;
  private streetLampBulbMat!: THREE.MeshStandardMaterial;
  private streetLampLight!: THREE.PointLight;
  private scrollingDashes: THREE.Mesh[] = [];
  private scrollingProps: THREE.Object3D[] = [];
  private starsPoints!: THREE.Points;

  // Headlight Spotlight Rig
  private spotLights: THREE.SpotLight[] = [];
  private beamUniforms: Array<{ uniforms: BeamUniforms; role: 'core' | 'halo' }> = [];
  private beamMeshes: THREE.Mesh[] = [];
  private flareSprites: THREE.Sprite[] = [];
  private roadLightPool!: THREE.Mesh;
  private roadLightPoolMat!: THREE.MeshBasicMaterial;
  private tailGlowLight: THREE.PointLight;
  private underglowLight: THREE.PointLight;
  private underglowPlane: THREE.Mesh;
  private underglowMat: THREE.MeshBasicMaterial;

  // Animation & Camera Transition
  private rafId: number | null = null;
  private clock = new THREE.Clock();
  private camTransition: {
    startPos: THREE.Vector3;
    endPos: THREE.Vector3;
    startTarget: THREE.Vector3;
    endTarget: THREE.Vector3;
    elapsed: number;
    duration: number;
  } | null = null;

  private onVoxelCountChange?: (count: number) => void;
  private resizeObserver: ResizeObserver;

  constructor(
    container: HTMLElement,
    initialConfig: CarConfig,
    onVoxelCountChange?: (count: number) => void
  ) {
    this.container = container;
    this.config = { ...initialConfig };
    this.currentModel = initialConfig.carModel;
    this.currentPattern = initialConfig.liveryPattern;
    this.currentHeadlightsOpen = initialConfig.headlightMode !== 'off';
    this.onVoxelCountChange = onVoxelCountChange;

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // 1. Renderer — crisp, clean toy-like rendering
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);

    // 2. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#141b33');
    this.scene.fog = new THREE.Fog('#141b33', 18, 42);

    // 3. Semi-Isometric Friendly Camera (FOV 34 gives that iconic cute Crossy Road miniature look!)
    this.camera = new THREE.PerspectiveCamera(34, width / height, 0.1, 100);
    this.camera.position.set(6.4, 4.7, 6.8);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.07;
    this.controls.enablePan = false;
    this.controls.minDistance = 4.2;
    this.controls.maxDistance = 16.5;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.05;
    this.controls.minPolarAngle = 0.15;
    this.controls.target.set(0, 0.72, 0.2);

    this.controls.addEventListener('start', () => {
      this.camTransition = null;
    });

    // 4. Clean Soft Crossy Road Lighting
    this.ambientLight = new THREE.AmbientLight('#b5cbff', 0.52);
    this.scene.add(this.ambientLight);

    this.hemiLight = new THREE.HemisphereLight('#a5c4ff', '#1e2740', 0.65);
    this.scene.add(this.hemiLight);

    // Main Sun / Moon Directional Shadow Caster
    this.sunLight = new THREE.DirectionalLight('#dce8ff', 1.25);
    this.sunLight.position.set(7.5, 11.5, 5.5);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.set(2048, 2048);
    this.sunLight.shadow.camera.near = 1;
    this.sunLight.shadow.camera.far = 32;
    const d = 11.5;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0005;
    this.scene.add(this.sunLight);

    // Gentle back-left fill so every voxel face stays colorful & legible
    this.fillLight = new THREE.DirectionalLight('#7aa6ff', 0.55);
    this.fillLight.position.set(-7, 5, -6);
    this.scene.add(this.fillLight);

    // 5. Build the Charming Crossy Road Voxel Island Diorama!
    this.buildCrossyRoadDiorama();
    this.buildTwilightStars();

    // 6. Build the Cute Crossy Road BMW M3 GTR Car Asset
    this.car = buildBMWVoxelCar(initialConfig);
    this.scene.add(this.car.root);
    this.onVoxelCountChange?.(this.car.voxelCount);

    // 7. Build Dual Headlight Spotlight System
    const glowTex = createRadialGlowTexture(256);
    this.buildHeadlightRig(glowTex);

    // Cute warm red taillight bounce on the road behind the car
    this.tailGlowLight = new THREE.PointLight('#ff2e44', 1.4, 4.5, 1.8);
    this.tailGlowLight.position.set(0, 0.55, -2.2);
    this.scene.add(this.tailGlowLight);

    // Cute Neon Underglow
    this.underglowLight = new THREE.PointLight(
      initialConfig.underglowColor,
      0,
      4.5,
      1.7
    );
    this.underglowLight.position.set(0, 0.24, 0);
    this.scene.add(this.underglowLight);

    this.underglowMat = new THREE.MeshBasicMaterial({
      map: glowTex,
      color: new THREE.Color(initialConfig.underglowColor),
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.underglowPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(3.2, 5.2),
      this.underglowMat
    );
    this.underglowPlane.rotation.x = -Math.PI / 2;
    this.underglowPlane.position.y = 0.012;
    this.scene.add(this.underglowPlane);

    // Align lights & apply initial config
    this.alignLightsToCarModel(initialConfig.carModel);
    this.updateConfig(initialConfig);

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(container);

    this.animate();
  }

  /**
   * Builds an adorable Crossy Road style voxel street diorama:
   * - Clean 2-lane gray voxel road with scrolling white dashes
   * - Raised curbs & vibrant alternating green Crossy Road grass bands
   * - Chunky voxel dirt/stone island base underneath
   * - Cute blocky trees, tiny bushes, and a cozy street lamp
   */
  private buildCrossyRoadDiorama(): void {
    const diorama = new THREE.Group();
    const roadLen = 19;

    // 1. Center Asphalt Road Strip (x = -2.75 .. +2.75)
    const roadMat = new THREE.MeshStandardMaterial({
      color: '#464d5e',
      roughness: 0.82,
      metalness: 0.04,
    });
    const roadMesh = new THREE.Mesh(
      new THREE.BoxGeometry(5.5, 0.5, roadLen),
      roadMat
    );
    roadMesh.position.set(0, -0.25, 0.8);
    roadMesh.receiveShadow = true;
    diorama.add(roadMesh);

    // Road edge crisp subtle white shoulder lines
    const lineMat = new THREE.MeshStandardMaterial({
      color: '#eef2f7',
      roughness: 0.7,
      metalness: 0.02,
    });
    for (const sx of [-2.45, 2.45]) {
      const edgeLine = new THREE.Mesh(
        new THREE.BoxGeometry(0.14, 0.02, roadLen - 0.6),
        lineMat
      );
      edgeLine.position.set(sx, 0.01, 0.8);
      edgeLine.receiveShadow = true;
      diorama.add(edgeLine);
    }

    // Center white road dashes (scroll smoothly in cruise mode!)
    const dashGeo = new THREE.BoxGeometry(0.18, 0.02, 1.3);
    for (let z = -7.5; z <= 9.0; z += 2.75) {
      const dash = new THREE.Mesh(dashGeo, lineMat);
      dash.position.set(0, 0.01, z);
      dash.receiveShadow = true;
      diorama.add(dash);
      this.scrollingDashes.push(dash);
    }

    // 2. Cute Raised Sidewalk Curbs (left & right of road)
    const curbMat = new THREE.MeshStandardMaterial({
      color: '#aeb7c7',
      roughness: 0.78,
      metalness: 0.03,
    });
    for (const cx of [-3.05, 3.05]) {
      const curb = new THREE.Mesh(
        new THREE.BoxGeometry(0.6, 0.62, roadLen),
        curbMat
      );
      curb.position.set(cx, -0.19, 0.8);
      curb.receiveShadow = true;
      curb.castShadow = true;
      diorama.add(curb);
    }

    // 3. Vibrant Alternating Crossy Road Grass Strips on both sides!
    const grassA = new THREE.MeshStandardMaterial({
      color: '#6ad152',
      roughness: 0.8,
      metalness: 0.02,
    });
    const grassB = new THREE.MeshStandardMaterial({
      color: '#5cc246',
      roughness: 0.8,
      metalness: 0.02,
    });

    const stripWidth = 2.0;
    const sideStrips = [
      { x: -4.35, mat: grassA },
      { x: -6.35, mat: grassB },
      { x: 4.35, mat: grassA },
      { x: 6.35, mat: grassB },
    ];
    for (const s of sideStrips) {
      const strip = new THREE.Mesh(
        new THREE.BoxGeometry(stripWidth, 0.58, roadLen),
        s.mat
      );
      strip.position.set(s.x, -0.21, 0.8);
      strip.receiveShadow = true;
      diorama.add(strip);
    }

    // 4. Chunky Earth / Stone Floating Diorama Base Underneath
    const dirtMat = new THREE.MeshStandardMaterial({
      color: '#52443c',
      roughness: 0.92,
      metalness: 0.02,
    });
    const baseBlock = new THREE.Mesh(
      new THREE.BoxGeometry(14.5, 0.85, roadLen - 0.1),
      dirtMat
    );
    baseBlock.position.set(0, -0.92, 0.8);
    diorama.add(baseBlock);

    // 5. Cute Blocky Crossy Road Trees & Bushes along the green grass!
    const propDefs: Array<{
      kind: 'tree' | 'bush';
      x: number;
      z: number;
      variant: number;
    }> = [
      { kind: 'tree', x: -4.7, z: -4.8, variant: 1.0 },
      { kind: 'tree', x: -6.1, z: 2.6, variant: 0.3 },
      { kind: 'bush', x: -4.4, z: 5.5, variant: 0 },
      { kind: 'tree', x: 4.9, z: -3.2, variant: 0.7 },
      { kind: 'bush', x: 4.3, z: 0.6, variant: 0 },
      { kind: 'tree', x: 5.9, z: 5.2, variant: 0.2 },
    ];

    for (const p of propDefs) {
      const obj =
        p.kind === 'tree'
          ? createCuteCrossyTree(p.variant)
          : createCuteBush();
      obj.position.set(p.x, 0.08, p.z);
      diorama.add(obj);
      this.scrollingProps.push(obj);
    }

    // 6. Cozy Voxel Street Lamp on the left curb!
    const lamp = createCuteStreetLamp();
    lamp.group.position.set(-3.1, 0.12, -1.6);
    diorama.add(lamp.group);
    this.streetLampBulbMat = lamp.bulbMat;
    this.streetLampLight = lamp.lampLight;

    this.scene.add(diorama);
  }

  private buildTwilightStars(): void {
    const count = 75;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const radius = 18 + Math.random() * 14;
      const theta = Math.random() * Math.PI * 2;
      const y = 3.5 + Math.random() * 13;
      positions[i * 3] = Math.cos(theta) * radius;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = Math.sin(theta) * radius;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({
      color: '#e0eeff',
      size: 0.16,
      transparent: true,
      opacity: 0.75,
    });
    this.starsPoints = new THREE.Points(geo, mat);
    this.scene.add(this.starsPoints);
  }

  /**
   * Builds the cute, super crisp dual headlight spotlight beams aligned directly
   * with our Crossy Road BMW's glowing headlight blocks (x = ±3 * VOXEL_SIZE).
   */
  private buildHeadlightRig(glowTex: THREE.CanvasTexture): void {
    // Exact center of front glowing headlights on our Crossy grid:
    // x = ±3 * VOXEL_SIZE, y = (2 + 0.25) * VOXEL_SIZE, z = (7 + 0.5) * VOXEL_SIZE
    const headY = 2.25 * VOXEL_SIZE;
    const headZ = 7.5 * VOXEL_SIZE;
    const headXs = [-3.0 * VOXEL_SIZE, 3.0 * VOXEL_SIZE];

    const beamLength = 7.8;

    const buildConeGeo = (farRadius: number, nearRadius: number, length: number) => {
      const geo = new THREE.CylinderGeometry(nearRadius, farRadius, length, 28, 1, true);
      geo.translate(0, -length / 2, 0);
      geo.rotateX(-Math.PI / 2);
      return geo;
    };

    const coreGeo = buildConeGeo(1.3, 0.14, beamLength);
    const haloGeo = buildConeGeo(2.2, 0.22, beamLength * 0.94);

    for (const hx of headXs) {
      // 1. Real SpotLight illuminating the Crossy Road street & lane markings!
      const spot = new THREE.SpotLight(
        this.config.headlightColor,
        36,
        18,
        0.58,
        0.65,
        1.4
      );
      spot.position.set(hx, headY + 0.05, headZ + 0.04);
      spot.target.position.set(hx * 1.25, 0.0, headZ + 7.2);
      spot.castShadow = true;
      spot.shadow.mapSize.set(1024, 1024);
      spot.shadow.bias = -0.0008;
      this.scene.add(spot);
      this.scene.add(spot.target);
      this.spotLights.push(spot);

      // 2. Volumetric Light Cones aimed smoothly down the road
      const beamDir = new THREE.Vector3()
        .subVectors(spot.target.position, spot.position)
        .normalize();
      const quat = new THREE.Quaternion().setFromUnitVectors(
        new THREE.Vector3(0, 0, 1),
        beamDir
      );

      const core = createVolumetricBeamMaterial(this.config.headlightColor, 0.3, 1.8);
      const coreMesh = new THREE.Mesh(coreGeo, core.material);
      coreMesh.position.set(hx, headY, headZ + 0.01);
      coreMesh.quaternion.copy(quat);
      coreMesh.renderOrder = 10;
      this.scene.add(coreMesh);
      this.beamUniforms.push({ uniforms: core.uniforms, role: 'core' });
      this.beamMeshes.push(coreMesh);

      const halo = createVolumetricBeamMaterial(this.config.headlightColor, 0.14, 1.45);
      const haloMesh = new THREE.Mesh(haloGeo, halo.material);
      haloMesh.position.set(hx, headY, headZ);
      haloMesh.quaternion.copy(quat);
      haloMesh.renderOrder = 9;
      this.scene.add(haloMesh);
      this.beamUniforms.push({ uniforms: halo.uniforms, role: 'halo' });
      this.beamMeshes.push(haloMesh);

      // 3. Cute Soft Headlight Glow Flare right on the lens
      const spriteMat = new THREE.SpriteMaterial({
        map: glowTex,
        color: new THREE.Color(this.config.headlightColor),
        transparent: true,
        opacity: 0.82,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.position.set(hx, headY, headZ + 0.08);
      sprite.scale.set(0.88, 0.65, 1);
      sprite.renderOrder = 12;
      this.scene.add(sprite);
      this.flareSprites.push(sprite);
    }

    // Soft additive light pool directly on the road surface ahead of the car
    this.roadLightPoolMat = new THREE.MeshBasicMaterial({
      map: glowTex,
      color: new THREE.Color(this.config.headlightColor),
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.roadLightPool = new THREE.Mesh(
      new THREE.PlaneGeometry(4.4, 7.6),
      this.roadLightPoolMat
    );
    this.roadLightPool.rotation.x = -Math.PI / 2;
    this.roadLightPool.position.set(0, 0.022, headZ + 3.4);
    this.roadLightPool.renderOrder = 8;
    this.scene.add(this.roadLightPool);
  }

  private alignLightsToCarModel(carModel: CarModelId): void {
    const headZ =
      (carModel === 'vw-golf-gti' ||
      carModel === 'ae86-trueno' ||
      carModel === 'rwb-964'
        ? 6.5
        : 7.5) * VOXEL_SIZE;
    const headY =
      (carModel === 'ae86-trueno' ||
      carModel === 'mustang-gt' ||
      carModel === 'rwb-964'
        ? 3.25
        : 2.25) * VOXEL_SIZE;
    const tailZ = (carModel === 'vw-golf-gti' ? -6.8 : -7.8) * VOXEL_SIZE;

    for (let i = 0; i < this.spotLights.length; i++) {
      const spot = this.spotLights[i];
      spot.position.y = headY + 0.05;
      spot.position.z = headZ + 0.04;
      spot.target.position.z = headZ + 7.2;

      const beamDir = new THREE.Vector3()
        .subVectors(spot.target.position, spot.position)
        .normalize();
      const quat = new THREE.Quaternion().setFromUnitVectors(
        new THREE.Vector3(0, 0, 1),
        beamDir
      );

      const coreMesh = this.beamMeshes[i * 2];
      const haloMesh = this.beamMeshes[i * 2 + 1];
      if (coreMesh) {
        coreMesh.position.y = headY;
        coreMesh.position.z = headZ + 0.01;
        coreMesh.quaternion.copy(quat);
      }
      if (haloMesh) {
        haloMesh.position.y = headY;
        haloMesh.position.z = headZ;
        haloMesh.quaternion.copy(quat);
      }

      const flare = this.flareSprites[i];
      if (flare) {
        flare.position.y = headY;
        flare.position.z = headZ + 0.08;
      }
    }

    this.roadLightPool.position.z = headZ + 3.4;
    this.tailGlowLight.position.z = tailZ;
  }

  public updateConfig(next: CarConfig): void {
    this.config = { ...next };

    const nextLightsOpen = next.headlightMode !== 'off';
    const needsPopupRebuild =
      next.carModel === 'ae86-trueno' &&
      nextLightsOpen !== this.currentHeadlightsOpen;

    // Rebuild car geometry if model, livery pattern, or AE86 pop-up state changed
    if (
      next.carModel !== this.currentModel ||
      next.liveryPattern !== this.currentPattern ||
      needsPopupRebuild
    ) {
      this.currentModel = next.carModel;
      this.currentPattern = next.liveryPattern;
      this.currentHeadlightsOpen = nextLightsOpen;
      const count = this.car.rebuildCar(
        next.carModel,
        next.liveryPattern,
        nextLightsOpen
      );
      this.alignLightsToCarModel(next.carModel);
      this.onVoxelCountChange?.(count);
    }

    // Instant color updates
    this.car.materials.body.color.set(next.bodyColor);
    this.car.materials.livery.color.set(next.liveryColor);
    this.car.materials.decal.color.set(next.decalColor);
    this.car.materials.rim.color.set(next.rimColor);

    // Headlight Spotlight Rig
    const beamColor = new THREE.Color(next.headlightColor);
    const modeScale =
      next.headlightMode === 'high'
        ? 1.0
        : next.headlightMode === 'low'
        ? 0.45
        : 0.0;
    const effective = modeScale * next.beamIntensity;
    const isDay = next.lightingMood === 'studio';

    this.car.materials.headlight.emissive.copy(beamColor);
    this.car.materials.headlight.emissiveIntensity =
      next.headlightMode === 'off' ? 0.1 : 1.4 + effective * 2.4;

    this.car.materials.indicator.emissiveIntensity =
      next.headlightMode === 'off' ? 0.08 : 0.7;

    this.car.materials.taillight.emissiveIntensity =
      next.headlightMode === 'off' ? 0.12 : next.headlightMode === 'high' ? 2.4 : 1.5;

    this.tailGlowLight.intensity =
      next.headlightMode === 'off'
        ? 0
        : (next.headlightMode === 'high' ? 1.5 : 0.85) * (isDay ? 0.25 : 1.0);

    for (const spot of this.spotLights) {
      spot.color.copy(beamColor);
      spot.intensity = effective * (isDay ? 22 : 48);
      spot.angle = next.headlightMode === 'high' ? 0.6 : 0.45;
      spot.visible = effective > 0.01;
    }

    const beamVisMul = isDay ? 0.34 : 1.0;
    for (const b of this.beamUniforms) {
      b.uniforms.uColor.value.copy(beamColor);
      const baseOp = b.role === 'core' ? 0.3 : 0.15;
      b.uniforms.uOpacity.value = baseOp * effective * beamVisMul;
    }
    for (const mesh of this.beamMeshes) {
      mesh.visible = effective > 0.01;
    }

    for (const sprite of this.flareSprites) {
      sprite.material.color.copy(beamColor);
      sprite.material.opacity = Math.min(0.92, effective * (isDay ? 0.55 : 0.85));
      const sc = next.headlightMode === 'high' ? 1.0 : 0.72;
      sprite.scale.set(0.9 * sc, 0.65 * sc, 1);
      sprite.visible = effective > 0.01;
    }

    this.roadLightPoolMat.color.copy(beamColor);
    this.roadLightPoolMat.opacity = Math.min(
      0.55,
      effective * (isDay ? 0.14 : 0.38)
    );
    this.roadLightPool.visible = effective > 0.01;

    // Underglow
    const underColor = new THREE.Color(next.underglowColor);
    this.underglowLight.color.copy(underColor);
    this.underglowLight.intensity = next.underglowEnabled
      ? isDay
        ? 0.7
        : 2.5
      : 0;
    this.underglowMat.color.copy(underColor);
    this.underglowMat.opacity = next.underglowEnabled
      ? isDay
        ? 0.2
        : 0.52
      : 0;
    this.underglowPlane.visible = next.underglowEnabled;

    // Mood: Cozy Crossy Twilight Night vs Cheerful Sunny Crossy Day
    if (isDay) {
      this.scene.background = new THREE.Color('#9ad8ff');
      (this.scene.fog as THREE.Fog).color.set('#9ad8ff');
      this.ambientLight.color.set('#ffffff');
      this.ambientLight.intensity = 0.78;
      this.hemiLight.color.set('#d4f0ff');
      this.hemiLight.groundColor.set('#6da856');
      this.hemiLight.intensity = 0.85;
      this.sunLight.color.set('#fff6dc');
      this.sunLight.intensity = 2.0;
      this.fillLight.color.set('#bae6fd');
      this.fillLight.intensity = 0.55;
      this.streetLampBulbMat.emissiveIntensity = 0.15;
      this.streetLampLight.intensity = 0;
      this.starsPoints.visible = false;
    } else {
      this.scene.background = new THREE.Color('#141b33');
      (this.scene.fog as THREE.Fog).color.set('#141b33');
      this.ambientLight.color.set('#a8c4ff');
      this.ambientLight.intensity = 0.45;
      this.hemiLight.color.set('#8fb4ff');
      this.hemiLight.groundColor.set('#1c243d');
      this.hemiLight.intensity = 0.58;
      this.sunLight.color.set('#cfe0ff');
      this.sunLight.intensity = 1.05;
      this.fillLight.color.set('#6b95f0');
      this.fillLight.intensity = 0.48;
      this.streetLampBulbMat.emissiveIntensity = 2.2;
      this.streetLampLight.intensity = 2.4;
      this.starsPoints.visible = true;
    }

    this.controls.autoRotate = next.autoRotate;
    this.controls.autoRotateSpeed = 1.25;
  }

  public goToCameraPreset(preset: CameraPreset): void {
    this.camTransition = {
      startPos: this.camera.position.clone(),
      endPos: new THREE.Vector3(...preset.position),
      startTarget: this.controls.target.clone(),
      endTarget: new THREE.Vector3(...preset.target),
      elapsed: 0,
      duration: 0.6,
    };
  }

  public exportGLB(): Promise<void> {
    return new Promise((resolve, reject) => {
      const exporter = new GLTFExporter();
      exporter.parse(
        this.car.root,
        (result) => {
          const blob =
            result instanceof ArrayBuffer
              ? new Blob([result], { type: 'model/gltf-binary' })
              : new Blob([JSON.stringify(result)], { type: 'application/json' });

          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${this.config.carModel}-crossy-voxel-${this.config.liveryPattern}.glb`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          setTimeout(() => URL.revokeObjectURL(url), 1000);
          resolve();
        },
        (err) => reject(err),
        { binary: true }
      );
    });
  }

  private handleResize(): void {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private animate = (): void => {
    this.rafId = requestAnimationFrame(this.animate);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    const elapsed = this.clock.getElapsedTime();

    for (const b of this.beamUniforms) {
      b.uniforms.uTime.value = elapsed;
    }

    // Cute Crossy Road car animation!
    if (this.config.wheelSpin) {
      // Spin chunky wheels smoothly
      const spinSpeed = dt * 8.0;
      for (const w of this.car.wheels) {
        w.rotation.x += spinSpeed;
      }

      // Adorable Crossy Road bouncy toy cruise bob!
      this.car.chassisGroup.position.y =
        Math.abs(Math.sin(elapsed * 9.5)) * 0.032;
      this.car.chassisGroup.rotation.z = Math.sin(elapsed * 4.75) * 0.015;

      // Scroll road dashes & roadside trees smoothly so the cute BMW drives down the street!
      const speed = dt * 5.2;
      for (const dash of this.scrollingDashes) {
        dash.position.z -= speed;
        if (dash.position.z < -8.2) {
          dash.position.z += 19.25;
        }
      }
      for (const prop of this.scrollingProps) {
        prop.position.z -= speed;
        if (prop.position.z < -8.0) {
          prop.position.z += 17.5;
        }
      }
    } else {
      // Very subtle cute idle engine purr
      this.car.chassisGroup.position.y = Math.sin(elapsed * 5.0) * 0.008;
      this.car.chassisGroup.rotation.z *= 0.85;
    }

    // Smooth camera preset ease-out
    if (this.camTransition) {
      this.camTransition.elapsed += dt;
      const t = Math.min(1, this.camTransition.elapsed / this.camTransition.duration);
      const ease = 1 - Math.pow(1 - t, 3);
      this.camera.position.lerpVectors(
        this.camTransition.startPos,
        this.camTransition.endPos,
        ease
      );
      this.controls.target.lerpVectors(
        this.camTransition.startTarget,
        this.camTransition.endTarget,
        ease
      );
      if (t >= 1) {
        this.camTransition = null;
      }
    }

    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  };

  public dispose(): void {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
    }
    this.resizeObserver.disconnect();
    this.controls.dispose();
    this.car.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
