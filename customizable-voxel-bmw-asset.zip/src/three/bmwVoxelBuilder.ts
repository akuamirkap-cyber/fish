import * as THREE from 'three';
import { CarConfig, CarModelId, LiveryPattern } from '../types/car';

// Chunky, toy-like Crossy Road voxel scale
export const VOXEL_SIZE = 0.25;

export type VoxelMatKey =
  | 'body'
  | 'livery'
  | 'decal'
  | 'carbon'
  | 'grille'
  | 'chrome'
  | 'glass'
  | 'tire'
  | 'rim'
  | 'caliper'
  | 'headlight'
  | 'indicator'
  | 'taillight'
  | 'badgeBlue'
  | 'plate';

interface VoxelEntry {
  x: number;
  y: number;
  z: number;
  mat: VoxelMatKey;
}

export interface BMWVoxelMaterials {
  body: THREE.MeshStandardMaterial;
  livery: THREE.MeshStandardMaterial;
  decal: THREE.MeshStandardMaterial;
  carbon: THREE.MeshStandardMaterial;
  grille: THREE.MeshStandardMaterial;
  chrome: THREE.MeshStandardMaterial;
  glass: THREE.MeshStandardMaterial;
  tire: THREE.MeshStandardMaterial;
  rim: THREE.MeshStandardMaterial;
  caliper: THREE.MeshStandardMaterial;
  headlight: THREE.MeshStandardMaterial;
  indicator: THREE.MeshStandardMaterial;
  taillight: THREE.MeshStandardMaterial;
  badgeBlue: THREE.MeshStandardMaterial;
  plate: THREE.MeshStandardMaterial;
}

export interface BMWCarAsset {
  root: THREE.Group;
  chassisGroup: THREE.Group;
  wheels: THREE.Group[];
  materials: BMWVoxelMaterials;
  voxelCount: number;
  rebuildCar: (
    carModel: CarModelId,
    pattern: LiveryPattern,
    headlightsOpen?: boolean
  ) => number;
  dispose: () => void;
}

/**
 * Generates a crisp Crossy Road style voxel block with a subtle 4.5% micro-bevel
 * so blocks stay super clean & blocky while catching soft toy-like highlights on edges.
 */
function createCrispVoxelTemplate(
  size: number,
  bevelRatio = 0.045
): {
  positions: Float32Array;
  normals: Float32Array;
} {
  const h = size * 0.5;
  const i = h * (1 - bevelRatio);

  const pos: number[] = [];
  const norm: number[] = [];

  const pushTri = (
    a: [number, number, number],
    b: [number, number, number],
    c: [number, number, number]
  ) => {
    const ux = b[0] - a[0];
    const uy = b[1] - a[1];
    const uz = b[2] - a[2];
    const vx = c[0] - a[0];
    const vy = c[1] - a[1];
    const vz = c[2] - a[2];
    let nx = uy * vz - uz * vy;
    let ny = uz * vx - ux * vz;
    let nz = ux * vy - uy * vx;
    const len = Math.hypot(nx, ny, nz) || 1;
    nx /= len;
    ny /= len;
    nz /= len;

    pos.push(a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]);
    norm.push(nx, ny, nz, nx, ny, nz, nx, ny, nz);
  };

  const pushQuad = (
    a: [number, number, number],
    b: [number, number, number],
    c: [number, number, number],
    d: [number, number, number]
  ) => {
    pushTri(a, b, c);
    pushTri(a, c, d);
  };

  // 6 main flat faces
  pushQuad([-i, h, i], [i, h, i], [i, h, -i], [-i, h, -i]);
  pushQuad([-i, -h, -i], [i, -h, -i], [i, -h, i], [-i, -h, i]);
  pushQuad([-i, -i, h], [i, -i, h], [i, i, h], [-i, i, h]);
  pushQuad([i, -i, -h], [-i, -i, -h], [-i, i, -h], [i, i, -h]);
  pushQuad([h, -i, i], [h, -i, -i], [h, i, -i], [h, i, i]);
  pushQuad([-h, -i, -i], [-h, -i, i], [-h, i, i], [-h, i, -i]);

  // 12 micro-bevel edges
  pushQuad([-i, i, h], [i, i, h], [i, h, i], [-i, h, i]);
  pushQuad([i, i, -h], [-i, i, -h], [-i, h, -i], [i, h, -i]);
  pushQuad([h, i, i], [h, i, -i], [i, h, -i], [i, h, i]);
  pushQuad([-h, i, -i], [-h, i, i], [-i, h, i], [-i, h, -i]);

  pushQuad([-i, -h, i], [i, -h, i], [i, -i, h], [-i, -i, h]);
  pushQuad([i, -h, -i], [-i, -h, -i], [-i, -i, -h], [i, -i, -h]);
  pushQuad([i, -h, i], [i, -h, -i], [h, -i, -i], [h, -i, i]);
  pushQuad([-i, -h, -i], [-i, -h, i], [-h, -i, i], [-h, -i, -i]);

  pushQuad([i, -i, h], [h, -i, i], [h, i, i], [i, i, h]);
  pushQuad([-h, -i, i], [-i, -i, h], [-i, i, h], [-h, i, i]);
  pushQuad([h, -i, -i], [i, -i, -h], [i, i, -h], [h, i, -i]);
  pushQuad([-i, -i, -h], [-h, -i, -i], [-h, i, -i], [-i, i, -h]);

  // 8 corner micro-chamfers
  pushTri([i, i, h], [h, i, i], [i, h, i]);
  pushTri([-h, i, i], [-i, i, h], [-i, h, i]);
  pushTri([h, i, -i], [i, i, -h], [i, h, -i]);
  pushTri([-i, i, -h], [-h, i, -i], [-i, h, -i]);

  pushTri([h, -i, i], [i, -i, h], [i, -h, i]);
  pushTri([-i, -i, h], [-h, -i, i], [-i, -h, i]);
  pushTri([i, -i, -h], [h, -i, -i], [i, -h, -i]);
  pushTri([-h, -i, -i], [-i, -i, -h], [-i, -h, -i]);

  return {
    positions: new Float32Array(pos),
    normals: new Float32Array(norm),
  };
}

const VOXEL_TEMPLATE = createCrispVoxelTemplate(VOXEL_SIZE, 0.045);

function buildMergedVoxelGeometry(
  voxels: Array<{ x: number; y: number; z: number }>,
  offsetX = 0,
  offsetY = 0,
  offsetZ = 0,
  scaleX = 1,
  scaleY = 1,
  scaleZ = 1
): THREE.BufferGeometry {
  const tplPos = VOXEL_TEMPLATE.positions;
  const tplNorm = VOXEL_TEMPLATE.normals;
  const floatsPerVoxel = tplPos.length;
  const count = voxels.length;

  const positions = new Float32Array(count * floatsPerVoxel);
  const normals = new Float32Array(count * floatsPerVoxel);

  for (let v = 0; v < count; v++) {
    const vx = (voxels[v].x + offsetX) * VOXEL_SIZE * scaleX;
    const vy = (voxels[v].y + offsetY) * VOXEL_SIZE * scaleY;
    const vz = (voxels[v].z + offsetZ) * VOXEL_SIZE * scaleZ;
    const base = v * floatsPerVoxel;

    for (let j = 0; j < floatsPerVoxel; j += 3) {
      positions[base + j] = tplPos[j] * scaleX + vx;
      positions[base + j + 1] = tplPos[j + 1] * scaleY + vy;
      positions[base + j + 2] = tplPos[j + 2] * scaleZ + vz;

      normals[base + j] = tplNorm[j];
      normals[base + j + 1] = tplNorm[j + 1];
      normals[base + j + 2] = tplNorm[j + 2];
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
  geometry.computeBoundingSphere();
  return geometry;
}

// =====================================================================
// CAR 1: BMW M3 GTR (E46) — CROSSY ROAD VOXEL STYLE
// =====================================================================

function isBMWLiveryVoxel(
  x: number,
  y: number,
  z: number,
  pattern: LiveryPattern
): boolean {
  if (pattern === 'clean') return false;
  const ax = Math.abs(x);

  if (pattern === 'm-stripe') {
    if (ax <= 1 && y >= 3) return true;
    if (ax === 4 && y === 2 && z >= -5 && z <= 5) return true;
    return false;
  }

  // Iconic Most Wanted '05 Livery
  if (y >= 4) return ax >= 2;
  if (z >= 3) {
    if (ax >= 2 && y === 3) return true;
    if (ax === 4 && y === 2 && z <= 6) return true;
    return false;
  }
  if (z <= -3) {
    if (ax >= 2 && y === 3) return true;
    if (ax === 4 && y === 2 && z >= -6) return true;
    return false;
  }
  if (ax === 4) {
    if (y === 2) return true;
    if (y === 3 && z <= -1) return true;
  }
  return false;
}

function isBMWWheelCutout(x: number, y: number, z: number): boolean {
  const ax = Math.abs(x);
  if (ax < 3 || y > 2) return false;
  if (z >= 3 && z <= 5) return true;
  if (z >= -5 && z <= -3) return true;
  return false;
}

function generateBMWVoxels(pattern: LiveryPattern): VoxelEntry[] {
  const map = new Map<string, VoxelEntry>();
  const set = (x: number, y: number, z: number, mat: VoxelMatKey) => {
    map.set(`${x},${y},${z}`, { x, y, z, mat });
  };
  const paintMat = (x: number, y: number, z: number): VoxelMatKey =>
    isBMWLiveryVoxel(x, y, z, pattern) ? 'livery' : 'body';

  // 1. Lower splitter & side skirts (y = 1)
  for (let z = -7; z <= 7; z++) {
    for (let x = -4; x <= 4; x++) {
      if (isBMWWheelCutout(x, 1, z)) continue;
      if (Math.abs(x) === 4 && z === -2) {
        set(x, 1, z, 'chrome');
        continue;
      }
      set(x, 1, z, 'carbon');
    }
  }

  // 2. Main body (y = 2..3)
  for (let y = 2; y <= 3; y++) {
    for (let z = -7; z <= 7; z++) {
      if (y === 3 && z === 7) continue;
      for (let x = -4; x <= 4; x++) {
        if (isBMWWheelCutout(x, y, z)) continue;
        set(x, y, z, paintMat(x, y, z));
      }
    }
  }

  // 3. Front BMW Kidney Grilles & Headlights (z = 7)
  set(-1, 2, 7, 'grille');
  set(1, 2, 7, 'grille');
  set(-3, 2, 7, 'headlight');
  set(3, 2, 7, 'headlight');
  set(-4, 2, 7, 'indicator');
  set(4, 2, 7, 'indicator');
  set(0, 3, 6, 'badgeBlue');
  set(-2, 3, 4, 'grille');
  set(2, 3, 4, 'grille');

  // 4. Rear Taillights & Plate (z = -7)
  set(-1, 2, -7, 'plate');
  set(0, 2, -7, 'plate');
  set(1, 2, -7, 'plate');
  set(-4, 2, -7, 'taillight');
  set(-3, 2, -7, 'taillight');
  set(3, 2, -7, 'taillight');
  set(4, 2, -7, 'taillight');
  set(0, 3, -7, 'badgeBlue');

  // 5. Cabin (y = 4..5, x = -3..3, z = -4..2)
  for (let y = 4; y <= 5; y++) {
    for (let z = -4; z <= 2; z++) {
      for (let x = -3; x <= 3; x++) {
        const ax = Math.abs(x);
        const isFront = z === 2;
        const isBack = z === -4;
        const isSide = ax === 3;
        if (!isFront && !isBack && !isSide) {
          set(x, y, z, 'grille');
          continue;
        }
        if (isFront || isBack) {
          set(x, y, z, ax === 3 ? paintMat(x, y, z) : 'glass');
          continue;
        }
        if (isSide) {
          if (z === -1) set(x, y, z, 'carbon');
          else if (z === -3) set(x, y, z, paintMat(x, y, z));
          else set(x, y, z, 'glass');
        }
      }
    }
  }

  // 6. Roof (y = 6)
  for (let z = -4; z <= 2; z++) {
    for (let x = -3; x <= 3; x++) {
      if ((z === 2 || z === -4) && Math.abs(x) === 3) continue;
      set(x, 6, z, paintMat(x, 6, z));
    }
  }

  // 7. Side mirrors & GT Wing
  const mirrorMat: VoxelMatKey = pattern === 'clean' ? 'body' : 'livery';
  set(-4, 4, 2, mirrorMat);
  set(4, 4, 2, mirrorMat);

  set(-2, 4, -6, 'carbon');
  set(2, 4, -6, 'carbon');
  for (let x = -4; x <= 4; x++) {
    set(x, 5, -7, 'carbon');
  }
  set(-4, 6, -7, pattern === 'clean' ? 'carbon' : 'livery');
  set(4, 6, -7, pattern === 'clean' ? 'carbon' : 'livery');

  return cullHiddenVoxels(map);
}

// =====================================================================
// CAR 2: VOLKSWAGEN GOLF GTI Mk5 (SONNY / HO SEUN) — CROSSY VOXEL STYLE
// =====================================================================

function isGolfWheelCutout(x: number, y: number, z: number): boolean {
  const ax = Math.abs(x);
  if (ax < 3 || y > 2) return false;
  // Front wheel bay: z = 2, 3, 4 (center z = 3.0)
  if (z >= 2 && z <= 4) return true;
  // Rear wheel bay: z = -5, -4, -3 (center z = -4.0) -> short hatchback rear!
  if (z >= -5 && z <= -3) return true;
  return false;
}

/**
 * Sonny (Ho Seun) Blacklist #15 VW Golf GTI Livery:
 * - Royal Blue (`livery`) front bumper/fenders & rear quarter panels/hatch/spoiler
 * - Crisp White (`body`) main side doors, roof, roof scoop, mirrors & hood center panel
 * - Crimson Red (`decal`) bold Japanese kanji "極速" motif on doors & hood!
 */
function paintGolfVoxel(
  x: number,
  y: number,
  z: number,
  pattern: LiveryPattern
): VoxelMatKey {
  if (pattern === 'clean') return 'body';

  const ax = Math.abs(x);

  if (pattern === 'm-stripe') {
    if (ax <= 1 && y >= 3) return 'livery';
    if (ax === 4 && y === 2 && z >= -5 && z <= 4) return 'livery';
    return 'body';
  }

  // Sonny's Iconic Most Wanted #15 Livery!
  // 1. Front nose & front fenders (z >= 3): Royal Blue wrap with White hood center + Red hood kanji!
  if (z >= 4) {
    if (y === 3 && ax <= 2 && z <= 5) {
      // White hood center with bold Red kanji accent block
      if ((x === 0 && z >= 4) || (ax === 1 && z === 4)) return 'decal';
      return 'body';
    }
    return 'livery'; // Royal Blue front bumper & fenders
  }

  // Front A-pillar & front fender border at z = 3
  if (z === 3 && y <= 3) {
    if (ax >= 3) return 'livery';
    return 'body';
  }

  // 2. Rear Hatch & Quarter Haunches (z <= -3): Royal Blue wrap!
  if (z <= -3) {
    // Roof stays crisp white except the rear hatch edge & spoiler (z <= -5)
    if (y === 6) {
      return z <= -5 ? 'livery' : 'body';
    }
    return 'livery';
  }

  // 3. Side Doors (-2 <= z <= 2): Crisp White doors with Red kanji "極速" & Blue arc!
  if (ax === 4 && y >= 2 && y <= 3) {
    // Blue rear swoosh arc meeting the white door at z = -2
    if (z === -2 && y === 2) return 'livery';
    // Red kanji "極速" pixel graphic across the white door!
    if ((z === 1 && y === 3) || (z === 0 && y >= 2) || (z === -1 && y === 2)) {
      return 'decal';
    }
    return 'body';
  }

  return 'body';
}

function generateGolfGTIVoxels(pattern: LiveryPattern): VoxelEntry[] {
  const map = new Map<string, VoxelEntry>();
  const set = (x: number, y: number, z: number, mat: VoxelMatKey) => {
    map.set(`${x},${y},${z}`, { x, y, z, mat });
  };
  const paint = (x: number, y: number, z: number): VoxelMatKey =>
    paintGolfVoxel(x, y, z, pattern);

  // 1. LOWER SKIRTS, FRONT SPLITTER & REAR DIFFUSER (y = 1, z = -6..6)
  for (let z = -6; z <= 6; z++) {
    for (let x = -4; x <= 4; x++) {
      if (isGolfWheelCutout(x, 1, z)) continue;

      // Wide front GTI honeycomb air dam (z = 6, y = 1)
      if (z === 6) {
        if (Math.abs(x) <= 2) {
          set(x, 1, z, 'grille');
        } else {
          set(x, 1, z, pattern === 'most-wanted' ? 'livery' : 'carbon');
        }
        continue;
      }

      // Rear GTI twin chrome exhaust on driver-left (z = -6, y = 1, x = -2, -1)
      if (z === -6 && (x === -2 || x === -1)) {
        set(x, 1, z, 'chrome');
        continue;
      }

      set(x, 1, z, 'carbon');
    }
  }

  // 2. MAIN CHUNKY HATCHBACK BODY (y = 2..3, z = -6..6)
  for (let y = 2; y <= 3; y++) {
    for (let z = -6; z <= 6; z++) {
      // Cute rounded Golf Mk5 short hood step at z = 6 (y = 2 only)
      if (y === 3 && z === 6) continue;

      for (let x = -4; x <= 4; x++) {
        if (isGolfWheelCutout(x, y, z)) continue;
        set(x, y, z, paint(x, y, z));
      }
    }
  }

  // 3. FRONT MK5 GOLF GTI GRILLE, VW EMBLEM & HEADLIGHTS (z = 6)
  // Iconic black center U-grille with silver VW badge in center!
  set(-1, 2, 6, 'grille');
  set(0, 2, 6, 'chrome'); // VW Roundel emblem!
  set(1, 2, 6, 'grille');

  // Glowing GTI headlights + amber corners
  set(-3, 2, 6, 'headlight');
  set(3, 2, 6, 'headlight');
  set(-4, 2, 6, 'indicator');
  set(4, 2, 6, 'indicator');

  // 4. REAR HATCHBACK TAILGATE & GOLF TAIL LIGHTS (z = -6..-5)
  // Vertical hatchback upper tailgate (y = 4..5 at z = -6..-5)!
  for (let y = 4; y <= 5; y++) {
    for (let x = -3; x <= 3; x++) {
      const ax = Math.abs(x);
      // C-pillars on outer rear corners, tinted rear hatch window in center!
      if (ax === 3) {
        set(x, y, -6, paint(x, y, -6));
      } else {
        set(x, y, -6, 'glass');
      }
    }
  }

  // White license plate on lower rear hatch (y = 2, z = -6)
  set(-1, 2, -6, 'plate');
  set(0, 2, -6, 'plate');
  set(1, 2, -6, 'plate');

  // Iconic Golf Mk5 glowing red round-square taillights (y = 3, z = -6)
  set(-4, 3, -6, 'taillight');
  set(-3, 3, -6, 'taillight');
  set(3, 3, -6, 'taillight');
  set(4, 3, -6, 'taillight');
  set(0, 3, -6, 'chrome'); // Rear VW hatch emblem

  // 5. HATCHBACK GREENHOUSE / CABIN (y = 4..5, x = -3..3, z = -5..2)
  for (let y = 4; y <= 5; y++) {
    for (let z = -5; z <= 2; z++) {
      for (let x = -3; x <= 3; x++) {
        const ax = Math.abs(x);
        const isFront = z === 2;
        const isSide = ax === 3;

        if (!isFront && !isSide && z > -6) {
          // Solid dark interior core
          set(x, y, z, 'grille');
          continue;
        }

        // Front steep hatchback windshield + painted A-pillars
        if (isFront) {
          set(x, y, z, ax === 3 ? paint(x, y, z) : 'glass');
          continue;
        }

        // Side windows + thick C-pillar sweeping into hatchback tail
        if (isSide) {
          if (z <= -3) {
            set(x, y, z, paint(x, y, z));
          } else if (z === -1) {
            set(x, y, z, 'carbon'); // Slim B-pillar
          } else {
            set(x, y, z, 'glass');
          }
        }
      }
    }
  }

  // 6. HATCHBACK ROOF + INTEGRATED GTI ROOF SPOILER (y = 6, z = -6..2)
  for (let z = -6; z <= 2; z++) {
    for (let x = -3; x <= 3; x++) {
      // Gently round front corners of roof
      if (z === 2 && Math.abs(x) === 3) continue;
      // Integrated hatch spoiler sticks out slightly at rear z = -6!
      set(x, 6, z, paint(x, 6, z));
    }
  }

  // 7. SONNY'S SIGNATURE WHITE RALLY ROOF SCOOP (y = 7)!
  set(-1, 7, 0, 'body');
  set(0, 7, 0, 'grille'); // Forward-facing scoop intake mouth!
  set(1, 7, 0, 'body');
  set(-1, 7, -1, 'body');
  set(0, 7, -1, 'body');
  set(1, 7, -1, 'body');

  // 8. ADORABLE WHITE SIDE MIRRORS (matching Sonny's Golf in screenshot!)
  set(-4, 4, 2, 'body');
  set(4, 4, 2, 'body');

  return cullHiddenVoxels(map);
}

// =====================================================================
// CAR 3: TOYOTA SPRINTER TRUENO AE86 (INITIAL D PANDA — IMAGE 1)
// =====================================================================

function paintAE86Voxel(
  x: number,
  y: number,
  z: number,
  pattern: LiveryPattern
): VoxelMatKey {
  if (pattern === 'clean') return 'body';
  const ax = Math.abs(x);

  if (pattern === 'm-stripe') {
    if (ax <= 1 && y >= 3) return 'livery';
    if (y === 1) return 'livery';
    return 'body';
  }

  // Classic Stage 1 Initial D Panda Trueno (matching Image 1: crisp White Hood + Black Lower Trim!):
  // 1. Lower Panda Black Bumpers, Front Lip & Side Skirts (y = 1)
  if (y === 1) return 'livery';

  // 2. Crisp Panda Black Side Trim & Fender Arch Lip along y = 2:
  if (y === 2) {
    // Classic black wheel-arch trim above front & rear wheels
    if (ax === 4 && (z === 2 || z === 6 || z === -2 || z === -6)) {
      return 'livery';
    }
    // Signature Panda black side trim stripe along doors & rear bumper edge
    if (ax === 4 && z >= -1 && z <= 1) {
      // Tiny Fujiwara Tofu decal hint on right door, black trim on left
      return x === 4 && z === 0 ? 'decal' : 'body';
    }
    // Black rear bumper upper corner wrap (z = -7)
    if (z === -7 && ax >= 3) return 'livery';
    return 'body';
  }

  // 3. White Hood, White Roof, White Upper Body (matching Image 1!)
  return 'body';
}

function generateAE86Voxels(
  pattern: LiveryPattern,
  headlightsOpen: boolean
): VoxelEntry[] {
  const map = new Map<string, VoxelEntry>();
  const set = (x: number, y: number, z: number, mat: VoxelMatKey) => {
    map.set(`${x},${y},${z}`, { x, y, z, mat });
  };
  const paint = (x: number, y: number, z: number): VoxelMatKey =>
    paintAE86Voxel(x, y, z, pattern);

  // 1. PANDA BLACK BUMPERS & SIDE SKIRTS (y = 1, z = -7..7)
  for (let z = -7; z <= 7; z++) {
    for (let x = -4; x <= 4; x++) {
      if (isBMWWheelCutout(x, 1, z)) continue;
      if (z === -7 && x === 2) {
        set(x, 1, z, 'chrome'); // Rear exhaust tip
        continue;
      }
      set(x, 1, z, paint(x, 1, z));
    }
  }

  // Iconic Yellow Fog Lights + White Japanese Plate in the Panda front bumper (y = 1, z = 7)!
  set(-2, 1, 7, 'indicator');
  set(2, 1, 7, 'indicator');
  set(-1, 1, 7, 'plate');
  set(0, 1, 7, 'plate');
  set(1, 1, 7, 'plate');

  // 2. WEDGE-NOSE AE86 MAIN BODY — CRISP WHITE HOOD (y = 2..3, z = -7..7)
  for (let y = 2; y <= 3; y++) {
    for (let z = -7; z <= 7; z++) {
      // Sleek wedge slope: z = 7 ends at y = 2 so the hood slopes cleanly down!
      if (y === 3 && z === 7) continue;

      for (let x = -4; x <= 4; x++) {
        if (isBMWWheelCutout(x, y, z)) continue;
        set(x, y, z, paint(x, y, z));
      }
    }
  }

  // 3. SLIM BLACK TRUENO FRONT GRILLE & AMBER BLINKERS (z = 7, y = 2)
  set(-1, 2, 7, 'grille');
  set(0, 2, 7, 'grille');
  set(1, 2, 7, 'grille');
  set(-2, 2, 7, 'grille');
  set(2, 2, 7, 'grille');
  set(-4, 2, 7, 'indicator');
  set(4, 2, 7, 'indicator');
  set(-3, 2, 7, 'indicator');
  set(3, 2, 7, 'indicator');

  // 4. ICONIC POP-UP HEADLIGHTS! (Pop up at y = 3, z = 6 when lights are ON)
  if (headlightsOpen) {
    set(-3, 3, 6, 'headlight');
    set(3, 3, 6, 'headlight');
    // Black pop-up headlight hood covers behind the lenses (exact match to Image 1!)
    set(-3, 3, 5, 'carbon');
    set(3, 3, 5, 'carbon');
  }

  // 5. REAR TRUENO FASTBACK TAILLIGHTS & BLACK LIP SPOILER (z = -7)
  set(-4, 2, -7, 'taillight');
  set(-3, 2, -7, 'taillight');
  set(3, 2, -7, 'taillight');
  set(4, 2, -7, 'taillight');
  set(-1, 2, -7, 'plate');
  set(0, 2, -7, 'plate');
  set(1, 2, -7, 'plate');
  for (let x = -3; x <= 3; x++) {
    set(x, 3, -7, 'carbon');
  }

  // 6. FASTBACK 3-DOOR LIFTBACK CABIN (y = 4..5, x = -3..3, z = -5..2)
  for (let y = 4; y <= 5; y++) {
    const zMin = y === 4 ? -5 : -4;
    for (let z = zMin; z <= 2; z++) {
      for (let x = -3; x <= 3; x++) {
        const ax = Math.abs(x);
        const isFront = z === 2;
        const isBack = z === zMin;
        const isSide = ax === 3;

        if (!isFront && !isBack && !isSide) {
          set(x, y, z, 'grille');
          continue;
        }
        if (isFront || isBack) {
          set(x, y, z, ax === 3 ? paint(x, y, z) : 'glass');
          continue;
        }
        if (isSide) {
          if (z === -1) set(x, y, z, 'carbon');
          else if (z <= -3) set(x, y, z, paint(x, y, z));
          else set(x, y, z, 'glass');
        }
      }
    }
  }

  // 7. CRISP WHITE ROOF (y = 6, z = -3..2)
  for (let z = -3; z <= 2; z++) {
    for (let x = -3; x <= 3; x++) {
      if ((z === 2 || z === -3) && Math.abs(x) === 3) continue;
      set(x, 6, z, paint(x, 6, z));
    }
  }

  // 8. BLACK SIDE MIRRORS (matching Image 1!)
  set(-4, 4, 2, 'carbon');
  set(4, 4, 2, 'carbon');

  return cullHiddenVoxels(map);
}

// =====================================================================
// CAR 4: FORD MUSTANG GT (RAZOR #1 — NFS MOST WANTED IMAGE 2)
// =====================================================================

function paintMustangVoxel(
  x: number,
  y: number,
  z: number,
  pattern: LiveryPattern
): VoxelMatKey {
  if (pattern === 'clean') return 'body';
  const ax = Math.abs(x);

  if (pattern === 'm-stripe') {
    if (ax <= 1 && y >= 3) return 'livery';
    if (ax === 4 && y === 2 && z >= -5 && z <= 5) return 'livery';
    return 'body';
  }

  // Razor's Iconic Most Wanted Mustang GT Livery (Image 2):
  // Obsidian Black body (`body`) + Yellow (`livery`) & Fiery Red (`decal`) Flames on hood & sides!
  // 1. Hood Flames (y = 3..4, z = 3..6, flanking center cowl bulge)
  if (y === 3 && z >= 3 && z <= 6) {
    if (ax === 2 && z >= 4) return 'livery'; // Yellow flame core licking forward
    if (ax === 3 && z >= 3 && z <= 5) return 'decal'; // Fiery red outer flame tips!
  }

  // 2. Side Fender & Door Sweeping Flames (x = ±4, y = 2..3, z = -4..5)
  if (ax === 4) {
    // Bold Yellow flame base right behind the front wheel well (z = 2..1, y = 2)
    if (y === 2 && (z === 2 || z === 1)) return 'livery';
    // Sweeping Yellow + Red flame licks stretching back across the door toward the rear quarter!
    if (y === 2 && (z === 0 || z === -1 || z === -3)) return 'decal';
    if (y === 3 && (z === 1 || z === 0 || z === -2)) return 'livery';
    if (y === 3 && (z === -1 || z === -3 || z === -4)) return 'decal';
  }

  return 'body';
}

function generateMustangVoxels(pattern: LiveryPattern): VoxelEntry[] {
  const map = new Map<string, VoxelEntry>();
  const set = (x: number, y: number, z: number, mat: VoxelMatKey) => {
    map.set(`${x},${y},${z}`, { x, y, z, mat });
  };
  const paint = (x: number, y: number, z: number): VoxelMatKey =>
    paintMustangVoxel(x, y, z, pattern);

  // 1. ICONIC GREY/GUNMETAL RAZOR WIDEBODY SPLITTER, FANGS & SIDE SKIRTS (y = 1)
  for (let z = -7; z <= 7; z++) {
    for (let x = -4; x <= 4; x++) {
      if (isBMWWheelCutout(x, 1, z)) continue;

      // Wide front grey aero lip + central intake (z = 7, y = 1)
      if (z === 7) {
        if (Math.abs(x) <= 1) {
          set(x, 1, z, 'grille');
        } else {
          set(x, 1, z, 'carbon'); // Grey widebody front lip
        }
        continue;
      }

      // Twin rear Mustang exhaust tips (z = -7, x = ±3, y = 1)
      if (z === -7 && Math.abs(x) === 3) {
        set(x, 1, z, 'chrome');
        continue;
      }

      set(x, 1, z, 'carbon');
    }
  }

  // 2. MUSCULAR S197 MUSTANG FASTBACK BODY (y = 2..3, z = -7..7)
  for (let y = 2; y <= 3; y++) {
    for (let z = -7; z <= 7; z++) {
      // Aggressive vertical Mustang shark-nose front (keep y = 2..3 at z = 7 on center/outer!)
      for (let x = -4; x <= 4; x++) {
        if (isBMWWheelCutout(x, y, z)) continue;
        set(x, y, z, paint(x, y, z));
      }
    }
  }

  // 3. RAZOR'S VERTICAL GREY BUMPER FANGS, RECESSED GRILLE & PONY BADGE (z = 7)
  // Vertical grey bumper fangs at x = ±2 (exact match to Image 2!)
  set(-2, 2, 7, 'carbon');
  set(2, 2, 7, 'carbon');
  set(-2, 3, 7, 'carbon');
  set(2, 3, 7, 'carbon');

  // Recessed dark Mustang center grille + silver Mustang pony badge!
  set(-1, 2, 7, 'grille');
  set(0, 2, 7, 'grille');
  set(1, 2, 7, 'grille');
  set(-1, 3, 7, 'grille');
  set(0, 3, 7, 'chrome'); // Silver Mustang Pony Emblem!
  set(1, 3, 7, 'grille');

  // Mean recessed outer Mustang headlights!
  set(-3, 3, 7, 'headlight');
  set(3, 3, 7, 'headlight');
  set(-4, 3, 7, 'carbon');
  set(4, 3, 7, 'carbon');
  set(-4, 2, 7, 'indicator');
  set(4, 2, 7, 'indicator');

  // 4. BULGING COWL INDUCTION HOOD SCOOP (y = 4, z = 3..5, x = -1..1)
  for (let z = 3; z <= 5; z++) {
    for (let x = -1; x <= 1; x++) {
      set(x, 4, z, 'body');
    }
  }

  // 5. REAR MUSTANG TRI-BAR RED TAILLIGHTS (z = -7, y = 3)
  set(-4, 3, -7, 'taillight');
  set(-3, 3, -7, 'taillight');
  set(3, 3, -7, 'taillight');
  set(4, 3, -7, 'taillight');
  set(-1, 2, -7, 'plate');
  set(0, 2, -7, 'plate');
  set(1, 2, -7, 'plate');

  // 6. FASTBACK MUSCLE CABIN (y = 4..5, x = -3..3, z = -4..2)
  for (let y = 4; y <= 5; y++) {
    for (let z = -4; z <= 2; z++) {
      for (let x = -3; x <= 3; x++) {
        const ax = Math.abs(x);
        const isFront = z === 2;
        const isBack = z === -4;
        const isSide = ax === 3;

        if (!isFront && !isBack && !isSide) {
          set(x, y, z, 'grille');
          continue;
        }
        if (isFront || isBack) {
          set(x, y, z, ax === 3 ? paint(x, y, z) : 'glass');
          continue;
        }
        if (isSide) {
          if (z === -1) set(x, y, z, 'carbon');
          else if (z <= -2) set(x, y, z, paint(x, y, z)); // Thick fastback C-pillar + louvers
          else set(x, y, z, 'glass');
        }
      }
    }
  }

  // 7. ROOF + RAZOR'S SIGNATURE ROOF SCOOP (y = 6..7)
  for (let z = -4; z <= 2; z++) {
    for (let x = -3; x <= 3; x++) {
      if ((z === 2 || z === -4) && Math.abs(x) === 3) continue;
      set(x, 6, z, paint(x, 6, z));
    }
  }
  // Black roof scoop on y = 7 (matching Image 2!)
  set(-1, 7, 0, 'body');
  set(0, 7, 0, 'grille');
  set(1, 7, 0, 'body');
  set(-1, 7, -1, 'body');
  set(0, 7, -1, 'body');
  set(1, 7, -1, 'body');

  // 8. SIDE MIRRORS & HIGH-MOUNT GREY/CARBON GT WING (matching Image 2!)
  set(-4, 4, 2, 'body');
  set(4, 4, 2, 'body');

  set(-2, 4, -6, 'carbon');
  set(2, 4, -6, 'carbon');
  for (let x = -4; x <= 4; x++) {
    set(x, 5, -7, 'carbon');
  }
  set(-4, 6, -7, 'carbon');
  set(4, 6, -7, 'carbon');

  return cullHiddenVoxels(map);
}

// =====================================================================
// CAR 5: PORSCHE 964 RWB (AKIRA NAKAI) — SLEEK CROSSY VOXEL STYLE
// =====================================================================

function isRWBWheelCutout(x: number, y: number, z: number): boolean {
  const ax = Math.abs(x);
  if (ax < 3 || y > 2) return false;
  if (z >= 3 && z <= 5) return true;
  if (z >= -5 && z <= -3) return true;
  return false;
}

function paintRWBVoxel(
  x: number,
  y: number,
  z: number,
  pattern: LiveryPattern
): VoxelMatKey {
  if (pattern === 'clean') return 'body';
  const ax = Math.abs(x);

  if (pattern === 'm-stripe') {
    // Classic twin/center Porsche Gulf racing stripe over frunk, roof & wing
    if (ax <= 1 && (z >= 3 || y >= 6 || z <= -6)) return 'livery';
    if (ax >= 4 && y === 2 && z >= -2 && z <= 2) return 'livery';
    return 'body';
  }

  // RWB Two-Tone Racing Livery (great for Oren-Biru & Biru-Oren!):
  // 1. Bold center racing stripe down frunk, roof, and rear deck
  if (ax <= 1 && (z >= 3 || y >= 6)) return 'livery';
  // 2. Side skirt / widebody rocker panel accent along doors
  if (ax >= 4 && y === 1 && z >= -2 && z <= 2) return 'livery';
  // 3. Upper RWB GT wing blade accent
  if (y === 6 && z === -7 && ax <= 3) return 'livery';

  return 'body';
}

function generateRWB964Voxels(pattern: LiveryPattern): VoxelEntry[] {
  const map = new Map<string, VoxelEntry>();
  const set = (x: number, y: number, z: number, mat: VoxelMatKey) => {
    map.set(`${x},${y},${z}`, { x, y, z, mat });
  };
  const paint = (x: number, y: number, z: number): VoxelMatKey =>
    paintRWBVoxel(x, y, z, pattern);

  // 1. LOW-SLUNG RWB FRONT SPLITTER, WIDE SKIRTS & REAR BUMPER (y = 1, z = -7..7)
  for (let z = -7; z <= 7; z++) {
    // Widebody RWB rear & side flare reaches ±5 around arches/skirts; nose stays rounded at ±3
    const maxX = z === 7 ? 3 : Math.abs(z) <= 5 ? 5 : 4;
    for (let x = -maxX; x <= maxX; x++) {
      if (isRWBWheelCutout(x, 1, z)) continue;

      // Low front carbon lip + recessed center cooling grille (z = 7, y = 1)
      if (z === 7) {
        set(x, 1, z, Math.abs(x) <= 1 ? 'grille' : 'carbon');
        continue;
      }

      // Rear bumper body-colored valance + dual chrome exhausts at x = ±2!
      if (z === -7) {
        if (Math.abs(x) === 2) {
          set(x, 1, z, 'chrome');
        } else {
          set(x, 1, z, paint(x, 1, z));
        }
        continue;
      }

      // Fat body-colored RWB side skirts (x = ±5, z = -2..2)
      if (Math.abs(x) === 5 && z >= -2 && z <= 2) {
        set(x, 1, z, paint(x, 1, z));
        continue;
      }

      set(x, 1, z, Math.abs(z) >= 6 ? paint(x, 1, z) : 'carbon');
    }
  }

  // 2. SLEEK SLOPED 964 BODY & ROUNDED WIDEBODY OVERFENDERS (y = 2..3, z = -7..7)
  for (let y = 2; y <= 3; y++) {
    for (let z = -7; z <= 7; z++) {
      // Round off front corners at z = 7 (maxX = 3) and flare wide over wheel arches (x = ±5 at y = 2)
      const isRearFlare = y === 2 && z >= -6 && z <= -2;
      const isFrontFlare = y === 2 && z >= 2 && z <= 5;
      const maxX =
        z === 7 ? 3 : isRearFlare || isFrontFlare ? 5 : 4;

      for (let x = -maxX; x <= maxX; x++) {
        if (isRWBWheelCutout(x, y, z)) continue;

        // Classic 911 sloping frunk:
        // At y = 3, front edge z = 7 is open, and center frunk (x = -2..2) drops low at z = 6!
        if (y === 3 && z === 7) continue;
        if (y === 3 && z === 6 && Math.abs(x) <= 2) continue;
        // Gently taper front outer fender corners at y = 3, z = 6 (x = ±4 omitted so frog-eye sits cleanly!)
        if (y === 3 && z === 6 && Math.abs(x) === 4) continue;

        set(x, y, z, paint(x, y, z));
      }
    }
  }

  // 3. CLEAN PORSCHE 964 FRONT END & FROG-EYE HEADLIGHTS!
  // Clean body-colored sloped nose at z = 7, y = 2 (no goofy yellow fangs!)
  // Subtle slim amber bumper indicator tucked cleanly at outer corner (x = ±4, y = 2, z = 6)
  set(-4, 2, 6, 'indicator');
  set(4, 2, 6, 'indicator');
  // Iconic proud 911 Frog-Eye Headlights sitting cleanly at x = ±3, y = 3, z = 6!
  set(-3, 3, 6, 'headlight');
  set(3, 3, 6, 'headlight');

  // 4. SIGNATURE PORSCHE 964 FULL-WIDTH RED REAR LIGHT BAR (z = -7, y = 2)
  for (let x = -4; x <= 4; x++) {
    set(x, 2, -7, 'taillight');
  }
  // Body-colored lower rear fender corners wrapping behind rear tires (z = -6, x = ±5, y = 2)
  set(-5, 2, -6, paint(-5, 2, -6));
  set(5, 2, -6, paint(5, 2, -6));

  // 5. SLEEK TEARDROP 911 FASTBACK CABIN (y = 4..5, x = -3..3)
  // Narrowed & smoothly sloped toward the rear so wide RWB rear hips bulge out proudly!
  for (let y = 4; y <= 5; y++) {
    const zMin = y === 4 ? -4 : -3;
    const zMax = y === 4 ? 2 : 1;
    for (let z = zMin; z <= zMax; z++) {
      for (let x = -3; x <= 3; x++) {
        const ax = Math.abs(x);
        // Round off the rear & front cabin corners at y = 5 for true Porsche 911 curves
        if (y === 5 && (z === zMin || z === zMax) && ax === 3) continue;

        const isFront = z === zMax;
        const isBack = z === zMin;
        const isSide = ax === 3;

        if (!isFront && !isBack && !isSide) {
          set(x, y, z, 'grille');
          continue;
        }
        if (isFront || isBack) {
          set(x, y, z, ax >= 3 ? paint(x, y, z) : 'glass');
          continue;
        }
        if (isSide) {
          if (z === -1) set(x, y, z, 'carbon');
          else if (z <= zMin + 1) set(x, y, z, paint(x, y, z));
          else set(x, y, z, 'glass');
        }
      }
    }
  }

  // 6. COMPACT ROUNDED 911 ROOF (y = 6, z = -2..0, x = -2..2)
  for (let z = -2; z <= 0; z++) {
    for (let x = -2; x <= 2; x++) {
      set(x, 6, z, paint(x, 6, z));
    }
  }

  // Sleek body-colored Porsche aero mirrors (tucked neatly at x = ±4, y = 4, z = 2)
  set(-4, 4, 2, paint(-4, 4, 2));
  set(4, 4, 2, paint(4, 4, 2));

  // 7. OPEN-AIR AKIRA NAKAI RWB WHALE-TAIL + HIGH GT WING (CLEAN & NON-BLOCKY!)
  // Rear engine deck & curved whale-tail base (y = 3..4, z = -6..-5, x = -3..3)
  for (let x = -3; x <= 3; x++) {
    set(x, 4, -6, paint(x, 4, -6));
  }
  // Open-center RWB wing uprights on outer sides ONLY (x = ±3, y = 5, z = -6)
  // Leaves center x = -2..2 open so you see right through the wing like the photo!
  set(-3, 5, -6, paint(-3, 5, -6));
  set(3, 5, -6, paint(3, 5, -6));

  // Sleek high-mount RWB GT wing blade across the rear (y = 6, z = -7, x = -4..4)
  for (let x = -4; x <= 4; x++) {
    set(x, 6, -7, paint(x, 6, -7));
  }
  // Thin matte-black RWB wing endplate accents on outer tips (y = 5, x = ±4, z = -7)
  set(-4, 5, -7, 'carbon');
  set(4, 5, -7, 'carbon');

  return cullHiddenVoxels(map);
}

function cullHiddenVoxels(map: Map<string, VoxelEntry>): VoxelEntry[] {
  const isOpaque = (key: string): boolean => map.get(key) !== undefined;
  const visible: VoxelEntry[] = [];
  for (const entry of map.values()) {
    const { x, y, z } = entry;
    if (
      isOpaque(`${x + 1},${y},${z}`) &&
      isOpaque(`${x - 1},${y},${z}`) &&
      isOpaque(`${x},${y + 1},${z}`) &&
      isOpaque(`${x},${y - 1},${z}`) &&
      isOpaque(`${x},${y},${z + 1}`) &&
      isOpaque(`${x},${y},${z - 1}`)
    ) {
      continue;
    }
    visible.push(entry);
  }
  return visible;
}

// =====================================================================
// FIXED CUTE CROSSY ROAD VOXEL WHEEL (SOLID 4x4 OCTAGONAL WHEEL!)
// =====================================================================

/**
 * Builds a proper, solid, super cute Crossy Road octagonal voxel wheel!
 * Uses a 4x4 sub-voxel grid (skipping the 4 outer corners) so:
 * - It looks unmistakably like a round-blocky wheel (NOT a + cross!)
 * - Tire has full solid tread around the rim
 * - Bright alloy rim sits cleanly inside with a tiny chrome hub & subtle spoke dots
 *   so rotating wheels look smooth and crisp!
 */
function buildProperCrossyWheel(
  materials: BMWVoxelMaterials,
  isRightSide: boolean
): { group: THREE.Group; voxelCount: number; geometries: THREE.BufferGeometry[] } {
  const group = new THREE.Group();

  // Sub-voxel size = 0.68 * VOXEL_SIZE -> 4x4 wheel diameter = 2.72 * VOXEL_SIZE = 0.68m
  // Fits neatly inside 3-voxel (0.75m) wheel wells with clean arch clearance!
  const subScale = 0.68;
  const subCoords = [-1.5, -0.5, 0.5, 1.5];
  const outerSign = isRightSide ? 1 : -1;

  const tireVoxels: Array<{ x: number; y: number; z: number }> = [];
  const rimVoxels: Array<{ x: number; y: number; z: number }> = [];
  const hubVoxels: Array<{ x: number; y: number; z: number }> = [];
  const caliperVoxels: Array<{ x: number; y: number; z: number }> = [];

  for (const y of subCoords) {
    for (const z of subCoords) {
      // Omit the 4 extreme corners of the 4x4 grid -> crisp octagonal wheel!
      if (Math.abs(y) === 1.5 && Math.abs(z) === 1.5) continue;

      const isOuterRing = Math.abs(y) === 1.5 || Math.abs(z) === 1.5;
      if (isOuterRing) {
        // Solid rubber tire tread (full 1.5x sub-voxel thickness along X)
        tireVoxels.push({ x: -0.28, y, z });
        tireVoxels.push({ x: 0.28, y, z });
      } else {
        // Inner 2x2 rim zone
        // Inner half = dark backing / subtle red brake caliper hint
        tireVoxels.push({ x: -outerSign * 0.28, y, z });
        // Outer half = bright alloy rim dish!
        rimVoxels.push({ x: outerSign * 0.22, y, z });
      }
    }
  }

  // Tiny crisp center hub nut + subtle spoke indicator on outer face so wheel spin is visible
  hubVoxels.push({ x: outerSign * 0.5, y: 0, z: 0 });
  caliperVoxels.push({ x: outerSign * 0.45, y: 0.55, z: 0.55 });
  caliperVoxels.push({ x: outerSign * 0.45, y: -0.55, z: -0.55 });

  const geometries: THREE.BufferGeometry[] = [];

  const tireGeo = buildMergedVoxelGeometry(
    tireVoxels,
    0,
    0,
    0,
    subScale,
    subScale,
    subScale
  );
  geometries.push(tireGeo);
  const tireMesh = new THREE.Mesh(tireGeo, materials.tire);
  tireMesh.castShadow = true;
  tireMesh.receiveShadow = true;
  tireMesh.name = 'wheel_tire';
  group.add(tireMesh);

  const rimGeo = buildMergedVoxelGeometry(
    rimVoxels,
    0,
    0,
    0,
    subScale,
    subScale,
    subScale
  );
  geometries.push(rimGeo);
  const rimMesh = new THREE.Mesh(rimGeo, materials.rim);
  rimMesh.castShadow = true;
  rimMesh.receiveShadow = true;
  rimMesh.name = 'wheel_rim';
  group.add(rimMesh);

  const hubGeo = buildMergedVoxelGeometry(
    hubVoxels,
    0,
    0,
    0,
    subScale * 0.55,
    subScale * 0.55,
    subScale * 0.55
  );
  geometries.push(hubGeo);
  const hubMesh = new THREE.Mesh(hubGeo, materials.chrome);
  hubMesh.name = 'wheel_hub';
  group.add(hubMesh);

  const lugGeo = buildMergedVoxelGeometry(
    caliperVoxels,
    0,
    0,
    0,
    subScale * 0.35,
    subScale * 0.35,
    subScale * 0.35
  );
  geometries.push(lugGeo);
  const lugMesh = new THREE.Mesh(lugGeo, materials.chrome);
  lugMesh.name = 'wheel_lugs';
  group.add(lugMesh);

  return {
    group,
    voxelCount: tireVoxels.length + rimVoxels.length,
    geometries,
  };
}

export function createBMWMaterials(config: CarConfig): BMWVoxelMaterials {
  return {
    body: new THREE.MeshStandardMaterial({
      color: new THREE.Color(config.bodyColor),
      metalness: 0.08,
      roughness: 0.5,
    }),
    livery: new THREE.MeshStandardMaterial({
      color: new THREE.Color(config.liveryColor),
      metalness: 0.08,
      roughness: 0.48,
    }),
    decal: new THREE.MeshStandardMaterial({
      color: new THREE.Color(config.decalColor),
      metalness: 0.06,
      roughness: 0.48,
    }),
    carbon: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#272c38'),
      metalness: 0.08,
      roughness: 0.72,
    }),
    grille: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#141821'),
      metalness: 0.05,
      roughness: 0.85,
    }),
    chrome: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#e2e8f0'),
      metalness: 0.68,
      roughness: 0.25,
    }),
    glass: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#223247'),
      metalness: 0.18,
      roughness: 0.18,
    }),
    tire: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#1d212a'),
      metalness: 0.04,
      roughness: 0.88,
    }),
    rim: new THREE.MeshStandardMaterial({
      color: new THREE.Color(config.rimColor),
      metalness: 0.38,
      roughness: 0.32,
    }),
    caliper: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#dc2626'),
      metalness: 0.2,
      roughness: 0.4,
    }),
    headlight: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#ffffff'),
      emissive: new THREE.Color(config.headlightColor),
      emissiveIntensity: 2.8,
      roughness: 0.18,
      metalness: 0.05,
    }),
    indicator: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#fbbf24'),
      emissive: new THREE.Color('#f59e0b'),
      emissiveIntensity: 0.75,
      roughness: 0.25,
      metalness: 0.05,
    }),
    taillight: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#ef4444'),
      emissive: new THREE.Color('#ff2436'),
      emissiveIntensity: 2.0,
      roughness: 0.25,
      metalness: 0.05,
    }),
    badgeBlue: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#3b82f6'),
      metalness: 0.2,
      roughness: 0.35,
    }),
    plate: new THREE.MeshStandardMaterial({
      color: new THREE.Color('#f8fafc'),
      roughness: 0.55,
      metalness: 0.04,
    }),
  };
}

/**
 * Builds the interactive 3D Crossy Voxel Car Asset (supports BMW M3 GTR & Sonny's VW Golf GTI!).
 */
export function buildBMWVoxelCar(config: CarConfig): BMWCarAsset {
  const root = new THREE.Group();
  root.name = 'MostWanted_CrossyVoxel_Car';

  const chassisGroup = new THREE.Group();
  chassisGroup.name = 'Chassis';
  root.add(chassisGroup);

  const materials = createBMWMaterials(config);

  let chassisGeometries: THREE.BufferGeometry[] = [];
  const wheelGeometries: THREE.BufferGeometry[] = [];

  // Build 4 solid, cute Crossy Road octagonal wheels!
  // Wheel center Y = 2 * (0.68 * VOXEL_SIZE) = 1.36 * VOXEL_SIZE -> touches road y = 0 cleanly!
  const wheelCenterY = 1.36 * VOXEL_SIZE;
  const wheelX = 3.72 * VOXEL_SIZE;

  const wheelDefs = [
    { name: 'Wheel_FL', x: wheelX, isRight: true },
    { name: 'Wheel_FR', x: -wheelX, isRight: false },
    { name: 'Wheel_RL', x: wheelX, isRight: true },
    { name: 'Wheel_RR', x: -wheelX, isRight: false },
  ];

  const wheels: THREE.Group[] = [];
  let wheelVoxelTotal = 0;

  for (const wd of wheelDefs) {
    const built = buildProperCrossyWheel(materials, wd.isRight);
    built.group.name = wd.name;
    built.group.position.set(wd.x, wheelCenterY, 0);
    root.add(built.group);
    wheels.push(built.group);
    wheelVoxelTotal += built.voxelCount;
    wheelGeometries.push(...built.geometries);
  }

  const positionWheelsForCar = (carModel: CarModelId) => {
    const frontZ = carModel === 'vw-golf-gti' ? 3.0 * VOXEL_SIZE : 4.0 * VOXEL_SIZE;
    const rearZ = -4.0 * VOXEL_SIZE;
    const wx = carModel === 'rwb-964' ? 4.22 * VOXEL_SIZE : 3.72 * VOXEL_SIZE;

    wheels[0].position.set(wx, wheelCenterY, frontZ);
    wheels[1].position.set(-wx, wheelCenterY, frontZ);
    wheels[2].position.set(wx, wheelCenterY, rearZ);
    wheels[3].position.set(-wx, wheelCenterY, rearZ);
  };

  const rebuildCar = (
    carModel: CarModelId,
    pattern: LiveryPattern,
    headlightsOpen = true
  ): number => {
    root.name =
      carModel === 'vw-golf-gti'
        ? 'VW_Golf_GTI_Sonny_CrossyVoxel'
        : carModel === 'ae86-trueno'
        ? 'Toyota_AE86_Trueno_InitialD_CrossyVoxel'
        : carModel === 'mustang-gt'
        ? 'Ford_Mustang_GT_Razor_CrossyVoxel'
        : carModel === 'rwb-964'
        ? 'Porsche_964_RWB_Nakai_CrossyVoxel'
        : 'BMW_M3_GTR_MostWanted_CrossyVoxel';

    positionWheelsForCar(carModel);

    while (chassisGroup.children.length > 0) {
      chassisGroup.remove(chassisGroup.children[0]);
    }
    for (const g of chassisGeometries) {
      g.dispose();
    }
    chassisGeometries = [];

    const voxels =
      carModel === 'vw-golf-gti'
        ? generateGolfGTIVoxels(pattern)
        : carModel === 'ae86-trueno'
        ? generateAE86Voxels(pattern, headlightsOpen)
        : carModel === 'mustang-gt'
        ? generateMustangVoxels(pattern)
        : carModel === 'rwb-964'
        ? generateRWB964Voxels(pattern)
        : generateBMWVoxels(pattern);

    const buckets = new Map<VoxelMatKey, Array<{ x: number; y: number; z: number }>>();
    for (const v of voxels) {
      let arr = buckets.get(v.mat);
      if (!arr) {
        arr = [];
        buckets.set(v.mat, arr);
      }
      arr.push({ x: v.x, y: v.y, z: v.z });
    }

    for (const [matKey, list] of buckets.entries()) {
      const geo = buildMergedVoxelGeometry(list, 0, 0.25, 0);
      chassisGeometries.push(geo);
      const mesh = new THREE.Mesh(geo, materials[matKey]);
      mesh.castShadow = matKey !== 'headlight';
      mesh.receiveShadow = true;
      mesh.name = `chassis_${matKey}`;
      chassisGroup.add(mesh);
    }

    return voxels.length + wheelVoxelTotal;
  };

  const initialCount = rebuildCar(
    config.carModel,
    config.liveryPattern,
    config.headlightMode !== 'off'
  );

  const dispose = () => {
    for (const g of chassisGeometries) g.dispose();
    for (const g of wheelGeometries) g.dispose();
    Object.values(materials).forEach((m) => m.dispose());
  };

  return {
    root,
    chassisGroup,
    wheels,
    materials,
    voxelCount: initialCount,
    rebuildCar,
    dispose,
  };
}
