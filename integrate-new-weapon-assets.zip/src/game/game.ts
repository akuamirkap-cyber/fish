import { Sound } from './audio';
import {
  drawBat3D,
  drawCharacter,
  drawFist,
  drawGhost,
  muzzleLen,
  PLAYER_DIMS,
  PLAYER_LOOK,
  Ragdoll,
  RP,
  type GunKind,
} from './character';
import { Enemy } from './enemy';
import { drawBossIntro, drawCrosshair, drawHitMarker, drawHud, type HudState, type StyleTag } from './hud';
import { ARENAS, BOSS_INFO, makeBoss, saveBossRecord, type BossHost, type BossId } from './bosses';
import { Hazards, type Hazard, type HazardHost } from './hazards';
import { BAT, CRICKET, isWeaponId, SLING, WEAPON_INFO, WEAPON_ORDER, type WeaponId } from './weapons';
import {
  drawHaloBullet,
  haloBeamFx,
  haloExplodeFx,
  HaloFx,
  haloImpactFx,
  haloLive,
  haloMuzzleFx,
  haloSpec,
  haloStatusFx,
  haloTrailFx,
  isHaloId,
  preloadHaloArt,
  type HaloSpec,
} from './halo';

preloadHaloArt();
import { drawKatana3D, KATANA, MOVES, type MeleeMove } from './melee';
import { Brawler, DOJO, FIST_MAX_AGE, FIST_WAVES, GURU_INFO, makeBrawler } from './fist';
import { LEVEL1, type CheckpointDef, type LevelDef } from './level';
import { approach, clamp, dist, pointInRect, rand, rectOverlap, segCircle, segRect, segSegDist, sign, smooth, TAU } from './math';
import { Particles } from './particles';
import { FLIP_TAG, Player, type PlayerInput } from './player';
import {
  createProp,
  drawBanana,
  drawBarrel,
  drawDoor,
  drawGlass,
  drawGlassDoor,
  drawLamp,
  drawPan,
  drawUziPickup,
  drawWeaponPickup,
  drawGunDrop,
  drawShotgunPickup,
  isGlass,
  lampLight,
  type Prop,
} from './props';
import {
  createPatterns,
  createSkyline,
  drawDeco,
  drawDreamSky,
  drawRoom,
  drawSky,
  drawSolid,
  drawZipline,
  type Patterns,
  type Skyline,
} from './render';
import { World, type DynSolid, type MoveResult } from './world';

export type Screen = 'menu' | 'playing' | 'paused' | 'dead' | 'complete';

export interface GameStats {
  score: number;
  kills: number;
  totalEnemies: number;
  headshots: number;
  maxCombo: number;
  time: number;
  deaths: number;
  bananas: number;
  totalBananas: number;
  rank: string;
  mode: 'story' | 'boss' | 'fist';
  age: number;
  wave: number;
  bossId: BossId | null;
  bossName: string;
  damageTaken: number;
}

export interface GameCallbacks {
  onScreen(s: Screen): void;
  onStats(s: GameStats): void;
}

interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  sx: number;
  sy: number;
  owner: 'player' | 'enemy';
  dmg: number;
  life: number;
  kind: GunKind;
  tags: string[];
  ricochets: number;
  alive: boolean;
  dodged: boolean;
  redirected: boolean;
  wake: number;
  pierce?: number;
  hitIds?: number[];
  kills?: number;
  dx?: number;
  dy?: number;
  /** peluru senjata HALO ARSENAL */
  halo?: HaloSpec;
  age?: number;
  trailAcc?: number;
  hx?: number;
  hy?: number;
}

interface Popup {
  x: number;
  y: number;
  text: string;
  t: number;
  color: string;
  size: number;
  max?: number;
  rot?: number;
  burst?: string;
  seed?: number;
}

const STYLE_PTS: Record<string, number> = {
  'FRONT FLIP': 125,
  'WALL FLIP': 150,
  MELAYANG: 50,
  PUTARAN: 100,
  SLIDE: 75,
  GULING: 75,
  ZIPLINE: 100,
  'SPLIT AIM': 100,
  FOKUS: 25,
  PANTULAN: 150,
  LEDAKAN: 100,
  TENDANGAN: 150,
  PINTU: 200,
  'DOUBLE FLIP': 250,
  AERIAL: 175,
  BACKFLIP: 175,
  VAULT: 100,
  LAMPU: 250,
  SUPERMAN: 200,
  DOBRAK: 150,
  INJAK: 250,
  'TENDANGAN TERBANG': 200,
  'HOME RUN': 150,
  TINJU: 50,
  HOOK: 75,
  'TENDANGAN MEMUTAR': 125,
  'TELAPAK GANDA': 200,
  UPPERCUT: 150,
  SAPUAN: 120,
  'TENDANGAN UDARA': 150,
  'SATU INCI': 300,
  TAKEDOWN: 300,
  PARRY: 150,
  MENTOK: 150,
  KATANA: 100,
  TATSUMAKI: 175,
  'KABUTO-WARI': 300,
  'TEBASAN NAGA': 150,
  'KAZE-GURUMA': 150,
  TUSUKAN: 200,
  'TERBANG WALET': 300,
  IAI: 350,
  BACKHAND: 150,
  HANTAMAN: 250,
  'GRAND SLAM': 400,
  'HANTAMAN UDARA': 200,
  TEMBUS: 200,
  KETAPEL: 150,
  'NOISY CRICKET': 150,
  'TANGKIS PELURU': 200,
};

const STUNT_TAGS = new Set([
  'FRONT FLIP',
  'WALL FLIP',
  'BACKFLIP',
  'DOUBLE FLIP',
  'AERIAL',
  'SUPERMAN',
  'GULING',
  'VAULT',
  'INJAK',
  'TENDANGAN TERBANG',
]);
const DOOR_G = 1700;

const DARKNESS: Record<string, number> = {
  basement: 0.52,
  freezer: 0.32,
  alley: 0.3,
  kitchen: 0.3,
  stair: 0.45,
  warehouse: 0.46,
  penthouse: 0.36,
  dream: 0,
  dojo: 0.22,
};

const STEP = 1 / 120;
const SLOW = 0.28;

export class Game implements BossHost, HazardHost {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  cb: GameCallbacks;
  level: LevelDef = LEVEL1;
  world: World;
  player: Player;
  enemies: Enemy[] = [];
  props: Prop[] = [];
  ragdolls: Ragdoll[] = [];
  bullets: Bullet[] = [];
  particles = new Particles();
  sfx = new Sound();
  patterns: Patterns;
  skyline: Skyline;
  playerRag: Ragdoll | null = null;

  W = 1280;
  H = 720;
  dpr = 1;
  cam = { x: 0, y: 0, zoom: 1, shake: 0, sx: 0, sy: 0, roll: 0 };
  camPunch = 0;
  impactT = 0;
  impactX = 0;
  impactY = 0;
  trauma = 0;
  shakeRot = 0;
  kick = { x: 0, y: 0, vx: 0, vy: 0 };
  killCam = { t: 0, x: 0, y: 0 };
  hitMark = { t: 0, kind: 0 };
  bloom = 0;
  scoreShown = 0;
  speedLines = 0;
  flashT = 0;
  breachX = 0;
  breachY = 0;
  lastStuntSlow = -10;
  private doorRes: MoveResult = { hitX: 0, hitY: 0, onGround: false, ground: null, wallSolid: null, dynHit: null };

  time = 0;
  realTime = 0;
  timeScale = 1;
  focusing = false;
  autoSlow = 0;
  deathSlow = 0;
  hitstop = 0;

  keys = new Set<string>();
  pressed = new Set<string>();
  mouse = { x: 640, y: 360, left: false, right: false, rightPressed: false, leftPressed: false, inside: true };
  split = { active: false, enemyId: -1, x: 0, y: 0 };
  aim = { x: 0, y: 0 };

  score = 0;
  combo = 0;
  comboT = 0;
  maxCombo = 0;
  headshots = 0;
  tags: StyleTag[] = [];
  popups: Popup[] = [];
  lastKillTime = -10;
  deaths = 0;
  playTime = 0;
  collected = new Set<string>();

  hintsShown = new Set<string>();
  hintQueue: string[] = [];
  hintText = '';
  hintChars = 0;
  hintTimer = 0;
  hintAlpha = 0;
  titleT = 0;
  centerMsg = '';
  centerT = 0;
  hurtFlash = 0;
  dodgeMsgT = 0;
  lockedMsgT = 0;

  checkpoint: CheckpointDef | null = null;
  cpScore = 0;
  cpHeadshots = 0;
  bossDead = false;
  screen: Screen = 'menu';
  mode: 'story' | 'boss' | 'fist' = 'story';
  bossId: BossId = 'jagal';
  hazards = new Hazards();
  bossIntro = 0;
  bossIntroMax = 3.4;
  victoryT = 0;
  damageTaken = 0;
  dreamPhase = 1;
  barrelRespawn: { x: number; y: number; t: number }[] = [];
  bubbles: { e: Enemy; text: string; t: number; max: number }[] = [];
  wheelDir = 0;
  wheelCd = 0;
  severNext = false;
  iaiMarks: number[] = [];
  iaiProps: number[] = [];
  iaiDone = true;
  iaiSheath = true;
  meleeHits = 0;
  meleeHitT = 0;
  lastWeapon: WeaponId = 'pistol';
  /** senjata pilihan pemain: dipakai lagi setiap mulai / hidup lagi */
  pickedWeapon: WeaponId = 'pistol';
  haloFx = new HaloFx();
  private haloStatus = new Map<number, { burn: number; freeze: number; tick: number }>();
  deflectMsgT = 0;
  age = 20;
  fistDeaths = 0;
  fistMul = 1;
  wave = 0;
  waveT = 0;
  guardStart = -9;

  private lightCanvas: HTMLCanvasElement;
  private lctx: CanvasRenderingContext2D;
  private raf = 0;
  private last = 0;
  private acc = 0;
  private destroyed = false;
  private hud: HudState;

  constructor(canvas: HTMLCanvasElement, cb: GameCallbacks) {
    this.canvas = canvas;
    this.cb = cb;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('no 2d context');
    this.ctx = ctx;
    this.patterns = createPatterns(ctx);
    this.lightCanvas = document.createElement('canvas');
    this.lctx = this.lightCanvas.getContext('2d') as CanvasRenderingContext2D;
    this.skyline = createSkyline();
    this.world = new World(this.level);
    this.player = new Player(this.level.spawn.x, this.level.spawn.y);
    this.particles.onShell = () => this.sfx.shell();
    this.particles.onGunDrop = () => this.sfx.thud();
    this.hud = this.makeHud();
    this.resetLevel();
    this.resize();
    this.cam.x = this.player.x + 200;
    this.cam.y = this.player.y - 120;
    this.bind();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  // ------------------------------------------------------------ host interface
  get ziplines() {
    return this.level.ziplines;
  }

  // ------------------------------------------------------------ lifecycle
  start() {
    this.sfx.init();
    this.sfx.startMusic();
    this.sfx.setTrack(this.mode === 'story' ? 'story' : this.mode === 'boss' && this.bossId === 'pedro' ? 'pedro' : 'boss');
    this.resetLevel();
    if (this.mode === 'fist') this.setupFist();
    this.titleT = this.mode === 'story' ? 4.2 : 0;
    if (this.mode === 'boss') {
      this.bossIntroMax = 3.4;
      this.bossIntro = 3.4;
      this.sfx.bossIntro();
      this.sfx.duck(0.3, 2.6);
    }
    this.setScreen('playing');
  }

  /** pakai lagi senjata pilihan terakhir (setelah mulai ulang / hidup lagi) */
  private applyPicked() {
    const p = this.player;
    if (this.mode === 'fist' || !p.has(this.pickedWeapon)) return;
    p.switchTo(this.pickedWeapon, false);
    this.lastWeapon = p.weapon;
  }

  /** dipakai panel ARSENAL: ganti senjata kapan saja */
  equipWeapon(id: string): boolean {
    if (!isWeaponId(id)) return false;
    if (this.screen === 'menu') {
      // dari menu: jadi senjata awal saat game dimulai
      this.pickedWeapon = id;
      return true;
    }
    if (this.mode === 'fist' || !this.player.has(id)) return false;
    this.pickedWeapon = id;
    this.player.switchTo(id, true);
    return true;
  }

  get currentWeapon(): WeaponId {
    return this.screen === 'menu' ? this.pickedWeapon : this.player.weapon;
  }

  get arsenalAllowed() {
    return this.mode !== 'fist';
  }

  pause() {
    if (this.screen !== 'playing') return;
    this.setScreen('paused');
  }

  resume() {
    if (this.screen !== 'paused') return;
    this.wheelDir = 0;
    this.mouse.left = false;
    this.last = performance.now();
    this.setScreen('playing');
  }

  toMenu() {
    if (this.mode !== 'story') {
      this.mode = 'story';
      this.loadLevel(LEVEL1);
      this.sfx.setTrack('story');
    }
    this.resetLevel();
    this.setScreen('menu');
  }

  setMuted(m: boolean) {
    this.sfx.setMuted(m);
  }

  setMusic(on: boolean) {
    this.sfx.setMusic(on);
  }

  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    this.unbind();
    this.sfx.destroy();
  }

  private setScreen(s: Screen) {
    this.screen = s;
    this.cb.onScreen(s);
    if (s === 'complete' || s === 'dead' || s === 'paused') this.cb.onStats(this.stats());
  }

  stats(): GameStats {
    const kills = this.enemies.filter((e) => !e.alive).length;
    const s = this.score;
    let rank = s >= 18000 ? 'S' : s >= 12000 ? 'A' : s >= 7000 ? 'B' : s >= 3500 ? 'C' : 'D';
    if (this.mode === 'boss') rank = this.bossRank();
    if (this.mode === 'fist') rank = this.age <= 24 ? 'S' : this.age <= 32 ? 'A' : this.age <= 45 ? 'B' : this.age <= 60 ? 'C' : 'D';
    return {
      score: this.score,
      kills,
      totalEnemies: this.level.enemies.length,
      headshots: this.headshots,
      maxCombo: this.maxCombo,
      time: this.playTime,
      deaths: this.deaths,
      bananas: this.collected.size,
      totalBananas: this.level.props.filter((p) => p.type === 'banana').length,
      rank,
      mode: this.mode,
      bossId: this.mode === 'boss' ? this.bossId : null,
      bossName: this.mode === 'boss' ? BOSS_INFO[this.bossId].name : '',
      damageTaken: Math.round(this.damageTaken),
      age: this.age,
      wave: this.wave,
    };
  }

  resetLevel() {
    this.enemies = [];
    this.props = [];
    this.ragdolls = [];
    this.bullets = [];
    this.particles.clear();
    this.particles.decals.length = 0;
    this.collected.clear();
    this.spawnSections(0);
    this.player = new Player(this.level.spawn.x, this.level.spawn.y);
    this.playerRag = null;
    this.score = 0;
    this.combo = 0;
    this.comboT = 0;
    this.maxCombo = 0;
    this.headshots = 0;
    this.tags = [];
    this.popups = [];
    this.deaths = 0;
    this.playTime = 0;
    this.time = 0;
    this.hintsShown.clear();
    this.hintQueue = [];
    this.hintText = '';
    this.hintAlpha = 0;
    this.checkpoint = null;
    this.cpScore = 0;
    this.cpHeadshots = 0;
    this.bossDead = false;
    this.focusing = false;
    this.autoSlow = 0;
    this.deathSlow = 0;
    this.timeScale = 1;
    this.split.active = false;
    this.centerT = 0;
    this.hurtFlash = 0;
    this.killCam.t = 0;
    this.trauma = 0;
    this.scoreShown = 0;
    this.hazards.clear();
    this.bossIntro = 0;
    this.victoryT = 0;
    this.damageTaken = 0;
    this.dreamPhase = 1;
    this.barrelRespawn = [];
    this.bubbles = [];
    this.sfx.laserHum(false);
    this.haloFx.clear();
    this.haloStatus.clear();
    this.applyPicked();
  }

  respawn() {
    if (this.mode === 'fist') {
      this.start();
      return;
    }
    if (this.mode === 'boss') {
      const d = this.deaths;
      this.resetLevel();
      this.deaths = d;
      this.bossIntroMax = 1.2;
      this.bossIntro = 1.2;
      this.last = performance.now();
      this.cam.x = this.player.x;
      this.cam.y = this.player.y - 80;
      this.setScreen('playing');
      return;
    }
    const cp = this.checkpoint;
    const sx = cp ? cp.spawn.x : this.level.spawn.x;
    const sy = cp ? cp.spawn.y : this.level.spawn.y;
    const sec = cp ? cp.section : 0;
    this.ragdolls = this.ragdolls.filter((r) => !r.isPlayer && r.section < sec);
    this.spawnSections(sec);
    this.player.reset(sx, sy);
    if (!cp) {
      this.player.setPistol();
    }
    this.applyPicked();
    this.haloFx.clear();
    this.haloStatus.clear();
    this.playerRag = null;
    this.bullets = [];
    this.particles.clear();
    this.score = this.cpScore;
    this.headshots = this.cpHeadshots;
    this.combo = 0;
    this.comboT = 0;
    this.focusing = false;
    this.autoSlow = 0;
    this.deathSlow = 0;
    this.timeScale = 1;
    this.bossDead = false;
    this.split.active = false;
    this.killCam.t = 0;
    this.trauma = 0;
    this.last = performance.now();
    this.cam.x = sx;
    this.cam.y = sy - 80;
    this.setScreen('playing');
  }

  private spawnSections(minSection: number) {
    this.enemies = this.enemies.filter((e) => e.section < minSection);
    this.props = this.props.filter((p) => p.section < minSection);
    for (const d of this.level.enemies) {
      if (d.section < minSection) continue;
      this.enemies.push(this.mode === 'boss' && d.type === 'boss' ? makeBoss(d, this.bossId) : new Enemy(d));
    }
    for (const d of this.level.props) {
      if (d.section < minSection) continue;
      if (d.type === 'banana' && this.collected.has(`${d.x},${d.y}`)) continue;
      this.props.push(createProp(d));
    }
    this.syncDyn();
  }

  private syncDyn() {
    const dyn: DynSolid[] = [];
    for (const p of this.props) {
      if (!p.alive) continue;
      if (isGlass(p) && p.state !== 'broken') dyn.push({ id: p.id, kind: 'glass', ref: p.id, x: p.x, y: p.y, w: p.w, h: p.h });
      if (p.type === 'door' && p.state === 'idle') dyn.push({ id: p.id, kind: 'door', ref: p.id, x: p.x, y: p.y, w: p.w, h: p.h });
    }
    this.world.dyn = dyn;
  }

  // ------------------------------------------------------------ input
  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.code;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(k)) e.preventDefault();
    if (e.repeat) return;
    if (!this.keys.has(k)) this.pressed.add(k);
    this.keys.add(k);
    if (k === 'Escape' || k === 'KeyP') {
      if (this.screen === 'playing') this.pause();
      else if (this.screen === 'paused') this.resume();
    }
    if (k === 'KeyR') {
      if (this.screen === 'dead') this.respawn();
      else if (this.screen === 'playing') this.player.manualReload(this.sfx);
    }
    if (k === 'Enter' && this.screen === 'dead') this.respawn();
    if (k === 'KeyM') this.setMusic(!this.sfx.musicOn);
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onMouseMove = (e: MouseEvent) => {
    const r = this.canvas.getBoundingClientRect();
    this.mouse.x = e.clientX - r.left;
    this.mouse.y = e.clientY - r.top;
  };

  private onMouseDown = (e: MouseEvent) => {
    if (this.screen !== 'playing') return;
    if (e.button === 0) {
      this.mouse.left = true;
      this.mouse.leftPressed = true;
    }
    if (e.button === 2) {
      this.mouse.right = true;
      this.mouse.rightPressed = true;
    }
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.mouse.left = false;
    if (e.button === 2) this.mouse.right = false;
  };

  private onWheel = (e: WheelEvent) => {
    // roda mouse hanya mengganti senjata saat bermain (bukan saat menggulir panel ARSENAL / jeda)
    if (this.screen !== 'playing') return;
    if (this.screen === 'playing') this.wheelDir = Math.sign(e.deltaY) || 0;
  };

  private onContext = (e: Event) => {
    e.preventDefault();
  };

  private onBlur = () => {
    this.keys.clear();
    this.mouse.left = false;
    this.mouse.right = false;
    if (this.screen === 'playing') this.pause();
  };

  private onResize = () => this.resize();

  private bind() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('mousemove', this.onMouseMove);
    window.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    window.addEventListener('contextmenu', this.onContext);
    window.addEventListener('wheel', this.onWheel, { passive: true });
    window.addEventListener('blur', this.onBlur);
    window.addEventListener('resize', this.onResize);
  }

  private unbind() {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('mousemove', this.onMouseMove);
    window.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mouseup', this.onMouseUp);
    window.removeEventListener('contextmenu', this.onContext);
    window.removeEventListener('wheel', this.onWheel);
    window.removeEventListener('blur', this.onBlur);
    window.removeEventListener('resize', this.onResize);
  }

  resize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.W = w;
    this.H = h;
    this.canvas.width = Math.floor(w * this.dpr);
    this.canvas.height = Math.floor(h * this.dpr);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
    this.lightCanvas.width = Math.max(1, Math.ceil((w * this.dpr) / 2));
    this.lightCanvas.height = Math.max(1, Math.ceil((h * this.dpr) / 2));
  }

  private k(...codes: string[]) {
    for (const c of codes) if (this.keys.has(c)) return true;
    return false;
  }

  private p(...codes: string[]) {
    for (const c of codes) if (this.pressed.has(c)) return true;
    return false;
  }

  // ------------------------------------------------------------ loop
  private loop = (now: number) => {
    if (this.destroyed) return;
    const realDt = Math.min(0.05, Math.max(0, (now - this.last) / 1000));
    this.last = now;
    this.realTime += realDt;
    if (this.screen === 'playing' || this.screen === 'dead') {
      this.acc += realDt;
      let n = 0;
      while (this.acc >= STEP && n < 6) {
        this.step(STEP);
        this.acc -= STEP;
        n++;
      }
      if (n >= 6) this.acc = 0;
      this.frame(realDt);
    } else if (this.screen === 'menu') {
      this.menuStep(realDt);
    }
    this.render();
    this.raf = requestAnimationFrame(this.loop);
  };

  private emptyInput(): PlayerInput {
    return {
      left: false,
      right: false,
      up: false,
      down: false,
      jumpPressed: false,
      downPressed: false,
      spinPressed: false,
      spinHeld: false,
      kickPressed: false,
      fireHeld: false,
      splitHeld: false,
      walk: false,
      aimX: this.player.x + 200,
      aimY: this.player.y - 50,
    };
  }

  private menuStep(realDt: number) {
    const inp = this.emptyInput();
    inp.aimX = this.player.x + 300;
    inp.aimY = this.player.y - 60 + Math.sin(this.realTime) * 30;
    this.player.aimF = Math.atan2(inp.aimY - this.player.wp.shF.y, inp.aimX - this.player.wp.shF.x);
    this.player.aimB = this.player.aimF + 0.05;
    for (let i = 0; i < 2; i++) this.player.update(realDt / 2, inp, this, realDt / 2);
    this.particles.update(realDt, this.world);
    for (const e of this.enemies) e.update(0, this);
    const tx = this.player.x + 260;
    const ty = this.player.y - 130;
    this.cam.x += (tx - this.cam.x) * smooth(3, realDt);
    this.cam.y += (ty - this.cam.y) * smooth(3, realDt);
    this.cam.zoom = this.H / 600;
  }

  get viewZoom() {
    return this.cam.zoom * (1 + this.camPunch);
  }

  screenToWorld(sx: number, sy: number) {
    const z = this.viewZoom;
    const dx = sx - this.W / 2;
    const dy = sy - this.H / 2;
    const c = Math.cos(-this.cam.roll);
    const sn = Math.sin(-this.cam.roll);
    return {
      x: this.cam.x + (dx * c - dy * sn) / z,
      y: this.cam.y + (dx * sn + dy * c) / z,
    };
  }

  worldToScreen(wx: number, wy: number) {
    const z = this.viewZoom;
    const dx = (wx - this.cam.x - this.cam.sx) * z;
    const dy = (wy - this.cam.y - this.cam.sy) * z;
    const c = Math.cos(this.cam.roll + this.shakeRot);
    const sn = Math.sin(this.cam.roll + this.shakeRot);
    return { x: this.W / 2 + dx * c - dy * sn, y: this.H / 2 + dx * sn + dy * c };
  }

  private step(realDt: number) {
    const p = this.player;
    const playing = this.screen === 'playing';
    if (this.bossIntro > 0) this.bossIntro = Math.max(0, this.bossIntro - realDt);

    // focus toggle
    if (playing && this.p('ShiftLeft', 'ShiftRight', 'KeyQ')) {
      if (this.focusing) {
        this.focusing = false;
        this.sfx.slowOut();
      } else if (p.focus > 8 && p.alive) {
        this.focusing = true;
        this.sfx.slowIn();
      }
    }

    let target = 1;
    if (this.focusing) target = SLOW;
    if (this.autoSlow > 0) {
      target = Math.min(target, 0.3);
      this.autoSlow -= realDt;
    }
    if (this.killCam.t > 0) {
      target = Math.min(target, 0.15);
      this.killCam.t -= realDt;
    }
    if (this.deathSlow > 0) {
      target = 0.22;
      this.deathSlow -= realDt;
      if (this.deathSlow <= 0 && this.screen === 'playing') {
        if (this.mode === 'fist' && this.age < FIST_MAX_AGE) this.reviveFist();
        else this.setScreen('dead');
      }
    }
    this.timeScale += (target - this.timeScale) * smooth(10, realDt);
    let scale = this.timeScale;
    if (this.hitstop > 0) {
      this.hitstop -= realDt;
      scale *= 0.12;
    }
    const dt = realDt * scale;
    this.time += dt;
    if (playing && p.alive && this.bossIntro <= 0 && !(this.mode === 'boss' && this.bossDead)) this.playTime += realDt;

    if (this.focusing) {
      p.focus -= 19 * realDt;
      if (p.focus <= 0) {
        p.focus = 0;
        this.focusing = false;
        this.sfx.slowOut();
      }
    } else {
      p.focus = Math.min(100, p.focus + 4.5 * realDt);
    }
    this.sfx.setSlowmo(clamp((1 - this.timeScale) / (1 - SLOW), 0, 1));

    // aim
    const aim = this.screenToWorld(this.mouse.x, this.mouse.y);
    this.aim = aim;
    const canAct = playing && p.alive && this.bossIntro <= 0 && p.dazed <= 0;
    if (canAct && this.mouse.rightPressed && WEAPON_INFO[p.weapon].dual) {
      let best: Enemy | null = null;
      let bd = 90;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        const d = dist(aim.x, aim.y, e.x, e.y - 60);
        if (d < bd) {
          bd = d;
          best = e;
        }
      }
      this.split.active = true;
      this.split.enemyId = best ? best.id : -1;
      this.split.x = best ? best.x : aim.x;
      this.split.y = best ? best.y - 62 : aim.y;
      this.sfx.click();
    }
    if (!this.mouse.right || !canAct || !WEAPON_INFO[p.weapon].dual) this.split.active = false;
    p.scoping = canAct && this.mouse.right && (p.weapon === 'sniper' || p.weapon === 'h_sniper');
    // weapon switching: number keys 1-6 / mouse wheel
    this.wheelCd -= realDt;
    if (canAct) {
      // 1..0 = senjata lama; Z / X (atau roda mouse) = geser ke semua senjata termasuk HALO ARSENAL
      for (let i = 0; i < 10; i++) if (this.pressed.has(`Digit${(i + 1) % 10}`)) p.switchTo(WEAPON_ORDER[i]);
      if (this.pressed.has('KeyZ') || this.pressed.has('BracketLeft')) p.cycleWeapon(-1);
      if (this.pressed.has('KeyX') || this.pressed.has('BracketRight')) p.cycleWeapon(1);
      if (this.wheelDir !== 0 && this.wheelCd <= 0) {
        p.cycleWeapon(this.wheelDir);
        this.wheelCd = 0.12;
      }
    }
    this.wheelDir = 0;
    if (this.split.active && this.split.enemyId >= 0) {
      const e = this.enemies.find((q) => q.id === this.split.enemyId);
      if (e && e.alive) {
        this.split.x = e.wp.neck.x;
        this.split.y = e.wp.neck.y + 6;
      } else this.split.enemyId = -1;
    }
    p.aimF = Math.atan2(aim.y - p.wp.shF.y, aim.x - p.wp.shF.x);
    p.aimB = this.split.active
      ? Math.atan2(this.split.y - p.wp.shB.y, this.split.x - p.wp.shB.x)
      : Math.atan2(aim.y - p.wp.shB.y, aim.x - p.wp.shB.x);

    const inp: PlayerInput = canAct
      ? {
          left: this.k('KeyA', 'ArrowLeft'),
          right: this.k('KeyD', 'ArrowRight'),
          up: this.k('KeyW', 'ArrowUp'),
          down: this.k('KeyS', 'ArrowDown', 'ControlLeft'),
          jumpPressed: this.p('KeyW', 'ArrowUp'),
          downPressed: this.p('KeyS', 'ArrowDown', 'ControlLeft'),
          spinPressed: this.p('Space'),
          spinHeld: this.k('Space'),
          kickPressed: this.p('KeyF', 'KeyE'),
          fireHeld: this.mouse.left,
          splitHeld: this.split.active,
          walk: this.k('KeyC'),
          aimX: aim.x,
          aimY: aim.y,
        }
      : this.emptyInput();

    const fireDt = realDt * Math.max(scale, 0.55);
    p.update(dt, inp, this, fireDt);
    if (canAct) {
      if (p.melee) this.meleeInput(realDt);
      else {
        p.guard = false;
        const gun = p.tryFire(this.mouse.left, this.time, this.sfx);
        if (gun >= 0) this.playerFire(gun);
      }
    } else {
      p.meleeCharge = 0;
      p.guard = false;
    }
    this.meleeResolve();
    if (p.cricketFire) {
      p.cricketFire = false;
      if (p.alive && p.weapon === 'cricket' && p.mag[0] > 0) {
        p.releaseCricket(this.time);
        this.fireCricket();
      }
    }
    if (p.boltEvent) {
      p.boltEvent = false;
      this.sfx.bolt();
      const h = p.wp.haB;
      const back = Math.cos(p.aimF) >= 0 ? -1 : 1;
      this.particles.shell(h.x, h.y - 2, back * rand(90, 180), rand(-400, -280), true);
    }
    this.haloTick(dt);
    if (p.weapon !== this.lastWeapon) {
      const prev = this.lastWeapon;
      this.lastWeapon = p.weapon;
      if (this.mode !== 'fist') this.pickedWeapon = p.weapon;
      if (p.weapon === 'katana') this.sfx.unsheath();
      else this.sfx.swap();
      if (prev !== 'pistol' && prev !== 'bat' && !p.has(prev) && p.alive) {
        this.popup(`${WEAPON_INFO[prev].name} HABIS!`, p.x, p.y - 128, '#ffffff');
      }
    }
    if (p.pumpEvent) {
      p.pumpEvent = false;
      this.sfx.pump();
      const h = p.wp.haB;
      const back = Math.cos(p.aimF) >= 0 ? -1 : 1;
      this.particles.shell(h.x, h.y - 2, back * rand(80, 170), rand(-380, -250), true);
    }
    if (canAct) this.airStrikes();
    if (p.reloadStarted) {
      p.reloadStarted = false;
      for (const h of [p.wp.haF, p.wp.haB]) {
        this.particles.spawn({
          kind: 'debris',
          x: h.x,
          y: h.y + 4,
          vx: rand(-60, 60),
          vy: rand(-80, 20),
          life: 2.5,
          w: 3,
          h: 7,
          rot: rand(-0.4, 0.4),
          vr: rand(-10, 10),
          color: '#26292e',
          g: 1700,
          drag: 0.3,
          bounce: 0.3,
          collide: true,
        });
      }
    }
    if (p.alive && p.y > this.level.killY) this.killPlayer(0, true);

    for (const e of this.enemies) if (e.alive) e.update(dt, this);
    this.hazards.update(dt, this);
    for (const h of this.hazards.list) {
      if (!h.alive || !h.batted) continue;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        if (Math.abs(h.x - e.x) < e.w / 2 + 20 && h.y > e.y - e.h - 12 && h.y < e.y + 8) {
          h.alive = false;
          this.explodeAt(h.x, h.y, ['HOME RUN'], h.kind === 'dynamite' ? 140 : 95, 0.5);
          break;
        }
      }
    }
    this.updateBullets(dt);
    this.updateProps(dt);
    if (this.mode === 'boss') {
      for (let i = this.barrelRespawn.length - 1; i >= 0; i--) {
        const br = this.barrelRespawn[i];
        br.t -= dt;
        if (br.t <= 0) {
          this.barrelRespawn.splice(i, 1);
          const np = createProp({ type: 'barrel', x: br.x, y: this.arenaRect.y + 60, section: 1 });
          this.props.push(np);
          this.particles.dust(br.x, this.arenaRect.y + 60, 6, 0);
        }
      }
      if (this.bossDead && playing) {
        this.victoryT += realDt;
        if (this.victoryT > 3.0) this.finishBossFight();
      }
    }
    if (this.mode === 'fist') {
      this.updateWaves(realDt);
      if (this.bossDead && playing) {
        this.victoryT += realDt;
        if (this.victoryT > 3.0) this.finishFist();
      }
    }
    for (const e of this.enemies) {
      if (e.alive && e.wallHit) {
        e.wallHit = false;
        e.flung = 0;
        this.enemyWallSlam(e);
      }
    }
    for (let i = this.bubbles.length - 1; i >= 0; i--) {
      this.bubbles[i].t -= realDt;
      if (this.bubbles[i].t <= 0) this.bubbles.splice(i, 1);
    }
    for (const r of this.ragdolls) {
      r.update(dt, this.world);
      if (r.cutBleed > 0 && Math.random() < 0.75) {
        const a = r.part === 1 ? RP.pelvis : RP.neck;
        const o = r.part === 1 ? RP.neck : RP.pelvis;
        const bx = r.p[a * 2];
        const by = r.p[a * 2 + 1];
        this.particles.blood(bx, by, bx - r.p[o * 2], by - r.p[o * 2 + 1] - 6, 1, 1.15);
      }
      if (r.bleed > 0 && Math.random() < 0.5) {
        const nx = r.p[RP.neck * 2];
        const ny = r.p[RP.neck * 2 + 1];
        const hx = r.p[RP.head * 2];
        const hy = r.p[RP.head * 2 + 1];
        this.particles.blood(nx, ny, hx - nx, hy - ny - 4, 1, 0.9);
      }
    }
    if (playing && p.alive) this.triggers();

    if (this.comboT > 0) {
      this.comboT -= dt / 3.4;
      if (this.comboT <= 0) {
        this.combo = 0;
        this.comboT = 0;
      }
    }

    this.pressed.clear();
    this.mouse.rightPressed = false;
    this.mouse.leftPressed = false;
  }

  private frame(realDt: number) {
    const dt = realDt * this.timeScale;
    this.particles.update(dt, this.world);
    for (let i = this.tags.length - 1; i >= 0; i--) {
      this.tags[i].t -= realDt;
      if (this.tags[i].t <= 0) this.tags.splice(i, 1);
    }
    for (let i = this.popups.length - 1; i >= 0; i--) {
      const pp = this.popups[i];
      if (pp.max === undefined) pp.max = pp.t;
      pp.t -= realDt;
      pp.y -= (pp.burst ? 16 : 40) * realDt;
      if (pp.t <= 0) this.popups.splice(i, 1);
    }
    this.bloom = Math.max(0, this.bloom - realDt * 3.2);
    this.meleeHitT -= realDt;
    if (this.meleeHitT <= 0) this.meleeHits = 0;
    this.hitMark.t = Math.max(0, this.hitMark.t - realDt);
    this.scoreShown += (this.score - this.scoreShown) * smooth(7, realDt);
    if (Math.abs(this.score - this.scoreShown) < 1) this.scoreShown = this.score;
    this.titleT -= realDt;
    this.centerT -= realDt;
    this.speedLines = Math.max(0, this.speedLines - realDt);
    this.impactT = Math.max(0, this.impactT - realDt);
    this.flashT = Math.max(0, this.flashT - realDt);
    this.camPunch *= Math.exp(-5 * realDt);
    this.hurtFlash = Math.max(0, this.hurtFlash - realDt * 2.5);
    this.dodgeMsgT -= realDt;
    this.lockedMsgT -= realDt;
    this.updateHints(realDt);
    this.updateCamera(realDt);
  }

  private updateCamera(realDt: number) {
    const p = this.player;
    let tx: number;
    let ty: number;
    if (!p.alive && this.playerRag) {
      const c = this.playerRag.center();
      tx = c.x;
      ty = c.y - 20;
    } else {
      const sc = p.scoping;
      const lookX = clamp(((this.mouse.x - this.W / 2) / this.cam.zoom) * (sc ? 1.0 : 0.3), sc ? -720 : -230, sc ? 720 : 230);
      const lookY = clamp(((this.mouse.y - this.H / 2) / this.cam.zoom) * (sc ? 0.8 : 0.24), sc ? -400 : -150, sc ? 400 : 150);
      tx = p.x + lookX + p.vx * 0.12;
      ty = p.y - 60 + lookY + clamp(p.vy, -400, 700) * 0.06;
    }
    if (this.mode === 'boss' && p.alive && this.bossIntro <= 0) {
      // keep the boss in frame: lean the camera toward it
      const bb = this.enemies.find((e) => e.type === 'boss' && e.alive);
      if (bb) {
        tx += clamp((bb.x - p.x) * 0.3, -260, 260);
        ty += clamp((bb.y - bb.h * 0.6 - (p.y - 60)) * 0.25, -160, 160);
      }
    }
    const bossFocus = this.bossIntro > 0 ? this.enemies.find((e) => e.type === 'boss' && e.alive) : undefined;
    if (bossFocus) {
      tx = bossFocus.x;
      ty = bossFocus.y - bossFocus.h * 0.6;
    }
    if (this.killCam.t > 0) {
      tx += (this.killCam.x - tx) * 0.5;
      ty += (this.killCam.y - ty) * 0.5;
    }
    this.cam.x += (tx - this.cam.x) * smooth(5.5, realDt);
    this.cam.y += (ty - this.cam.y) * smooth(5, realDt);
    const slowAmt = clamp((1 - this.timeScale) / (1 - SLOW), 0, 1);
    const targetZoom =
      (this.H / 620) *
      (this.mode !== 'story' ? 0.9 : 1) *
      (p.scoping ? 0.84 : 1) * (1 + slowAmt * 0.07 + (p.alive ? 0 : 0.12) + (this.killCam.t > 0 ? 0.13 : 0) + (this.bossIntro > 0 ? 0.28 : 0));
    this.cam.zoom += (targetZoom - this.cam.zoom) * smooth(4, realDt);
    const b = this.level.bounds;
    const hw = this.W / 2 / this.cam.zoom;
    const hh = this.H / 2 / this.cam.zoom;
    this.cam.x = clamp(this.cam.x, b.x + hw, Math.max(b.x + hw, b.x + b.w - hw));
    this.cam.y = clamp(this.cam.y, b.y + hh, Math.max(b.y + hh, b.y + b.h - hh));
    let rollT = 0;
    if (p.alive && p.flipping) rollT = Math.sin(p.stuntK * Math.PI) * 0.045 * p.flipDir * p.facing;
    else if (p.alive && p.roll > 0) rollT = 0.025 * p.rollDir;
    else if (p.alive && p.dkPre) {
      // lean back with the wind-up, then the impact whips it forward
      rollT = -0.05 * p.facing;
      this.camPunch = Math.max(this.camPunch, 0.05 * (p.dkT / 0.17));
    }
    this.cam.roll += (rollT - this.cam.roll) * smooth(8, realDt);
    // trauma-based smooth shake + spring-loaded camera kick
    this.trauma = Math.max(0, this.trauma - realDt * 1.5);
    const amt = Math.pow(this.trauma, 1.5);
    const nt = this.realTime;
    const nz = (sd: number) =>
      Math.sin(nt * 37 + sd) * 0.5 + Math.sin(nt * 61 + sd * 1.7) * 0.3 + Math.sin(nt * 97 + sd * 2.3) * 0.2;
    const k = this.kick;
    const kdt = Math.min(realDt, 1 / 30);
    k.vx += (-260 * k.x - 22 * k.vx) * kdt;
    k.vy += (-260 * k.y - 22 * k.vy) * kdt;
    k.x += k.vx * kdt;
    k.y += k.vy * kdt;
    this.cam.sx = nz(1) * 24 * amt + k.x;
    this.cam.sy = nz(5) * 24 * amt + k.y;
    this.shakeRot = nz(9) * 0.04 * amt;
  }

  shake(a: number) {
    this.trauma = Math.min(1, this.trauma + a / 22);
  }

  camKick(x: number, y: number) {
    this.kick.vx += x * 27;
    this.kick.vy += y * 27;
  }

  stamp(text: string, x: number, y: number, color: string, size = 36, burst = '#ff4d4d') {
    this.popups.push({ x, y, text, t: 1.15, color, size, burst, rot: rand(-0.14, 0.14), seed: Math.floor(Math.random() * 1e6) });
    if (this.popups.length > 16) this.popups.shift();
  }

  private mark(kind: number) {
    if (this.hitMark.t > 0 && kind < this.hitMark.kind) return;
    this.hitMark.kind = kind;
    this.hitMark.t = kind === 0 ? 0.22 : 0.42;
    this.sfx.marker(kind);
  }

  popup(text: string, x: number, y: number, color: string) {
    this.popups.push({ x, y, text, t: 0.9, color, size: 22 });
  }

  // ------------------------------------------------------------ hints & triggers
  queueHint(text: string, urgent = false) {
    if (urgent) {
      this.hintQueue = [text];
      if (this.hintText) this.hintTimer = 1e9;
    } else this.hintQueue.push(text);
  }

  private updateHints(realDt: number) {
    if (!this.hintText && this.hintQueue.length) {
      this.hintText = this.hintQueue.shift() as string;
      this.hintChars = 0;
      this.hintTimer = 0;
    }
    if (this.hintText) {
      this.hintTimer += realDt;
      this.hintChars += 48 * realDt;
      const dur = Math.max(4.5, this.hintText.length * 0.06) + 1;
      const done = this.hintTimer > dur || (this.hintQueue.length > 0 && this.hintTimer > 3.2);
      if (done) {
        this.hintAlpha -= realDt * 4;
        if (this.hintAlpha <= 0) {
          this.hintAlpha = 0;
          this.hintText = '';
        }
      } else this.hintAlpha = Math.min(1, this.hintAlpha + realDt * 5);
    }
  }

  private triggers() {
    const p = this.player;
    const cx = p.x;
    const cy = p.y - 45;
    for (const h of this.level.hints) {
      if (this.hintsShown.has(h.id)) continue;
      if (pointInRect(cx, cy, h.trigger)) {
        this.hintsShown.add(h.id);
        this.queueHint(h.text);
      }
    }
    for (const cp of this.level.checkpoints) {
      if (this.checkpoint && cp.id <= this.checkpoint.id) continue;
      if (pointInRect(cx, cy, cp.trigger)) {
        this.checkpoint = cp;
        this.cpScore = this.score;
        this.cpHeadshots = this.headshots;
        this.centerMsg = 'CHECKPOINT!';
        this.centerT = 2;
        this.sfx.pickup();
      }
    }
    const ex = this.level.exit;
    const pr = { x: p.x - p.w / 2, y: p.y - p.h, w: p.w, h: p.h };
    if (rectOverlap(pr, ex)) {
      if (this.bossDead) {
        this.sfx.banana();
        this.focusing = false;
        this.setScreen('complete');
      } else if (this.lockedMsgT <= 0) {
        this.lockedMsgT = 4;
        this.queueHint('Pintunya terkunci! Kalahkan Don Kumis dulu.', true);
      }
    }
  }

  // ------------------------------------------------------------ player actions
  private styleSnapshot(split: boolean) {
    const p = this.player;
    const tags: string[] = [];
    if (p.flipping) tags.push(FLIP_TAG[p.flipKind]);
    else if (p.vault > 0) tags.push('VAULT');
    else if (!p.onGround && p.airTime > 0.15 && !p.zip) tags.push('MELAYANG');
    if (p.spin > 0) tags.push('PUTARAN');
    if (p.slide > 0) tags.push('SLIDE');
    if (p.roll > 0) tags.push('GULING');
    if (p.zip) tags.push('ZIPLINE');
    if (split) tags.push('SPLIT AIM');
    if (this.timeScale < 0.6) tags.push('FOKUS');
    return tags;
  }

  private playerFire(gun: number) {
    const p = this.player;
    const weapon = p.weapon;
    if (isHaloId(weapon)) {
      this.fireHalo();
      return;
    }
    if (weapon === 'sling') {
      this.fireSling();
      return;
    }
    if (weapon === 'cricket') {
      this.fireCricket();
      return;
    }
    const len = muzzleLen(weapon);
    const m = p.muzzle(gun, len);
    const sh = gun === 0 ? p.wp.shF : p.wp.shB;
    const usingSplit = gun === 1 && this.split.active;
    const tx = usingSplit ? this.split.x : this.aim.x;
    const ty = usingSplit ? this.split.y : this.aim.y;
    let base = Math.atan2(ty - m.y, tx - m.x);
    if (dist(tx, ty, m.x, m.y) < 40) base = m.a;
    const tags = this.styleSnapshot(usingSplit);
    const shotgun = weapon === 'shotgun';
    const sniper = weapon === 'sniper';
    const ak = weapon === 'ak47';
    const pellets = shotgun ? 8 : 1;
    const spread = shotgun ? 0.13 : weapon === 'uzi' ? 0.04 : ak ? 0.012 + p.heat * 0.055 : sniper ? 0.002 : 0.012;
    const block = this.world.raycast(sh.x, sh.y, m.x, m.y, true);
    for (let i = 0; i < pellets; i++) {
      const ang = shotgun ? base - spread + (spread * 2 * (i + Math.random())) / pellets : base + rand(-spread, spread);
      const speed = shotgun ? rand(2900, 3300) : sniper ? 6500 : ak ? 3700 : 3400;
      const b: Bullet = {
        x: m.x,
        y: m.y,
        vx: Math.cos(ang) * speed,
        vy: Math.sin(ang) * speed,
        sx: m.x,
        sy: m.y,
        owner: 'player',
        dmg: shotgun ? 1.25 : sniper ? 10 : ak ? 1.25 : 1,
        life: shotgun ? 0.24 : sniper ? 0.45 : 0.5,
        kind: weapon,
        tags: tags.slice(),
        ricochets: 0,
        alive: true,
        dodged: false,
        redirected: false,
        wake: 0,
        pierce: sniper ? 4 : 0,
        hitIds: sniper ? [] : undefined,
        kills: 0,
      };
      if (block) {
        b.x = sh.x;
        b.y = sh.y;
        this.traceBullet(b, sh.x, sh.y, m.x + Math.cos(ang) * 4, m.y + Math.sin(ang) * 4, 0);
      }
      if (b.alive) this.bullets.push(b);
    }
    this.sfx.shoot(weapon === 'bat' || weapon === 'katana' || weapon === 'fist' ? 'pistol' : weapon);
    const ca = Math.cos(base);
    const sa = Math.sin(base);
    const hand = gun === 0 ? p.wp.haF : p.wp.haB;
    const back = ca >= 0 ? -1 : 1;
    if (!shotgun && !sniper) this.particles.shell(hand.x, hand.y - 3, back * rand(70, 170), rand(-370, -230));
    // muzzle smoke & sparks
    const puffs = shotgun ? 6 : sniper ? 7 : 2;
    for (let i = 0; i < puffs; i++) {
      this.particles.spawn({
        kind: 'smoke',
        x: m.x + ca * i * 4,
        y: m.y + sa * i * 4,
        vx: ca * rand(30, 110) + rand(-15, 15),
        vy: sa * rand(30, 110) - rand(15, 40),
        life: rand(0.45, 0.9),
        size: shotgun ? rand(5, 9) : rand(3, 5),
        color: '#d6d0c8',
        drag: 2.5,
      });
    }
    this.particles.sparks(m.x, m.y, ca, sa, shotgun ? 12 : 3, '#ffe9a0');
    // feel: directional camera kick, trauma, crosshair bloom
    const kickAmt = shotgun ? 9 : sniper ? 13 : ak ? 2.2 : weapon === 'uzi' ? 1.3 : 2.4;
    this.camKick(-ca * kickAmt, -sa * kickAmt);
    this.shake(shotgun ? 8 : sniper ? 9 : ak ? 1.4 : weapon === 'uzi' ? 1.2 : 1.8);
    this.bloom = Math.min(1, this.bloom + (shotgun || sniper ? 1 : ak ? 0.24 : weapon === 'uzi' ? 0.18 : 0.32));
    if (sniper) {
      this.camPunch = Math.max(this.camPunch, 0.045);
      this.particles.spawn({ kind: 'ring', x: m.x, y: m.y, life: 0.25, size: 40, color: '#ffffff' });
      if (p.onGround) p.vx -= ca * 170;
      else {
        p.vx -= ca * 240;
        p.vy -= sa * 240;
      }
    }
    if (shotgun) {
      this.camPunch = Math.max(this.camPunch, 0.035);
      // recoil shove — aim down while airborne for a SHOTGUN JUMP
      if (p.onGround) {
        p.vx -= ca * 230;
        if (sa > 0.75) {
          p.vy = -660;
          p.onGround = false;
          this.popup('SHOTGUN JUMP!', p.x, p.y - 120, '#ffb36b');
        }
      } else {
        p.vx -= ca * 380;
        p.vy = clamp(p.vy - sa * 760, -880, 1500);
        if (sa > 0.6) {
          p.airJumps = Math.max(p.airJumps, 1);
          this.popup('SHOTGUN JUMP!', p.x, p.y - 120, '#ffb36b');
        }
      }
    }
    for (const e of this.enemies) e.hearNoise(p.x, p.y - 50, shotgun ? 900 : 650, this.time, this.sfx);
  }

  // ------------------------------------------------------------ HALO ARSENAL
  /** tembakan senjata HALO: proyektil asli, sinar instan, efek moncong khas tiap senjata */
  private fireHalo() {
    const p = this.player;
    const s = haloSpec(p.weapon);
    const m = p.muzzle(0, 0);
    const sh = p.wp.shF;
    let base = Math.atan2(this.aim.y - m.y, this.aim.x - m.x);
    if (dist(this.aim.x, this.aim.y, m.x, m.y) < 40) base = m.a;
    const tags = this.styleSnapshot(false);
    const block = this.world.raycast(sh.x, sh.y, m.x, m.y, true);
    const spread = s.spread + (s.heat > 0 ? p.heat * 0.05 : 0);
    for (let i = 0; i < s.pellets; i++) {
      const ang = s.pellets > 1 ? base + (i - (s.pellets - 1) / 2) * s.spread + rand(-0.012, 0.012) : base + rand(-spread, spread);
      const ca = Math.cos(ang);
      const sa = Math.sin(ang);
      const speed = s.beam ? 3000 : s.speed * rand(0.97, 1.03);
      const b: Bullet = {
        x: m.x,
        y: m.y,
        vx: ca * speed,
        vy: sa * speed,
        sx: m.x,
        sy: m.y,
        owner: 'player',
        dmg: s.dmg,
        life: s.life,
        kind: s.id,
        tags: tags.slice(),
        ricochets: 0,
        alive: true,
        dodged: false,
        redirected: false,
        wake: 0,
        pierce: s.pierce,
        hitIds: s.pierce > 0 ? [] : undefined,
        kills: 0,
        halo: s,
        age: 0,
        trailAcc: 0,
      };
      if (s.beam) {
        // sinar instan: telusuri sampai kena, lalu gambar sinarnya dari moncong
        const R = 2400;
        const ox = block ? sh.x : m.x;
        const oy = block ? sh.y : m.y;
        this.traceBullet(b, ox, oy, m.x + ca * R, m.y + sa * R, 0);
        const ex = b.alive ? m.x + ca * R : (b.hx ?? m.x);
        const ey = b.alive ? m.y + sa * R : (b.hy ?? m.y);
        haloBeamFx(this.haloFx, s, m.x, m.y, ex, ey);
        continue;
      }
      if (block) {
        b.x = sh.x;
        b.y = sh.y;
        this.traceBullet(b, sh.x, sh.y, m.x + ca * 4, m.y + sa * 4, 0);
      }
      if (b.alive) this.bullets.push(b);
    }
    const ca = Math.cos(base);
    const sa = Math.sin(base);
    this.sfx.haloShot(s.sound);
    haloMuzzleFx(this.haloFx, s, m.x, m.y, base);
    if (s.def.casing) {
      const hand = p.wp.haF;
      this.particles.shell(hand.x, hand.y - 3, (ca >= 0 ? -1 : 1) * rand(70, 170), rand(-370, -230), s.kick >= 8);
    }
    this.camKick(-ca * s.kick, -sa * s.kick);
    this.shake(s.shake);
    this.bloom = Math.min(1, this.bloom + (s.kick >= 8 ? 1 : s.cd < 0.1 ? 0.2 : 0.32));
    if (s.kick >= 10) this.camPunch = Math.max(this.camPunch, 0.045);
    if (!s.silent) for (const e of this.enemies) e.hearNoise(p.x, p.y - 50, s.kick >= 8 ? 1200 : 700, this.time, this.sfx);
  }

  private haloState(e: Enemy) {
    let st = this.haloStatus.get(e.id);
    if (!st) {
      st = { burn: 0, freeze: 0, tick: 0.3 };
      this.haloStatus.set(e.id, st);
    }
    return st;
  }

  /** animasi senjata di tangan, partikel HALO, dan status terbakar / beku pada musuh */
  private haloTick(dt: number) {
    const p = this.player;
    const hs = isHaloId(p.weapon) ? haloSpec(p.weapon) : null;
    haloLive.time = performance.now() / 1000;
    haloLive.sinceShot = Math.max(0, this.time - p.lastShot);
    haloLive.spin = hs && hs.spinup ? p.heat : 0;
    haloLive.spinAngle += dt * (3 + haloLive.spin * 42);
    haloLive.ammoRatio = p.magSize > 0 ? p.mag[0] / p.magSize : 1;
    haloLive.shots = hs ? hs.mag - p.mag[0] : 0;
    haloLive.ready = !hs || (p.fireCd <= hs.cd * 0.45 && p.reload <= 0 && p.mag[0] > 0);
    this.haloFx.update(dt);
    for (const [id, st] of this.haloStatus) {
      const e = this.enemies.find((q) => q.id === id);
      if (!e || !e.alive) {
        this.haloStatus.delete(id);
        continue;
      }
      if (st.burn > 0) {
        st.burn -= dt;
        st.tick -= dt;
        if (Math.random() < dt * 34) haloStatusFx(this.haloFx, 'burn', e.x, e.y, e.h);
        if (st.tick <= 0) {
          st.tick = 0.45;
          if (e.hurt(e.isBossMode ? 0.2 : 0.5, 0, false, this.time, this.sfx)) {
            this.killEnemy(e, 0, -0.4, false, 320, ['TERBAKAR'], e.x, e.y - e.h * 0.5);
            this.mark(1);
          }
        }
      }
      if (st.freeze > 0) {
        st.freeze -= dt;
        if (Math.random() < dt * 26) haloStatusFx(this.haloFx, 'freeze', e.x, e.y, e.h);
      }
      if (st.burn <= 0 && st.freeze <= 0) this.haloStatus.delete(id);
    }
  }

  /**
   * peluru HALO mengenai sesuatu: efek tumbukan khas + kemampuan senjata.
   * return true = sudah ditangani sepenuhnya (ledakan).
   */
  private haloHit(
    b: Bullet,
    type: string,
    hx: number,
    hy: number,
    ux: number,
    uy: number,
    e: Enemy | null,
    nx: number,
    ny: number,
    prop: Prop | null,
  ): boolean {
    const s = b.halo as HaloSpec;
    if (type === 'player') return false;
    haloImpactFx(this.haloFx, s, hx, hy, nx, ny);
    if (s.explode > 0 && type !== 'glass') {
      b.alive = false;
      if (type === 'door' && prop && prop.type === 'door' && prop.state === 'idle') this.breachDoor(prop, sign(ux) || 1, true, hy);
      else if (type === 'barrel' && prop) this.explode(prop, b.tags);
      haloExplodeFx(this.haloFx, s, hx, hy, s.explode);
      this.explodeAt(hx - ux * 6, hy - uy * 6, [...b.tags.filter((t) => t !== 'FOKUS'), s.name], s.explode, 0.25, null, false, 1.7);
      return true;
    }
    const bossy = !!e && (e.type === 'boss' || e.isBossMode);
    if (e) {
      b.dmg = s.dmg * (bossy ? s.bossMul : 1);
      if (s.burn) this.haloState(e).burn = 3;
      if (s.freeze) {
        this.haloState(e).freeze = 2.2;
        if (!bossy) e.stunFor(2.2, 0, 0);
        if (this.dodgeMsgT <= 0) {
          this.dodgeMsgT = 0.5;
          this.popup('❄ BEKU!', e.x, e.y - e.h - 30, '#9be7ff');
        }
      }
      if (s.chain) {
        // petir berantai: loncat ke dua musuh terdekat
        const seen = new Set<number>([e.id]);
        let cur = e;
        let fx = hx;
        let fy = hy;
        for (let n = 0; n < 2; n++) {
          let nxt: Enemy | null = null;
          let bd = 280;
          for (const o of this.enemies) {
            if (!o.alive || seen.has(o.id)) continue;
            const d = dist(cur.x, cur.y - 50, o.x, o.y - 50);
            if (d < bd) {
              bd = d;
              nxt = o;
            }
          }
          if (!nxt) break;
          seen.add(nxt.id);
          const ty = nxt.y - nxt.h * 0.55;
          this.haloFx.bolt(fx, fy, nxt.x, ty, s.rgb, 2.2, 0.22);
          haloImpactFx(this.haloFx, s, nxt.x, ty, 0, -1);
          if (nxt.hurt(s.dmg * 0.7 * (nxt.isBossMode ? 0.4 : 1), sign(nxt.x - cur.x) || 1, false, this.time, this.sfx)) {
            this.killEnemy(nxt, sign(nxt.x - cur.x) || 1, -0.3, false, 520, [...b.tags, 'RANTAI'], nxt.x, ty);
            this.mark(1);
          }
          fx = nxt.x;
          fy = ty;
          cur = nxt;
        }
      }
    }
    if (s.pull && type !== 'glass') {
      // lubang hitam runtuh: sedot semua musuh di sekitar ke titik tumbukan
      for (const o of this.enemies) {
        if (!o.alive) continue;
        const d = dist(hx, hy, o.x, o.y - 50);
        if (d > 210) continue;
        o.vx += (sign(hx - o.x) || 1) * 420 * (1 - d / 260);
        if (!(o.type === 'boss' || o.isBossMode)) o.stunFor(0.9, 0, -60);
      }
      this.shake(5);
    }
    return false;
  }

  /** bonus khas senjata saat membunuh */
  private haloKill(s: HaloSpec, hx: number, hy: number) {
    if (s.bonus === 'gold') {
      this.score += 300;
      this.stamp('3X KOIN!', hx, hy - 60, '#ffffff', 30, '#ffb020');
    } else if (s.bonus === 'fish' && Math.random() < 0.35) {
      this.score += 150;
      this.popup('🐟 IKAN HOKI! +150', hx, hy - 70, '#7fd3ff');
    } else if (s.bonus === 'diamond' && Math.random() < 0.25) {
      this.score += 400;
      this.stamp('BERLIAN!', hx, hy - 60, '#ffffff', 30, '#22d3ee');
    }
  }

  enemyFire(e: Enemy, gun: GunKind, x: number, y: number, angle: number) {
    const sh = e.wp.shF;
    if (this.world.raycast(sh.x, sh.y, x, y, true)) return;
    const pellets = gun === 'shotgun' ? 6 : 1;
    const spread =
      gun === 'shotgun' ? 0.22 : gun === 'uzi' ? 0.075 : gun === 'tommy' ? 0.05 : gun === 'ak47' ? 0.06 : gun === 'sniper' ? 0 : 0.045;
    for (let i = 0; i < pellets; i++) {
      const a = gun === 'shotgun' ? angle - spread + (spread * 2 * (i + Math.random())) / pellets : angle + rand(-spread, spread);
      const sp = gun === 'shotgun' ? rand(1250, 1450) : gun === 'sniper' ? 4600 : gun === 'ak47' ? 1700 : 1450;
      this.bullets.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        sx: x,
        sy: y,
        owner: 'enemy',
        dmg: gun === 'shotgun' ? 8 : gun === 'uzi' ? 7 : gun === 'tommy' ? 6 : gun === 'ak47' ? 8 : gun === 'sniper' ? 40 : 13,
        life: gun === 'sniper' ? 0.5 : 1.1,
        kind: gun,
        tags: [],
        ricochets: 0,
        alive: true,
        dodged: false,
        redirected: false,
        wake: 0,
      });
    }
    const d = dist(e.x, e.y, this.player.x, this.player.y);
    const vol = clamp(1.2 - d / 1300, 0.25, 1);
    this.sfx.shoot(gun === 'shotgun'
        ? 'enemyShotgun'
        : gun === 'uzi' || gun === 'tommy'
          ? 'enemyUzi'
          : gun === 'ak47'
            ? 'enemyAk'
            : gun === 'sniper'
              ? 'enemySniper'
              : 'enemy',
      vol,
    );
    const back = Math.cos(angle) >= 0 ? -1 : 1;
    this.particles.shell(e.wp.haF.x, e.wp.haF.y - 3, back * rand(60, 140), rand(-300, -180), gun === 'shotgun');
    this.shake(gun === 'shotgun' ? 3 : 1);
  }

  breakGlass(d: DynSolid, vx: number, vy: number) {
    const p = this.props.find((q) => q.id === d.ref);
    if (!p) return;
    this.breakGlassProp(p, vx, vy, true);
  }

  private breakGlassProp(p: Prop, vx: number, vy: number, body: boolean) {
    if (p.state === 'broken') return;
    p.state = 'broken';
    this.syncDyn();
    this.particles.glass(p.x, p.y, p.w, p.h, vx * 0.55, vy * 0.4);
    this.sfx.glass();
    this.shake(4);
    if (body) {
      const door = p.type === 'glassdoor';
      this.autoSlow = door ? 0.8 : 1.7;
      if (!door) this.sfx.slowIn();
      this.centerMsg = door ? 'PRANG!' : 'PRANGG!';
      this.centerT = 1.2;
    }
  }

  kickAt(x: number, y: number, w: number, h: number, dir: number): boolean {
    let hit = false;
    const r = { x, y, w, h };
    for (const p of this.props) {
      if (!p.alive) continue;
      if (p.type === 'pan') {
        if (pointInRect(p.x, p.y, { x: x - 14, y: y - 14, w: w + 28, h: h + 28 })) {
          p.state = 'flying';
          p.vy = -820;
          p.vx = dir * 120;
          p.vr = dir * 22;
          p.kickedAt = this.time;
          hit = true;
          this.particles.sparks(p.x, p.y, 0, -1, 6);
        }
      } else if (p.type === 'barrel') {
        if (rectOverlap(r, { x: p.x - p.w / 2, y: p.y - p.h, w: p.w, h: p.h })) {
          p.vx = dir * 520;
          p.vy = -260;
          p.onGround = false;
          hit = true;
        }
      } else if (isGlass(p) && p.state !== 'broken') {
        if (rectOverlap({ x: x - 10, y, w: w + 20, h }, { x: p.x, y: p.y, w: p.w, h: p.h })) {
          this.breakGlassProp(p, dir * 500, -60, true);
          hit = true;
        }
      } else if (p.type === 'door' && p.state === 'idle') {
        if (rectOverlap({ x: x - 14, y, w: w + 28, h }, { x: p.x, y: p.y, w: p.w, h: p.h })) {
          this.breachDoor(p, dir, false);
          hit = true;
        }
      }
    }
    for (const e of this.enemies) {
      if (!e.alive) continue;
      if (rectOverlap(r, { x: e.x - e.w / 2, y: e.y - e.h, w: e.w, h: e.h })) {
        hit = true;
        this.particles.blood(e.x, e.y - 60, dir, -0.3, 6, 0.6);
        this.sfx.thud();
        const dmg = e.type === 'boss' ? (e.isBossMode ? 5 : 2) : 1.5;
        if (e.hurt(dmg, dir, false, this.time, this.sfx)) {
          this.killEnemy(e, dir, -0.4, false, 900, ['TENDANGAN'], e.x, e.y - 60);
        } else if (e.type !== 'boss') e.stunFor(1.1, dir * 520, -260);
        else e.stunFor(0.4, dir * 220, -100);
      }
    }
    for (const rg of this.ragdolls) {
      const c = rg.center();
      if (pointInRect(c.x, c.y, { x: x - 10, y: y - 10, w: w + 20, h: h + 20 })) {
        rg.impulseAll(dir * 650, -380);
        hit = true;
      }
    }
    if (hit) {
      this.hitstop = 0.05;
      this.shake(5);
    }
    return hit;
  }

  breach(d: DynSolid, dir: number, footY?: number) {
    const p = this.props.find((q) => q.id === d.ref);
    if (p && p.type === 'door' && p.state === 'idle') this.breachDoor(p, dir, true, footY);
  }

  /** cinematic door breach: the door is launched at the nearest enemy behind it */
  private breachDoor(p: Prop, dir: number, barge: boolean, footY?: number) {
    p.state = 'flying';
    // where the heel hits the door
    const ix = dir > 0 ? p.x : p.x + p.w;
    const iy = clamp(footY ?? this.player.y - 52, p.y + 14, p.y + p.h - 14);
    p.crack = 1;
    p.crackY = iy - (p.y + p.h / 2);
    p.kickedAt = this.time;
    p.noCol = 0.1;
    p.hitIds = [];
    p.hist = [];
    p.tags = [...this.styleSnapshot(false).filter((t) => t !== 'FOKUS'), ...(barge ? ['DOBRAK'] : [])];
    this.syncDyn();
    const cx = p.x + p.w / 2;
    const cy = p.y + p.h / 2;
    let target: Enemy | null = null;
    let bd = 1e9;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const dx = (e.x - cx) * dir;
      if (dx < 0 || dx > 720) continue;
      const ty = e.y - e.h * 0.55;
      if (Math.abs(ty - cy) > 240) continue;
      if (!this.world.los(cx + dir * 24, cy, e.x, ty)) continue;
      if (dx < bd) {
        bd = dx;
        target = e;
      }
    }
    if (target) {
      const tx = target.x;
      const ty = target.y - target.h * 0.55;
      const T = clamp(Math.abs(tx - cx) / 1150, 0.1, 0.55);
      p.vx = (tx - cx) / T;
      p.vy = (ty - cy - 0.5 * DOOR_G * T * T) / T;
    } else {
      p.vx = dir * 1100;
      p.vy = -240;
    }
    p.vr = dir * rand(7.5, 10);
    // ---- juice
    const hx = dir > 0 ? p.x : p.x + p.w;
    this.particles.sparks(hx, p.y + 14, -dir, -0.3, 10, '#ffe08a');
    this.particles.sparks(hx, p.y + p.h - 14, -dir, 0.3, 10, '#ffe08a');
    this.particles.debris(cx, cy, 30, '#8a5a34', 1.6, true);
    this.particles.debris(cx, cy, 16, '#5c3a1f', 1.3, false);
    this.particles.smoke(cx, cy, 8, 18);
    this.particles.dust(cx, p.y + p.h, 12, dir);
    this.particles.spawn({ kind: 'ring', x: cx, y: cy, life: 0.4, size: 150, color: '#ffffff' });
    this.particles.spawn({ kind: 'flash', x: cx, y: cy, life: 0.15, size: 170, color: '#ffe2a8' });
    this.sfx.breach();
    this.sfx.duck(0.25, 0.9);
    if (!this.focusing) this.sfx.slowIn();
    this.shake(20);
    this.camKick(dir * 16, -4);
    this.hitstop = 0.2;
    this.autoSlow = Math.max(this.autoSlow, 1.3);
    this.camPunch = 0.2;
    this.speedLines = 0.9;
    this.flashT = 0.06;
    this.impactT = 0.1;
    this.impactX = ix;
    this.impactY = iy;
    this.breachX = ix;
    this.breachY = iy;
    this.camKick(dir * 8, 0);
    this.stamp('BRAKK!', ix + dir * 40, iy - 58, '#ffffff', 56, '#ff4d4d');
    // heel impact: splinter spray from the hole, hinges ripped out, door panel chunks
    this.particles.spawn({ kind: 'impact', x: ix, y: iy, life: 0.12, size: 46, color: '#ffffff' });
    this.particles.spawn({ kind: 'ring', x: ix, y: iy, life: 0.32, size: 90, color: '#ffffff' });
    this.particles.sparks(ix, iy, dir, 0, 16, '#fff2c0');
    for (let i = 0; i < 14; i++) {
      const a = (dir > 0 ? 0 : Math.PI) + rand(-0.7, 0.7);
      const sp = rand(380, 900);
      this.particles.spawn({
        kind: 'debris',
        x: ix,
        y: iy + rand(-8, 8),
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 120,
        life: rand(1.6, 2.8),
        w: rand(8, 16),
        h: rand(2, 3.5),
        rot: a,
        vr: rand(-20, 20),
        color: Math.random() < 0.5 ? '#c99a6a' : '#8a5a34',
        g: 1600,
        drag: 0.3,
        bounce: 0.35,
        collide: true,
      });
    }
    for (const hy of [p.y + 18, p.y + p.h - 18]) {
      for (let i = 0; i < 3; i++) {
        this.particles.spawn({
          kind: 'debris',
          x: ix,
          y: hy,
          vx: dir * rand(250, 520),
          vy: rand(-380, -120),
          life: rand(2, 3),
          w: rand(3, 5),
          h: rand(2, 3),
          rot: rand(0, TAU),
          vr: rand(-25, 25),
          color: '#aab3bc',
          g: 1700,
          drag: 0.3,
          bounce: 0.45,
          collide: true,
        });
      }
    }
    for (let i = 0; i < 2; i++) {
      this.particles.spawn({
        kind: 'plank',
        x: ix + dir * 6,
        y: iy + (i ? 16 : -16),
        vx: dir * rand(260, 520),
        vy: rand(-420, -180),
        life: rand(3, 4.5),
        w: rand(16, 22),
        h: rand(5, 7),
        rot: rand(0, TAU),
        vr: rand(-16, 16),
        color: i ? '#7a4f2c' : '#8a5a34',
        g: 1700,
        drag: 0.3,
        bounce: 0.3,
        collide: true,
      });
    }
    for (let i = 0; i < 9; i++) {
      this.particles.spawn({
        kind: 'puff',
        x: cx + rand(-10, 10),
        y: p.y + p.h * rand(0.2, 0.95),
        vx: dir * rand(60, 280),
        vy: rand(-60, 20),
        life: rand(0.8, 1.5),
        size: rand(14, 26),
        color: '#cfc4b4',
        drag: 2.2,
      });
    }
    // everyone nearby flinches
    for (const e of this.enemies) {
      if (!e.alive || e === target) continue;
      if (Math.abs(e.x - cx) < 520 && Math.abs(e.y - (p.y + p.h)) < 220) {
        e.alert(this.time, this.sfx);
        e.reaction = Math.max(e.reaction, 0.75);
        e.hitT = 0.22;
        e.hitDir = dir;
      }
    }
  }

  private updateFlyingDoor(p: Prop, dt: number) {
    const w = this.world;
    if (this.time - p.kickedAt > 3.5) {
      // safety: never leave a door stuck in the flying state
      p.state = 'resting';
      p.rot = Math.round((p.rot - Math.PI / 2) / Math.PI) * Math.PI + Math.PI / 2;
      p.vx = 0;
      p.vy = 0;
      p.vr = 0;
      p.hist.length = 0;
      return;
    }
    p.noCol -= dt;
    p.vy = Math.min(1500, p.vy + DOOR_G * dt);
    let cx = p.x + p.w / 2;
    let cy = p.y + p.h / 2;
    p.hist.push(cx, cy, p.rot);
    if (p.hist.length > 12) p.hist.splice(0, 3);
    p.rot += p.vr * dt;
    const ax = -Math.sin(p.rot);
    const ay = Math.cos(p.rot);
    const half = p.h / 2 - 4;
    const speed = Math.hypot(p.vx, p.vy);
    if (speed > 260) {
      const ux = p.vx / speed;
      const uy = p.vy / speed;
      for (const e of this.enemies) {
        if (!e.alive || p.hitIds.includes(e.id)) continue;
        const d = segSegDist(cx - ax * half, cy - ay * half, cx + ax * half, cy + ay * half, e.x, e.y - e.h + 6, e.x, e.y - 6);
        if (d > p.w / 2 + e.w / 2) continue;
        p.hitIds.push(e.id);
        const hy = clamp(cy, e.y - e.h + 12, e.y - 12);
        this.particles.blood(e.x, hy, ux, uy - 0.25, 16, 1.1);
        this.particles.debris(e.x, hy, 12, '#8a5a34', 1.1, true);
        this.sfx.hit(false);
        this.sfx.thud();
        this.shake(12);
        this.hitstop = Math.max(this.hitstop, 0.07);
        this.stamp('BUAKK!', e.x + sign(p.vx) * 34, e.y - e.h * 0.55, '#ffffff', 42, '#ff7b3a');
        this.camKick(sign(p.vx) * 8, 0);
        if (e.type === 'boss') {
          if (e.hurt(7, ux, false, this.time, this.sfx)) {
            this.killEnemy(e, ux, -0.6, false, 1250, ['PINTU', ...p.tags], e.x, hy);
          } else e.stunFor(1.1, ux * 420, -280);
          p.vx *= 0.4;
          p.vy *= 0.5;
        } else {
          this.killEnemy(e, ux, -0.55, false, 1300, ['PINTU', ...p.tags], e.x, hy);
          p.vx *= 0.8;
        }
        p.vr += rand(-4, 4);
      }
      for (const r of this.ragdolls) {
        const c = r.center();
        if (dist(c.x, c.y, cx, cy) > p.h / 2 + 12) continue;
        const rvx = (r.p[4] - r.o[4]) / r.lastDt;
        if (Math.abs(rvx) < Math.abs(p.vx) * 0.6) r.impulseAll(p.vx * 0.55, p.vy * 0.4 - 160);
      }
      for (const q of this.props) {
        if (!q.alive || q === p) continue;
        if (q.type === 'barrel' && Math.abs(q.x - cx) < 34 && Math.abs(q.y - q.h / 2 - cy) < p.h / 2 + 12) {
          this.explode(q, ['PINTU']);
        } else if (isGlass(q) && q.state !== 'broken' && rectOverlap({ x: cx - 22, y: cy - p.h / 2, w: 44, h: p.h }, q)) {
          this.breakGlassProp(q, p.vx, p.vy, false);
        }
      }
    }
    // world collision with the rotated bounding box
    const c = Math.abs(Math.cos(p.rot));
    const sn = Math.abs(Math.sin(p.rot));
    const ex = (c * p.w) / 2 + (sn * p.h) / 2;
    const ey = (sn * p.w) / 2 + (c * p.h) / 2;
    if (p.noCol > 0) {
      cx += p.vx * dt;
      cy += p.vy * dt;
    } else {
      let guard = 0;
      while (!w.rectFree(cx - ex, cy - ey, ex * 2, ey * 2, false) && guard < 10) {
        cy -= 3;
        guard++;
      }
      const body = { x: cx - ex, y: cy - ey, w: ex * 2, h: ey * 2, vx: p.vx, vy: p.vy };
      const res = this.doorRes;
      w.moveBody(body, dt, false, res);
      cx = body.x + ex;
      cy = body.y + ey;
      if (res.hitX !== 0) {
        if (Math.abs(p.vx) > 520) {
          this.shatterDoor(p, cx, cy, res.hitX);
          return;
        }
        if (Math.abs(p.vx) > 200) {
          this.particles.debris(cx + res.hitX * ex, cy, 8, '#8a5a34', 0.8, true);
          this.sfx.thud();
          this.shake(5);
        }
        p.vx = -p.vx * 0.3;
        p.vr = -p.vr * 0.5;
      }
      if (res.hitY === -1) p.vy = Math.abs(p.vy) * 0.3;
      if (res.onGround) {
        const impact = p.vy;
        if (impact > 220) {
          this.particles.dust(cx, cy + ey, 8, sign(p.vx));
          this.particles.debris(cx, cy + ey, 4, '#8a5a34', 0.6);
          this.sfx.thud();
          this.shake(Math.min(8, impact / 120));
        }
        p.vy = impact > 140 ? -impact * 0.28 : 0;
        p.vx *= 0.6;
        p.vr *= 0.5;
      }
      const ground = w.solidAt(cx, cy + ey + 2, true);
      if (ground && p.vy >= 0) {
        p.vx = approach(p.vx, 0, 900 * dt);
        const flat = Math.round((p.rot - Math.PI / 2) / Math.PI) * Math.PI + Math.PI / 2;
        p.vr = (flat - p.rot) * 10;
        if (Math.abs(p.vx) < 30 && Math.abs(p.vy) < 30 && Math.abs(flat - p.rot) < 0.05) {
          p.state = 'resting';
          p.rot = flat;
          p.vx = 0;
          p.vy = 0;
          p.vr = 0;
          cy = ground.y - p.w / 2;
          p.hist.length = 0;
          this.sfx.thud();
        }
      }
    }
    p.x = cx - p.w / 2;
    p.y = cy - p.h / 2;
    if (cy > this.level.killY + 300) p.alive = false;
  }

  private shatterDoor(p: Prop, cx: number, cy: number, side: number) {
    p.alive = false;
    const c = Math.cos(p.rot);
    const sn = Math.sin(p.rot);
    for (let i = 0; i < 4; i++) {
      const lx = (i % 2 === 0 ? -1 : 1) * (p.w / 4);
      const ly = (i < 2 ? -1 : 1) * (p.h / 4);
      this.particles.spawn({
        kind: 'plank',
        x: cx + lx * c - ly * sn,
        y: cy + lx * sn + ly * c,
        vx: -side * rand(140, 420),
        vy: rand(-560, -220),
        life: rand(3.5, 5),
        w: p.h / 2 - 4,
        h: p.w / 2 + 2,
        rot: p.rot + Math.PI / 2 + rand(-0.3, 0.3),
        vr: rand(-14, 14),
        color: i % 2 ? '#8a5a34' : '#7a4f2c',
        g: 1700,
        drag: 0.3,
        bounce: 0.3,
        collide: true,
      });
    }
    this.particles.debris(cx, cy, 26, '#8a5a34', 1.4, true);
    this.particles.smoke(cx, cy, 6, 14);
    this.sfx.shatter();
    this.shake(10);
    this.camKick(-side * 6, 0);
    this.stamp('KRAKK!', cx, cy - 50, '#ffffff', 38, '#ffb347');
  }

  private spawnGunDrop(gun: GunKind, x: number, y: number, vx: number, vy: number, section: number) {
    const p = createProp({ type: 'gundrop', x, y, section });
    p.gun = gun;
    p.vx = vx;
    p.vy = vy;
    p.vr = rand(-14, 14);
    p.state = 'flying';
    p.t = 0;
    this.props.push(p);
  }

  /** stomps (falling onto heads) and flying dive-kick hits */
  private airStrikes() {
    const p = this.player;
    if (!p.alive || p.onGround || p.zip) return;
    if (p.dive) {
      // aim assist: bend the flying kick toward an enemy ahead
      let target: Enemy | null = null;
      let bd = 1e9;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        const dx = (e.x - p.x) * p.facing;
        const dy = e.y - e.h * 0.55 - p.y;
        if (dx > 10 && dx < 360 && dy > -30 && dy < 320 && dx < bd) {
          bd = dx;
          target = e;
        }
      }
      if (target) {
        const dy = Math.max(30, target.y - target.h * 0.55 - p.y + 40);
        const tt = dy / Math.max(400, p.vy);
        p.diveVx = clamp(bd / Math.max(0.12, tt), 420, 980);
      }
      const toe = p.wp.toeF;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        if (toe.x > e.x - e.w / 2 - 16 && toe.x < e.x + e.w / 2 + 16 && toe.y > e.y - e.h - 8 && toe.y < e.y + 6) {
          this.diveHit(e);
          return;
        }
      }
      return;
    }
    if (p.vy < 100) return;
    // stomp assist: falling just above a head gently steers onto it
    let best: Enemy | null = null;
    let bd = 1e9;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const dx = e.wp.head.x - p.x;
      const above = e.wp.head.y - p.y;
      if (Math.abs(dx) < 70 && above > -14 && above < 160 && Math.abs(dx) < bd) {
        bd = Math.abs(dx);
        best = e;
      }
    }
    if (best) {
      // pull strength scales with how close the feet are to the head
      const above = best.wp.head.y - p.y;
      const pull = above < 110 ? 4.2 : 2.6;
      const nx = p.x + clamp(best.wp.head.x - p.x, -pull, pull);
      if (this.world.rectFree(nx - p.w / 2, p.y - p.h, p.w, p.h - 2)) p.x = nx;
    }
    if (p.vy < 160) return;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const hx = e.wp.head.x;
      const hy = e.wp.head.y;
      if (Math.abs(p.x - hx) < 28 && p.y > hy - e.dims.headR - 12 && p.y < hy + 14) {
        this.stompEnemy(e);
        return;
      }
    }
  }

  private stompEnemy(e: Enemy) {
    const p = this.player;
    const tags = [...this.styleSnapshot(false).filter((t) => t !== 'MELAYANG'), 'INJAK'];
    const hx = e.wp.head.x;
    const hy = e.wp.head.y;
    this.particles.blood(hx, hy, 0.3 * p.facing, 1, 14, 0.8);
    this.particles.dust(p.x, p.y, 6, 0);
    this.particles.spawn({ kind: 'ring', x: hx, y: hy - 6, life: 0.3, size: 58, color: '#ffffff' });
    this.sfx.stomp();
    this.shake(9);
    this.camKick(0, 9);
    this.hitstop = Math.max(this.hitstop, 0.08);
    this.stamp('INJAK!', hx - p.facing * 70, hy - 20, '#ffffff', 40, '#ff4d4d');
    if (e.type === 'boss') {
      if (e.hurt(e.isBossMode ? 9 : 4, p.facing, false, this.time, this.sfx)) this.killEnemy(e, 0.2 * p.facing, 1, false, 700, tags, hx, hy);
      else e.stunFor(1.1, p.facing * 140, -80);
    } else {
      this.killEnemy(e, 0.15 * p.facing, 1, false, 700, tags, hx, hy);
    }
    p.bounceOff(-780, 'front');
    this.autoSlow = Math.max(this.autoSlow, 0.45);
  }

  private diveHit(e: Enemy) {
    const p = this.player;
    const dir = p.facing;
    const tags = [...this.styleSnapshot(false).filter((t) => t !== 'MELAYANG'), 'TENDANGAN TERBANG'];
    const hy = e.y - e.h * 0.6;
    this.particles.blood(e.x, hy, dir, -0.2, 18, 1.1);
    this.particles.spawn({ kind: 'ring', x: e.x, y: hy, life: 0.32, size: 72, color: '#ffffff' });
    this.particles.spawn({ kind: 'impact', x: e.x - dir * 6, y: hy, life: 0.1, size: 32, color: '#fff2c0' });
    this.sfx.kick();
    this.sfx.hit(false);
    this.sfx.thud();
    this.shake(13);
    this.camKick(dir * 10, 4);
    this.camPunch = Math.max(this.camPunch, 0.06);
    this.hitstop = Math.max(this.hitstop, 0.1);
    this.stamp('DUAKK!', e.x + dir * 10, e.y - e.h - 36, '#ffffff', 46, '#ff7b3a');
    if (e.type === 'boss') {
      if (e.hurt(e.isBossMode ? 11 : 5, dir, false, this.time, this.sfx)) this.killEnemy(e, dir, -0.4, false, 1300, tags, e.x, hy);
      else e.stunFor(1.2, dir * 420, -240);
    } else {
      this.killEnemy(e, dir, -0.35, false, 1450, tags, e.x, hy);
    }
    p.bounceOff(-660, 'back');
    p.vx = -dir * 230;
    this.autoSlow = Math.max(this.autoSlow, 0.55);
  }

  /** heavy landing shockwave: knocks nearby enemies off balance */
  groundPound(x: number, y: number, power: number) {
    const R = 150 + power * 100;
    this.particles.spawn({ kind: 'shock', x, y, life: 0.45, size: R, color: '#ffffff' });
    this.particles.spawn({ kind: 'ring', x, y: y - 4, life: 0.3, size: 70 + power * 40, color: '#ffffff' });
    this.particles.addDecal({ x, y: y - 1, w: 34 + power * 26, h: 8, rot: Math.floor(Math.random() * 1e6) + 1, color: '#000', kind: 'crack' });
    this.particles.dust(x - 12, y, 10, -1);
    this.particles.dust(x + 12, y, 10, 1);
    for (let i = 0; i < 6; i++) {
      const d = i % 2 === 0 ? -1 : 1;
      this.particles.spawn({
        kind: 'puff',
        x: x + d * rand(10, 40),
        y: y - rand(4, 16),
        vx: d * rand(120, 320),
        vy: rand(-50, -10),
        life: rand(0.6, 1.1),
        size: rand(10, 18),
        color: '#cfc4b4',
        drag: 2.6,
      });
    }
    this.particles.debris(x, y - 3, 10, '#77736c', 0.7);
    this.sfx.slam();
    this.shake(10 + power * 8);
    this.camKick(0, 11 + power * 7);
    this.camPunch = Math.max(this.camPunch, 0.05 + power * 0.04);
    this.hitstop = Math.max(this.hitstop, 0.05 + power * 0.04);
    this.autoSlow = Math.max(this.autoSlow, 0.3 + power * 0.25);
    let n = 0;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const dx = e.x - x;
      if (Math.abs(dx) < R && Math.abs(e.y - y) < 72) {
        const f = 1 - Math.abs(dx) / R;
        e.alert(this.time, this.sfx, true);
        if (e.type === 'boss') e.stunFor(0.45 + f * 0.4, sign(dx) * 160 * f, -160 * f);
        else e.stunFor(0.8 + f * 0.8, sign(dx || 1) * (200 + 320 * f), -(260 + 300 * f));
        n++;
      }
    }
    for (const r of this.ragdolls) {
      const c = r.center();
      const dx = c.x - x;
      if (Math.abs(dx) < R && Math.abs(c.y - y) < 80) {
        const f = 1 - Math.abs(dx) / R;
        r.impulseAll(sign(dx || 1) * 320 * f, -560 * f);
      }
    }
    for (const q of this.props) {
      if (!q.alive) continue;
      const dx = q.x - x;
      if (Math.abs(dx) > R || Math.abs(q.y - y) > 60) continue;
      const f = 1 - Math.abs(dx) / R;
      if (q.type === 'barrel') {
        q.vy = -420 * f;
        q.vx += sign(dx || 1) * 120 * f;
        q.onGround = false;
      } else if (q.type === 'pan') {
        q.state = 'flying';
        q.vy = -700 * f - 200;
        q.vr = 20;
      }
    }
    if (n > 0 || power >= 1) this.stamp(n > 0 ? 'BUMM!' : 'BLARR!', x, y - 130, '#ffffff', 40, '#3a9bff');
  }

  // ------------------------------------------------------------ slingshot & noisy cricket
  private fireSling() {
    const p = this.player;
    const pw = p.slingPower;
    const o = p.slingFork;
    let ang = Math.atan2(this.aim.y - o.y, this.aim.x - o.x);
    if (dist(this.aim.x, this.aim.y, o.x, o.y) < 30) ang = p.aimF;
    const sp = SLING.vmin + (SLING.vmax - SLING.vmin) * pw;
    const sh = p.wp.shF;
    const start = this.world.raycast(sh.x, sh.y, o.x, o.y, true) ? { x: sh.x, y: sh.y } : o;
    this.bullets.push({
      x: start.x,
      y: start.y,
      vx: Math.cos(ang) * sp,
      vy: Math.sin(ang) * sp,
      sx: start.x,
      sy: start.y,
      owner: 'player',
      dmg: 0.75,
      life: 2.2,
      kind: 'sling',
      tags: this.styleSnapshot(false),
      ricochets: 0,
      alive: true,
      dodged: false,
      redirected: false,
      wake: 0,
    });
    this.sfx.thwip(pw);
    this.camKick(Math.cos(ang) * 2, Math.sin(ang) * 2);
    // silent: nobody hears a slingshot
  }

  private fireCricket() {
    const p = this.player;
    const m = p.muzzle(0, muzzleLen('cricket'));
    let ang = Math.atan2(this.aim.y - m.y, this.aim.x - m.x);
    if (dist(this.aim.x, this.aim.y, m.x, m.y) < 30) ang = p.aimF;
    const ca = Math.cos(ang);
    const sa = Math.sin(ang);
    const sh = p.wp.shF;
    const b: Bullet = {
      x: m.x,
      y: m.y,
      vx: ca * 2300,
      vy: sa * 2300,
      sx: m.x,
      sy: m.y,
      owner: 'player',
      dmg: 20,
      life: 0.9,
      kind: 'cricket',
      tags: this.styleSnapshot(false),
      ricochets: 0,
      alive: true,
      dodged: false,
      redirected: false,
      wake: 0,
    };
    if (this.world.raycast(sh.x, sh.y, m.x, m.y, true)) {
      b.x = sh.x;
      b.y = sh.y;
      this.traceBullet(b, sh.x, sh.y, m.x + ca * 4, m.y + sa * 4, 0);
    }
    if (b.alive) this.bullets.push(b);
    this.sfx.cricketBoom();
    this.particles.spawn({ kind: 'flash', x: m.x, y: m.y, life: 0.16, size: 130, color: '#9fe8ff' });
    this.particles.spawn({ kind: 'ring', x: m.x, y: m.y, life: 0.3, size: 80, color: '#dff6ff' });
    this.particles.sparks(m.x, m.y, ca, sa, 18, '#e6fbff');
    this.particles.smoke(m.x, m.y, 6, 10);
    this.shake(16);
    this.camKick(-ca * 22, -sa * 22);
    this.camPunch = Math.max(this.camPunch, 0.1);
    this.hitstop = Math.max(this.hitstop, 0.07);
    this.flashT = Math.max(this.flashT, 0.05);
    // the recoil throws the shooter across the room
    p.dkOn = false;
    p.slide = 0;
    p.roll = 0;
    p.heavyLand = 0;
    p.dive = false;
    p.vx = -ca * (p.onGround ? 1050 : 1150);
    p.vy = Math.min(p.vy, -sa * 700 - 380);
    p.onGround = false;
    p.cricketFly = 0.75;
    p.airJumps = Math.max(p.airJumps, 1);
    p.startStunt('back');
    p.usedStunt = true;
    this.stamp('ZZAPP!', m.x + ca * 30, m.y - 30, '#ffffff', 34, '#3fa8ff');
    this.autoSlow = Math.max(this.autoSlow, 0.45);
    for (const e of this.enemies) e.hearNoise(p.x, p.y - 50, 1400, this.time, this.sfx);
  }

  wallSplat(x: number, y: number, dir: number) {
    this.shake(12);
    this.camKick(dir * 10, 0);
    this.hitstop = Math.max(this.hitstop, 0.06);
    this.sfx.thud();
    this.sfx.land();
    this.particles.dust(x, y, 10, -dir);
    this.particles.debris(x, y, 10, '#77736c', 0.8);
    this.particles.spawn({ kind: 'ring', x, y, life: 0.3, size: 60, color: '#ffffff' });
    this.stamp('GEDEBUK!', x - dir * 30, y - 50, '#ffffff', 36, '#ff7b3a');
  }

  /** bat in front of the body + slingshot bands, drawn after the character */
  private drawPlayerOverlayFx(ctx: CanvasRenderingContext2D) {
    const p = this.player;
    this.drawBlade(ctx, true);
    if (p.weapon === 'sling') {
      const [ax, ay, bx, by] = p.slingTips;
      const pc = p.slingPouch;
      const k = Math.min(1, p.slingCharge / SLING.max);
      ctx.save();
      ctx.lineCap = 'round';
      for (const [w, col] of [
        [3.4, '#1b1410'],
        [1.8, k > 0.95 ? '#ffde6b' : '#c0392b'],
      ] as [number, string][]) {
        ctx.strokeStyle = col;
        ctx.lineWidth = w;
        ctx.beginPath();
        ctx.moveTo(ax, ay);
        ctx.lineTo(pc.x, pc.y);
        ctx.lineTo(bx, by);
        ctx.stroke();
      }
      ctx.fillStyle = '#5a3a1f';
      ctx.strokeStyle = '#1b1410';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.ellipse(pc.x, pc.y, 3.6, 2.6, Math.atan2(by - ay, bx - ax), 0, TAU);
      ctx.fill();
      ctx.stroke();
      if (p.mag[0] > 0 && p.fireCd <= 0.05) {
        ctx.fillStyle = '#b8b2a8';
        ctx.beginPath();
        ctx.arc(pc.x, pc.y - 1, 2.6, 0, TAU);
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();
      if (p.slingCharge > 0.02) this.drawSlingPreview(ctx, k);
    }
    if (p.weapon === 'cricket' && p.cricketCharge > 0) {
      const k = 1 - p.cricketCharge / CRICKET.charge;
      const m = p.muzzle(0, muzzleLen('cricket'));
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, 16 + 34 * k);
      g.addColorStop(0, `rgba(230,250,255,${0.5 + 0.5 * k})`);
      g.addColorStop(0.4, `rgba(80,190,255,${0.35 * k})`);
      g.addColorStop(1, 'rgba(60,150,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(m.x, m.y, 16 + 34 * k, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = `rgba(200,240,255,${0.6 * k})`;
      ctx.lineWidth = 1.2;
      for (let i = 0; i < 4; i++) {
        const a = rand(0, TAU);
        const r = 14 + 26 * k * Math.random();
        ctx.beginPath();
        ctx.moveTo(m.x + Math.cos(a) * r, m.y + Math.sin(a) * r);
        ctx.lineTo(m.x + Math.cos(a + 0.4) * r * 0.5, m.y + Math.sin(a + 0.4) * r * 0.5);
        ctx.lineTo(m.x, m.y);
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  /** dotted ballistic arc for the slingshot */
  private drawSlingPreview(ctx: CanvasRenderingContext2D, k: number) {
    const p = this.player;
    const o = p.slingFork;
    let ang = Math.atan2(this.aim.y - o.y, this.aim.x - o.x);
    if (dist(this.aim.x, this.aim.y, o.x, o.y) < 30) ang = p.aimF;
    const sp = SLING.vmin + (SLING.vmax - SLING.vmin) * k;
    let x = o.x;
    let y = o.y;
    let vx = Math.cos(ang) * sp;
    let vy = Math.sin(ang) * sp;
    const dt = 1 / 60;
    ctx.save();
    for (let i = 0; i < 70; i++) {
      const nx = x + vx * dt;
      const ny = y + vy * dt;
      vy += SLING.g * dt;
      const hit = this.world.raycast(x, y, nx, ny, true, true);
      if (hit) {
        ctx.strokeStyle = 'rgba(255,255,255,0.85)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(hit.x, hit.y, 6, 0, TAU);
        ctx.stroke();
        break;
      }
      x = nx;
      y = ny;
      if (i % 3 === 0) {
        const a = (1 - i / 70) * (0.35 + 0.6 * k);
        ctx.fillStyle = `rgba(255,255,255,${a})`;
        ctx.beginPath();
        ctx.arc(x, y, 2.2, 0, TAU);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  // ------------------------------------------------------------ new weapons
  private weaponHint(id: WeaponId) {
    const hints: Partial<Record<WeaponId, string>> = {
      ak47: 'AK-47! Tahan klik kiri = otomatis. Makin lama ditahan makin melenceng — tembak pendek-pendek!',
      sniper: 'SNIPER! Pelurunya MENEMBUS banyak musuh & pintu. Tahan KLIK KANAN = SCOPE untuk melihat jauh.',
      bat: 'PEMUKUL! Klik beruntun = HOME RUN → BACKHAND → HANTAMAN. TAHAN lalu lepas = GRAND SLAM! Pukul balik peluru & dinamit.',
      katana: 'KATANA! Klik beruntun = COMBO 5 jurus. TAHAN klik lalu LEPAS = IAI (tebas semua di jalur). Tahan KLIK KANAN = tangkis peluru!',
      shotgun: 'SHOTGUN! Tembak ke bawah saat di udara = SHOTGUN JUMP.',
      sling: 'KETAPEL! TAHAN klik kiri untuk menarik karet (lihat lintasannya), LEPAS untuk menembak. Senyap! Kena kepala = tumbang.',
      cricket: 'NOISY CRICKET! Kecil tapi DAHSYAT — hentakannya akan MELEMPARMU ke belakang. Jangan tembak di pinggir atap!',
      uzi: 'UZI GANDA! Tembakan super cepat.',
    };
    const key = 'w-' + id;
    if (!this.hintsShown.has(key) && hints[id]) {
      this.hintsShown.add(key);
      this.queueHint(hints[id] as string, true);
    }
    if (id === 'katana' && !this.hintsShown.has('w-katana2')) {
      this.hintsShown.add('w-katana2');
      this.queueHint('Katana di udara: klik dekat musuh = TERBANG WALET, S+klik = TUSUK ke bawah. Di darat W+klik = tebasan NAIK, lalu kejar di udara!');
    }
    if (!this.hintsShown.has('w-swap')) {
      this.hintsShown.add('w-swap');
      this.queueHint('Ganti senjata: tombol 1-9 atau SCROLL mouse. Pistol ganda selalu ada di tombol 1.');
    }
  }

  // ------------------------------------------------------------ melee: katana & bat
  private meleeInput(realDt: number) {
    const p = this.player;
    const kat = p.weapon === 'katana';
    const press = this.mouse.leftPressed;
    const held = this.mouse.left;
    const fist = p.weapon === 'fist';
    if (fist && this.mouse.rightPressed) {
      this.guardStart = this.realTime;
      if (p.mv && p.mvT > p.mv.hit[1] && !p.mv.air) p.endMove();
    }
    p.guard = (kat || fist) && this.mouse.right && !p.mv && p.swallowT < 0 && p.swapT <= 0 && p.meleeCharge <= 0;
    if (press) {
      p.meleeHeld = 0;
      if (p.mv) {
        if (p.mv.next && p.mvT > 0.02 && !p.mvQueued) p.mvQueued = p.mv.next;
      } else if (p.swallowT < 0 && p.swapT <= 0 && !p.guard) {
        this.meleeStart();
      }
    }
    if (held) {
      p.meleeHeld += realDt;
      // holding after a hit: cancel the recovery into the charge stance
      const mv = p.mv;
      const free =
        !mv ||
        (p.mvT > mv.hit[1] + 0.06 && !mv.air && !mv.plunge && !p.mvQueued && mv.id !== 'kIaiDash' && mv.id !== 'kIaiHold');
      if (free && mv && p.meleeHeld > KATANA.holdT && p.onGround && !p.guard) p.endMove();
      if (!p.mv && p.onGround && p.swallowT < 0 && p.meleeHeld > KATANA.holdT && !p.guard) {
        const was = p.meleeCharge;
        p.meleeCharge = Math.min(1, p.meleeCharge + realDt / KATANA.chargeT);
        if (was === 0) this.sfx.chargeUp(kat);
        if (was < 1 && p.meleeCharge >= 1) {
          this.sfx.chargeFull();
          this.particles.spawn({ kind: 'ring', x: p.x, y: p.y - 50, life: 0.3, size: 70, color: kat ? '#c7f0ff' : '#ffd0a0' });
        }
        if (Math.random() < 0.8) {
          const a = rand(0, TAU);
          const r = 48 + rand(0, 22);
          this.particles.spawn({
            kind: 'spark',
            x: p.x + Math.cos(a) * r,
            y: p.y - 50 + Math.sin(a) * r,
            vx: -Math.cos(a) * 240,
            vy: -Math.sin(a) * 240,
            life: 0.2,
            size: 1.8,
            color: kat ? '#9fe8ff' : '#ffb36b',
          });
        }
      }
    } else {
      if (p.meleeCharge >= 1 && !p.mv) this.meleeSpecial();
      p.meleeCharge = 0;
      p.meleeHeld = 0;
    }
  }

  private meleeFace() {
    const p = this.player;
    const dir = (this.k('KeyD', 'ArrowRight') ? 1 : 0) - (this.k('KeyA', 'ArrowLeft') ? 1 : 0);
    p.facing = dir !== 0 ? dir : this.aim.x >= p.x ? 1 : -1;
  }

  private meleeStart() {
    const p = this.player;
    const kat = p.weapon === 'katana';
    this.meleeFace();
    if (p.weapon === 'fist') {
      if (!p.onGround) {
        if (p.mvAir < 1) {
          p.mvAir++;
          p.startMove('fAir');
          p.vx = p.facing * 470;
          p.vy = Math.min(p.vy, -140);
        }
        return;
      }
      if (this.k('KeyW', 'ArrowUp')) {
        p.startMove('fUpper');
        return;
      }
      if (this.k('KeyS', 'ArrowDown')) {
        p.startMove('fSweep');
        return;
      }
      let fid = 'f1';
      if (p.mvLast && p.animT - p.mvLastEndT < 0.2) {
        const lm = MOVES[p.mvLast];
        if (lm && lm.next && lm.w === 'fist') fid = lm.next;
      }
      p.startMove(fid);
      return;
    }
    if (!p.onGround) {
      if (!kat) {
        p.startMove('bAir');
        return;
      }
      if (this.k('KeyS', 'ArrowDown')) {
        p.startMove('kPlunge');
        return;
      }
      const t = this.swallowTarget();
      if (t) {
        p.startSwallow(t.x, t.y - t.h * 0.55, t.id);
        this.sfx.slash('katana', true);
        return;
      }
      if (p.mvAir < 3) {
        p.mvAir++;
        p.startMove('kAir');
      }
      return;
    }
    if (kat && this.k('KeyW', 'ArrowUp')) {
      p.startMove('kRise');
      return;
    }
    let id = kat ? 'k1' : 'b1';
    if (p.mvLast && p.animT - p.mvLastEndT < 0.2) {
      const last = MOVES[p.mvLast];
      if (last && last.next && last.w === p.weapon) id = last.next;
    }
    p.startMove(id);
  }

  private swallowTarget(): Enemy | null {
    const p = this.player;
    const f = p.facing;
    let best: Enemy | null = null;
    let bd = 1e9;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const ex = e.x;
      const ey = e.y - e.h * 0.55;
      const dx = (ex - p.x) * f;
      const dy = ey - (p.y - 48);
      if (dx < 10 || dx > 360 || dy < -280 || dy > 320) continue;
      if (!this.world.los(p.x, p.y - 48, ex, ey)) continue;
      const d = Math.hypot(dx, dy);
      if (d < bd) {
        bd = d;
        best = e;
      }
    }
    return best;
  }

  /** release after a full charge: IAI dash (katana) / GRAND SLAM (bat) */
  private meleeSpecial() {
    const p = this.player;
    this.meleeFace();
    if (p.weapon === 'fist') {
      p.startMove('fPalm');
      this.sfx.whoosh(0.5);
      return;
    }
    if (p.weapon === 'bat') {
      p.startMove('bSlam');
      this.sfx.whoosh(0.5);
      return;
    }
    const f = p.facing;
    const y = p.y - 50;
    const maxD = 330;
    const hit = this.world.raycast(p.x, y, p.x + f * maxD, y, false);
    const d = hit ? Math.max(0, hit.t * maxD - 26) : maxD;
    const x1 = p.x + f * d;
    const x0 = p.x;
    p.startIai(x1);
    p.invuln = Math.max(p.invuln, 0.75);
    this.iaiMarks = [];
    this.iaiProps = [];
    this.iaiDone = false;
    this.iaiSheath = false;
    const lo = Math.min(x0, x1) - 18;
    const band = { x: lo, y: p.y - 116, w: Math.abs(x1 - x0) + 36, h: 118 };
    for (const e of this.enemies) {
      if (!e.alive || !rectOverlap(band, { x: e.x - e.w / 2, y: e.y - e.h, w: e.w, h: e.h })) continue;
      this.iaiMarks.push(e.id);
      if (e.type !== 'boss' && !e.isBossMode) e.stunFor(0.7, 0, 0);
    }
    for (const q of this.props) {
      if (!q.alive) continue;
      if (q.type === 'door' && q.state === 'idle' && rectOverlap(band, q)) this.breachDoor(q, f, true, y);
      else if (isGlass(q) && q.state !== 'broken' && rectOverlap(band, q)) this.breakGlassProp(q, f * 600, 0, false);
      else if (q.type === 'barrel' && rectOverlap(band, { x: q.x - q.w / 2, y: q.y - q.h, w: q.w, h: q.h })) this.iaiProps.push(q.id);
    }
    for (const b of this.bullets) {
      if (b.alive && b.owner === 'enemy' && pointInRect(b.x, b.y, band)) {
        b.alive = false;
        this.particles.sparks(b.x, b.y, -f, 0, 6, '#e6fbff');
      }
    }
    this.sfx.slash('katana', true);
    this.sfx.whoosh(0.55);
    this.particles.dust(x0, p.y, 14, -f);
    this.flashT = Math.max(this.flashT, 0.05);
    this.speedLines = 0.45;
    this.breachX = (x0 + x1) / 2;
    this.breachY = y;
  }

  private meleeResolve() {
    const p = this.player;
    if (!p.alive) return;
    const m = p.mv;
    if (m && !p.mvSwish && m.hit[0] < 5 && p.mvT >= m.hit[0] - 0.03) {
      p.mvSwish = true;
      if (m.w === 'fist') this.sfx.whoosh(m.heavy ? 0.45 : 0.22);
      else this.sfx.slash(m.w, !!m.heavy);
    }
    if (p.swallowT >= 0) this.resolveSwallow();
    if (m && m.id === 'kIaiHold' && !this.iaiDone && p.mvT >= 0.3) this.iaiSlice();
    if (m && m.id === 'kIaiHold' && !this.iaiSheath && p.mvT >= 0.8) {
      this.iaiSheath = true;
      this.sfx.sheath();
    }
    if (m && m.slam && !p.mvSlam && p.mvT >= m.hit[0] + 0.02) {
      p.mvSlam = true;
      const sx = p.x + p.facing * (m.w === 'katana' ? 80 : 64);
      if (m.w === 'bat') this.groundPound(sx, p.y, 0.3);
      else {
        this.particles.spawn({ kind: 'shock', x: sx, y: p.y, life: 0.4, size: 150, color: '#c7f0ff' });
        this.particles.addDecal({ x: sx, y: p.y - 1, w: 40, h: 8, rot: Math.floor(Math.random() * 1e6) + 1, color: '#000', kind: 'crack' });
        this.particles.sparks(sx, p.y - 2, 0, -1, 16, '#e6fbff');
        this.particles.dust(sx - 10, p.y, 8, -1);
        this.particles.dust(sx + 10, p.y, 8, 1);
        this.sfx.thud();
        this.shake(10);
        this.camKick(0, 8);
      }
    }
    if (p.guard && p.weapon === 'katana') this.guardDeflect();
    if (m && p.mvStrike) this.meleeStrike(m);
  }

  private meleeStrike(m: MeleeMove) {
    const p = this.player;
    const f = p.facing;
    const [zx0, zx1, zy0, zy1] = m.zone;
    const zone = { x: f > 0 ? p.x + zx0 : p.x - zx1, y: p.y + zy0, w: zx1 - zx0, h: zy1 - zy0 };
    for (const e of this.enemies) {
      if (!e.alive || p.mvHit.includes(e.id) || e.invuln > 0) continue;
      if (!rectOverlap(zone, { x: e.x - e.w / 2, y: e.y - e.h, w: e.w, h: e.h })) continue;
      p.mvHit.push(e.id);
      this.meleeHitEnemy(e, m);
      if (p.mv !== m) return;
    }
    for (const b of this.bullets) {
      if (m.w === 'fist' || !b.alive || b.owner !== 'enemy' || !pointInRect(b.x, b.y, zone)) continue;
      this.deflectBullet(b);
      if (m.w === 'katana') this.sfx.ting();
    }
    const big = { x: zone.x - 10, y: zone.y - 10, w: zone.w + 20, h: zone.h + 20 };
    for (const h of this.hazards.list) {
      if (!h.alive || h.batted || h.kind === 'laser' || h.kind === 'wave') continue;
      if (h.kind === 'cleaver' && h.stuck) continue;
      if (!pointInRect(h.x, h.y, big)) continue;
      this.batHazard(h, f);
    }
    for (const q of this.props) {
      if (!q.alive || p.mvHit.includes(-q.id)) continue;
      if (q.type === 'barrel') {
        if (!rectOverlap(zone, { x: q.x - q.w / 2, y: q.y - q.h, w: q.w, h: q.h })) continue;
        p.mvHit.push(-q.id);
        if (m.w === 'katana') {
          this.particles.spawn({ kind: 'slash', x: q.x, y: q.y - q.h / 2, rot: -0.3, size: 70, w: 5, life: 0.2, color: 'rgba(140,215,255,0.9)' });
          this.sfx.cut();
          if (q.fuse < 0) q.fuse = 0.3;
        } else {
          q.vx = f * 880;
          q.vy = -360;
          q.onGround = false;
          if (q.fuse < 0) q.fuse = 0.85;
          this.sfx.batHit();
          this.shake(8);
          this.stamp('BOOM BALL!', q.x, q.y - 70, '#ffffff', 32, '#ff7b3a');
        }
      } else if (q.type === 'pan' && pointInRect(q.x, q.y, zone)) {
        p.mvHit.push(-q.id);
        q.state = 'flying';
        q.vy = -880;
        q.vx = f * 160;
        q.vr = f * 26;
        this.sfx.clang();
      } else if (q.type === 'door' && q.state === 'idle' && rectOverlap(zone, q)) {
        p.mvHit.push(-q.id);
        this.breachDoor(q, f, true, p.y - 62);
        if (m.w === 'bat') this.useBat();
        if (p.mv !== m) return;
      } else if (isGlass(q) && q.state !== 'broken' && rectOverlap(zone, q)) {
        p.mvHit.push(-q.id);
        this.breakGlassProp(q, f * 500, -60, false);
      }
    }
  }

  private meleeHitEnemy(e: Enemy, m: MeleeMove) {
    if (m.w === 'fist') {
      this.fistHit(e, m);
      return;
    }
    const p = this.player;
    const kat = m.w === 'katana';
    const dir = m.spin ? sign(e.x - p.x) || p.facing : p.facing;
    const hy = e.y - e.h * 0.6;
    const boss = e.type === 'boss' || e.isBossMode;
    const tags = [...this.styleSnapshot(false).filter((t) => t !== 'FOKUS'), m.tag];
    this.meleeHits++;
    this.meleeHitT = 1.5;
    // the slash mark follows the blade's actual direction of travel
    const reach = kat ? KATANA.reach : BAT.len;
    const q0 = p.bladeAt(Math.max(0, p.mvT - 0.02));
    const q1 = p.bladeAt(p.mvT);
    let sa = Math.atan2(m.dir[1], dir * m.dir[0]);
    if (q0 && q1) {
      const ddx = q1.gx + q1.dx * reach - (q0.gx + q0.dx * reach);
      const ddy = q1.gy + q1.dy * reach - (q0.gy + q0.dy * reach);
      if (Math.hypot(ddx, ddy) > 2) sa = Math.atan2(ddy, ddx);
    }
    if (kat) {
      this.particles.spawn({ kind: 'slash', x: e.x, y: hy, rot: sa, size: 120, w: 7, life: 0.22, color: 'rgba(140,215,255,0.9)' });
      this.particles.blood(e.x, hy, Math.cos(sa), Math.sin(sa), 14, 1.1);
      this.particles.blood(e.x, hy, -Math.cos(sa), -Math.sin(sa) - 0.3, 6, 0.7);
      this.particles.sparks(e.x, hy, Math.cos(sa), Math.sin(sa), 8, '#e6fbff');
      this.sfx.cut();
    } else {
      this.sfx.batHit();
      this.particles.spawn({ kind: 'impact', x: e.x - dir * 8, y: hy, life: 0.1, size: m.heavy ? 46 : 36, color: '#fff2c0' });
      this.particles.spawn({ kind: 'ring', x: e.x, y: hy, life: 0.3, size: m.heavy ? 96 : 74, color: '#ffffff' });
      this.particles.sparks(e.x, hy, dir, -0.4, 12, '#fff2c0');
    }
    this.shake(m.shake);
    this.camKick(dir * (m.heavy ? 12 : kat ? 5 : 10), m.heavy ? -3 : -1);
    if (m.heavy) this.camPunch = Math.max(this.camPunch, 0.06);
    this.hitstop = Math.max(this.hitstop, m.stop);
    const dmg = boss ? m.boss : m.dmg;
    const ux = dir * m.dir[0];
    const uy = m.dir[1];
    if (e.hurt(dmg, dir, false, this.time, this.sfx)) {
      const sever = kat && !e.customDeath && Math.random() < (m.sever ?? 0.35);
      this.severNext = sever;
      this.killEnemy(e, ux, uy, false, m.power, tags, e.x, hy);
      this.mark(1);
      if (sever) this.stamp('TERBELAH!', e.x + dir * 24, e.y - e.h - 40, '#ffffff', m.heavy ? 50 : 40, '#c81d2a');
      else if (!kat) {
        const word = m.id === 'b3' || m.id === 'bAir' ? 'HANTAM!' : m.id === 'bSlam' ? 'GRAND SLAM!' : m.id === 'b2' ? 'BACKHAND!' : 'HOME RUN!';
        this.stamp(word, e.x + dir * 40, e.y - e.h - 44, '#ffffff', m.heavy ? 52 : 44, '#3a9bff');
      }
      if (m.id === 'bSlam') this.flashT = Math.max(this.flashT, 0.06);
    } else {
      this.mark(0);
      if (!boss) {
        if (m.launch) e.stunFor(1.2, dir * 50, -m.launch);
        else e.stunFor(0.45, dir * (kat ? 150 : 320), !e.onGround ? -330 : kat ? -60 : -160);
      } else if (m.heavy) e.stunFor(0.5, dir * 220, -120);
      if (!kat && boss) this.stamp('BUKK!', e.x + dir * 20, e.y - e.h - 30, '#ffffff', 40, '#3a9bff');
    }
    if (!kat) this.useBat();
  }

  private resolveSwallow() {
    const p = this.player;
    const e = this.enemies.find((q) => q.id === p.swallowId);
    if (!e || !e.alive || p.swallowT > 0.5 || (p.onGround && p.swallowT > 0.12)) {
      p.endSwallow(false);
      return;
    }
    p.swallowX = e.x;
    p.swallowY = e.y - e.h * 0.55;
    const touch =
      dist(p.x, p.y - 48, p.swallowX, p.swallowY) < 46 ||
      rectOverlap({ x: p.x - p.w / 2, y: p.y - p.h, w: p.w, h: p.h }, { x: e.x - e.w / 2, y: e.y - e.h, w: e.w, h: e.h });
    if (!touch) return;
    const f = p.facing;
    const hy = e.y - e.h * 0.62;
    const boss = e.type === 'boss' || e.isBossMode;
    const tags = [...this.styleSnapshot(false).filter((t) => t !== 'FOKUS'), 'TERBANG WALET'];
    this.particles.spawn({ kind: 'slash', x: e.x, y: hy, rot: f > 0 ? -0.5 : 0.5 + Math.PI, size: 150, w: 9, life: 0.26, color: 'rgba(140,215,255,0.9)' });
    this.particles.sparks(e.x, hy, f, -0.4, 14, '#e6fbff');
    this.sfx.cut();
    this.sfx.slash('katana', true);
    this.hitstop = Math.max(this.hitstop, 0.12);
    this.autoSlow = Math.max(this.autoSlow, 0.5);
    this.shake(12);
    this.camKick(f * 10, -4);
    if (boss) {
      if (e.hurt(15, f, false, this.time, this.sfx)) {
        this.severNext = !e.customDeath;
        this.killEnemy(e, f, -0.6, false, 800, tags, e.x, hy);
      } else e.stunFor(0.8, f * 200, -150);
    } else {
      e.hp = 0;
      this.severNext = true;
      this.killEnemy(e, f, -0.6, false, 800, tags, e.x, hy);
    }
    this.stamp('TERBANG WALET!', e.x, e.y - e.h - 54, '#ffffff', 40, '#3a9bff');
    this.mark(2);
    this.meleeHits++;
    this.meleeHitT = 1.5;
    p.endSwallow(true);
  }

  private iaiSlice() {
    this.iaiDone = true;
    const p = this.player;
    const f = p.facing;
    const y = p.y - 55;
    this.impactT = 0.1;
    this.impactX = (p.iaiX0 + p.x) / 2;
    this.impactY = y;
    this.sfx.zan();
    this.shake(16);
    this.camPunch = Math.max(this.camPunch, 0.1);
    this.hitstop = Math.max(this.hitstop, 0.06);
    this.stamp('ZAN!', this.impactX, y - 92, '#ffffff', 66, '#c81d2a');
    this.particles.spawn({ kind: 'slash', x: this.impactX, y, rot: 0, size: Math.abs(p.x - p.iaiX0) + 90, w: 6, life: 0.38, color: 'rgba(140,215,255,0.9)' });
    const tags = [...this.styleSnapshot(false).filter((t) => t !== 'FOKUS'), 'IAI'];
    let n = 0;
    for (const id of this.iaiMarks) {
      const e = this.enemies.find((q) => q.id === id);
      if (!e || !e.alive) continue;
      const hy = e.y - e.h * 0.55;
      this.particles.spawn({ kind: 'slash', x: e.x, y: hy, rot: rand(-0.35, 0.35), size: 130, w: 8, life: 0.26, color: 'rgba(255,90,90,0.85)' });
      this.particles.blood(e.x, hy, f, -0.6, 22, 1.3);
      if (e.type === 'boss' || e.isBossMode) {
        if (e.hurt(30, f, false, this.time, this.sfx)) {
          this.severNext = !e.customDeath;
          this.killEnemy(e, f, -0.4, false, 900, tags, e.x, hy);
        } else e.stunFor(0.9, f * 120, -80);
      } else {
        e.hp = 0;
        this.severNext = true;
        this.killEnemy(e, f * 0.4, -0.5, false, 650, tags, e.x, hy);
      }
      n++;
      this.meleeHits++;
    }
    this.meleeHitT = 1.5;
    for (const id of this.iaiProps) {
      const q = this.props.find((o) => o.id === id);
      if (q && q.alive && q.type === 'barrel') this.explode(q, tags);
    }
    if (n >= 2) this.stamp(`${n} SEKALIGUS!`, this.impactX, y - 150, '#ffffff', 36, '#2ecc71');
    this.autoSlow = Math.max(this.autoSlow, n > 0 ? 0.9 : 0.4);
    this.mark(n > 0 ? 2 : 0);
  }

  private guardDeflect() {
    const p = this.player;
    const f = p.facing;
    const gx = p.x + f * 20;
    const gy = p.y - 62;
    for (const b of this.bullets) {
      if (!b.alive || b.owner !== 'enemy') continue;
      if ((b.x - p.x) * f < -6 || b.vx * f > 0) continue;
      if (dist(b.x, b.y, gx, gy) > 72) continue;
      this.deflectBullet(b);
      this.sfx.ting();
      this.particles.sparks(b.x, b.y, -f, -0.3, 10, '#e6fbff');
    }
    for (const h of this.hazards.list) {
      if (!h.alive || h.batted || (h.kind !== 'cleaver' && h.kind !== 'dynamite' && h.kind !== 'bomb')) continue;
      if (h.kind === 'cleaver' && h.stuck) continue;
      if ((h.x - p.x) * f < -6 || dist(h.x, h.y, gx, gy) > 80) continue;
      this.batHazard(h, f);
      this.sfx.ting();
    }
  }

  /** draws the held katana / bat (behind or in front of the body) */
  private drawBlade(ctx: CanvasRenderingContext2D, front: boolean) {
    const p = this.player;
    if (!p.melee || p.weapon === 'fist' || p.bladeFront !== front) return;
    const kat = p.weapon === 'katana';
    if (p.meleeCharge > 0 && !front) {
      const k = p.meleeCharge;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(p.x, p.y - 50, 10, p.x, p.y - 50, 70 + 20 * k);
      g.addColorStop(0, kat ? `rgba(120,210,255,${0.28 * k})` : `rgba(255,150,70,${0.28 * k})`);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(p.x, p.y - 50, 70 + 20 * k, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
    if (kat) {
      if (p.mv && p.mvStrike && p.mv.trail > 0) {
        for (const [lag, a] of [
          [0.034, 0.16],
          [0.017, 0.3],
        ]) {
          const q = p.bladeAt(p.mvT - lag);
          if (!q) continue;
          ctx.save();
          ctx.globalAlpha = a;
          drawKatana3D(ctx, { gx: q.gx, gy: q.gy, dx: q.dx, dy: q.dy, dz: q.dz, L: KATANA.reach }, 0.7, -1, 'rgba(40,90,130,0.7)');
          ctx.restore();
        }
      }
      drawKatana3D(ctx, p.blade3, kat ? p.meleeCharge : 0, p.bladeShine);
    } else drawBat3D(ctx, p.blade3);
    if (front) drawFist(ctx, p.wp.haF.x, p.wp.haF.y, PLAYER_LOOK);
  }

  /** Ninja-Gaiden style crescent slash swept by the blade tip */
  private drawMeleeTrail(ctx: CanvasRenderingContext2D) {
    const p = this.player;
    const m = p.mv;
    if (!m) return;
    if ((m.id === 'kIaiDash' || m.id === 'kIaiHold') && !this.iaiDone) {
      const y = p.y - 55;
      const k = m.id === 'kIaiDash' ? 1 : 1 - clamp(p.mvT / 0.3, 0, 1) * 0.5;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.lineCap = 'round';
      ctx.strokeStyle = `rgba(120,210,255,${0.35 * k})`;
      ctx.lineWidth = 16;
      ctx.beginPath();
      ctx.moveTo(p.iaiX0, y);
      ctx.lineTo(p.x, y);
      ctx.stroke();
      ctx.strokeStyle = `rgba(255,255,255,${0.95 * k})`;
      ctx.lineWidth = 2.5;
      ctx.stroke();
      ctx.restore();
    }
    if (m.trail <= 0) return;
    const t1 = p.mvT;
    if (t1 < m.hit[0] - 0.035 || t1 > m.hit[1] + 0.09) return;
    const kat = m.w === 'katana';
    const reach = kat ? KATANA.reach : BAT.len + 4;
    const inner = kat ? KATANA.handle + 8 : BAT.len * 0.38;
    const t0 = Math.max(m.hit[0] - 0.045, t1 - (kat ? 0.08 : 0.065));
    const N = 18;
    const S: { tx: number; ty: number; ix: number; iy: number }[] = [];
    for (let i = 0; i <= N; i++) {
      const q = p.bladeAt(t0 + ((t1 - t0) * i) / N);
      if (!q) return;
      S.push({ tx: q.gx + q.dx * reach, ty: q.gy + q.dy * reach, ix: q.gx + q.dx * inner, iy: q.gy + q.dy * inner });
    }
    const fade = 1 - clamp((t1 - m.hit[1]) / 0.09, 0, 1);
    const ws = m.trail;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 1; i <= N; i++) {
      const a0 = S[i - 1];
      const a1 = S[i];
      const w0 = Math.min(1, (0.15 + 0.85 * Math.sin((Math.PI * (i - 1)) / N)) * ws);
      const w1 = Math.min(1, (0.15 + 0.85 * Math.sin((Math.PI * i) / N)) * ws);
      const al = Math.pow(i / N, 1.2) * (kat ? 0.5 : 0.42) * fade;
      ctx.fillStyle = kat ? `rgba(160,220,255,${al})` : `rgba(255,220,170,${al})`;
      ctx.beginPath();
      ctx.moveTo(a0.tx, a0.ty);
      ctx.lineTo(a1.tx, a1.ty);
      ctx.lineTo(a1.tx + (a1.ix - a1.tx) * w1, a1.ty + (a1.iy - a1.ty) * w1);
      ctx.lineTo(a0.tx + (a0.ix - a0.tx) * w0, a0.ty + (a0.iy - a0.ty) * w0);
      ctx.closePath();
      ctx.fill();
    }
    // cutting edge: a few continuous strokes (no per-segment caps -> no beading), tapering toward the old end
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    const edge = (from: number, w: number, style: string) => {
      const i0 = Math.max(0, Math.floor(from * N));
      ctx.strokeStyle = style;
      ctx.lineWidth = w;
      ctx.beginPath();
      ctx.moveTo(S[i0].tx, S[i0].ty);
      for (let i = i0 + 1; i <= N; i++) ctx.lineTo(S[i].tx, S[i].ty);
      ctx.stroke();
    };
    const glow = kat ? '110,200,255' : '255,170,90';
    edge(0.3, 5 * ws, `rgba(${glow},${0.22 * fade})`);
    edge(0.62, 11 * ws, `rgba(${glow},${0.3 * fade})`);
    edge(0.12, 1.4, `rgba(255,255,255,${0.55 * fade})`);
    edge(0.55, 3.2, `rgba(255,255,255,${0.9 * fade})`);
    ctx.restore();
  }

  private useBat() {
    const p = this.player;
    if (p.weapon !== 'bat') return;
    p.mag[0]--;
    if (p.mag[0] > 0) return;
    const g = p.grip;
    for (let i = 0; i < 2; i++) {
      this.particles.spawn({
        kind: 'plank',
        x: g.x + p.facing * (14 + i * 18),
        y: g.y,
        vx: p.facing * rand(120, 320),
        vy: rand(-420, -200),
        life: 3.5,
        w: 18,
        h: 6,
        rot: rand(0, TAU),
        vr: rand(-18, 18),
        color: '#d39a5c',
        g: 1700,
        drag: 0.3,
        bounce: 0.3,
        collide: true,
      });
    }
    this.particles.debris(g.x + p.facing * 20, g.y, 12, '#d39a5c', 0.9);
    this.sfx.batBreak();
    this.stamp('PEMUKUL PATAH!', p.x, p.y - 130, '#ffffff', 34, '#b8783a');
    p.dropCurrent();
  }

  private deflectBullet(b: Bullet) {
    const p = this.player;
    let target: Enemy | null = null;
    let bd = 1300;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const tx = e.wp.neck.x;
      const ty = e.wp.neck.y;
      const d = dist(b.x, b.y, tx, ty);
      if (d < bd && this.world.los(b.x, b.y, tx, ty)) {
        bd = d;
        target = e;
      }
    }
    const ang = target
      ? Math.atan2(target.wp.neck.y - b.y, target.wp.neck.x - b.x)
      : Math.atan2(-b.vy, -b.vx) + rand(-0.1, 0.1);
    b.owner = 'player';
    b.vx = Math.cos(ang) * 3600;
    b.vy = Math.sin(ang) * 3600;
    b.sx = b.x;
    b.sy = b.y;
    b.life = 0.6;
    b.dmg = 4;
    b.tags = ['TANGKIS PELURU'];
    b.dodged = false;
    b.redirected = true;
    this.sfx.ricochet();
    this.particles.sparks(b.x, b.y, Math.cos(ang), Math.sin(ang), 10, '#fff2a8');
    this.particles.spawn({ kind: 'impact', x: b.x, y: b.y, life: 0.08, size: 20, color: '#ffffff' });
    this.hitstop = Math.max(this.hitstop, 0.05);
    this.mark(0);
    if (this.deflectMsgT <= this.realTime) {
      this.deflectMsgT = this.realTime + 0.5;
      this.stamp('TANGKIS!', p.x + p.facing * 40, p.y - 120, '#ffffff', 34, '#2ecc71');
    }
  }

  private batHazard(h: Hazard, f: number) {
    this.sfx.batHit();
    this.hitstop = Math.max(this.hitstop, 0.06);
    this.shake(6);
    let target: Enemy | null = null;
    let bd = 1400;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const d = dist(h.x, h.y, e.x, e.y - e.h * 0.5);
      if (d < bd) {
        bd = d;
        target = e;
      }
    }
    if (h.kind === 'cleaver') {
      h.alive = false;
      this.sfx.clang();
      this.particles.sparks(h.x, h.y, f, -0.3, 14, '#fff2a8');
      this.particles.debris(h.x, h.y, 5, '#c9ced4', 0.9, true);
      this.styleBonus('TANGKIS', 150, h.x, h.y);
    } else if (h.kind === 'minion') {
      h.alive = false;
      this.particles.debris(h.x, h.y, 14, '#ffd93b', 1.2, true);
      this.sfx.bananaPop();
      this.styleBonus('MINI PEDRO', 200, h.x, h.y);
    } else if (h.kind === 'dynamite' || h.kind === 'bomb') {
      h.batted = true;
      const tx = target ? target.x : h.x + f * 600;
      const ty = target ? target.y - target.h * 0.55 : h.y - 120;
      if (h.kind === 'dynamite') {
        const T = clamp(dist(h.x, h.y, tx, ty) / 950, 0.3, 0.9);
        h.vx = (tx - h.x) / T;
        h.vy = (ty - h.y - 0.5 * 1500 * T * T) / T;
        h.t = Math.min(h.t, h.life - (T + 0.2));
        h.vr = f * 16;
      } else {
        const a = Math.atan2(ty - h.y, tx - h.x);
        h.vx = Math.cos(a) * 950;
        h.vy = Math.sin(a) * 950;
        h.life = h.t + 2;
      }
      this.stamp('HOME RUN!', h.x, h.y - 40, '#ffffff', 36, '#3a9bff');
    }
    this.mark(0);
  }

  private drawPlayerWeaponFx(ctx: CanvasRenderingContext2D) {
    const p = this.player;
    this.drawMeleeTrail(ctx);
    if ((p.weapon === 'sniper' || p.weapon === 'h_sniper') && p.swapT <= 0 && p.alive) {
      const m = p.muzzle(0, muzzleLen(p.weapon));
      const a = p.aimF;
      const c = Math.cos(a);
      const sn = Math.sin(a);
      let L = 2400;
      const hit = this.world.raycast(m.x, m.y, m.x + c * L, m.y + sn * L, true);
      if (hit) L *= hit.t;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        const h = this.enemyHitTest(e, m.x, m.y, m.x + c * L, m.y + sn * L);
        if (h) L *= h.t;
      }
      const ex = m.x + c * L;
      const ey = m.y + sn * L;
      const sc = p.scoping;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = `rgba(255,40,40,${sc ? 0.75 : 0.32})`;
      ctx.lineWidth = sc ? 1.8 : 1.1;
      ctx.beginPath();
      ctx.moveTo(m.x, m.y);
      ctx.lineTo(ex, ey);
      ctx.stroke();
      const dg = ctx.createRadialGradient(ex, ey, 0, ex, ey, 12);
      dg.addColorStop(0, 'rgba(255,90,90,0.95)');
      dg.addColorStop(1, 'rgba(255,0,0,0)');
      ctx.fillStyle = dg;
      ctx.beginPath();
      ctx.arc(ex, ey, 12, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
  }

  private drawSniperLaser(ctx: CanvasRenderingContext2D, e: Enemy) {
    const h = e.wp.haF;
    const a = e.aim;
    const c = Math.cos(a);
    const sn = Math.sin(a);
    const len = 1700;
    const hit = this.world.raycast(h.x, h.y, h.x + c * len, h.y + sn * len, true);
    let L = hit ? hit.t * len : len;
    const pl = this.player;
    const tp = segRect(h.x, h.y, h.x + c * L, h.y + sn * L, { x: pl.x - pl.w / 2, y: pl.y - pl.h, w: pl.w, h: pl.h });
    if (tp) L *= Math.max(0.02, tp.t);
    const k = clamp(e.snipe / 1.25, 0, 1);
    const blink = k > 0.72 && Math.floor(this.realTime * 18) % 2 === 0;
    const ex = h.x + c * L;
    const ey = h.y + sn * L;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    ctx.strokeStyle = `rgba(255,30,40,${(e.seen ? 0.22 : 0.1) + 0.55 * k})`;
    ctx.lineWidth = 1 + 2.4 * k;
    ctx.beginPath();
    ctx.moveTo(h.x, h.y);
    ctx.lineTo(ex, ey);
    ctx.stroke();
    if (blink) {
      ctx.strokeStyle = 'rgba(255,255,255,0.8)';
      ctx.lineWidth = 1.2;
      ctx.stroke();
    }
    const r = 6 + 8 * k;
    const dg = ctx.createRadialGradient(ex, ey, 0, ex, ey, r);
    dg.addColorStop(0, `rgba(255,${blink ? 255 : 90},${blink ? 255 : 90},0.95)`);
    dg.addColorStop(1, 'rgba(255,0,0,0)');
    ctx.fillStyle = dg;
    ctx.beginPath();
    ctx.arc(ex, ey, r, 0, TAU);
    ctx.fill();
    ctx.restore();
  }

  private drawScope(ctx: CanvasRenderingContext2D, W: number, H: number, s: number) {
    const mx = this.mouse.x;
    const my = this.mouse.y;
    const r = Math.min(W, H) * 0.34;
    ctx.save();
    ctx.fillStyle = 'rgba(4,6,8,0.62)';
    ctx.beginPath();
    ctx.rect(0, 0, W, H);
    ctx.arc(mx, my, r, 0, TAU, true);
    ctx.fill('evenodd');
    const vg = ctx.createRadialGradient(mx, my, r * 0.7, mx, my, r);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = vg;
    ctx.beginPath();
    ctx.arc(mx, my, r, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = '#0b0b0b';
    ctx.lineWidth = 10 * s;
    ctx.beginPath();
    ctx.arc(mx, my, r, 0, TAU);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(10,10,10,0.9)';
    ctx.lineWidth = 2 * s;
    const gap = 16 * s;
    ctx.beginPath();
    ctx.moveTo(mx - r, my);
    ctx.lineTo(mx - gap, my);
    ctx.moveTo(mx + gap, my);
    ctx.lineTo(mx + r, my);
    ctx.moveTo(mx, my - r);
    ctx.lineTo(mx, my - gap);
    ctx.moveTo(mx, my + gap);
    ctx.lineTo(mx, my + r);
    ctx.stroke();
    ctx.lineWidth = 4.5 * s;
    ctx.beginPath();
    ctx.moveTo(mx - r, my);
    ctx.lineTo(mx - r * 0.55, my);
    ctx.moveTo(mx + r * 0.55, my);
    ctx.lineTo(mx + r, my);
    ctx.moveTo(mx, my + r * 0.55);
    ctx.lineTo(mx, my + r);
    ctx.stroke();
    ctx.fillStyle = 'rgba(10,10,10,0.9)';
    for (let i = 1; i <= 4; i++) {
      const d = gap + i * ((r * 0.55 - gap) / 4.5);
      for (const [dx, dy] of [
        [d, 0],
        [-d, 0],
        [0, d],
      ]) {
        ctx.beginPath();
        ctx.arc(mx + dx, my + dy, 2 * s, 0, TAU);
        ctx.fill();
      }
    }
    ctx.fillStyle = '#ff3030';
    ctx.beginPath();
    ctx.arc(mx, my, 2.6 * s, 0, TAU);
    ctx.fill();
    ctx.font = `${16 * s}px Bangers, Impact, sans-serif`;
    ctx.fillStyle = 'rgba(160,255,160,0.9)';
    ctx.textAlign = 'left';
    ctx.fillText(`x4  ·  PELURU ${this.player.mag[0]}`, mx + r * 0.25, my + r * 0.45);
    ctx.restore();
  }

  // ------------------------------------------------------------ kung fu mode
  startFist() {
    this.mode = 'fist';
    this.loadLevel(DOJO);
    this.start();
  }

  private setupFist() {
    this.age = 20;
    this.fistDeaths = 0;
    this.fistMul = 1;
    this.wave = 0;
    this.waveT = 0;
    const p = this.player;
    p.inv = { fist: [1, 0] };
    p.switchTo('fist', false);
    p.maxHp = 100;
    p.hp = 100;
    p.noRegen = true;
    this.lastWeapon = 'fist';
    this.queueHint('MODE KUNGFU! Klik = combo 5 jurus · W+klik = uppercut · S+klik = sapuan · tahan-lepas = PUKULAN SATU INCI.');
    this.queueHint('Klik KANAN = tangkis. Tekan TEPAT saat pukulan datang = PARRY! Cahaya MERAH = tidak bisa ditangkis: berputar (SPACE) atau lompat!');
    this.queueHint('Penuhi bar oranye musuh lalu pukul = TAKEDOWN (+HP). Setiap mati kamu MENUA — umur 70 = tamat!');
  }

  private updateWaves(realDt: number) {
    if (this.bossDead || !this.player.alive || this.bossIntro > 0) return;
    if (this.enemies.some((e) => e.alive)) return;
    if (this.wave >= FIST_WAVES.length) return;
    this.waveT += realDt;
    if (this.waveT < (this.wave === 0 ? 0.8 : 1.8)) return;
    this.waveT = 0;
    const list = FIST_WAVES[this.wave];
    this.wave++;
    const A = this.arenaRect;
    const floor = A.y + A.h;
    list.forEach((code, i) => {
      const left = i % 2 === 0;
      const x = left ? A.x + 70 + i * 22 : A.x + A.w - 70 - i * 22;
      this.enemies.push(makeBrawler(code, x, floor, left ? 1 : -1, this.wave + i));
      this.particles.dust(x, floor, 10, left ? 1 : -1);
    });
    if (this.wave === FIST_WAVES.length) {
      this.bossIntroMax = 2.8;
      this.bossIntro = 2.8;
      this.sfx.bossIntro();
      this.sfx.duck(0.3, 2.4);
    } else {
      this.centerMsg = `GELOMBANG ${this.wave}`;
      this.centerT = 1.8;
      this.sfx.whistle();
    }
  }

  private finishFist() {
    if (this.screen !== 'playing') return;
    this.sfx.banana();
    this.focusing = false;
    this.setScreen('complete');
  }

  /** Sifu-style revival: older, weaker body, harder hits */
  private reviveFist() {
    const p = this.player;
    const A = this.arenaRect;
    if (this.playerRag) {
      const c = this.playerRag.center();
      p.x = clamp(c.x, A.x + 40, A.x + A.w - 40);
      p.y = A.y + A.h;
      this.ragdolls = this.ragdolls.filter((r) => r !== this.playerRag);
    }
    this.playerRag = null;
    p.maxHp = Math.max(50, 100 - (this.age - 20));
    p.reset(p.x, p.y);
    p.noRegen = true;
    this.fistMul = 1 + (this.age - 20) * 0.02;
    this.timeScale = 1;
    this.deathSlow = 0;
    this.stamp(`UMUR ${this.age}!`, p.x, p.y - 140, '#ffffff', 52, '#9d4edd');
    this.popup(`+${this.fistDeaths} TAHUN · DAMAGE +${Math.round((this.fistMul - 1) * 100)}%`, p.x, p.y - 190, '#e0c3ff');
    this.particles.spawn({ kind: 'ring', x: p.x, y: p.y - 50, life: 0.5, size: 260, color: '#e0c3ff' });
    this.sfx.slowOut();
    this.shake(8);
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const dx = e.x - p.x;
      if (Math.abs(dx) < 260) e.stunFor(0.8, sign(dx || 1) * 380, -220);
    }
  }

  /** a kung-fu enemy's strike reaches the player: parry / block / hit / miss */
  brawlerHit(e: Enemy, dmg: number, dir: number, kind: 'hit' | 'unblock' | 'low'): 'parry' | 'block' | 'hit' | 'miss' {
    const p = this.player;
    if (!p.alive || this.bossIntro > 0) return 'miss';
    if (p.dodging || p.invuln > 0) {
      if (this.dodgeMsgT <= 0) {
        this.dodgeMsgT = 0.6;
        this.popup('MELESET!', p.x, p.y - 120, '#9fe8ff');
      }
      return 'miss';
    }
    if (kind === 'low' && !p.onGround) {
      this.popup('LOMPATI!', p.x, p.y - 120, '#9fe8ff');
      return 'miss';
    }
    const facingEnemy = sign(e.x - p.x) === p.facing;
    if (p.guard && facingEnemy && kind !== 'unblock') {
      const hx = p.x + p.facing * 18;
      const hy = p.y - 70;
      if (this.realTime - this.guardStart < 0.22) {
        this.sfx.parry();
        this.stamp('PARRY!', hx, hy - 40, '#ffffff', 40, '#3a9bff');
        this.particles.spawn({ kind: 'impact', x: hx, y: hy, life: 0.12, size: 40, color: '#ffffff' });
        this.particles.sparks(hx, hy, -p.facing, -0.3, 18, '#dff6ff');
        this.hitstop = Math.max(this.hitstop, 0.1);
        this.autoSlow = Math.max(this.autoSlow, 0.45);
        this.shake(8);
        this.styleBonus('PARRY', 150, hx, hy);
        this.mark(2);
        p.guardStruct = Math.max(0, p.guardStruct - 30);
        return 'parry';
      }
      p.guardStruct += 24 + dmg;
      this.sfx.block();
      this.particles.sparks(hx, hy, -p.facing, -0.2, 8, '#ffe9a0');
      p.vx = -p.facing * 160;
      this.shake(3);
      if (dmg * 0.12 >= 1) this.damagePlayer(Math.round(dmg * 0.12), dir);
      if (p.guardStruct >= 100) {
        p.guardStruct = 0;
        p.dazed = 0.9;
        p.guard = false;
        this.stamp('KUDA-KUDA PECAH!', p.x, p.y - 130, '#ffffff', 32, '#c81d2a');
        this.sfx.hurt();
      }
      return 'block';
    }
    if (kind === 'unblock' && p.guard && facingEnemy) this.popup('TIDAK BISA DITANGKIS!', p.x, p.y - 140, '#ff6b6b');
    const hit = this.hurtPlayer(dmg, dir, kind === 'unblock' ? 380 : 200);
    if (hit) {
      this.sfx.punch(kind === 'unblock');
      this.particles.spawn({ kind: 'impact', x: p.x - dir * 6, y: p.y - 60, life: 0.08, size: 26, color: '#ffffff' });
    }
    return hit ? 'hit' : 'miss';
  }

  private fistHit(e: Enemy, m: MeleeMove) {
    const p = this.player;
    const dir = sign(e.x - p.x) || p.facing;
    const hy = e.y - e.h * 0.62;
    const boss = e.type === 'boss' || e.isBossMode;
    const tags = [...this.styleSnapshot(false).filter((t) => t !== 'FOKUS'), m.tag];
    const bw = e instanceof Brawler ? e : null;
    if (bw && bw.tryBlock(!!m.heavy)) {
      bw.addStruct((m.struct ?? 1) * 0.5);
      this.sfx.block();
      this.particles.sparks(e.x - dir * 10, hy, -dir, -0.3, 8, '#bfe6ff');
      this.popup('DITANGKIS', e.x, e.y - e.h - 26, '#9fe8ff');
      e.vx = dir * 120;
      this.hitstop = Math.max(this.hitstop, 0.03);
      return;
    }
    this.meleeHits++;
    this.meleeHitT = 1.5;
    const broken = bw ? bw.act === 'broken' : e.structMax > 0 && e.struct >= e.structMax && e.state === 'stunned';
    if (broken) {
      this.takedown(e, dir, tags);
      return;
    }
    this.sfx.punch(!!m.heavy);
    this.particles.spawn({ kind: 'impact', x: e.x - dir * 8, y: hy, life: 0.08, size: m.heavy ? 40 : 24, color: '#ffffff' });
    this.particles.sparks(e.x - dir * 6, hy, dir, -0.2, m.heavy ? 12 : 5, '#fff2c0');
    if (m.heavy) this.particles.spawn({ kind: 'ring', x: e.x, y: hy, life: 0.3, size: 80, color: '#ffffff' });
    this.shake(m.shake);
    this.camKick(dir * (m.heavy ? 10 : 3), -1);
    this.hitstop = Math.max(this.hitstop, m.stop);
    const mul = this.mode === 'fist' ? this.fistMul : 1;
    const dmg = (boss ? m.boss : m.dmg) * mul;
    if (e.hurt(dmg, dir, false, this.time, this.sfx)) {
      this.killEnemy(e, dir * m.dir[0], m.dir[1], false, m.power, tags, e.x, hy);
      this.mark(1);
      if (m.heavy) this.stamp(m.tag + '!', e.x + dir * 30, e.y - e.h - 40, '#ffffff', 40, '#ff7b3a');
      return;
    }
    this.mark(0);
    const st = (m.struct ?? 1) * mul;
    let brk: boolean;
    if (bw) brk = bw.addStruct(st);
    else {
      e.struct += st;
      brk = e.struct >= e.structMax;
    }
    if (brk) {
      this.stamp('RUSAK!', e.x, e.y - e.h - 40, '#ffffff', 38, '#ffb347');
      this.flashT = Math.max(this.flashT, 0.04);
      this.autoSlow = Math.max(this.autoSlow, 0.3);
      this.sfx.chargeFull();
      if (!bw) e.stunFor(2.2, dir * 60, -100);
      return;
    }
    if (m.launch) e.stunFor(1.1, dir * 40, -m.launch);
    else if (m.knock) {
      e.stunFor(0.7, dir * m.knock, -200);
      e.flung = 0.7;
    } else if (m.id === 'fSweep') e.stunFor(1.1, dir * 60, -300);
    else e.stunFor(0.28, dir * 90, e.onGround ? -30 : -240);
    if (m.heavy) this.stamp(m.tag + '!', e.x + dir * 30, e.y - e.h - 40, '#ffffff', 36, '#ff7b3a');
  }

  private takedown(e: Enemy, dir: number, tags: string[]) {
    const p = this.player;
    const hy = e.y - e.h * 0.6;
    this.sfx.punch(true);
    this.sfx.zan();
    this.impactT = 0.1;
    this.impactX = e.x;
    this.impactY = hy;
    this.hitstop = Math.max(this.hitstop, 0.14);
    this.autoSlow = Math.max(this.autoSlow, 0.7);
    this.shake(16);
    this.camPunch = Math.max(this.camPunch, 0.12);
    this.stamp('TAKEDOWN!', e.x, e.y - e.h - 50, '#ffffff', 50, '#c81d2a');
    if (e.type === 'boss' || e.isBossMode) {
      if (e.hurt(8 * this.fistMul, dir, false, this.time, this.sfx)) {
        this.killEnemy(e, dir, -0.8, false, 1500, [...tags, 'TAKEDOWN'], e.x, hy);
      } else {
        e.struct = 0;
        if (e instanceof Brawler) e.act = 'hurt';
        e.stunFor(1.2, dir * 420, -320);
      }
    } else {
      e.hp = 0;
      this.killEnemy(e, dir, -0.8, false, 1600, [...tags, 'TAKEDOWN'], e.x, hy);
    }
    p.hp = Math.min(p.maxHp, p.hp + 12);
    this.popup('+12 HP', p.x, p.y - 120, '#7dffa0');
    this.mark(2);
  }

  private enemyWallSlam(e: Enemy) {
    const x = e.x + e.wallDir * e.w * 0.5;
    const y = e.y - e.h * 0.5;
    this.particles.debris(x, y, 10, '#77736c', 0.8);
    this.particles.dust(x, y, 8, -e.wallDir);
    this.particles.spawn({ kind: 'ring', x, y, life: 0.3, size: 70, color: '#ffffff' });
    this.sfx.thud();
    this.sfx.punch(true);
    this.shake(10);
    this.hitstop = Math.max(this.hitstop, 0.06);
    this.stamp('MENTOK!', x - e.wallDir * 30, y - 50, '#ffffff', 38, '#ff7b3a');
    if (e.hurt(1.5 * this.fistMul, -e.wallDir, false, this.time, this.sfx)) {
      this.killEnemy(e, -e.wallDir, -0.4, false, 600, ['MENTOK'], e.x, y);
      return;
    }
    if (e instanceof Brawler) e.addStruct(3);
    else e.struct += 3;
  }

  // ------------------------------------------------------------ boss mode
  get arenaRect() {
    return this.level.arena ?? this.level.bounds;
  }

  startStory() {
    this.mode = 'story';
    this.loadLevel(LEVEL1);
    this.start();
  }

  startBoss(id: BossId) {
    this.mode = 'boss';
    this.bossId = id;
    this.loadLevel(ARENAS[id]);
    this.start();
  }

  private loadLevel(def: LevelDef) {
    this.level = def;
    this.world = new World(def);
    this.hazards.clear();
  }

  hurtPlayer(dmg: number, dirx: number, knock: number): boolean {
    const p = this.player;
    if (!p.alive || p.invuln > 0 || p.dodging || this.bossIntro > 0) return false;
    this.damagePlayer(dmg, dirx);
    if (knock > 0 && p.alive) {
      p.vx = dirx * knock;
      p.vy = Math.min(p.vy, -knock * 0.5);
      p.onGround = false;
      p.slide = 0;
    }
    return true;
  }

  enemyShoot(x: number, y: number, angle: number, speed: number, dmg: number) {
    this.bullets.push({
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      sx: x,
      sy: y,
      owner: 'enemy',
      dmg,
      life: 2.2,
      kind: 'pistol',
      tags: [],
      ricochets: 0,
      alive: true,
      dodged: false,
      redirected: false,
      wake: 0,
    });
  }

  spawnGoon(x: number, dir: number) {
    const floor = this.arenaRect.y + this.arenaRect.h;
    const type = Math.random() < 0.34 ? 'gunner' : 'thug';
    const e = new Enemy({ x, y: floor, type, facing: dir >= 0 ? 1 : -1, section: 1, variant: Math.floor(Math.random() * 6) });
    e.alert(this.time, this.sfx);
    e.reaction = 0.9;
    this.enemies.push(e);
    this.particles.dust(x, floor, 10, dir);
    this.particles.spawn({ kind: 'ring', x, y: floor - 50, life: 0.35, size: 70, color: '#ffffff' });
  }

  goonCount() {
    let n = 0;
    for (const e of this.enemies) if (e.alive && e.type !== 'boss') n++;
    return n;
  }

  say(e: Enemy, text: string, dur: number) {
    this.bubbles = this.bubbles.filter((b) => b.e !== e);
    this.bubbles.push({ e, text, t: dur, max: dur });
  }

  finishBoss(e: Enemy) {
    if (!e.alive) return;
    this.killEnemy(e, 0, -1, false, 600, [], e.x, e.y - e.h / 2);
  }

  setDreamPhase(n: number) {
    this.dreamPhase = n;
  }

  private bossRank() {
    const info = BOSS_INFO[this.bossId];
    const tk = this.playTime / info.par;
    const dmg = this.damageTaken;
    let pts = tk < 0.75 ? 2 : tk < 1 ? 1.5 : tk < 1.4 ? 1 : tk < 2 ? 0.5 : 0;
    pts += dmg < 30 ? 2 : dmg < 80 ? 1.5 : dmg < 150 ? 1 : dmg < 250 ? 0.5 : 0;
    if (this.deaths === 0) pts += 0.5;
    return pts >= 4 ? 'S' : pts >= 3 ? 'A' : pts >= 2 ? 'B' : pts >= 1 ? 'C' : 'D';
  }

  private finishBossFight() {
    if (this.screen !== 'playing') return;
    const st = this.stats();
    saveBossRecord(this.bossId, st.time, st.rank, st.score);
    this.sfx.banana();
    this.focusing = false;
    this.setScreen('complete');
  }

  private styleBonus(text: string, pts: number, x: number, y: number) {
    this.score += pts;
    this.tags.unshift({ text, pts, t: 1.6, big: false });
    if (this.tags.length > 6) this.tags.length = 6;
    this.popups.push({ x, y: y - 20, text: `+${pts}`, t: 0.9, color: '#ffe9a8', size: 20 });
  }

  private shootHazard(h: Hazard, hx: number, hy: number, ux: number, uy: number, tags: string[]) {
    switch (h.kind) {
      case 'cleaver':
        h.alive = false;
        this.particles.sparks(hx, hy, -ux, -uy, 14, '#fff2a8');
        this.particles.debris(hx, hy, 5, '#c9ced4', 0.9, true);
        this.sfx.clang();
        this.mark(1);
        this.stamp('TANGKIS!', hx, hy - 30, '#ffffff', 30, '#3a9bff');
        this.styleBonus('TANGKIS', 150, hx, hy);
        break;
      case 'dynamite':
        h.alive = false;
        this.mark(1);
        this.explodeAt(h.x, h.y, [...tags.filter((t) => t !== 'FOKUS'), 'LEDAKAN'], 140, 1);
        this.styleBonus('DINAMIT MELEDAK', 100, hx, hy);
        break;
      case 'bomb':
        h.alive = false;
        this.mark(0);
        this.explodeAt(h.x, h.y, [], 70, 0.4);
        this.styleBonus('TANGKIS', 50, hx, hy);
        break;
      case 'minion':
        h.hp--;
        h.flash = 0.1;
        this.particles.sparks(hx, hy, -ux, -uy, 5, '#ffe066');
        if (h.hp <= 0) {
          h.alive = false;
          this.particles.debris(h.x, h.y, 14, '#ffd93b', 1.1, true);
          this.particles.spawn({ kind: 'ring', x: h.x, y: h.y, life: 0.3, size: 50, color: '#fff3a0' });
          this.sfx.bananaPop();
          this.mark(2);
          this.styleBonus('MINI PEDRO', 200, h.x, h.y);
        } else this.mark(0);
        break;
      default:
        break;
    }
  }

  private drawBubbles(ctx: CanvasRenderingContext2D) {
    for (const b of this.bubbles) {
      const e = b.e;
      if (!e.alive) continue;
      const a = clamp(b.t * 4, 0, 1) * clamp((b.max - b.t) * 8, 0, 1);
      if (a <= 0.01) continue;
      const big = e.w > 80;
      const x = e.wp.head.x;
      const y = e.wp.head.y - (big ? 40 : 34);
      ctx.save();
      ctx.globalAlpha = a;
      ctx.font = `${big ? 26 : 20}px Bangers, Impact, sans-serif`;
      const tw = ctx.measureText(b.text).width;
      const pw = tw + 24;
      const ph = big ? 40 : 32;
      const bx = x - pw / 2;
      const by = y - ph - 14;
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = '#120d0a';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(bx, by, pw, ph, 12);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x - 8, by + ph - 1.5);
      ctx.lineTo(x + 2, by + ph + 14);
      ctx.lineTo(x + 10, by + ph - 1.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillRect(x - 7, by + ph - 4, 16, 4);
      ctx.fillStyle = '#120d0a';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(b.text, x, by + ph / 2 + 1);
      ctx.restore();
    }
  }

  // ------------------------------------------------------------ damage
  private damagePlayer(dmg: number, dirx: number) {
    const p = this.player;
    if (!p.alive || p.invuln > 0 || this.bossIntro > 0) return;
    p.hp -= dmg;
    this.damageTaken += dmg;
    p.regenDelay = 2.6;
    p.hurtT = 0.3;
    this.hurtFlash = 1;
    this.sfx.hurt();
    this.shake(6);
    this.particles.blood(p.x, p.y - 58, dirx, -0.2, 8, 0.8);
    if (p.hp <= 0) this.killPlayer(dirx, false);
  }

  private killPlayer(dirx: number, fell: boolean) {
    const p = this.player;
    if (!p.alive) return;
    p.alive = false;
    p.hp = 0;
    this.deaths++;
    if (this.mode === 'fist') {
      this.fistDeaths++;
      this.age += this.fistDeaths;
    }
    this.focusing = false;
    this.split.active = false;
    const rag = new Ragdoll(p.wp, PLAYER_LOOK, PLAYER_DIMS, p.vx * 0.5, p.vy * 0.5, STEP, true, 0);
    rag.impulseAll(dirx * 380, -220);
    this.ragdolls.push(rag);
    this.playerRag = rag;
    this.particles.dropGun(p.wp.haF.x, p.wp.haF.y, dirx * 150 + rand(-80, 80), -300, p.weapon);
    this.particles.dropGun(p.wp.haB.x, p.wp.haB.y, dirx * 120 + rand(-80, 80), -260, p.weapon);
    this.sfx.death();
    this.deathSlow = fell ? 0.6 : 1.5;
  }

  private killEnemy(
    e: Enemy,
    dirx: number,
    diry: number,
    head: boolean,
    power: number,
    extraTags: string[],
    hx: number,
    hy: number,
  ) {
    if (!e.alive) return;
    const sever = this.severNext && !e.customDeath;
    this.severNext = false;
    e.alive = false;
    const len = Math.hypot(dirx, diry) || 1;
    const ux = dirx / len;
    const uy = diry / len;
    if (e.customDeath) e.onCustomDeath(this);
    const hatOff = head && e.look.hat && !e.customDeath;
    if (!e.customDeath) {
    const rag = new Ragdoll(e.wp, hatOff ? { ...e.look, hat: false } : e.look, e.dims, e.vx, e.vy, STEP, false, e.section);
    if (head) {
      rag.impulse(RP.head, ux * power * 1.7, uy * power * 1.7 - 80);
      rag.bleed = 1.3;
    } else {
      rag.impulse(RP.neck, ux * power, uy * power);
      rag.impulse(RP.pelvis, ux * power * 0.7, uy * power * 0.7);
    }
    rag.impulseAll(ux * power * 0.35, uy * power * 0.35 - 90);
    this.ragdolls.push(rag);
    if (sever) {
      // cut clean through the waist: two ragdoll halves
      const lower = new Ragdoll(e.wp, e.look, e.dims, e.vx, e.vy, STEP, false, e.section);
      rag.makeHalf(1);
      lower.makeHalf(2);
      rag.impulseAll(ux * power * 0.22, uy * power * 0.2 - 240);
      lower.impulseAll(ux * 110, 30);
      this.ragdolls.push(lower);
      const cx = (e.wp.neck.x + e.wp.pelvis.x) / 2;
      const cy = (e.wp.neck.y + e.wp.pelvis.y) / 2;
      this.particles.spawn({ kind: 'slash', x: cx, y: cy, rot: rand(-0.25, 0.25), size: 150, w: 9, life: 0.28, color: 'rgba(255,80,90,0.9)' });
      this.particles.blood(cx, cy, 0, -1, 26, 1.3);
      this.particles.blood(cx, cy, ux, uy, 14, 1.1);
      this.hitstop = Math.max(this.hitstop, 0.09);
      this.autoSlow = Math.max(this.autoSlow, 0.45);
    }
    if (this.ragdolls.length > 40) {
      const idx = this.ragdolls.findIndex((r) => !r.isPlayer);
      if (idx >= 0) this.ragdolls.splice(idx, 1);
    }
    if (e.gun === 'uzi' || e.gun === 'shotgun' || e.gun === 'ak47' || e.gun === 'sniper') {
      this.spawnGunDrop(e.gun, e.wp.haF.x, e.wp.haF.y, ux * 200 + rand(-80, 80), -300, e.section);
    } else if (e.gun) this.particles.dropGun(e.wp.haF.x, e.wp.haF.y, ux * 200 + rand(-80, 80), -260, e.gun);
    }
    if (hatOff) {
      this.particles.spawn({
        kind: 'hat',
        x: e.wp.head.x,
        y: e.wp.head.y - e.dims.headR,
        vx: ux * 240 + rand(-60, 60),
        vy: rand(-640, -480),
        life: 9,
        size: e.dims.headR,
        vr: rand(9, 16) * (ux >= 0 ? 1 : -1),
        color: e.look.hatColor,
        band: e.look.hatBand,
        g: 1500,
        drag: 0.4,
        bounce: 0.3,
        collide: true,
      });
    }
    if (head) this.stamp('HEADSHOT!', e.wp.head.x, e.wp.head.y - 34, '#ffffff', 26, '#c81d2a');
    this.particles.spawn({ kind: 'ring', x: e.x, y: e.y - e.h * 0.6, life: 0.3, size: 46, color: '#ffffff' });
    if (!e.customDeath) {
      this.particles.blood(hx, hy, ux, uy, head ? 34 : 20, 1.25);
      this.particles.blood(hx, hy, -ux, -0.4, 6, 0.6);
    }
    this.sfx.hit(head);
    this.hitstop = Math.max(this.hitstop, 0.035);
    this.player.focus = Math.min(100, this.player.focus + 12);
    this.registerKill(e, head, extraTags);
    const left = this.enemies.some((q) => q.alive && q.section === e.section);
    if (!left && e.type !== 'boss') {
      // last enemy of the area: kill-cam
      this.killCam = { t: 1.0, x: e.x, y: e.y - 60 };
      this.sfx.duck(0.45, 1.1);
      this.centerMsg = 'AREA BERSIH!';
      this.centerT = 1.6;
    }
    if (e.type === 'boss') {
      this.bossDead = true;
      this.killCam = { t: 2.0, x: e.x, y: e.y - (e.customDeath ? e.h * 0.5 : 60) };
      this.sfx.duck(0.3, 2.2);
      this.autoSlow = 2;
      this.centerMsg = `${e.bossName || 'DON KUMIS'} TUMBANG!`;
      this.centerT = 3;
      if (this.mode === 'story') this.queueHint(this.level.bossHint, true);
      else {
        this.hazards.clear();
        this.sfx.laserHum(false);
        for (const bl of this.bullets) if (bl.owner === 'enemy') bl.alive = false;
        this.player.invuln = 99;
        this.victoryT = 0;
      }
      this.shake(10);
    }
  }

  private registerKill(e: Enemy, head: boolean, tags: string[]) {
    let pts = e.type === 'boss' ? 1000 : 100;
    const parts: string[] = [];
    if (head) {
      pts += 50;
      parts.push('HEADSHOT');
      this.headshots++;
    }
    for (const t of tags) {
      if (parts.includes(t)) continue;
      pts += STYLE_PTS[t] ?? 0;
      parts.push(t);
    }
    if (this.time - this.lastKillTime < 0.4) {
      pts += 100;
      parts.push('MULTI');
    }
    this.lastKillTime = this.time;
    if (parts.some((t) => STUNT_TAGS.has(t)) && this.realTime - this.lastStuntSlow > 1.2) {
      this.lastStuntSlow = this.realTime;
      this.autoSlow = Math.max(this.autoSlow, 0.5);
    }
    this.combo++;
    this.comboT = 1;
    this.maxCombo = Math.max(this.maxCombo, this.combo);
    const mult = Math.min(this.combo, 10);
    const total = pts * mult;
    this.score += total;
    this.tags.unshift({ text: parts.length ? parts.join(' · ') : 'KILL', pts: total, t: 1.8, big: parts.length >= 2 });
    if (this.tags.length > 6) this.tags.length = 6;
    this.popups.push({ x: e.x, y: e.y - e.h - 105, text: `+${total}`, t: 1.3, color: parts.length >= 2 ? '#ffd23f' : '#fff', size: parts.length >= 2 ? 30 : 24 });
    this.sfx.combo(this.combo);
  }

  // ------------------------------------------------------------ bullets
  private enemyHitTest(e: Enemy, x1: number, y1: number, x2: number, y2: number): { t: number; head: boolean } | null {
    const custom = e.hitTestCustom(x1, y1, x2, y2);
    if (custom !== undefined) return custom;
    const minx = Math.min(x1, x2);
    const maxx = Math.max(x1, x2);
    const miny = Math.min(y1, y2);
    const maxy = Math.max(y1, y2);
    if (maxx < e.x - 50 || minx > e.x + 50 || maxy < e.y - e.h - 30 || miny > e.y + 6) return null;
    const wp = e.wp;
    let best: { t: number; head: boolean } | null = null;
    const th = segCircle(x1, y1, x2, y2, wp.head.x, wp.head.y, e.dims.headR + 3);
    if (th !== null) best = { t: th, head: true };
    const r = e.dims.torsoTop / 2 + 3;
    for (let k = 0; k <= 2; k++) {
      const cx = wp.pelvis.x + (wp.neck.x - wp.pelvis.x) * (k / 2);
      const cy = wp.pelvis.y + (wp.neck.y - wp.pelvis.y) * (k / 2);
      const t = segCircle(x1, y1, x2, y2, cx, cy, r);
      if (t !== null && (!best || t < best.t)) best = { t, head: false };
    }
    const legPts = [
      wp.knF,
      wp.knB,
      { x: (wp.knF.x + wp.ftF.x) / 2, y: (wp.knF.y + wp.ftF.y) / 2 },
      { x: (wp.knB.x + wp.ftB.x) / 2, y: (wp.knB.y + wp.ftB.y) / 2 },
    ];
    for (const lp of legPts) {
      const t = segCircle(x1, y1, x2, y2, lp.x, lp.y, 7);
      if (t !== null && (!best || t < best.t)) best = { t, head: false };
    }
    return best;
  }

  private updateBullets(dt: number) {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.life -= dt;
      if (!b.alive || b.life <= 0) {
        if (b.alive && b.halo) {
          // proyektil HALO habis jarak: roket tetap meledak, yang lain padam dengan efeknya
          const s = b.halo;
          const sp0 = Math.hypot(b.vx, b.vy) || 1;
          haloImpactFx(this.haloFx, s, b.x, b.y, -b.vx / sp0, -b.vy / sp0);
          if (s.explode > 0) {
            haloExplodeFx(this.haloFx, s, b.x, b.y, s.explode);
            this.explodeAt(b.x, b.y, [...b.tags.filter((t) => t !== 'FOKUS'), s.name], s.explode, 0.25, null, false, 1.7);
          }
        }
        this.bullets.splice(i, 1);
        continue;
      }
      if (b.kind === 'sling') b.vy += SLING.g * dt;
      if (b.halo) {
        const s = b.halo;
        b.age = (b.age ?? 0) + dt;
        if (s.gravity) b.vy += s.gravity * dt;
        const sp = Math.hypot(b.vx, b.vy) || 1;
        b.trailAcc = (b.trailAcc ?? 0) + sp * dt;
        let guard = 0;
        while (b.trailAcc > 11 && guard++ < 5) {
          b.trailAcc -= 11;
          const k = Math.random() * dt;
          haloTrailFx(this.haloFx, s, b.x + b.vx * k, b.y + b.vy * k, b.vx / sp, b.vy / sp);
        }
        if (b.trailAcc > 11) b.trailAcc = 0;
        if (s.pull) {
          // lubang hitam menyeret musuh yang dilewatinya
          for (const o of this.enemies) {
            if (!o.alive || o.type === 'boss' || o.isBossMode) continue;
            const d = dist(b.x, b.y, o.x, o.y - 50);
            if (d < 170) o.vx += (sign(b.x - o.x) || 1) * 1500 * dt * (1 - d / 170);
          }
        }
      }
      if (b.kind === 'cricket' && Math.random() < 0.8) {
        this.particles.sparks(b.x, b.y, -b.vx, -b.vy, 2, Math.random() < 0.5 ? '#e6fbff' : '#7fdcff');
      }
      const nx = b.x + b.vx * dt;
      const ny = b.y + b.vy * dt;
      if (this.timeScale < 0.6) {
        b.wake += Math.hypot(b.vx, b.vy) * dt;
        if (b.wake > 46) {
          b.wake = 0;
          this.particles.spawn({
            kind: 'wake',
            x: b.x,
            y: b.y,
            life: 0.4,
            size: b.owner === 'player' ? 9 : 11,
            rot: Math.atan2(b.vy, b.vx),
            color: b.owner === 'player' ? '#ffffff' : '#ffb08a',
          });
        }
      }
      b.redirected = false;
      const ox = b.x;
      const oy = b.y;
      this.traceBullet(b, b.x, b.y, nx, ny, 0);
      if (b.kind === 'sniper') {
        const ex = !b.alive ? (b.dx ?? nx) : b.redirected ? b.x : nx;
        const ey = !b.alive ? (b.dy ?? ny) : b.redirected ? b.y : ny;
        this.particles.spawn({ kind: 'beam', x: ox, y: oy, w: ex, h: ey, life: b.owner === 'player' ? 0.6 : 0.35 });
      }
      if (!b.alive) {
        this.bullets.splice(i, 1);
        continue;
      }
      if (!b.redirected) {
        b.x = nx;
        b.y = ny;
      }
    }
  }

  private traceBullet(b: Bullet, x1: number, y1: number, x2: number, y2: number, depth: number) {
    if (depth > 8) return;
    type Hit =
      | { type: 'wall'; t: number; nx: number; ny: number; kind: string }
      | { type: 'glass'; t: number; prop: Prop }
      | { type: 'door'; t: number; prop: Prop | null }
      | { type: 'lamp'; t: number; prop: Prop }
      | { type: 'hazard'; t: number; hz: Hazard }
      | { type: 'enemy'; t: number; e: Enemy; head: boolean }
      | { type: 'pan'; t: number; prop: Prop }
      | { type: 'barrel'; t: number; prop: Prop }
      | { type: 'player'; t: number };
    let best: Hit | null = null;
    // GHOST GUN: pelurunya gaib, menembus tembok & pintu
    const wall = b.halo && b.halo.phase ? null : this.world.raycast(x1, y1, x2, y2, true, false);
    if (wall) {
      if (wall.dyn) {
        const prop = this.props.find((q) => q.id === (wall.solid as DynSolid).ref);
        if (prop && isGlass(prop)) best = { type: 'glass', t: wall.t, prop };
        else best = { type: 'door', t: wall.t, prop: prop ?? null };
      } else best = { type: 'wall', t: wall.t, nx: wall.nx, ny: wall.ny, kind: wall.solid.kind };
    }
    for (const p of this.props) {
      if (!p.alive) continue;
      if (p.type === 'pan' && b.owner === 'player') {
        const t = segCircle(x1, y1, x2, y2, p.x, p.y, 14);
        if (t !== null && (!best || t < best.t)) best = { type: 'pan', t, prop: p };
      } else if (p.type === 'barrel') {
        const h = segRect(x1, y1, x2, y2, { x: p.x - p.w / 2, y: p.y - p.h, w: p.w, h: p.h });
        if (h && (!best || h.t < best.t)) best = { type: 'barrel', t: h.t, prop: p };
      } else if ((p.type === 'lamp' || p.type === 'chandelier') && b.owner === 'player' && (p.state === 'idle' || p.state === 'broken')) {
        const ch = p.type === 'chandelier';
        const t = segCircle(x1, y1, x2, y2, p.x, p.y + (ch ? 16 : 0), ch ? 32 : 13);
        if (t !== null && (!best || t < best.t)) best = { type: 'lamp', t, prop: p };
      } else if (p.type === 'streetlamp' && b.owner === 'player' && p.state === 'idle') {
        const t = segCircle(x1, y1, x2, y2, p.ax + 44, p.ay - p.h - 13, 13);
        if (t !== null && (!best || t < best.t)) best = { type: 'lamp', t, prop: p };
      }
    }
    if (b.owner === 'player') {
      for (const e of this.enemies) {
        if (!e.alive) continue;
        if (b.hitIds && b.hitIds.includes(e.id)) continue;
        const h = this.enemyHitTest(e, x1, y1, x2, y2);
        if (!h) continue;
        if (e.invuln > 0) {
          if (!b.dodged) {
            b.dodged = true;
            if (this.dodgeMsgT <= 0) {
              this.dodgeMsgT = 0.6;
              this.popups.push({ x: e.x, y: e.y - e.h - 30, text: 'MELESET!', t: 0.7, color: '#9fe8ff', size: 20 });
            }
          }
          continue;
        }
        if (!best || h.t < best.t) best = { type: 'enemy', t: h.t, e, head: h.head };
      }
      const hz = this.hazards.hitTest(x1, y1, x2, y2);
      if (hz && (!best || hz.t < best.t)) best = { type: 'hazard', t: hz.t, hz: hz.h };
      // ragdolls (pass-through)
      const limit = best ? best.t : 1;
      for (const r of this.ragdolls) {
        if (r.isPlayer) continue;
        const c = r.center();
        if (Math.abs(c.x - x1) > 140 || Math.abs(c.y - y1) > 140) continue;
        const h = r.hitTest(x1, y1, x2, y2);
        if (h && h.t < limit) {
          const len = Math.hypot(b.vx, b.vy) || 1;
          const ip = b.kind === 'shotgun' ? 700 : 420;
          r.impulse(h.i, (b.vx / len) * ip, (b.vy / len) * ip - 60);
          const px = x1 + (x2 - x1) * h.t;
          const py = y1 + (y2 - y1) * h.t;
          this.particles.blood(px, py, b.vx, b.vy, 5, 0.8);
        }
      }
    } else {
      const p = this.player;
      if (p.alive) {
        const h = segRect(x1, y1, x2, y2, { x: p.x - p.w / 2 + 3, y: p.y - p.h + 4, w: p.w - 6, h: p.h - 4 });
        if (h && (!best || h.t < best.t)) {
          if (p.dodging || p.invuln > 0) {
            if (!b.dodged) {
              b.dodged = true;
              this.sfx.dodge();
              if (this.dodgeMsgT <= 0) {
                this.dodgeMsgT = 0.8;
                this.popups.push({ x: p.x, y: p.y - 110, text: 'MELESET!', t: 0.7, color: '#9fe8ff', size: 20 });
              }
            }
          } else best = { type: 'player', t: h.t };
        }
      }
    }
    if (!best) return;
    const hx = x1 + (x2 - x1) * best.t;
    const hy = y1 + (y2 - y1) * best.t;
    const len = Math.hypot(b.vx, b.vy) || 1;
    const ux = b.vx / len;
    const uy = b.vy / len;
    if (b.halo && b.owner === 'player') {
      b.hx = hx;
      b.hy = hy;
      const hitE = best.type === 'enemy' ? best.e : null;
      const hitProp = best.type === 'door' || best.type === 'barrel' ? best.prop : null;
      const wnx = best.type === 'wall' ? best.nx : -ux;
      const wny = best.type === 'wall' ? best.ny : -uy;
      if (this.haloHit(b, best.type, hx, hy, ux, uy, hitE, wnx, wny, hitProp)) return;
    }
    if (b.kind === 'cricket' && b.owner === 'player' && best.type !== 'glass' && best.type !== 'player') {
      b.alive = false;
      b.dx = hx;
      b.dy = hy;
      if (best.type === 'door' && best.prop && best.prop.type === 'door' && best.prop.state === 'idle') {
        this.breachDoor(best.prop, sign(ux) || 1, true, hy);
      } else if (best.type === 'barrel') this.explode(best.prop, b.tags);
      this.explodeAt(hx - ux * 6, hy - uy * 6, [...b.tags.filter((t) => t !== 'FOKUS'), 'NOISY CRICKET'], 195, 0.25, null, true, 1.7);
      return;
    }
    if (b.kind === 'sling' && b.owner === 'player') {
      if (best.type === 'wall' && b.ricochets < 1) {
        // stones skip off walls once
        const vn = b.vx * best.nx + b.vy * best.ny;
        b.vx = (b.vx - 2 * vn * best.nx) * 0.45;
        b.vy = (b.vy - 2 * vn * best.ny) * 0.45;
        b.x = hx + best.nx * 1.5;
        b.y = hy + best.ny * 1.5;
        b.sx = b.x;
        b.sy = b.y;
        b.ricochets++;
        b.redirected = true;
        this.particles.sparks(hx, hy, best.nx, best.ny, 3, '#e8e2d6');
        this.particles.debris(hx, hy, 2, '#9a948c', 0.4);
        this.sfx.tok();
        return;
      }
      if (best.type === 'enemy') {
        b.alive = false;
        const e = best.e;
        const head = best.head;
        this.sfx.tok();
        this.particles.spawn({ kind: 'impact', x: hx, y: hy, life: 0.07, size: 12, color: '#ffffff' });
        this.particles.debris(hx, hy, 3, '#9a948c', 0.5);
        const ktags = [...b.tags.filter((t) => t !== 'FOKUS'), 'KETAPEL'];
        if (e.type === 'boss' || e.isBossMode) {
          if (e.hurt(head ? 5 : 2, ux, head, this.time, this.sfx)) this.killEnemy(e, ux, uy - 0.3, head, 500, ktags, hx, hy);
          else this.mark(0);
        } else if (head) {
          e.hp = 0;
          this.killEnemy(e, ux, uy - 0.3, true, 420, ktags, hx, hy);
          this.mark(2);
          this.stamp('TOENG!', hx, hy - 30, '#ffffff', 30, '#7ac93a');
        } else if (e.hurt(0.75, ux, false, this.time, this.sfx)) {
          this.killEnemy(e, ux, uy - 0.3, false, 420, ktags, hx, hy);
          this.mark(1);
        } else {
          e.stunFor(1.7, ux * 120, -110);
          this.mark(0);
          this.popup('PUSING!', e.x, e.y - e.h - 30, '#ffd23f');
        }
        return;
      }
      if (best.type === 'door' || best.type === 'wall') {
        b.alive = false;
        this.sfx.tok();
        this.particles.debris(hx, hy, 3, '#9a948c', 0.5);
        return;
      }
    }
    switch (best.type) {
      case 'wall': {
        b.alive = false;
        b.dx = hx;
        b.dy = hy;
        const metal = best.kind === 'metal' || best.kind === 'duct' || best.kind === 'dumpster';
        this.particles.sparks(hx, hy, best.nx, best.ny, metal ? 7 : 3, metal ? '#ffe08a' : '#ffd36b');
        this.particles.spawn({ kind: 'impact', x: hx, y: hy, life: 0.06, size: metal ? 14 : 9, color: '#ffe8b0' });
        this.particles.debris(hx + best.nx * 2, hy + best.ny * 2, 3, best.kind === 'crate' ? '#8a5a34' : '#77736c', 0.5);
        this.particles.spawn({ kind: 'dust', x: hx, y: hy, vx: best.nx * 40, vy: best.ny * 40, life: 0.4, size: 4, color: 'rgba(200,190,175,1)', drag: 3 });
        this.particles.addDecal({ x: hx + best.nx * 0.5, y: hy + best.ny * 0.5, w: 1.8, h: 1.8, rot: 0, color: '#000', kind: 'hole' });
        if (b.owner === 'player') this.sfx.wallHit();
        break;
      }
      case 'door': {
        const pierceDoor = (b.kind === 'sniper' || b.kind === 'h_sniper' || b.kind === 'h_railgun') && b.owner === 'player';
        if (!pierceDoor) {
          b.alive = false;
          b.dx = hx;
          b.dy = hy;
        }
        this.particles.debris(hx, hy, pierceDoor ? 12 : 5, '#8a5a34', pierceDoor ? 1.1 : 0.6);
        this.sfx.wallHit();
        const door = best.prop;
        if (pierceDoor) this.traceBullet(b, hx + ux * 36, hy + uy * 36, x2, y2, depth + 1);
        if (door && door.type === 'door' && door.state === 'idle' && b.owner === 'player') {
          door.hp -= pierceDoor ? 3 : 1;
          if (door.hp <= 0) {
            door.alive = false;
            this.syncDyn();
            this.particles.debris(door.x + door.w / 2, door.y + door.h / 2, 22, '#8a5a34', 1.3, true);
            this.sfx.door();
            this.shake(5);
            this.popup('PINTU HANCUR!', door.x + door.w / 2, door.y - 10, '#ffd23f');
          }
        }
        break;
      }
      case 'hazard': {
        b.alive = false;
        this.shootHazard(best.hz, hx, hy, ux, uy, b.tags);
        break;
      }
      case 'lamp': {
        b.alive = false;
        this.hitLamp(best.prop, ux, uy);
        break;
      }
      case 'glass':
        this.breakGlassProp(best.prop, b.vx * 0.2, b.vy * 0.2, false);
        this.traceBullet(b, hx + ux, hy + uy, x2, y2, depth + 1);
        break;
      case 'barrel':
        b.alive = false;
        this.explode(best.prop, b.owner === 'player' ? b.tags : []);
        break;
      case 'pan': {
        const pan = best.prop;
        pan.state = 'flying';
        pan.vy = Math.min(pan.vy, -420);
        pan.vx = pan.vx * 0.5 + ux * 60;
        pan.vr += rand(-25, 25);
        this.sfx.ricochet();
        this.particles.sparks(hx, hy, -ux, -uy, 12, '#fff2a8');
        b.ricochets++;
        if (b.ricochets > 4) {
          b.alive = false;
          break;
        }
        // auto-target nearest visible enemy
        let target: Enemy | null = null;
        let bd = 1100;
        for (const e of this.enemies) {
          if (!e.alive) continue;
          const d = dist(pan.x, pan.y, e.wp.head.x, e.wp.head.y);
          if (d < bd && this.world.los(pan.x, pan.y, e.wp.head.x, e.wp.head.y)) {
            bd = d;
            target = e;
          }
        }
        let na: number;
        if (target) na = Math.atan2(target.wp.head.y - pan.y, target.wp.head.x - pan.x);
        else na = Math.atan2(-Math.abs(uy) - 0.5, -ux + rand(-0.5, 0.5));
        b.x = pan.x + Math.cos(na) * 16;
        b.y = pan.y + Math.sin(na) * 16;
        b.sx = pan.x;
        b.sy = pan.y;
        b.vx = Math.cos(na) * 3600;
        b.vy = Math.sin(na) * 3600;
        b.life = 0.5;
        if (!b.tags.includes('PANTULAN')) b.tags.push('PANTULAN');
        b.redirected = true;
        break;
      }
      case 'enemy': {
        const e = best.e;
        const head = best.head;
        const pierce = (b.pierce ?? 0) > 0 && b.owner === 'player';
        if (pierce) {
          b.pierce = (b.pierce ?? 0) - 1;
          if (!b.hitIds) b.hitIds = [];
          b.hitIds.push(e.id);
        } else b.alive = false;
        const ktags = pierce && (b.kills ?? 0) >= 1 ? [...b.tags, 'TEMBUS'] : b.tags;
        const dmg = (head ? b.dmg * 3 : b.dmg) * (e.isBossMode ? 0.4 : 1);
        if (e.customDeath) {
          this.particles.sparks(hx, hy, -ux, -uy, 6, '#ffe066');
          this.particles.debris(hx, hy, 3, '#ffd93b', 0.6);
        } else {
          this.particles.blood(hx, hy, ux, uy, head ? 12 : 7, 0.9);
          if (head) this.particles.blood(hx, hy, -ux, -uy - 0.3, 4, 0.5);
        }
        this.particles.spawn({ kind: 'impact', x: hx, y: hy, life: 0.07, size: head ? 16 : 12, color: '#ffffff' });
        const pow = b.halo ? b.halo.pow : b.kind === 'shotgun' ? 1150 : b.kind === 'sniper' ? 1400 : b.kind === 'uzi' ? 520 : b.kind === 'ak47' ? 700 : 650;
        if (e.hurt(dmg, ux, head, this.time, this.sfx)) {
          this.killEnemy(e, ux, uy - 0.25, head, pow, ktags, hx, hy);
          b.kills = (b.kills ?? 0) + 1;
          if (b.halo) this.haloKill(b.halo, hx, hy);
          if (b.owner === 'player') this.mark(head ? 2 : 1);
          if (pierce && (b.kills ?? 0) >= 2) this.stamp(`TEMBUS x${b.kills}!`, hx, hy - 50, '#ffffff', 34, '#2ecc71');
        } else {
          this.sfx.hit(head);
          if (b.owner === 'player') this.mark(0);
          if (b.kind === 'shotgun') e.vx += ux * 160;
        }
        if (pierce && b.alive) this.traceBullet(b, hx + ux * 3, hy + uy * 3, x2, y2, depth + 1);
        break;
      }
      case 'player':
        b.alive = false;
        this.damagePlayer(b.dmg, ux);
        break;
    }
  }

  // ------------------------------------------------------------ props
  private explode(p: Prop, tags: string[]) {
    if (!p.alive) return;
    p.alive = false;
    this.particles.addDecal({ x: p.x, y: p.y, w: 70, h: 18, rot: 0, color: '#000', kind: 'scorch' });
    if (this.mode === 'boss' && p.type === 'barrel') this.barrelRespawn.push({ x: p.ax, y: p.ay, t: 14 });
    this.explodeAt(p.x, p.y - p.h / 2, tags, 155, 1, p);
  }

  explodeAt(
    cx: number,
    cy: number,
    tags: string[],
    R = 155,
    playerScale = 1,
    src: Prop | null = null,
    energy = false,
    bossMul = 1,
  ) {
    const big = R >= 100;
    if (big) {
      this.particles.explosion(cx, cy, energy);
      if (energy) this.sfx.cricketBoom();
      else this.sfx.explosion();
      this.sfx.duck(0.4, 0.7);
      this.shake(energy ? 24 : 18);
      this.camPunch = Math.max(this.camPunch, energy ? 0.12 : 0.08);
      if (energy) {
        this.flashT = Math.max(this.flashT, 0.07);
        this.stamp('BWOOOM!', cx, cy - 80, '#ffffff', 60, '#3fa8ff');
        this.particles.addDecal({ x: cx, y: cy, w: 90, h: 30, rot: 0, color: '#000', kind: 'scorch' });
      } else this.stamp('DUARR!', cx, cy - 70, '#ffffff', 54, '#ff7b3a');
    } else {
      this.particles.spawn({ kind: 'flash', x: cx, y: cy, life: 0.16, size: R * 1.3, color: '#ffb347' });
      for (let i = 0; i < 10; i++) {
        const a = rand(0, TAU);
        const sp = rand(60, 260);
        this.particles.spawn({
          kind: 'fire',
          x: cx,
          y: cy,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp - 80,
          life: rand(0.2, 0.45),
          size: rand(6, 14),
          color: Math.random() < 0.5 ? '#ffb02e' : '#ff6a1a',
          drag: 3.5,
          g: -100,
        });
      }
      this.particles.smoke(cx, cy - 6, 4, 10, true);
      this.particles.sparks(cx, cy, 0, -1, 8, '#ffcf5a');
      this.sfx.thud();
      this.sfx.bananaPop();
      this.shake(5);
    }
    let kills = 0;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const ex = e.x;
      const ey = e.y - e.h / 2;
      const d = dist(cx, cy, ex, ey);
      if (d < R) {
        const dx = (ex - cx) / (d || 1);
        const pow = 700 + 700 * (1 - d / R);
        const etags = [...tags.filter((t) => t !== 'PANTULAN'), 'LEDAKAN'];
        if (e.type === 'boss') {
          const bd = Math.round((e.isBossMode ? 10 + 14 * (1 - d / R) : 4 + 8 * (1 - d / R)) * (big ? 1 : 0.5) * bossMul);
          if (e.hurt(bd, dx, false, this.time, this.sfx)) this.killEnemy(e, dx, -0.9, false, pow, etags, ex, ey);
          else e.stunFor(0.6, dx * 200, -150);
          continue;
        }
        kills++;
        this.killEnemy(e, dx, -0.9, false, pow, etags, ex, ey);
      } else if (d < R * 1.8) {
        e.hearNoise(cx, cy, 2000, this.time, this.sfx);
      }
    }
    const pl = this.player;
    if (pl.alive) {
      const d = dist(cx, cy, pl.x, pl.y - 45);
      if (d < R * 0.85 && !pl.dodging) {
        this.damagePlayer(Math.round((55 * (1 - d / (R * 0.85)) + 10) * playerScale), sign(pl.x - cx));
        pl.vx += sign(pl.x - cx) * 300;
        pl.vy = Math.min(pl.vy, -450);
        pl.onGround = false;
      }
    }
    for (const r of this.ragdolls) {
      const c = r.center();
      const d = dist(cx, cy, c.x, c.y);
      if (d < R * 1.5) {
        const pow = 900 * (1 - d / (R * 1.5));
        r.impulseAll(((c.x - cx) / (d || 1)) * pow, -pow * 0.9);
      }
    }
    for (const q of this.props) {
      if (!q.alive || q === src) continue;
      const d = dist(cx, cy, q.x, q.y - (q.h || 0) / 2);
      if (q.type === 'barrel' && d < R * 1.2 && q.fuse < 0) q.fuse = 0.14;
      if (q.type === 'pan' && d < R * 1.5) {
        q.state = 'flying';
        q.vy = -700;
        q.vx = sign(q.x - cx) * 200;
        q.vr = 30;
      }
      if (isGlass(q) && d < R * 1.3) this.breakGlassProp(q, (q.x - cx) * 3, -100, false);
      if (q.type === 'door' && q.state === 'idle' && dist(cx, cy, q.x + q.w / 2, q.y + q.h / 2) < R * 1.05) {
        this.breachDoor(q, sign(q.x + q.w / 2 - cx) || 1, false, cy);
      }
      if ((q.type === 'lamp' || q.type === 'streetlamp' || q.type === 'chandelier') && q.state === 'idle' && d < R * 1.6) {
        this.hitLamp(q, sign(q.x - cx), -1);
      }
    }
    if (kills >= 1) this.autoSlow = Math.max(this.autoSlow, 0.7);
  }

  private hitLamp(p: Prop, ux: number, uy: number) {
    if (p.type === 'streetlamp') {
      if (p.state !== 'idle') return;
      p.state = 'broken';
      const bx = p.ax + 44;
      const by = p.ay - p.h - 13;
      this.particles.sparks(bx, by, 0, 1, 14, '#fff2a8');
      this.particles.glass(bx - 10, by - 4, 20, 8, ux * 120, 0);
      this.sfx.pop();
      this.popup('LAMPU PECAH!', bx, by - 20, '#fff2a8');
      return;
    }
    if (p.state === 'idle') {
      p.state = 'broken';
      p.vr += ux * 3.2;
      this.particles.sparks(p.x, p.y + 6, ux, uy, 16, '#fff2a8');
      this.particles.glass(p.x - 9, p.y + 2, 18, 8, ux * 150, 60);
      this.sfx.pop();
      this.popup('LAMPU PECAH!', p.x, p.y - 22, '#fff2a8');
    } else if (p.state === 'broken') {
      // cord snaps: lamp drops
      p.state = 'flying';
      const L = p.h + 7;
      p.vx = p.vr * L * Math.cos(p.rot) + ux * 60;
      p.vy = -p.vr * L * Math.sin(p.rot);
      p.vr = (Math.random() - 0.5) * 8;
      this.particles.sparks(p.ax, p.ay + 10, 0, 1, 8);
      this.sfx.wallHit();
      this.popup('TALI PUTUS!', p.x, p.y - 22, '#ffd23f');
    } else {
      p.vr += ux * 2;
    }
  }

  private updateProps(dt: number) {
    const w = this.world;
    const pl = this.player;
    for (const p of this.props) {
      if (!p.alive) continue;
      p.t += dt;
      switch (p.type) {
        case 'barrel': {
          if (p.fuse >= 0) {
            p.fuse -= dt;
            if (p.fuse < 0) {
              this.explode(p, []);
              break;
            }
          }
          p.vy += 2000 * dt;
          const body = { x: p.x - p.w / 2, y: p.y - p.h, w: p.w, h: p.h, vx: p.vx, vy: p.vy };
          const res = { hitX: 0, hitY: 0, onGround: false, ground: null, wallSolid: null, dynHit: null };
          w.moveBody(body, dt, false, res);
          p.x = body.x + p.w / 2;
          p.y = body.y + p.h;
          if (res.hitX) p.vx = -p.vx * 0.3;
          if (res.onGround) {
            p.vy = 0;
            p.vx *= Math.max(0, 1 - 5 * dt);
          }
          // barrels sliding into enemies knock them
          if (Math.abs(p.vx) > 250) {
            for (const e of this.enemies) {
              if (!e.alive || e.state === 'stunned') continue;
              if (Math.abs(e.x - p.x) < 24 && Math.abs(e.y - p.y) < 30) {
                e.stunFor(0.9, sign(p.vx) * 300, -200);
                p.vx *= 0.4;
                this.sfx.thud();
              }
            }
          }
          break;
        }
        case 'pan': {
          if (p.state !== 'flying') break;
          p.vy += 1500 * dt;
          p.vx *= Math.max(0, 1 - 0.4 * dt);
          const nx = p.x + p.vx * dt;
          const ny = p.y + p.vy * dt;
          p.rot += p.vr * dt;
          const sy = w.solidAt(p.x, ny + (p.vy > 0 ? 4 : -4), true);
          if (sy && !(sy.oneWay && (p.vy < 0 || p.y > sy.y))) {
            if (p.vy > 0) {
              p.y = sy.y - 4;
              p.vy = -p.vy * 0.35;
              p.vx *= 0.6;
              p.vr *= 0.5;
              if (Math.abs(p.vy) < 90) {
                p.vy = 0;
                p.vr = 0;
                p.rot = 0;
                p.state = 'idle';
              }
              this.sfx.thud();
            } else {
              p.vy = Math.abs(p.vy) * 0.3;
            }
          } else p.y = ny;
          if (w.solidAt(nx + sign(p.vx) * 10, p.y, false)) p.vx = -p.vx * 0.5;
          else p.x = nx;
          break;
        }
        case 'door': {
          if (p.state === 'flying') this.updateFlyingDoor(p, dt);
          break;
        }
        case 'lamp':
        case 'chandelier': {
          if (p.state === 'idle' || p.state === 'broken') {
            const L = p.h + 14;
            p.vr += (-(1700 / L) * Math.sin(p.rot) - p.vr * 0.55) * dt;
            p.rot += p.vr * dt;
            p.x = p.ax + Math.sin(p.rot) * (p.h + 7);
            p.y = p.ay + Math.cos(p.rot) * (p.h + 7);
            if (p.state === 'broken' && Math.random() < 0.04 * (dt * 120)) {
              this.particles.sparks(p.x, p.y + 6, 0, 1, 1, '#9fe8ff');
            }
          } else if (p.state === 'flying') {
            p.vy += 2000 * dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.rot += p.vr * dt;
            for (const e of this.enemies) {
              if (!e.alive) continue;
              const bigL = p.type === 'chandelier';
              if (Math.abs(e.x - p.x) < (bigL ? 50 : 24) && p.y > e.y - e.h - (bigL ? 40 : 14) && p.y < e.y - e.h + 34 && p.vy > 150) {
                if (e.type === 'boss') {
                  const dmg = bigL ? 30 : 14;
                  if (e.hurt(dmg, sign(p.vx) || 1, true, this.time, this.sfx)) {
                    this.killEnemy(e, sign(p.vx) * 0.3, 1, true, 500, ['LAMPU'], p.x, p.y);
                  } else {
                    e.stunFor(1.2, 0, 0);
                    this.stamp(bigL ? 'KRAAANG!' : 'TONK!', e.x, e.y - e.h - 30, '#ffffff', 44, '#ffd23f');
                    this.mark(2);
                    this.shake(10);
                    this.styleBonus('LAMPU', bigL ? 400 : 150, e.x, e.y - e.h);
                  }
                } else this.killEnemy(e, sign(p.vx) * 0.3, 1, true, 500, ['LAMPU'], p.x, p.y);
                p.vy *= -0.2;
              }
            }
            const sld = w.solidAt(p.x, p.y + 8, true);
            if (sld && !(sld.oneWay && p.vy < 0)) {
              p.state = 'resting';
              p.y = sld.y - 8;
              p.vx = 0;
              p.vy = 0;
              p.rot = 0.25;
              this.particles.glass(p.x - 10, p.y - 6, 20, 8, 0, -100);
              this.particles.debris(p.x, p.y, 6, '#2d3a33', 0.8);
              this.sfx.glass();
              this.sfx.thud();
            }
          }
          break;
        }
        case 'banana': {
          if (pl.alive && dist(pl.x, pl.y - 45, p.x, p.y) < 42) {
            p.alive = false;
            const def = this.level.props.find((d) => d.type === 'banana' && Math.abs(d.x - p.x) < 1 && Math.abs(d.y - p.y) < 1);
            if (def) this.collected.add(`${def.x},${def.y}`);
            this.score += 500;
            this.sfx.banana();
            this.tags.unshift({ text: `PISANG RAHASIA ${this.collected.size}/3`, pts: 500, t: 2.2, big: true });
            this.popups.push({ x: p.x, y: p.y - 30, text: '+500', t: 1.2, color: '#ffd93b', size: 28 });
            this.particles.sparks(p.x, p.y, 0, -1, 16, '#ffe066');
          }
          break;
        }
        case 'shotgun': {
          if (pl.alive && dist(pl.x, pl.y - 45, p.x, p.y - 14) < 48) {
            p.alive = false;
            pl.give('shotgun', 6);
            pl.switchTo('shotgun');
            this.sfx.pickup();
            this.sfx.pump();
            this.stamp('SHOTGUN!', p.x, p.y - 60, '#ffffff', 40, '#ff7b3a');
            this.queueHint(
              'SHOTGUN! Musuh terpental jauh — kamu juga terdorong mundur. Tembak ke BAWAH saat di udara = SHOTGUN JUMP!',
              true,
            );
          }
          break;
        }
        case 'gundrop': {
          if (p.state === 'flying') {
            const oy = p.y;
            p.vy = Math.min(1500, p.vy + 1700 * dt);
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.rot += p.vr * dt;
            if (w.solidAt(p.x + sign(p.vx) * 9, p.y - 3, false)) {
              p.x -= p.vx * dt;
              p.vx = -p.vx * 0.4;
            }
            const sld = w.solidAt(p.x, p.y + 3, true);
            if (sld && p.vy > 0 && !(sld.oneWay && oy + 3 > sld.y + 2)) {
              p.y = sld.y - 3;
              if (p.vy > 220) {
                p.vy = -p.vy * 0.3;
                p.vx *= 0.6;
                p.vr *= 0.5;
                this.sfx.thud();
              } else {
                p.vy = 0;
                p.vx = 0;
                p.vr = 0;
                p.rot = Math.round(p.rot / Math.PI) * Math.PI;
                p.state = 'resting';
              }
            }
            if (p.y > this.level.killY + 200) p.alive = false;
          }
          if (pl.alive && p.t > 0.35 && isWeaponId(p.gun) && dist(pl.x, pl.y - 30, p.x, p.y) < 56 && pl.canTake(p.gun)) {
            const id = p.gun;
            const had = pl.has(id);
            p.alive = false;
            pl.give(id, WEAPON_INFO[id].drop);
            if (pl.weapon === 'pistol') pl.switchTo(id);
            this.sfx.pickup();
            if (id === 'shotgun') this.sfx.pump();
            if (id === 'sniper') this.sfx.bolt();
            this.stamp(had ? `+${WEAPON_INFO[id].drop} ${WEAPON_INFO[id].name}` : WEAPON_INFO[id].name, p.x, p.y - 50, '#ffffff', 30, '#3ad1e8');
            if (!had) this.weaponHint(id);
          }
          break;
        }
        case 'weapon': {
          if (pl.alive && isWeaponId(p.gun) && dist(pl.x, pl.y - 45, p.x, p.y - 14) < 62) {
            const id = p.gun;
            p.alive = false;
            pl.give(id, WEAPON_INFO[id].pickup);
            // semua senjata sudah terbuka: jangan paksa ganti kalau pemain sudah memilih senjata sendiri
            if (pl.weapon === 'pistol') pl.switchTo(id);
            this.sfx.pickup();
            if (id === 'sniper') this.sfx.bolt();
            if (id === 'ak47') this.sfx.reload();
            this.stamp(WEAPON_INFO[id].name + '!', p.x, p.y - 70, '#ffffff', 40, WEAPON_INFO[id].color);
            this.particles.sparks(p.x, p.y - 20, 0, -1, 14, '#ffe9a0');
            this.weaponHint(id);
          }
          break;
        }
        case 'uzi': {
          if (pl.alive && dist(pl.x, pl.y - 45, p.x, p.y - 14) < 46) {
            p.alive = false;
            pl.give('uzi', 50);
            pl.switchTo('uzi');
            this.sfx.pickup();
            this.centerMsg = 'UZI GANDA!';
            this.centerT = 2;
            this.queueHint('UZI GANDA! Tembakan super cepat. Pelurunya terbatas — habiskan dengan gaya!', true);
          }
          break;
        }
        default:
          break;
      }
    }
  }

  // ------------------------------------------------------------ rendering
  private makeHud(): HudState {
    return {
      hp: 100,
      focus: 100,
      focusing: false,
      weapon: 'pistol',
      mag: [12, 12],
      magSize: 12,
      reload: 0,
      score: 0,
      combo: 0,
      comboT: 0,
      tags: [],
      kills: 0,
      totalEnemies: 0,
      bananas: 0,
      totalBananas: 3,
      hintText: '',
      hintChars: 0,
      hintAlpha: 0,
      titleT: 0,
      levelName: '',
      levelSub: '',
      time: 0,
      hurt: 0,
      centerMsg: '',
      centerT: 0,
      boss: null,
      realTime: 0,
      splitActive: false,
      scorePulse: 0,
      mode: 'story',
      inv: [],
      bolt: 0,
      heat: 0,
      charge: 0,
      hits: 0,
      hitsT: 0,
      age: 0,
      maxHp: 100,
      guard: 0,
      wave: 0,
      waves: 5,
    };
  }

  private render() {
    const ctx = this.ctx;
    const { W, H, dpr, cam } = this;
    const z = this.viewZoom;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
    if (this.level.sky === 'dream') drawDreamSky(ctx, W, H, this.realTime, this.dreamPhase, cam.x);
    else drawSky(ctx, W, H, cam.x, cam.y, z, this.skyline);

    const camX = cam.x + cam.sx;
    const camY = cam.y + cam.sy;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.translate(W / 2, H / 2);
    ctx.rotate(cam.roll + this.shakeRot);
    ctx.scale(z, z);
    ctx.translate(-camX, -camY);
    const pad = Math.abs(cam.roll + this.shakeRot) > 0.002 ? 70 / z : 0;
    const vx0 = camX - W / 2 / z - pad;
    const vy0 = camY - H / 2 / z - pad;
    const vx1 = camX + W / 2 / z + pad;
    const vy1 = camY + H / 2 / z + pad;
    const vis = (x: number, y: number, w: number, h: number) => x < vx1 && x + w > vx0 && y < vy1 && y + h > vy0;
    const t = this.realTime;

    // abyss between buildings
    if (this.mode === 'story' && vis(7160, -400, 540, 1000)) {
      const g = ctx.createLinearGradient(0, -300, 0, 420);
      g.addColorStop(0, 'rgba(8,6,14,0)');
      g.addColorStop(1, 'rgba(8,6,14,0.95)');
      ctx.fillStyle = g;
      ctx.fillRect(7160, -300, 540, 720);
    }

    for (const r of this.level.rooms) if (vis(r.x, r.y, r.w, r.h)) drawRoom(ctx, r, this.patterns, t);
    for (const d of this.level.decos) {
      if (!vis(d.x - 260, d.y - 300, 600, 700)) continue;
      drawDeco(ctx, d, t);
    }
    for (const zl of this.level.ziplines) drawZipline(ctx, zl);

    // exit door
    const ex = this.level.exit;
    if (this.mode === 'story' && vis(ex.x - 40, ex.y - 40, ex.w + 80, ex.h + 80)) this.drawExit(ctx, t);

    for (const s of this.world.solids) if (vis(s.x - 6, s.y - 40, s.w + 12, s.h + 60)) drawSolid(ctx, s, this.patterns);
    this.particles.drawDecals(ctx, vx0, vy0, vx1, vy1);

    // lamps
    for (const p of this.props) {
      if (!p.alive || (p.type !== 'lamp' && p.type !== 'streetlamp' && p.type !== 'chandelier')) continue;
      if (p.type === 'streetlamp') {
        if (!vis(p.ax - 60, p.ay - p.h - 40, 160, p.h + 60)) continue;
      } else if (!vis(Math.min(p.ax, p.x) - 60, Math.min(p.ay, p.y) - 30, Math.abs(p.x - p.ax) + 120, Math.abs(p.y - p.ay) + 70)) {
        continue;
      }
      drawLamp(ctx, p, t);
    }

    // props
    for (const p of this.props) {
      if (!p.alive) continue;
      if (!vis(p.x - 80, p.y - 160, 200, 260)) continue;
      switch (p.type) {
        case 'barrel':
          drawBarrel(ctx, p);
          break;
        case 'pan':
          drawPan(ctx, p);
          break;
        case 'glass':
          drawGlass(ctx, p);
          break;
        case 'glassdoor':
          drawGlassDoor(ctx, p);
          break;
        case 'lamp':
        case 'streetlamp':
        case 'chandelier':
          break;
        case 'door':
          drawDoor(ctx, p);
          break;
        case 'banana': {
          const bob = Math.sin(p.t * 3) * 5;
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          const g = ctx.createRadialGradient(p.x, p.y + bob, 0, p.x, p.y + bob, 34);
          g.addColorStop(0, 'rgba(255,230,90,0.45)');
          g.addColorStop(1, 'rgba(255,230,90,0)');
          ctx.fillStyle = g;
          ctx.fillRect(p.x - 34, p.y + bob - 34, 68, 68);
          ctx.restore();
          drawBanana(ctx, p.x, p.y + bob, 0.85, Math.sin(p.t * 2) * 0.3, true);
          break;
        }
        case 'uzi':
          drawUziPickup(ctx, p);
          break;
        case 'shotgun':
          drawShotgunPickup(ctx, p);
          break;
        case 'gundrop':
          drawGunDrop(ctx, p, t);
          break;
        case 'weapon':
          drawWeaponPickup(ctx, p);
          break;
      }
    }

    this.drawDarkness(camX, camY, z, vis);

    // ragdolls
    for (const r of this.ragdolls) {
      const c = r.center();
      if (!vis(c.x - 100, c.y - 100, 200, 200)) continue;
      drawCharacter(ctx, r.toWorldPose(), r.look, r.dims);
    }

    // enemies
    for (const e of this.enemies) {
      if (!e.alive) continue;
      if (!vis(e.x - e.w - 60, e.y - e.h - 80, e.w * 2 + 120, e.h + 100)) continue;
      if (e.type === 'sniper' && e.state === 'alert' && this.player.alive) this.drawSniperLaser(ctx, e);
      // telegraph laser
      if (e.type !== 'sniper' && e.state === 'alert' && e.seen && this.player.alive) {
        const ready = e.type === 'gunner' ? e.burst > 0 || e.fireCd < 0.35 : e.fireCd < 0.35;
        if (ready && e.reaction < 0.35) {
          const h = e.wp.haF;
          const a = e.wp.aimF;
          const len = 900;
          const hit = this.world.raycast(h.x, h.y, h.x + Math.cos(a) * len, h.y + Math.sin(a) * len, true);
          const L = hit ? hit.t * len : len;
          const g = ctx.createLinearGradient(h.x, h.y, h.x + Math.cos(a) * L, h.y + Math.sin(a) * L);
          g.addColorStop(0, 'rgba(255,40,40,0.55)');
          g.addColorStop(1, 'rgba(255,40,40,0)');
          ctx.strokeStyle = g;
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(h.x, h.y);
          ctx.lineTo(h.x + Math.cos(a) * L, h.y + Math.sin(a) * L);
          ctx.stroke();
        }
      }
      if (!e.drawSelf(ctx, t)) drawCharacter(ctx, e.wp, e.look, e.dims);
      e.drawOverlay(ctx, t);
      if (e.noticeT > 0) {
        const bounce = Math.abs(Math.sin(e.noticeT * 8)) * 6;
        ctx.save();
        ctx.font = '30px Bangers, Impact, sans-serif';
        ctx.textAlign = 'center';
        ctx.lineWidth = 5;
        ctx.strokeStyle = '#120d0a';
        ctx.globalAlpha = Math.min(1, e.noticeT * 3);
        ctx.strokeText('!', e.wp.head.x, e.wp.head.y - 26 - bounce);
        ctx.fillStyle = '#ffd23f';
        ctx.fillText('!', e.wp.head.x, e.wp.head.y - 26 - bounce);
        ctx.restore();
      }
    }

    this.hazards.draw(ctx, t);

    // lights
    ctx.globalCompositeOperation = 'lighter';
    for (const p of this.props) {
      const L = lampLight(p);
      if (!L || !vis(L.x - 280, L.y - 80, 560, 460)) continue;
      this.lightShape(ctx, L, t, false);
    }
    for (const m of this.muzzleLights()) {
      const g = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, 130);
      g.addColorStop(0, `rgba(255,210,120,${0.4 * m.k})`);
      g.addColorStop(1, 'rgba(255,170,60,0)');
      ctx.fillStyle = g;
      ctx.fillRect(m.x - 130, m.y - 130, 260, 260);
    }
    ctx.globalCompositeOperation = 'source-over';

    // focus desaturation (world only)
    const slowAmt = clamp((1 - this.timeScale) / (1 - SLOW), 0, 1);
    if (slowAmt > 0.02) {
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalCompositeOperation = 'saturation';
      ctx.globalAlpha = slowAmt * 0.72;
      ctx.fillStyle = '#808080';
      ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = slowAmt * 0.1;
      ctx.fillStyle = '#ff9a2e';
      ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
      ctx.restore();
    }

    // player
    const p = this.player;
    if (p.alive) {
      this.drawPlayerWeaponFx(ctx);
      this.drawTrail(ctx, p.trail, '#fff1b8');
      this.drawTrail(ctx, p.trail2, '#c8f1ff');
      for (const g of p.ghosts) {
        drawGhost(ctx, g.pts, p.spin > 0 ? '#9fe8ff' : '#ffd23f', (g.life / 0.2) * 0.16, PLAYER_DIMS);
      }
      if (p.invuln > 0 && Math.floor(t * 20) % 2 === 0) ctx.globalAlpha = 0.5;
      this.drawBlade(ctx, false);
      drawCharacter(ctx, p.wp, PLAYER_LOOK, PLAYER_DIMS);
      this.drawPlayerOverlayFx(ctx);
      ctx.globalAlpha = 1;
      // split aim lasers
      if (this.split.active) {
        ctx.save();
        ctx.setLineDash([6, 6]);
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = 'rgba(255,90,90,0.55)';
        ctx.beginPath();
        ctx.moveTo(p.wp.haB.x, p.wp.haB.y);
        ctx.lineTo(this.split.x, this.split.y);
        ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,0.35)';
        ctx.beginPath();
        ctx.moveTo(p.wp.haF.x, p.wp.haF.y);
        ctx.lineTo(this.aim.x, this.aim.y);
        ctx.stroke();
        ctx.restore();
      }
      if (p.dodging) {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        // swoosh arcs
        const prog = 1 - p.spin / 0.6;
        for (let k = 0; k < (p.spin > 0 ? 3 : 0); k++) {
          const yy = p.y - 22 - k * 26;
          const a0 = p.spinAngle * 1.5 + k * 1.7;
          ctx.strokeStyle = `rgba(200,240,255,${0.5 * (1 - prog * 0.6)})`;
          ctx.lineWidth = 2.2;
          ctx.beginPath();
          ctx.ellipse(p.x, yy, 30 - k * 3, 8, 0, a0, a0 + 2.6);
          ctx.stroke();
        }
        const g = ctx.createRadialGradient(p.x, p.y - 48, 0, p.x, p.y - 48, 60);
        g.addColorStop(0, 'rgba(140,220,255,0.18)');
        g.addColorStop(1, 'rgba(140,220,255,0)');
        ctx.fillStyle = g;
        ctx.fillRect(p.x - 60, p.y - 108, 120, 120);
        ctx.restore();
      }
    }

    // bullets
    ctx.lineCap = 'round';
    for (const b of this.bullets) {
      if (b.halo) {
        // proyektil asli HALO, ujungnya searah laju peluru
        drawHaloBullet(ctx, b.halo, b);
        continue;
      }
      if (b.kind === 'sling') {
        ctx.fillStyle = '#b8b2a8';
        ctx.strokeStyle = '#1b1410';
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.arc(b.x, b.y, 3.4, 0, TAU);
        ctx.fill();
        ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,0.35)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(b.x - b.vx * 0.012, b.y - b.vy * 0.012);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        continue;
      }
      if (b.kind === 'cricket') {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        const tl = Math.min(90, dist(b.x, b.y, b.sx, b.sy));
        const L = Math.hypot(b.vx, b.vy) || 1;
        const tx = b.x - (b.vx / L) * tl;
        const ty = b.y - (b.vy / L) * tl;
        const tg = ctx.createLinearGradient(tx, ty, b.x, b.y);
        tg.addColorStop(0, 'rgba(80,190,255,0)');
        tg.addColorStop(1, 'rgba(200,240,255,0.9)');
        ctx.strokeStyle = tg;
        ctx.lineCap = 'round';
        ctx.lineWidth = 12;
        ctx.beginPath();
        ctx.moveTo(tx, ty);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        const g = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, 26);
        g.addColorStop(0, 'rgba(255,255,255,1)');
        g.addColorStop(0.35, 'rgba(140,220,255,0.85)');
        g.addColorStop(1, 'rgba(60,150,255,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(b.x, b.y, 26, 0, TAU);
        ctx.fill();
        ctx.restore();
        continue;
      }
      const len = Math.hypot(b.vx, b.vy) || 1;
      const ux = b.vx / len;
      const uy = b.vy / len;
      const maxTail = b.kind === 'sniper' ? (b.owner === 'player' ? 520 : 320) : b.owner === 'player' ? 110 : 70;
      const tail = Math.min(maxTail, dist(b.x, b.y, b.sx, b.sy));
      const tx = b.x - ux * tail;
      const ty = b.y - uy * tail;
      const g = ctx.createLinearGradient(tx, ty, b.x, b.y);
      if (b.owner === 'player') {
        g.addColorStop(0, 'rgba(255,230,140,0)');
        g.addColorStop(1, 'rgba(255,250,220,1)');
      } else {
        g.addColorStop(0, 'rgba(255,80,40,0)');
        g.addColorStop(1, 'rgba(255,170,90,1)');
      }
      if (b.owner === 'player') {
        ctx.globalCompositeOperation = 'lighter';
        ctx.strokeStyle = b.kind === 'shotgun' ? 'rgba(255,170,80,0.22)' : 'rgba(255,205,110,0.24)';
        ctx.lineWidth = 7;
        ctx.beginPath();
        ctx.moveTo(tx, ty);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        ctx.globalCompositeOperation = 'source-over';
      }
      ctx.strokeStyle = g;
      ctx.lineWidth = b.kind === 'sniper' ? 4 : b.owner === 'player' ? 2.4 : 3;
      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
      if (slowAmt > 0.3 || b.owner === 'enemy') {
        ctx.fillStyle = b.owner === 'player' ? '#fff8d0' : '#ffcf9a';
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.owner === 'player' ? 2 : 2.6, 0, TAU);
        ctx.fill();
      }
    }

    this.particles.draw(ctx, vx0, vy0, vx1, vy1);
    this.haloFx.draw(ctx, vx0, vy0, vx1, vy1);

    // popups
    for (const pp of this.popups) {
      const max = pp.max ?? pp.t;
      const age = max - pp.t;
      let sc = 1;
      if (pp.burst) sc = age < 0.1 ? 2 - (age / 0.1) * 1.12 : age < 0.18 ? 0.88 + ((age - 0.1) / 0.08) * 0.12 : 1;
      ctx.save();
      ctx.translate(pp.x, pp.y);
      ctx.rotate(pp.rot ?? 0);
      ctx.scale(sc, sc);
      ctx.globalAlpha = clamp(pp.t * 2.5, 0, 1);
      ctx.font = `${pp.size}px Bangers, Impact, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.lineJoin = 'round';
      if (pp.burst) {
        // comic starburst behind the word
        const tw = ctx.measureText(pp.text).width;
        const rx = tw * 0.62 + pp.size * 0.42;
        const ry = pp.size * 0.95;
        let sd = pp.seed ?? 1;
        const rnd = () => {
          sd = (sd * 16807) % 2147483647;
          return sd / 2147483647;
        };
        const n = 18;
        ctx.beginPath();
        for (let i = 0; i < n; i++) {
          const ang = (i / n) * TAU;
          const rr = i % 2 === 0 ? 1 + rnd() * 0.18 : 0.7 + rnd() * 0.06;
          const px = Math.cos(ang) * rx * rr;
          const py = Math.sin(ang) * ry * rr;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.lineWidth = 4;
        ctx.strokeStyle = '#120d0a';
        ctx.stroke();
        ctx.fillStyle = pp.burst;
        ctx.fill();
      }
      ctx.lineWidth = pp.burst ? 7 : 5;
      ctx.strokeStyle = '#120d0a';
      ctx.strokeText(pp.text, 0, 0);
      ctx.fillStyle = pp.color;
      ctx.fillText(pp.text, 0, 0);
      ctx.restore();
    }

    this.drawBubbles(ctx);

    // Pedro floating companion
    if (this.hintAlpha > 0.05 && p.alive && this.screen === 'playing') {
      const bx = p.x - p.facing * 46;
      const by = p.y - 118 + Math.sin(t * 3) * 5;
      ctx.globalAlpha = this.hintAlpha;
      drawBanana(ctx, bx, by, 0.62, Math.sin(t * 2.2) * 0.2, true, Math.sin(t * 30) > 0 ? 1 : 0);
      ctx.globalAlpha = 1;
    }

    // ---------------- screen space
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    // vignette
    const vg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, `rgba(0,0,0,${0.45 + slowAmt * 0.35})`);
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);
    if (slowAmt > 0.02) {
      // focus frame bars
      ctx.fillStyle = `rgba(0,0,0,${slowAmt * 0.6})`;
      const bh = 34 * slowAmt * (H / 720);
      ctx.fillRect(0, 0, W, bh);
      ctx.fillRect(0, H - bh, W, bh);
    }
    if (this.speedLines > 0) {
      const a = clamp(this.speedLines / 0.75, 0, 1);
      const c = this.worldToScreen(this.breachX, this.breachY);
      const R0 = Math.hypot(W, H);
      let seed = Math.floor(this.realTime * 24) * 9301 + 49297;
      const rnd = () => {
        seed = (seed * 9301 + 49297) % 233280;
        return seed / 233280;
      };
      ctx.save();
      ctx.strokeStyle = `rgba(255,255,255,${0.5 * a})`;
      ctx.lineCap = 'round';
      for (let i = 0; i < 40; i++) {
        const ang = (i / 40) * TAU + rnd() * 0.12;
        const inner = Math.min(W, H) * (0.3 + rnd() * 0.25);
        ctx.lineWidth = 1 + rnd() * 3.5;
        ctx.beginPath();
        ctx.moveTo(c.x + Math.cos(ang) * inner, c.y + Math.sin(ang) * inner);
        ctx.lineTo(c.x + Math.cos(ang) * R0, c.y + Math.sin(ang) * R0);
        ctx.stroke();
      }
      ctx.restore();
    }
    if (this.flashT > 0) {
      ctx.fillStyle = `rgba(255,250,235,${(this.flashT / 0.09) * 0.36})`;
      ctx.fillRect(0, 0, W, H);
    }
    if (this.impactT > 0) this.drawImpactFrame(ctx, W, H);
    const lowHp = p.alive && p.hp < 35 ? (0.25 + Math.sin(t * 8) * 0.12) * (1 - p.hp / 35) : 0;
    const hurtA = Math.max(this.hurtFlash * 0.55, lowHp);
    if (hurtA > 0.01) {
      const hg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.7);
      hg.addColorStop(0, 'rgba(200,0,0,0)');
      hg.addColorStop(1, `rgba(200,0,0,${hurtA})`);
      ctx.fillStyle = hg;
      ctx.fillRect(0, 0, W, H);
    }

    if ((this.screen === 'playing' || this.screen === 'paused' || this.screen === 'dead') && this.bossIntro <= 0) {
      this.fillHud();
      drawHud(ctx, W, H, this.hud);
    }
    if (this.mode !== 'story' && this.bossIntro > 0 && this.screen === 'playing') {
      const info = this.mode === 'fist' ? GURU_INFO : BOSS_INFO[this.bossId];
      drawBossIntro(ctx, W, H, {
        name: info.name,
        title: info.title,
        tip: info.tip,
        color: info.color,
        el: this.bossIntroMax - this.bossIntro,
        rem: this.bossIntro,
        t,
      });
    }

    if (this.screen === 'playing' && p.alive && this.bossIntro <= 0) {
      const s = clamp(Math.min(W / 1280, H / 760), 0.7, 1.4);
      if (p.scoping) this.drawScope(ctx, W, H, s);
      else drawCrosshair(ctx, this.mouse.x, this.mouse.y, s, '#ffffff', 0, 'main', this.bloom);
      if (this.hitMark.t > 0) drawHitMarker(ctx, this.mouse.x, this.mouse.y, s, this.hitMark.t, this.hitMark.kind);
      if (this.mode === 'boss') {
        // off-screen boss indicator
        const bb = this.enemies.find((e) => e.type === 'boss' && e.alive);
        if (bb) {
          const sp = this.worldToScreen(bb.x, bb.y - bb.h * 0.6);
          const m = 48;
          if (sp.x < m || sp.x > W - m || sp.y < m || sp.y > H - m) {
            const ax = clamp(sp.x, m, W - m);
            const ay = clamp(sp.y, m + 40, H - m - 60);
            const a = Math.atan2(sp.y - ay, sp.x - ax);
            const pulse = 1 + Math.sin(t * 8) * 0.12;
            ctx.save();
            ctx.translate(ax, ay);
            ctx.save();
            ctx.rotate(a);
            ctx.scale(pulse * s, pulse * s);
            ctx.fillStyle = '#ff4d4d';
            ctx.strokeStyle = '#120d0a';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(22, 0);
            ctx.lineTo(-10, -15);
            ctx.lineTo(-3, 0);
            ctx.lineTo(-10, 15);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();
            ctx.font = `${18 * s}px Bangers, Impact, sans-serif`;
            ctx.textAlign = 'center';
            ctx.lineWidth = 4;
            ctx.strokeStyle = '#120d0a';
            ctx.strokeText('BOS', -Math.cos(a) * 30 * s, -Math.sin(a) * 30 * s + 6);
            ctx.fillStyle = '#ffffff';
            ctx.fillText('BOS', -Math.cos(a) * 30 * s, -Math.sin(a) * 30 * s + 6);
            ctx.restore();
          }
        }
      }
      if (this.split.active) {
        const sp = this.worldToScreen(this.split.x, this.split.y);
        drawCrosshair(ctx, sp.x, sp.y, s, '#ff5a5a', t * 3, 'split');
      }
    }
  }

  /** a few frames of high-contrast black & white with a manga impact burst at the heel */
  private drawImpactFrame(ctx: CanvasRenderingContext2D, W: number, H: number) {
    const k = clamp(this.impactT / 0.1, 0, 1);
    const ip = this.worldToScreen(this.impactX, this.impactY);
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalCompositeOperation = 'saturation';
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#808080';
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    ctx.globalCompositeOperation = 'color-burn';
    ctx.globalAlpha = 0.55;
    ctx.fillStyle = '#8c8c8c';
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    ctx.restore();
    ctx.save();
    const R = Math.hypot(W, H);
    const u = Math.min(W / 1280, H / 760);
    // black radial action lines
    let sd = 977;
    const rnd = () => {
      sd = (sd * 16807) % 2147483647;
      return sd / 2147483647;
    };
    ctx.fillStyle = `rgba(10,8,6,${0.85 * k})`;
    for (let i = 0; i < 46; i++) {
      const a = (i / 46) * TAU + rnd() * 0.08;
      const w0 = 0.01 + rnd() * 0.025;
      const r0 = (110 + rnd() * 160) * u;
      ctx.beginPath();
      ctx.moveTo(ip.x + Math.cos(a) * r0, ip.y + Math.sin(a) * r0);
      ctx.lineTo(ip.x + Math.cos(a - w0) * R, ip.y + Math.sin(a - w0) * R);
      ctx.lineTo(ip.x + Math.cos(a + w0) * R, ip.y + Math.sin(a + w0) * R);
      ctx.closePath();
      ctx.fill();
    }
    // white jagged burst at the heel
    const r1 = 95 * u * (1.25 - 0.25 * k);
    ctx.beginPath();
    for (let i = 0; i < 22; i++) {
      const a = (i / 22) * TAU;
      const rr = i % 2 === 0 ? r1 * (0.9 + rnd() * 0.5) : r1 * 0.42;
      const x = ip.x + Math.cos(a) * rr;
      const y = ip.y + Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.lineWidth = 5 * u;
    ctx.strokeStyle = '#120d0a';
    ctx.stroke();
    ctx.restore();
  }

  private drawTrail(ctx: CanvasRenderingContext2D, pts: number[], color: string) {
    const n = pts.length / 3;
    if (n < 2) return;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    ctx.strokeStyle = color;
    for (let i = 1; i < n; i++) {
      const f = i / (n - 1);
      ctx.globalAlpha = 0.55 * f;
      ctx.lineWidth = 1 + 8 * f;
      ctx.beginPath();
      ctx.moveTo(pts[(i - 1) * 3], pts[(i - 1) * 3 + 1]);
      ctx.lineTo(pts[i * 3], pts[i * 3 + 1]);
      ctx.stroke();
    }
    ctx.restore();
  }

  private muzzleLights() {
    const out: { x: number; y: number; k: number }[] = [];
    const p = this.player;
    if (p.alive) {
      for (let g = 0; g < 2; g++) {
        if (p.flash[g] > 0) {
          const m = p.muzzle(g, muzzleLen(p.weapon));
          out.push({ x: m.x, y: m.y, k: p.flash[g] / 0.05 });
        }
      }
    }
    for (const e of this.enemies) {
      if (e.alive && e.flash > 0) out.push({ x: e.wp.haF.x, y: e.wp.haF.y, k: e.flash / 0.06 });
    }
    return out;
  }

  /** cone + glow of a lamp; cut=true draws opaque shapes for the darkness mask */
  private lightShape(
    ctx: CanvasRenderingContext2D,
    L: { x: number; y: number; a: number; street: boolean; big?: boolean },
    t: number,
    cut: boolean,
  ) {
    const len = L.street ? 230 : L.big ? 430 : 340;
    const spread = L.street ? 125 : L.big ? 250 : 170;
    const flick = 0.92 + Math.sin(t * 37 + L.x) * 0.04;
    const dx = Math.sin(L.a);
    const dy = Math.cos(L.a);
    const px = dy;
    const py = -dx;
    const ex = L.x + dx * len;
    const ey = L.y + dy * len;
    const g = ctx.createLinearGradient(L.x, L.y, ex, ey);
    if (cut) {
      g.addColorStop(0, 'rgba(0,0,0,0.95)');
      g.addColorStop(0.7, 'rgba(0,0,0,0.5)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
    } else {
      g.addColorStop(0, `rgba(255,214,140,${0.22 * flick})`);
      g.addColorStop(1, 'rgba(255,214,140,0)');
    }
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(L.x - px * 12, L.y - py * 12);
    ctx.lineTo(L.x + px * 12, L.y + py * 12);
    ctx.lineTo(ex + px * spread, ey + py * spread);
    ctx.lineTo(ex - px * spread, ey - py * spread);
    ctx.closePath();
    ctx.fill();
    const r = cut ? 120 : 60;
    const rg = ctx.createRadialGradient(L.x, L.y, 0, L.x, L.y, r);
    if (cut) {
      rg.addColorStop(0, 'rgba(0,0,0,1)');
      rg.addColorStop(1, 'rgba(0,0,0,0)');
    } else {
      rg.addColorStop(0, `rgba(255,236,180,${0.35 * flick})`);
      rg.addColorStop(1, 'rgba(255,236,180,0)');
    }
    ctx.fillStyle = rg;
    ctx.fillRect(L.x - r, L.y - r, r * 2, r * 2);
  }

  /** room darkness with lamp light cut-outs (shoot the lamps = darker rooms) */
  private drawDarkness(
    camX: number,
    camY: number,
    z: number,
    vis: (x: number, y: number, w: number, h: number) => boolean,
  ) {
    const l = this.lctx;
    const lc = this.lightCanvas;
    const s = this.dpr / 2;
    l.setTransform(1, 0, 0, 1, 0, 0);
    l.globalCompositeOperation = 'source-over';
    l.clearRect(0, 0, lc.width, lc.height);
    l.setTransform(s, 0, 0, s, 0, 0);
    l.translate(this.W / 2, this.H / 2);
    l.rotate(this.cam.roll + this.shakeRot);
    l.scale(z, z);
    l.translate(-camX, -camY);
    let any = false;
    for (const r of this.level.rooms) {
      if (!vis(r.x, r.y, r.w, r.h)) continue;
      const dk = DARKNESS[r.style] ?? 0.3;
      if (dk <= 0) continue;
      l.fillStyle = `rgba(4,3,12,${dk})`;
      l.fillRect(r.x, r.y, r.w, r.h);
      any = true;
    }
    if (!any) return;
    l.globalCompositeOperation = 'destination-out';
    for (const p of this.props) {
      const L = lampLight(p);
      if (!L || !vis(L.x - 300, L.y - 140, 600, 520)) continue;
      this.lightShape(l, L, this.realTime, true);
    }
    for (const m of this.muzzleLights()) {
      const g = l.createRadialGradient(m.x, m.y, 0, m.x, m.y, 140);
      g.addColorStop(0, `rgba(0,0,0,${0.85 * m.k})`);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      l.fillStyle = g;
      l.fillRect(m.x - 140, m.y - 140, 280, 280);
    }
    for (const q of this.particles.list) {
      if (q.kind !== 'flash' && q.kind !== 'fire') continue;
      const rr = q.kind === 'flash' ? q.size : q.size * 2.5;
      const g = l.createRadialGradient(q.x, q.y, 0, q.x, q.y, rr);
      g.addColorStop(0, `rgba(0,0,0,${Math.min(1, q.life / q.max + 0.2)})`);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      l.fillStyle = g;
      l.fillRect(q.x - rr, q.y - rr, rr * 2, rr * 2);
    }
    l.globalCompositeOperation = 'source-over';
    const ctx = this.ctx;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.drawImage(lc, 0, 0, this.canvas.width, this.canvas.height);
    ctx.restore();
  }

  private drawExit(ctx: CanvasRenderingContext2D, t: number) {
    const ex = this.level.exit;
    ctx.fillStyle = '#1b1f24';
    ctx.fillRect(ex.x - 10, ex.y - 12, ex.w + 20, ex.h + 12);
    if (this.bossDead) {
      const g = ctx.createLinearGradient(ex.x, ex.y, ex.x, ex.y + ex.h);
      g.addColorStop(0, '#fff3c4');
      g.addColorStop(1, '#ffb347');
      ctx.fillStyle = g;
      ctx.fillRect(ex.x, ex.y, ex.w, ex.h);
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = `rgba(120,255,150,${0.15 + Math.sin(t * 5) * 0.08})`;
      ctx.fillRect(ex.x - 40, ex.y - 20, ex.w + 80, ex.h + 20);
      ctx.restore();
      ctx.fillStyle = '#2ecc71';
      ctx.font = '26px Bangers, Impact, sans-serif';
      ctx.textAlign = 'center';
      const by = ex.y - 30 + Math.sin(t * 6) * 6;
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#120d0a';
      ctx.strokeText('▼', ex.x + ex.w / 2, by);
      ctx.fillText('▼', ex.x + ex.w / 2, by);
    } else {
      ctx.fillStyle = '#5b636c';
      ctx.fillRect(ex.x, ex.y, ex.w, ex.h);
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      for (let y = ex.y + 8; y < ex.y + ex.h; y += 14) ctx.fillRect(ex.x, y, ex.w, 3);
      ctx.fillStyle = Math.sin(t * 4) > 0 ? '#ff3b3b' : '#7a1010';
      ctx.beginPath();
      ctx.arc(ex.x + ex.w / 2, ex.y - 4, 4, 0, TAU);
      ctx.fill();
    }
    ctx.strokeStyle = '#120d0a';
    ctx.lineWidth = 3;
    ctx.strokeRect(ex.x, ex.y, ex.w, ex.h);
  }

  private fillHud() {
    const h = this.hud;
    const p = this.player;
    h.hp = Math.max(0, p.hp);
    h.focus = p.focus;
    h.focusing = this.focusing;
    h.weapon = p.weapon;
    h.mag = p.mag;
    h.magSize = p.magSize;
    h.inv = p.owned().map((id) => {
      const m = p.inv[id] as [number, number];
      return { id, ammo: WEAPON_INFO[id].dual ? m[0] + m[1] : m[0] };
    });
    h.bolt = p.boltT;
    h.heat = p.heat;
    h.hits = this.meleeHits;
    h.hitsT = this.meleeHitT;
    h.charge = p.melee
      ? p.meleeCharge
      : p.weapon === 'sling'
        ? Math.min(1, p.slingCharge / SLING.max)
        : p.weapon === 'cricket' && p.cricketCharge > 0
          ? 1 - p.cricketCharge / CRICKET.charge
          : 0;
    h.reload = p.reload > 0 ? p.reload / 0.85 : 0;
    h.score = Math.round(this.scoreShown);
    h.scorePulse = clamp((this.score - this.scoreShown) / 400, 0, 1);
    h.combo = this.combo;
    h.comboT = this.comboT;
    h.tags = this.tags;
    h.kills = this.enemies.filter((e) => !e.alive).length;
    h.totalEnemies = this.level.enemies.length;
    h.bananas = this.collected.size;
    h.totalBananas = 3;
    h.hintText = this.hintText;
    h.hintChars = this.hintChars;
    h.hintAlpha = this.hintAlpha;
    h.titleT = this.titleT;
    h.levelName = this.level.name;
    h.levelSub = this.level.subtitle;
    h.time = this.playTime;
    h.hurt = this.hurtFlash;
    h.centerMsg = this.centerMsg;
    h.centerT = this.centerT;
    h.realTime = this.realTime;
    h.splitActive = this.split.active;
    h.mode = this.mode;
    h.age = this.mode === 'fist' ? this.age : 0;
    h.maxHp = p.maxHp;
    h.guard = clamp(p.guardStruct / 100, 0, 1);
    h.wave = this.wave;
    h.waves = FIST_WAVES.length;
    const boss = this.enemies.find((e) => e.type === 'boss' && e.alive && e.state !== 'idle');
    if (boss) {
      const k = boss.hp / boss.maxHp;
      h.boss = {
        hp: Math.max(0, boss.hp),
        max: boss.maxHp,
        name: boss.bossName || 'DON KUMIS',
        title: boss.bossTitle,
        marks: boss.phaseMarks,
        shown: Math.max(boss.hp, boss.hpShown),
        phase: 1 + boss.phaseMarks.filter((m) => k <= m).length,
      };
    } else h.boss = null;
  }
}
