/**
 * HALO ARSENAL — jembatan antara 28 senjata dari game "Halo / Perfect Shot"
 * dan engine parkour.
 *
 * Semua gambar senjata, kilatan moncong dan proyektil memakai kode art ASLI
 * dari game pertama (src/halo/gunhit/...). Art aslinya digambar tegak
 * (moncong di (0,0), badan senjata memanjang ke +y). Modul ini memutarnya
 * supaya moncong selalu searah bidikan pemain, mencerminkannya saat membidik
 * ke kiri (gagang tetap di bawah), dan menaruh gagangnya tepat di tangan.
 */
import { drawFlash as artDrawFlash, drawGun as artDrawGun } from '../halo/gunhit/game/art/guns';
import { drawProjectile as artDrawProjectile } from '../halo/gunhit/game/art/projectiles';
import { gunState } from '../halo/gunhit/game/art/kit';
import { getGunMetrics } from '../halo/gunhit/game/art/metrics';
import { WEAPONS as HALO_DEFS, type Weapon as HaloDef, type WeaponId as HaloArtId } from '../halo/gunhit/game/weapons';
import { HALO_ZIP, type HaloZipArt } from './haloZipData';

const TAU = Math.PI * 2;
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

export type HaloId = `h_${string}`;
export type HaloRarity = 'UMUM' | 'LANGKA' | 'EPIC' | 'LEGENDARIS';
export type HaloSound =
  | 'bullet' | 'auto' | 'heavy' | 'sniper' | 'energy' | 'beam' | 'rail' | 'launcher' | 'flame'
  | 'silent' | 'magic' | 'water' | 'ice' | 'void' | 'holy' | 'boom';

export const HALO_RARITY_COLOR: Record<HaloRarity, string> = {
  UMUM: '#b6bfcc',
  LANGKA: '#4f9bff',
  EPIC: '#c27bff',
  LEGENDARIS: '#ffb020',
};

export interface HaloSpec {
  id: HaloId;
  art: HaloArtId;
  def: HaloDef;
  name: string;
  rarity: HaloRarity;
  perk: string;
  /** warna utama (hex) & warna jejak "r,g,b" */
  color: string;
  rgb: string;
  sparks: string[];
  /** panjang senjata di dunia parkour (px), moncong -> popor */
  len: number;
  two: boolean;
  /** posisi gagang: gy = fraksi panjang dari moncong, gx = fraksi panjang ke sisi gagang */
  gy: number;
  gx: number;
  /** tangan penopang: fraksi panjang di depan gagang (senjata dua tangan) */
  fore: number;
  /** art aslinya punya gagang di sisi -x */
  flip: boolean;
  mag: number;
  cd: number;
  cdMin: number;
  dmg: number;
  speed: number;
  life: number;
  pellets: number;
  spread: number;
  pierce: number;
  pow: number;
  kick: number;
  shake: number;
  /** skala gambar proyektil */
  ps: number;
  sound: HaloSound;
  beam: boolean;
  explode: number;
  phase: boolean;
  burn: boolean;
  freeze: boolean;
  chain: boolean;
  pull: boolean;
  gravity: number;
  silent: boolean;
  scope: boolean;
  spinup: boolean;
  spin: boolean;
  bossMul: number;
  bonus: '' | 'gold' | 'fish' | 'diamond';
  heat: number;
}

interface Row {
  len: number;
  two?: boolean;
  g: [number, number];
  fore?: number;
  flip?: boolean;
  mag: number;
  cd: number;
  dmg: number;
  speed: number;
  x?: Partial<HaloSpec>;
}

/**
 * Tabel penyesuaian tiap senjata untuk dunia parkour.
 * g = [gy, gx] posisi gagang diukur dari lembar kontak art aslinya.
 */
const ROWS: Record<string, Row> = {
  // ---------------- UMUM
  pistol: { len: 25, g: [0.79, 0.27], mag: 12, cd: 0.14, dmg: 1.25, speed: 3300, x: { sound: 'bullet' } },
  ak47: { len: 56, two: true, g: [0.64, 0.1], fore: 0.36, mag: 30, cd: 0.085, dmg: 1.25, speed: 3700, x: { sound: 'auto', heat: 0.1, kick: 2.2, shake: 1.4 } },
  nail: { len: 28, g: [0.7, 0.27], mag: 40, cd: 0.07, dmg: 0.7, speed: 3200, x: { sound: 'silent', kick: 1.1, shake: 0.8, spread: 0.02 } },
  crossbow: { len: 46, two: true, g: [0.68, 0.08], fore: 0.28, mag: 8, cd: 0.42, dmg: 3.6, speed: 3600, x: { sound: 'silent', pierce: 1, silent: true, kick: 2, shake: 1.4, ps: 0.5 } },
  shotgun: { len: 50, two: true, g: [0.69, 0.09], fore: 0.42, mag: 8, cd: 0.6, dmg: 2.6, speed: 3000, x: { sound: 'heavy', pellets: 3, spread: 0.075, kick: 9, shake: 8, life: 0.3, pow: 1150 } },
  slingshot: { len: 24, g: [0.76, 0.0], mag: 20, cd: 0.36, dmg: 2, speed: 2100, x: { sound: 'silent', gravity: 420, spin: true, silent: true, kick: 0.8, shake: 0.6, ps: 0.5 } },
  blowgun: { len: 58, two: true, g: [0.8, 0.02], fore: 0.34, mag: 20, cd: 0.18, dmg: 1.6, speed: 3300, x: { sound: 'silent', silent: true, kick: 0.6, shake: 0.4, spread: 0.004 } },
  // ---------------- LANGKA
  sniper: { len: 66, two: true, g: [0.63, 0.11], fore: 0.25, mag: 5, cd: 0.9, dmg: 10, speed: 6500, x: { perk: 'SCOPE & TEMBUS', sound: 'sniper', pierce: 4, scope: true, spread: 0.002, kick: 13, shake: 9, life: 0.45, pow: 1400 } },
  flamethrower: { len: 46, two: true, g: [0.77, 0.23], fore: 0.4, mag: 60, cd: 0.085, dmg: 0.6, speed: 1250, x: { sound: 'flame', burn: true, life: 0.55, spread: 0.07, kick: 0.6, shake: 0.5, ps: 0.55, pow: 300 } },
  plasma: { len: 44, two: true, g: [0.81, 0.21], fore: 0.39, mag: 24, cd: 0.16, dmg: 2.4, speed: 1900, x: { perk: 'BOLA PLASMA', sound: 'energy', ps: 0.5, life: 1.1 } },
  laser: { len: 44, two: true, g: [0.6, 0.23], fore: 0.22, mag: 30, cd: 0.14, dmg: 1.5, speed: 14000, x: { perk: 'SINAR INSTAN', sound: 'beam', beam: true, kick: 0.8, shake: 0.7, spread: 0.003 } },
  rpg: { len: 60, two: true, g: [0.64, 0.11], fore: 0.24, mag: 4, cd: 0.8, dmg: 6, speed: 2100, x: { perk: 'ROKET LEDAK', sound: 'launcher', explode: 150, kick: 10, shake: 7, ps: 0.62, life: 1.2 } },
  bamboo: { len: 54, two: true, g: [0.66, 0.07], fore: 0.3, mag: 5, cd: 0.7, dmg: 5, speed: 1700, x: { sound: 'boom', explode: 130, kick: 11, shake: 9, ps: 0.6, life: 1.2 } },
  fish: { len: 30, g: [0.81, 0.09], mag: 20, cd: 0.2, dmg: 1.7, speed: 1700, x: { perk: 'IKAN HOKI', sound: 'water', bonus: 'fish', ps: 0.55, life: 1.1, kick: 1.4, shake: 1 } },
  // ---------------- EPIC
  minigun: { len: 58, two: true, g: [0.75, 0.13], fore: 0.29, mag: 150, cd: 0.2, dmg: 0.9, speed: 3600, x: { sound: 'auto', spinup: true, cdMin: 0.04, spread: 0.035, kick: 1.5, shake: 1.5 } },
  railgun: { len: 58, two: true, g: [0.74, 0.07], fore: 0.34, mag: 6, cd: 0.7, dmg: 8, speed: 9500, x: { perk: 'TEMBUS SEMUA', sound: 'rail', beam: true, pierce: 99, kick: 12, shake: 9, spread: 0.001, pow: 1300 } },
  electro: { len: 38, g: [0.77, 0.23], mag: 24, cd: 0.18, dmg: 1.5, speed: 2800, x: { perk: 'PETIR BERANTAI', sound: 'energy', chain: true, ps: 0.5 } },
  bazooka: { len: 64, two: true, g: [0.63, 0.11], fore: 0.25, mag: 3, cd: 0.9, dmg: 8, speed: 1500, x: { perk: 'LEDAKAN BESAR', sound: 'launcher', explode: 185, kick: 13, shake: 9, ps: 0.66, life: 1.5 } },
  keris: { len: 36, g: [0.76, 0.0], mag: 12, cd: 0.25, dmg: 3, speed: 3000, x: { perk: 'TEMBUS 3 MUSUH', sound: 'magic', pierce: 3, silent: true, kick: 1, shake: 0.8, ps: 0.55 } },
  shark: { len: 56, two: true, g: [0.58, 0.16], fore: 0.23, mag: 6, cd: 0.45, dmg: 6, speed: 2600, x: { perk: 'GIGITAN HIU', sound: 'water', kick: 8, shake: 6, ps: 0.7, life: 0.9, pow: 1200 } },
  ghost: { len: 30, g: [0.75, 0.0], mag: 20, cd: 0.22, dmg: 2, speed: 1900, x: { perk: 'TEMBUS TEMBOK', sound: 'void', phase: true, silent: true, ps: 0.55, life: 1.1, kick: 0.8, shake: 0.6 } },
  // ---------------- LEGENDARIS
  freeze: { len: 36, g: [0.78, 0.17], mag: 24, cd: 0.18, dmg: 1, speed: 2400, x: { sound: 'ice', freeze: true, ps: 0.5 } },
  golden: { len: 28, g: [0.78, 0.2], mag: 7, cd: 0.2, dmg: 4, speed: 3400, x: { perk: 'BONUS SKOR', sound: 'bullet', bonus: 'gold', kick: 3.4, shake: 2.4, pow: 900 } },
  blackhole: { len: 36, g: [0.69, 0.04], mag: 5, cd: 0.6, dmg: 3, speed: 1250, x: { perk: 'SEDOT MUSUH', sound: 'void', pull: true, ps: 0.6, life: 1.4, kick: 3, shake: 3 } },
  dragon: { len: 50, two: true, g: [0.7, 0.06], fore: 0.3, mag: 20, cd: 0.22, dmg: 2.2, speed: 2000, x: { sound: 'flame', burn: true, bossMul: 2, ps: 0.6, life: 0.9, kick: 3, shake: 2.4 } },
  meteor: { len: 52, two: true, g: [0.7, 0.09], fore: 0.3, mag: 3, cd: 1.0, dmg: 10, speed: 1400, x: { perk: 'LEDAKAN METEOR', sound: 'launcher', explode: 200, kick: 13, shake: 10, ps: 0.7, life: 1.6 } },
  diamond: { len: 32, g: [0.74, 0.12], mag: 24, cd: 0.16, dmg: 1.7, speed: 3400, x: { perk: 'BONUS BERLIAN', sound: 'magic', pierce: 1, bonus: 'diamond', ps: 0.5 } },
  holy: { len: 40, g: [0.57, 0.22], mag: 8, cd: 0.5, dmg: 6, speed: 14000, x: { perk: 'SINAR SUCI', sound: 'holy', beam: true, pierce: 3, kick: 5, shake: 4, spread: 0.001 } },
};

/** penjelasan tiap senjata sesuai perilakunya di game parkour */
export const HALO_DESC: Record<string, string> = {
  pistol: 'Pistol klasik satu tangan. Seimbang, akurat, reload cepat.',
  ak47: 'Senapan serbu otomatis. Tahan klik untuk menyemprot; makin lama makin melebar.',
  nail: 'Paku tipis super cepat, 40 paku per magasin. Senyap tapi mematikan dari dekat.',
  crossbow: 'Panah baja senyap: musuh lain tidak mendengar tembakanmu. Tembus 1 musuh.',
  shotgun: 'Tiga peluru besar menyebar sekaligus. Hentakannya keras, cocok jarak dekat.',
  slingshot: 'Ketapel kayu: batu berputar dengan lintasan melengkung. Senyap.',
  blowgun: 'Sumpit Dayak: jarum tipis, cepat, dan benar-benar senyap.',
  sniper: 'Peluru super cepat yang menembus 4 musuh & pintu. Klik kanan = scope + laser.',
  flamethrower: 'Semburan bola api jarak pendek. Musuh terbakar dan terus kena damage.',
  plasma: 'Bola plasma hijau yang lambat tapi sakit, meninggalkan jejak cahaya.',
  laser: 'Sinar merah instan: begitu ditembak langsung kena, tanpa waktu terbang.',
  rpg: 'Roket berasap yang MELEDAK saat kena apa pun. Awas ledakan dekat kaki sendiri!',
  bamboo: 'Meriam bambu Lebaran: DUARR! Ledakan putih penuh serpihan kertas petasan.',
  fish: 'Menembakkan ikan dengan gelembung air. 35% peluang IKAN HOKI = bonus skor.',
  minigun: 'Laras berputar makin kencang selama klik ditahan. 150 peluru, hujan timah!',
  railgun: 'Sinar rel biru instan yang menembus SEMUA musuh dan pintu dalam satu garis.',
  electro: 'Bola listrik: saat kena, petir meloncat berantai ke 2 musuh terdekat.',
  bazooka: 'Roket besar dan lambat dengan ledakan paling lebar di kelas roket.',
  keris: 'Keris sakti melayang bertabur cahaya emas, menembus sampai 3 musuh. Senyap.',
  shark: 'Meluncurkan hiu! Damage tinggi, hentakan besar, cipratan air di mana-mana.',
  ghost: 'Peluru hantu gaib yang MENEMBUS tembok dan pintu. Musuh tidak bisa berlindung.',
  freeze: 'Serpihan es yang MEMBEKUKAN musuh 2 detik di tempat.',
  golden: 'Pistol emas 7 peluru: damage besar dan +300 skor untuk tiap kill.',
  blackhole: 'Bola lubang hitam: menyeret musuh yang dilewati, lalu menyedot semua di titik tumbukan.',
  dragon: 'Napas naga: bola api yang membakar musuh. Damage 2x ke bos!',
  meteor: 'Meteor berapi dengan ledakan TERBESAR di game. 3 peluru, pakai dengan bijak.',
  diamond: 'Peluru kristal berkilau, tembus 1 musuh. 25% peluang BERLIAN = +400 skor.',
  holy: 'Sinar suci instan dengan pilar cahaya. Menembus 3 musuh sekaligus.',
};

function hexToRgb(c: string): string {
  if (!c.startsWith('#')) return c;
  let h = c.slice(1);
  if (h.length === 3) h = h.split('').map((ch) => ch + ch).join('');
  return `${parseInt(h.slice(0, 2), 16)},${parseInt(h.slice(2, 4), 16)},${parseInt(h.slice(4, 6), 16)}`;
}

export const HALO_SPECS: Record<string, HaloSpec> = {};
export const HALO_ORDER: HaloId[] = [];

for (const def of HALO_DEFS) {
  const row = ROWS[def.id];
  if (!row) continue;
  const id = `h_${def.id}` as HaloId;
  const spec: HaloSpec = {
    id,
    art: def.id,
    def,
    name: def.name,
    rarity: def.rarity as HaloRarity,
    perk: def.perk,
    color: def.color,
    rgb: def.trail,
    sparks: def.sparks.map(hexToRgb),
    len: Math.round(row.len * 1.2),
    two: !!row.two,
    gy: row.g[0],
    gx: row.g[1],
    fore: row.fore ?? 0.3,
    flip: !!row.flip,
    mag: row.mag,
    cd: row.cd,
    cdMin: row.cd,
    dmg: row.dmg,
    speed: row.speed,
    life: 0.55,
    pellets: 1,
    spread: 0.012,
    pierce: 0,
    pow: 650,
    kick: 2.4,
    shake: 1.8,
    ps: 0.42,
    sound: 'bullet',
    beam: false,
    explode: 0,
    phase: false,
    burn: false,
    freeze: false,
    chain: false,
    pull: false,
    gravity: 0,
    silent: false,
    scope: false,
    spinup: false,
    spin: false,
    bossMul: 1,
    bonus: '',
    heat: 0,
    ...(row.x ?? {}),
  };
  HALO_SPECS[id] = spec;
  HALO_ORDER.push(id);
}

export function isHaloId(s: unknown): s is HaloId {
  return typeof s === 'string' && s.charCodeAt(0) === 104 && s.charCodeAt(1) === 95 && s in HALO_SPECS;
}

export function haloSpec(id: string): HaloSpec {
  return HALO_SPECS[id];
}

// ------------------------------------------------------------------ live state
/** keadaan animasi senjata yang sedang dipegang pemain; diisi game tiap frame */
export const haloLive = {
  time: 0,
  sinceShot: 9,
  spin: 0,
  spinAngle: 0,
  charge: 0,
  ammoRatio: 1,
  shots: 0,
  ready: true,
};

function applyGunState(live: boolean) {
  const gs = gunState as Record<string, unknown>;
  gs.sinceShot = live ? haloLive.sinceShot : 9;
  gs.reloadT = 0;
  gs.spin = live ? haloLive.spin : 0;
  gs.spinAngle = live ? haloLive.spinAngle : 0;
  gs.charge = live ? haloLive.charge : 0;
  gs.ammoRatio = live ? haloLive.ammoRatio : 1;
  gs.shots = live ? haloLive.shots : 0;
  gs.inPreview = !live;
  gs.bigShot = 0;
}

// ------------------------------------------------------------------ zip (SVG) art
interface ZipRaster {
  art: HaloZipArt;
  /** panjang moncong -> popor dalam unit SVG */
  len: number;
  idle: HTMLCanvasElement | null;
  fire: HTMLCanvasElement | null;
  /** kotak potong (unit SVG) */
  cx: number;
  cy: number;
  cw: number;
  ch: number;
  failed: boolean;
}

const RASTER_PX = 340;
const zipRasters: Record<string, ZipRaster> = {};
let artVersion = 0;
/** naik tiap kali sebuah art SVG selesai dirender (untuk menggambar ulang ikon) */
export const haloArtVersion = () => artVersion;

function buildSvg(markup: string, cx: number, cy: number, cw: number, ch: number, pxPerUnit: number, firing: boolean): string {
  const w = Math.ceil(cw * pxPerUnit);
  const h = Math.ceil(ch * pxPerUnit);
  let s = markup.replace(/viewBox="[^"]*"/, `viewBox="${cx} ${cy} ${cw} ${ch}" width="${w}" height="${h}"`);
  s = s.replace(/^<svg style="[^"]*"/, '<svg');
  if (firing) {
    s = s.replace(/class="weapon-svg/, 'class="weapon-svg wx-is-firing');
    s = s.replace(/(<svg[^>]*>)/, '$1<style>*{animation-play-state:paused!important;animation-delay:-0.07s!important}</style>');
  }
  return s;
}

function rasterize(svg: string, w: number, h: number, done: (cv: HTMLCanvasElement | null) => void) {
  const img = new Image();
  img.onload = () => {
    try {
      const cv = document.createElement('canvas');
      cv.width = w;
      cv.height = h;
      const c = cv.getContext('2d');
      if (!c) return done(null);
      c.drawImage(img, 0, 0, w, h);
      done(cv);
    } catch {
      done(null);
    }
  };
  img.onerror = () => done(null);
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}

function initZip(artId: string) {
  const art = HALO_ZIP[artId];
  if (!art) return;
  const ink = art.ink;
  const len = Math.max(1, ink.y1 - ink.muzzleY);
  const mx = 70;
  const top = 150;
  const cx = ink.x0 - mx;
  const cy = Math.min(ink.y0, ink.muzzleY) - top;
  const cw = ink.x1 - ink.x0 + mx * 2;
  const ch = ink.y1 + 40 - cy;
  const r: ZipRaster = { art, len, idle: null, fire: null, cx, cy, cw, ch, failed: false };
  zipRasters[artId] = r;
  const ppu = RASTER_PX / len;
  const w = Math.ceil(cw * ppu);
  const h = Math.ceil(ch * ppu);
  rasterize(buildSvg(art.markup, cx, cy, cw, ch, ppu, false), w, h, (cv) => {
    if (cv) r.idle = cv;
    else r.failed = true;
    artVersion++;
  });
  const fireSrc = art.fireMarkup
    ? buildSvg(art.fireMarkup, cx, cy, cw, ch, ppu, false)
    : /wx-is-firing/.test(art.markup)
      ? buildSvg(art.markup, cx, cy, cw, ch, ppu, true)
      : null;
  if (fireSrc) {
    rasterize(fireSrc, w, h, (cv) => {
      r.fire = cv;
      artVersion++;
    });
  }
}

let zipStarted = false;
/** mulai merender semua art SVG (dipanggil sekali; aman dipanggil berulang) */
export function preloadHaloArt() {
  if (zipStarted || typeof document === 'undefined') return;
  zipStarted = true;
  const ids = Object.keys(HALO_ZIP);
  ids.forEach((id, i) => setTimeout(() => initZip(id), 30 + i * 45));
}

/**
 * Gambar art tegak: moncong di (0,0), laras ke -y, panjang senjata = 1 unit.
 * `flash` 0..1 = kilatan moncong.
 */
function drawArtUnit(ctx: CanvasRenderingContext2D, spec: HaloSpec, flash: number, live: boolean) {
  const artId = spec.art;
  const t = haloLive.time;
  applyGunState(live);
  const z = zipRasters[artId];
  const canvasLen = getGunMetrics(artId).totalLen;
  if (z && z.idle) {
    const k = 1 / z.len;
    const firing = live && z.fire && (flash > 0 || haloLive.sinceShot < 0.09);
    const cv = firing ? (z.fire as HTMLCanvasElement) : z.idle;
    ctx.save();
    ctx.scale(k, k);
    ctx.drawImage(cv, z.cx - z.art.ink.muzzleX, z.cy - z.art.ink.muzzleY, z.cw, z.ch);
    ctx.restore();
    if (flash > 0) {
      ctx.save();
      ctx.scale(1 / canvasLen, 1 / canvasLen);
      try {
        artDrawFlash(ctx, artId, 0, 0, t, flash);
      } catch {
        /* art tanpa kilatan khusus */
      }
      ctx.restore();
    }
    return;
  }
  ctx.save();
  ctx.scale(1 / canvasLen, 1 / canvasLen);
  try {
    artDrawGun(ctx, artId, 0, 0, t, flash, live ? haloLive.ready : true);
  } catch {
    /* jangan pernah menjatuhkan game karena satu gambar */
  }
  ctx.restore();
}

/** untuk lembar kontak / debugging: art tegak, panjang = `len` px */
export function drawHaloUpright(ctx: CanvasRenderingContext2D, id: string, x: number, y: number, len: number, flash = 0) {
  const spec = HALO_SPECS[id];
  if (!spec) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(len, len);
  drawArtUnit(ctx, spec, flash, flash > 0);
  ctx.restore();
}

/**
 * Senjata di tangan: (x,y) = posisi tangan (gagang), `angle` = arah bidik.
 * Moncong dijamin menghadap `angle`; saat membidik ke kiri art dicerminkan
 * agar gagang & magasin tetap di bawah.
 */
export function drawHaloGun(ctx: CanvasRenderingContext2D, id: string, x: number, y: number, angle: number, flashT: number, live = true) {
  const spec = HALO_SPECS[id];
  if (!spec) return;
  const flash = clamp01(flashT / 0.07);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle + Math.PI / 2);
  const right = Math.cos(angle) >= 0;
  const sx = (right ? 1 : -1) * (spec.flip ? -1 : 1);
  ctx.scale(spec.len * sx, spec.len);
  ctx.translate(-spec.gx * (spec.flip ? -1 : 1), -spec.gy);
  drawArtUnit(ctx, spec, flash, live);
  ctx.restore();
}

/** offset moncong dari tangan: sepanjang laras & tegak lurus (gaya `Player.muzzle`) */
export function haloMuzzleOffset(id: string): { along: number; ly: number } {
  const s = HALO_SPECS[id];
  return { along: s.gy * s.len, ly: -s.gx * s.len };
}

const ICON_W = 208;
const ICON_H = 112;
const iconCache = new Map<string, { cv: HTMLCanvasElement; ver: number }>();

function renderIcon(ctx: CanvasRenderingContext2D, spec: HaloSpec) {
  const thick = spec.art === 'holy' ? 0.95 : spec.art === 'crossbow' || spec.art === 'dragon' ? 0.8 : 0.52;
  const s = Math.min(ICON_W * 0.94, ICON_H / thick);
  ctx.save();
  ctx.translate(ICON_W / 2, ICON_H / 2);
  ctx.rotate(Math.PI / 2);
  ctx.scale(s * (spec.flip ? -1 : 1), s);
  ctx.translate(-(spec.gx * 0.45) * (spec.flip ? -1 : 1), -0.5);
  drawArtUnit(ctx, spec, 0, false);
  ctx.restore();
}

/**
 * ikon mendatar (moncong ke kanan) yang pas di kotak w x h berpusat di (cx,cy).
 * Art-nya dirender sekali ke kanvas kecil lalu dipakai ulang (HUD menggambar 9 ikon tiap frame).
 */
export function drawHaloIcon(ctx: CanvasRenderingContext2D, id: string, cx: number, cy: number, w: number, h: number) {
  const spec = HALO_SPECS[id];
  if (!spec) return;
  let ic = iconCache.get(id);
  if (!ic || ic.ver !== artVersion) {
    const cv = ic ? ic.cv : document.createElement('canvas');
    cv.width = ICON_W;
    cv.height = ICON_H;
    const c = cv.getContext('2d');
    if (c) renderIcon(c, spec);
    ic = { cv, ver: artVersion };
    iconCache.set(id, ic);
  }
  const k = Math.min(w / ICON_W, h / ICON_H);
  ctx.drawImage(ic.cv, cx - (ICON_W * k) / 2, cy - (ICON_H * k) / 2, ICON_W * k, ICON_H * k);
}

// ------------------------------------------------------------------ projectiles
export interface HaloBulletLike {
  x: number;
  y: number;
  vx: number;
  vy: number;
  sx: number;
  sy: number;
  age?: number;
}

const glowCache = new Map<string, HTMLCanvasElement>();
function glowSprite(rgb: string): HTMLCanvasElement {
  let cv = glowCache.get(rgb);
  if (cv) return cv;
  cv = document.createElement('canvas');
  cv.width = 64;
  cv.height = 64;
  const c = cv.getContext('2d') as CanvasRenderingContext2D;
  const g = c.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.22, `rgba(${rgb},0.85)`);
  g.addColorStop(0.55, `rgba(${rgb},0.28)`);
  g.addColorStop(1, `rgba(${rgb},0)`);
  c.fillStyle = g;
  c.fillRect(0, 0, 64, 64);
  glowCache.set(rgb, cv);
  return cv;
}

/** proyektil asli Halo, ujungnya di posisi peluru dan searah lajunya */
export function drawHaloBullet(ctx: CanvasRenderingContext2D, spec: HaloSpec, b: HaloBulletLike) {
  const sp = Math.hypot(b.vx, b.vy) || 1;
  const ux = b.vx / sp;
  const uy = b.vy / sp;
  const def = spec.def;
  const age = b.age ?? 0;
  const travelled = Math.hypot(b.x - b.sx, b.y - b.sy);
  // jejak cahaya pendek di belakang peluru
  const tailMax = def.trailFx === 'none' ? 80 : 46;
  const tail = Math.min(tailMax, travelled);
  if (tail > 4) {
    const tx = b.x - ux * tail;
    const ty = b.y - uy * tail;
    const g = ctx.createLinearGradient(tx, ty, b.x, b.y);
    g.addColorStop(0, `rgba(${spec.rgb},0)`);
    g.addColorStop(1, `rgba(${spec.rgb},${def.trailFx === 'none' ? 0.75 : 0.5})`);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    ctx.strokeStyle = g;
    ctx.lineWidth = Math.max(1.6, def.half * spec.ps * 1.5);
    ctx.beginPath();
    ctx.moveTo(tx, ty);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.restore();
  }
  if (def.energy || def.trailFx === 'fire' || def.trailFx === 'gold' || def.trailFx === 'void') {
    const r = (10 + def.half * 2.2) * spec.ps * 1.5;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.75;
    ctx.drawImage(glowSprite(spec.rgb), b.x - ux * r * 0.3 - r, b.y - uy * r * 0.3 - r, r * 2, r * 2);
    ctx.restore();
  }
  const len = def.stick + 21;
  ctx.save();
  ctx.translate(b.x, b.y);
  ctx.rotate(Math.atan2(uy, ux) + Math.PI / 2);
  ctx.scale(spec.ps, spec.ps);
  if (spec.spin) {
    ctx.translate(0, len * 0.5);
    ctx.rotate(age * 22);
    ctx.translate(0, -len * 0.5);
  }
  try {
    artDrawProjectile(ctx, def.id, len, haloLive.time, age, false);
  } catch {
    ctx.fillStyle = spec.color;
    ctx.fillRect(-2, 0, 4, len);
  }
  ctx.restore();
}

// ------------------------------------------------------------------ effects
type FxKind = 'glow' | 'ring' | 'beam' | 'bolt' | 'bubble' | 'shard' | 'smoke' | 'star' | 'pillar' | 'paper';

interface Fx {
  k: FxKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  rgb: string;
  g: number;
  drag: number;
  x2: number;
  y2: number;
  rot: number;
  vr: number;
  grow: number;
  w: number;
  seed: number;
}

const ADD: Record<FxKind, boolean> = {
  glow: true, ring: true, beam: true, bolt: true, star: true, pillar: true,
  bubble: false, shard: false, smoke: false, paper: false,
};

export class HaloFx {
  list: Fx[] = [];

  add(p: Partial<Fx> & { k: FxKind; x: number; y: number }): Fx {
    const life = p.life ?? 0.3;
    const f: Fx = {
      vx: 0, vy: 0, size: 6, rgb: '255,255,255', g: 0, drag: 0, x2: 0, y2: 0, rot: 0, vr: 0, grow: 0, w: 2,
      seed: Math.random() * 1000,
      ...p,
      life,
      max: life,
    };
    if (this.list.length > 1100) this.list.splice(0, 120);
    this.list.push(f);
    return f;
  }

  clear() {
    this.list.length = 0;
  }

  update(dt: number) {
    const L = this.list;
    let n = 0;
    for (let i = 0; i < L.length; i++) {
      const f = L[i];
      f.life -= dt;
      if (f.life <= 0) continue;
      if (f.g) f.vy += f.g * dt;
      if (f.drag) {
        const k = Math.exp(-f.drag * dt);
        f.vx *= k;
        f.vy *= k;
      }
      f.x += f.vx * dt;
      f.y += f.vy * dt;
      if (f.grow) f.size = Math.max(0.2, f.size + f.grow * dt);
      if (f.vr) f.rot += f.vr * dt;
      L[n++] = f;
    }
    L.length = n;
  }

  // ---- emitters
  glow(x: number, y: number, rgb: string, size: number, life: number, vx = 0, vy = 0, g = 0, drag = 0, grow = 0) {
    return this.add({ k: 'glow', x, y, rgb, size, life, vx, vy, g, drag, grow });
  }

  ring(x: number, y: number, rgb: string, size: number, life: number, w = 3, implode = false) {
    return this.add({ k: 'ring', x, y, rgb, size, life, w, grow: implode ? -1 : 0 });
  }

  beam(x1: number, y1: number, x2: number, y2: number, rgb: string, w: number, life: number) {
    return this.add({ k: 'beam', x: x1, y: y1, x2, y2, rgb, w, life });
  }

  bolt(x1: number, y1: number, x2: number, y2: number, rgb: string, w = 2, life = 0.16) {
    return this.add({ k: 'bolt', x: x1, y: y1, x2, y2, rgb, w, life });
  }

  sparks(x: number, y: number, nx: number, ny: number, cols: string[], n: number, spd = 220, g = 520, size = 3.2) {
    for (let i = 0; i < n; i++) {
      const a = Math.atan2(ny, nx) + rnd(-1.1, 1.1);
      const v = rnd(0.3, 1) * spd;
      this.add({
        k: 'glow', x, y, rgb: cols[(Math.random() * cols.length) | 0], size: rnd(0.6, 1.2) * size,
        life: rnd(0.16, 0.42), vx: Math.cos(a) * v, vy: Math.sin(a) * v, g, drag: 2.2,
      });
    }
  }

  draw(ctx: CanvasRenderingContext2D, vx0: number, vy0: number, vx1: number, vy1: number) {
    const L = this.list;
    if (!L.length) return;
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    for (let pass = 0; pass < 2; pass++) {
      const add = pass === 1;
      ctx.globalCompositeOperation = add ? 'lighter' : 'source-over';
      for (let i = 0; i < L.length; i++) {
        const f = L[i];
        if (ADD[f.k] !== add) continue;
        const far = f.k === 'beam' || f.k === 'bolt';
        if (!far && (f.x < vx0 - 80 || f.x > vx1 + 80 || f.y < vy0 - 80 || f.y > vy1 + 240)) continue;
        const a = clamp01(f.life / f.max);
        switch (f.k) {
          case 'glow': {
            ctx.globalAlpha = Math.min(1, a * 1.4);
            const s = f.size * (0.55 + 0.45 * a) * 2.6;
            ctx.drawImage(glowSprite(f.rgb), f.x - s, f.y - s, s * 2, s * 2);
            break;
          }
          case 'ring': {
            const r = f.grow < 0 ? f.size * a : f.size * (1 - a * a);
            ctx.globalAlpha = a;
            ctx.strokeStyle = `rgb(${f.rgb})`;
            ctx.lineWidth = Math.max(0.6, f.w * a);
            ctx.beginPath();
            ctx.arc(f.x, f.y, Math.max(0.5, r), 0, TAU);
            ctx.stroke();
            break;
          }
          case 'beam': {
            ctx.globalAlpha = a * 0.3;
            ctx.strokeStyle = `rgb(${f.rgb})`;
            ctx.lineWidth = f.w * 3.4 * (0.5 + 0.5 * a);
            ctx.beginPath();
            ctx.moveTo(f.x, f.y);
            ctx.lineTo(f.x2, f.y2);
            ctx.stroke();
            ctx.globalAlpha = a * 0.75;
            ctx.lineWidth = f.w * 1.5 * (0.4 + 0.6 * a);
            ctx.stroke();
            ctx.globalAlpha = a;
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = Math.max(0.7, f.w * 0.55 * a);
            ctx.stroke();
            break;
          }
          case 'bolt': {
            const dx = f.x2 - f.x;
            const dy = f.y2 - f.y;
            const d = Math.hypot(dx, dy) || 1;
            const segs = Math.max(3, Math.min(14, Math.round(d / 16)));
            const px = -dy / d;
            const py = dx / d;
            ctx.beginPath();
            ctx.moveTo(f.x, f.y);
            for (let s = 1; s < segs; s++) {
              const k = s / segs;
              const off = rnd(-1, 1) * Math.min(14, d * 0.12);
              ctx.lineTo(f.x + dx * k + px * off, f.y + dy * k + py * off);
            }
            ctx.lineTo(f.x2, f.y2);
            ctx.globalAlpha = a * 0.45;
            ctx.strokeStyle = `rgb(${f.rgb})`;
            ctx.lineWidth = f.w * 3;
            ctx.stroke();
            ctx.globalAlpha = a;
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = f.w * 0.8;
            ctx.stroke();
            break;
          }
          case 'star': {
            const tw = 0.55 + 0.45 * Math.sin(f.seed + f.life * 30);
            const s = f.size * a * tw;
            ctx.globalAlpha = Math.min(1, a * 1.3);
            ctx.strokeStyle = `rgb(${f.rgb})`;
            ctx.lineWidth = Math.max(0.5, s * 0.28);
            ctx.beginPath();
            ctx.moveTo(f.x - s, f.y);
            ctx.lineTo(f.x + s, f.y);
            ctx.moveTo(f.x, f.y - s * 1.35);
            ctx.lineTo(f.x, f.y + s * 1.35);
            ctx.stroke();
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(f.x, f.y, s * 0.3, 0, TAU);
            ctx.fill();
            break;
          }
          case 'pillar': {
            const w = f.size * (0.4 + 0.6 * a);
            const g = ctx.createLinearGradient(0, f.y - f.w, 0, f.y);
            g.addColorStop(0, `rgba(${f.rgb},0)`);
            g.addColorStop(0.6, `rgba(${f.rgb},${0.55 * a})`);
            g.addColorStop(1, `rgba(255,255,255,${0.9 * a})`);
            ctx.globalAlpha = 1;
            ctx.fillStyle = g;
            ctx.fillRect(f.x - w, f.y - f.w, w * 2, f.w);
            break;
          }
          case 'smoke': {
            ctx.globalAlpha = a * 0.42;
            ctx.fillStyle = `rgb(${f.rgb})`;
            ctx.beginPath();
            ctx.arc(f.x, f.y, f.size, 0, TAU);
            ctx.fill();
            break;
          }
          case 'bubble': {
            ctx.globalAlpha = Math.min(1, a * 1.6);
            ctx.strokeStyle = `rgba(${f.rgb},0.95)`;
            ctx.fillStyle = `rgba(${f.rgb},0.22)`;
            ctx.lineWidth = 0.9;
            ctx.beginPath();
            ctx.arc(f.x + Math.sin(f.seed + f.life * 9) * 1.6, f.y, f.size, 0, TAU);
            ctx.fill();
            ctx.stroke();
            ctx.fillStyle = 'rgba(255,255,255,0.9)';
            ctx.beginPath();
            ctx.arc(f.x - f.size * 0.3, f.y - f.size * 0.3, f.size * 0.22, 0, TAU);
            ctx.fill();
            break;
          }
          case 'shard':
          case 'paper': {
            ctx.globalAlpha = Math.min(1, a * 1.5);
            ctx.save();
            ctx.translate(f.x, f.y);
            ctx.rotate(f.rot);
            ctx.fillStyle = `rgb(${f.rgb})`;
            ctx.beginPath();
            if (f.k === 'shard') {
              ctx.moveTo(0, -f.size);
              ctx.lineTo(f.size * 0.45, 0);
              ctx.lineTo(0, f.size);
              ctx.lineTo(-f.size * 0.45, 0);
              ctx.closePath();
              ctx.fill();
              ctx.strokeStyle = 'rgba(255,255,255,0.9)';
              ctx.lineWidth = 0.6;
              ctx.stroke();
            } else {
              ctx.rect(-f.size, -f.size * 0.5 * Math.abs(Math.cos(f.rot * 2)), f.size * 2, f.size * Math.abs(Math.cos(f.rot * 2)) + 0.4);
              ctx.fill();
            }
            ctx.restore();
            break;
          }
        }
      }
    }
    ctx.restore();
  }
}

const SMOKE = '214,208,200';
const FIRE = ['255,236,160', '255,170,50', '255,90,20'];

/** efek di moncong saat menembak */
export function haloMuzzleFx(fx: HaloFx, s: HaloSpec, x: number, y: number, ang: number) {
  const ca = Math.cos(ang);
  const sa = Math.sin(ang);
  const def = s.def;
  const hot = !def.energy && !def.noSmoke;
  const big = s.kick >= 8 ? 1.8 : s.kick >= 3 ? 1.25 : 1;
  const flashRgb = hot ? '255,214,120' : s.rgb;
  fx.glow(x + ca * 4, y + sa * 4, flashRgb, 9 * big, 0.09);
  if (def.energy) fx.ring(x + ca * 2, y + sa * 2, s.rgb, 13 * big, 0.2, 2.2);
  if (hot) {
    fx.sparks(x, y, ca, sa, FIRE, big > 1.5 ? 9 : 3, 300 * big, 300, 2.6);
    for (let i = 0; i < (big > 1.5 ? 5 : 2); i++) {
      fx.add({ k: 'smoke', x: x + ca * i * 4, y: y + sa * i * 4, rgb: SMOKE, size: rnd(3, 5) * big, life: rnd(0.4, 0.8), vx: ca * rnd(30, 110), vy: sa * rnd(30, 110) - rnd(10, 30), drag: 2.5, grow: 9 });
    }
  } else if (def.energy) {
    fx.sparks(x, y, ca, sa, s.sparks, 4, 240, 0, 2.6);
  }
  if (def.backblast) {
    const bx = x - ca * s.len * 0.98;
    const by = y - sa * s.len * 0.98;
    for (let i = 0; i < 9; i++) {
      fx.add({ k: 'smoke', x: bx, y: by, rgb: i % 3 === 0 ? '120,112,104' : SMOKE, size: rnd(5, 9), life: rnd(0.5, 1), vx: -ca * rnd(120, 420) + rnd(-40, 40), vy: -sa * rnd(120, 420) - rnd(10, 60), drag: 3, grow: 18 });
    }
    fx.sparks(bx, by, -ca, -sa, FIRE, 8, 380, 200, 3.4);
    fx.glow(bx, by, '255,170,60', 16, 0.14);
  }
  switch (s.art) {
    case 'flamethrower':
    case 'dragon':
      for (let i = 0; i < 4; i++) {
        fx.glow(x + ca * rnd(0, 10), y + sa * rnd(0, 10), FIRE[(Math.random() * 3) | 0], rnd(5, 9), rnd(0.2, 0.4), ca * rnd(120, 320) + rnd(-50, 50), sa * rnd(120, 320) + rnd(-50, 50), -180, 2.5, -8);
      }
      break;
    case 'shotgun':
    case 'bamboo':
      fx.ring(x, y, '255,236,190', 26, 0.22, 3);
      break;
    case 'sniper':
    case 'railgun':
      fx.ring(x, y, s.art === 'railgun' ? s.rgb : '255,255,255', 34, 0.25, 3);
      break;
    case 'fish':
    case 'shark':
      for (let i = 0; i < (s.art === 'shark' ? 9 : 5); i++) {
        fx.add({ k: 'bubble', x: x + rnd(-4, 4), y: y + rnd(-4, 4), rgb: '170,225,255', size: rnd(1.6, 3.6), life: rnd(0.5, 1), vx: ca * rnd(40, 180) + rnd(-40, 40), vy: sa * rnd(40, 180) - rnd(20, 70), g: -60, drag: 2.2 });
      }
      break;
    case 'freeze':
      for (let i = 0; i < 4; i++) {
        fx.add({ k: 'shard', x, y, rgb: '200,240,255', size: rnd(2, 4), life: rnd(0.3, 0.6), vx: ca * rnd(80, 260) + rnd(-70, 70), vy: sa * rnd(80, 260) + rnd(-70, 70), g: 260, drag: 2, rot: rnd(0, TAU), vr: rnd(-9, 9) });
      }
      break;
    case 'golden':
    case 'diamond':
    case 'keris':
    case 'holy':
      for (let i = 0; i < 5; i++) {
        fx.add({ k: 'star', x: x + rnd(-6, 6), y: y + rnd(-6, 6), rgb: s.rgb, size: rnd(3, 6), life: rnd(0.25, 0.55), vx: ca * rnd(20, 140) + rnd(-50, 50), vy: sa * rnd(20, 140) + rnd(-50, 50), drag: 3 });
      }
      break;
    case 'blackhole':
      fx.ring(x, y, s.rgb, 30, 0.26, 3, true);
      break;
    case 'electro':
      for (let i = 0; i < 2; i++) fx.bolt(x, y, x + ca * rnd(14, 30) + rnd(-12, 12), y + sa * rnd(14, 30) + rnd(-12, 12), s.rgb, 1.4, 0.1);
      break;
  }
}

/** jejak di belakang proyektil (dipanggil kira-kira tiap 12 px lintasan) */
export function haloTrailFx(fx: HaloFx, s: HaloSpec, x: number, y: number, ux: number, uy: number) {
  const px = -uy;
  const py = ux;
  switch (s.def.trailFx) {
    case 'glow':
      fx.glow(x + rnd(-1.5, 1.5), y + rnd(-1.5, 1.5), s.rgb, rnd(3, 5), rnd(0.18, 0.32), -ux * 30, -uy * 30, 0, 0, -6);
      if (s.art === 'ghost' && Math.random() < 0.5) fx.glow(x, y, '235,238,255', rnd(4, 7), rnd(0.4, 0.7), rnd(-20, 20), rnd(-70, -30), 0, 1.5, -5);
      break;
    case 'smoke':
      fx.add({ k: 'smoke', x: x + rnd(-2, 2), y: y + rnd(-2, 2), rgb: Math.random() < 0.3 ? '150,144,138' : SMOKE, size: rnd(3, 5.5), life: rnd(0.5, 0.95), vx: rnd(-18, 18), vy: rnd(-34, -8), drag: 1.5, grow: 10 });
      fx.glow(x, y, FIRE[(Math.random() * 3) | 0], rnd(3.5, 6), rnd(0.1, 0.2), -ux * 80, -uy * 80, 0, 0, -10);
      break;
    case 'spark': {
      const o = rnd(-1, 1);
      fx.glow(x, y, s.sparks[(Math.random() * s.sparks.length) | 0], rnd(1.6, 3), rnd(0.15, 0.3), px * o * 170, py * o * 170, 0, 4);
      if (Math.random() < 0.3) fx.bolt(x, y, x - ux * rnd(8, 20) + px * rnd(-10, 10), y - uy * rnd(8, 20) + py * rnd(-10, 10), s.rgb, 1, 0.08);
      break;
    }
    case 'bubble':
      fx.add({ k: 'bubble', x: x + rnd(-3, 3), y: y + rnd(-3, 3), rgb: '170,225,255', size: rnd(1.4, 3.4), life: rnd(0.5, 1.1), vx: rnd(-20, 20), vy: rnd(-70, -25), drag: 1.2 });
      if (Math.random() < 0.5) fx.glow(x, y, s.rgb, rnd(2, 3.5), 0.2, px * rnd(-60, 60), py * rnd(-60, 60) + 40, 400);
      break;
    case 'frost':
      fx.glow(x, y, s.rgb, rnd(3, 5), rnd(0.2, 0.36), 0, 0, 0, 0, -5);
      if (Math.random() < 0.6) fx.add({ k: 'shard', x, y, rgb: '215,245,255', size: rnd(1.4, 2.8), life: rnd(0.35, 0.7), vx: rnd(-30, 30), vy: rnd(10, 60), g: 160, rot: rnd(0, TAU), vr: rnd(-8, 8) });
      break;
    case 'gold':
      fx.add({ k: 'star', x: x + rnd(-3, 3), y: y + rnd(-3, 3), rgb: s.rgb, size: rnd(2.4, 4.6), life: rnd(0.3, 0.6), vx: rnd(-20, 20), vy: rnd(10, 50), drag: 1 });
      if (Math.random() < 0.4) fx.glow(x, y, s.rgb, rnd(2.5, 4), 0.2);
      break;
    case 'void': {
      const ph = haloLive.time * 22;
      const o = Math.sin(ph) * 7;
      fx.glow(x + px * o, y + py * o, s.rgb, rnd(3, 5.5), rnd(0.25, 0.45), -ux * 20, -uy * 20, 0, 0, -6);
      fx.glow(x - px * o, y - py * o, '90,40,170', rnd(3, 5), rnd(0.25, 0.4), 0, 0, 0, 0, -6);
      break;
    }
    case 'fire':
      fx.glow(x + rnd(-2, 2), y + rnd(-2, 2), FIRE[(Math.random() * 3) | 0], rnd(4, 7.5), rnd(0.22, 0.45), rnd(-30, 30) - ux * 40, rnd(-90, -30) - uy * 40, -120, 1.5, -9);
      if (Math.random() < 0.35) fx.add({ k: 'smoke', x, y, rgb: '90,84,80', size: rnd(3, 5), life: rnd(0.4, 0.8), vx: rnd(-15, 15), vy: rnd(-50, -20), drag: 1.5, grow: 9 });
      break;
    default:
      break;
  }
}

/** efek tumbukan di (x,y); (nx,ny) = arah pantul / normal */
export function haloImpactFx(fx: HaloFx, s: HaloSpec, x: number, y: number, nx: number, ny: number) {
  const def = s.def;
  fx.glow(x, y, def.energy ? s.rgb : '255,232,180', def.energy ? 13 : 8, 0.12);
  fx.sparks(x, y, nx, ny, s.sparks, def.energy ? 8 : 5, 260, def.energy ? 120 : 560, 3);
  if (def.energy) fx.ring(x, y, s.rgb, 22, 0.24, 2.4);
  const bf = def.burstFx;
  if (bf) {
    for (let i = 0; i < bf.n; i++) {
      const a = Math.atan2(ny, nx) + rnd(-1.5, 1.5);
      const v = rnd(0.35, 1) * (bf.spd ?? 200);
      fx.add({ k: 'glow', x, y, rgb: hexToRgb(bf.colors[i % bf.colors.length]), size: rnd(0.5, 1) * (bf.size ?? 5) * 0.62, life: rnd(0.25, 0.6), vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: (bf.g ?? 300) * 0.7, drag: 1.6 });
    }
  }
  switch (s.art) {
    case 'freeze':
      fx.ring(x, y, '210,244,255', 30, 0.32, 3);
      for (let i = 0; i < 8; i++) {
        const a = rnd(0, TAU);
        fx.add({ k: 'shard', x, y, rgb: '205,240,255', size: rnd(2.4, 5), life: rnd(0.4, 0.8), vx: Math.cos(a) * rnd(60, 240), vy: Math.sin(a) * rnd(60, 240) - 40, g: 420, drag: 1.5, rot: rnd(0, TAU), vr: rnd(-10, 10) });
      }
      break;
    case 'fish':
    case 'shark':
      for (let i = 0; i < (s.art === 'shark' ? 10 : 6); i++) {
        fx.add({ k: 'bubble', x: x + rnd(-6, 6), y: y + rnd(-6, 6), rgb: '170,225,255', size: rnd(1.6, 4), life: rnd(0.5, 1.1), vx: rnd(-70, 70), vy: rnd(-120, -30), drag: 1.6 });
      }
      if (s.art === 'shark') fx.ring(x, y, '190,235,255', 36, 0.3, 3.4);
      break;
    case 'blackhole':
      fx.ring(x, y, s.rgb, 70, 0.4, 4, true);
      fx.ring(x, y, '255,255,255', 40, 0.28, 2, true);
      for (let i = 0; i < 12; i++) {
        const a = rnd(0, TAU);
        const d = rnd(30, 70);
        fx.glow(x + Math.cos(a) * d, y + Math.sin(a) * d, i % 2 ? s.rgb : '90,40,170', rnd(3, 6), rnd(0.3, 0.5), -Math.cos(a) * d * 2.6, -Math.sin(a) * d * 2.6, 0, 0, -6);
      }
      break;
    case 'holy':
      fx.add({ k: 'pillar', x, y: y + 8, rgb: '255,236,170', size: 12, w: 210, life: 0.45 });
      fx.ring(x, y, '255,244,200', 42, 0.36, 3);
      for (let i = 0; i < 9; i++) fx.add({ k: 'star', x: x + rnd(-16, 16), y: y + rnd(-30, 10), rgb: '255,240,180', size: rnd(3, 7), life: rnd(0.4, 0.9), vx: rnd(-40, 40), vy: rnd(-120, -30), drag: 1.5 });
      break;
    case 'golden':
    case 'diamond':
    case 'keris':
      for (let i = 0; i < 7; i++) fx.add({ k: 'star', x: x + rnd(-8, 8), y: y + rnd(-8, 8), rgb: s.rgb, size: rnd(3, 6.5), life: rnd(0.3, 0.7), vx: rnd(-110, 110), vy: rnd(-150, 20), g: 240, drag: 1.5 });
      if (s.art === 'diamond') {
        for (let i = 0; i < 4; i++) fx.add({ k: 'shard', x, y, rgb: '190,248,255', size: rnd(2, 4), life: rnd(0.4, 0.7), vx: rnd(-150, 150), vy: rnd(-200, -40), g: 620, rot: rnd(0, TAU), vr: rnd(-12, 12) });
      }
      break;
    case 'electro':
    case 'railgun':
      for (let i = 0; i < 4; i++) {
        const a = rnd(0, TAU);
        const d = rnd(16, 40);
        fx.bolt(x, y, x + Math.cos(a) * d, y + Math.sin(a) * d, s.rgb, 1.3, rnd(0.08, 0.18));
      }
      break;
    case 'plasma':
      fx.glow(x, y, s.rgb, 20, 0.22);
      fx.ring(x, y, '214,255,233', 34, 0.3, 3);
      break;
    case 'flamethrower':
    case 'dragon':
    case 'meteor':
      for (let i = 0; i < 7; i++) fx.glow(x + rnd(-6, 6), y + rnd(-6, 6), FIRE[(Math.random() * 3) | 0], rnd(5, 10), rnd(0.3, 0.6), rnd(-60, 60), rnd(-150, -40), -120, 1.5, -9);
      break;
    case 'ghost':
      for (let i = 0; i < 6; i++) fx.glow(x + rnd(-8, 8), y + rnd(-8, 8), '225,230,255', rnd(4, 8), rnd(0.4, 0.8), rnd(-30, 30), rnd(-90, -30), 0, 1.2, -6);
      break;
    case 'bamboo':
      for (let i = 0; i < 16; i++) {
        const a = rnd(0, TAU);
        fx.add({ k: 'paper', x, y, rgb: i % 3 === 0 ? '255,255,255' : i % 3 === 1 ? '240,60,60' : '253,230,138', size: rnd(1.6, 3), life: rnd(0.7, 1.4), vx: Math.cos(a) * rnd(60, 330), vy: Math.sin(a) * rnd(60, 330) - 80, g: 300, drag: 2, rot: rnd(0, TAU), vr: rnd(-9, 9) });
      }
      fx.ring(x, y, '255,255,255', 90, 0.4, 5);
      break;
    case 'laser':
      fx.glow(x, y, s.rgb, 11, 0.2);
      break;
    default:
      break;
  }
}

/** ledakan berwarna khas senjata, di atas ledakan bawaan engine */
export function haloExplodeFx(fx: HaloFx, s: HaloSpec, x: number, y: number, r: number) {
  fx.ring(x, y, s.rgb, r * 0.95, 0.45, 6);
  fx.ring(x, y, '255,255,255', r * 0.6, 0.3, 3);
  fx.glow(x, y, s.rgb, r * 0.42, 0.28);
  const cols = s.art === 'bamboo' ? ['255,255,255', '253,230,138', '248,113,113'] : FIRE;
  for (let i = 0; i < 22; i++) {
    const a = rnd(0, TAU);
    const v = rnd(120, 520);
    fx.add({ k: 'glow', x, y, rgb: cols[i % cols.length], size: rnd(3, 7), life: rnd(0.35, 0.8), vx: Math.cos(a) * v, vy: Math.sin(a) * v - 60, g: 420, drag: 1.8 });
  }
  if (s.art === 'meteor') {
    for (let i = 0; i < 10; i++) {
      const a = rnd(-Math.PI, 0);
      fx.add({ k: 'shard', x, y, rgb: '120,60,30', size: rnd(3, 6), life: rnd(0.6, 1.1), vx: Math.cos(a) * rnd(140, 420), vy: Math.sin(a) * rnd(200, 520), g: 900, rot: rnd(0, TAU), vr: rnd(-12, 12) });
    }
  }
}

/** sinar instan (laser / railgun / holy) dari moncong ke titik akhir */
export function haloBeamFx(fx: HaloFx, s: HaloSpec, x1: number, y1: number, x2: number, y2: number) {
  const d = Math.hypot(x2 - x1, y2 - y1) || 1;
  const ux = (x2 - x1) / d;
  const uy = (y2 - y1) / d;
  if (s.art === 'laser') {
    fx.beam(x1, y1, x2, y2, s.rgb, 2.6, 0.16);
  } else if (s.art === 'railgun') {
    fx.beam(x1, y1, x2, y2, s.rgb, 4.2, 0.42);
    const n = Math.min(46, Math.floor(d / 26));
    for (let i = 0; i < n; i++) {
      const k = (i + Math.random()) / n;
      const ph = k * d * 0.12;
      const o = Math.sin(ph) * 7;
      fx.glow(x1 + ux * d * k - uy * o, y1 + uy * d * k + ux * o, i % 2 ? s.rgb : '255,255,255', rnd(1.8, 3.2), rnd(0.3, 0.6), -uy * o * 6, ux * o * 6, 0, 3);
    }
    for (let i = 0; i < 3; i++) {
      const k = Math.random();
      fx.bolt(x1 + ux * d * k, y1 + uy * d * k, x1 + ux * d * k + rnd(-26, 26), y1 + uy * d * k + rnd(-26, 26), s.rgb, 1.1, 0.14);
    }
  } else {
    fx.beam(x1, y1, x2, y2, '255,236,170', 6.5, 0.4);
    fx.beam(x1, y1, x2, y2, '255,255,255', 2.4, 0.5);
    const n = Math.min(34, Math.floor(d / 34));
    for (let i = 0; i < n; i++) {
      const k = (i + Math.random()) / n;
      fx.add({ k: 'star', x: x1 + ux * d * k + rnd(-7, 7), y: y1 + uy * d * k + rnd(-7, 7), rgb: '255,240,180', size: rnd(2.6, 5.5), life: rnd(0.35, 0.8), vx: rnd(-20, 20), vy: rnd(-60, -10), drag: 1 });
    }
  }
}

/** efek status di tubuh musuh: terbakar / beku */
export function haloStatusFx(fx: HaloFx, kind: 'burn' | 'freeze', x: number, y: number, h: number) {
  if (kind === 'burn') {
    fx.glow(x + rnd(-10, 10), y - rnd(0.1, 0.9) * h, FIRE[(Math.random() * 3) | 0], rnd(5, 9), rnd(0.25, 0.5), rnd(-20, 20), rnd(-120, -50), -100, 1.5, -9);
    if (Math.random() < 0.3) fx.add({ k: 'smoke', x: x + rnd(-8, 8), y: y - h, rgb: '70,66,62', size: rnd(3, 5), life: rnd(0.5, 0.9), vx: rnd(-12, 12), vy: rnd(-70, -30), drag: 1.2, grow: 9 });
  } else {
    fx.glow(x + rnd(-12, 12), y - rnd(0.05, 0.95) * h, '170,230,255', rnd(4, 7), rnd(0.25, 0.45), 0, 0, 0, 0, -5);
    if (Math.random() < 0.4) fx.add({ k: 'shard', x: x + rnd(-13, 13), y: y - rnd(0.1, 0.95) * h, rgb: '215,245,255', size: rnd(2, 4), life: rnd(0.4, 0.8), vx: rnd(-14, 14), vy: rnd(10, 50), g: 120, rot: rnd(0, TAU), vr: rnd(-5, 5) });
  }
}
