// @ts-nocheck — art asli dari game Halo, dipakai apa adanya
import { storage } from './safeStorage';

export type WeaponId =
  // UMUM (7)
  | 'pistol' | 'ak47' | 'nail' | 'crossbow' | 'shotgun' | 'slingshot' | 'blowgun'
  // LANGKA (7)
  | 'sniper' | 'flamethrower' | 'plasma' | 'laser' | 'rpg' | 'bamboo' | 'fish'
  // EPIC (7)
  | 'minigun' | 'railgun' | 'electro' | 'bazooka' | 'keris' | 'shark' | 'ghost'
  // LEGENDARIS (7)
  | 'freeze' | 'golden' | 'blackhole' | 'dragon' | 'meteor' | 'diamond' | 'holy';

export type ProjKind = WeaponId | 'old';
export type Rarity = 'UMUM' | 'LANGKA' | 'EPIC' | 'LEGENDARIS';
export type TrailFx = 'none' | 'glow' | 'smoke' | 'spark' | 'bubble' | 'frost' | 'gold' | 'void' | 'fire';
export type SaveFx = 'return' | 'bubble' | 'portal' | 'glitch' | 'mirror';

export interface BurstFx { colors: string[]; n: number; glow?: boolean; g?: number; spd?: number; size?: number }

export interface Weapon {
  id: WeaponId;
  name: string;
  emoji: string;
  desc: string;
  perk: string;
  rarity: Rarity;
  speed: number;
  cooldown: number;
  auto: boolean;
  points: number;
  ammoDelta?: number;
  coinRadius: number;
  coinValue: number;
  recoil: number;
  shake: number;
  half: number;
  stick: number;
  energy: boolean;
  color: string;
  trail: string;
  trailFx: TrailFx;
  sparks: string[];
  casing?: string;
  ejectY?: number;
  explode?: boolean;
  explodeFx?: 'fire' | 'white';
  slowStyle?: 'ice' | 'water' | 'honey';
  charge?: boolean;
  paint?: boolean;
  meltEvery?: number;
  meltText?: string;
  meltColors?: string[];
  everyBonus?: { n: number; pts: number; text: string };
  randomMagic?: boolean;
  transmute?: number;
  obliterate?: number;
  spinFly?: boolean;
  burnText?: string;
  burnIcon?: string;
  spikeText?: string;
  jackpotText?: string;
  saveText?: string;
  notes?: boolean;
  phaseSpikes?: boolean;
  meltOld?: boolean;
  abductEvery?: number;
  chain?: boolean;
  slow?: boolean;
  slowFactor?: number;
  slowTime?: number;
  slowRgb?: string;
  slowText?: string;
  luckyCoin?: number;
  luckyText?: string;
  pullCoins?: boolean;
  comboWindow?: number;
  backblast?: boolean;
  noSmoke?: boolean;
  burstFx?: BurstFx;
  burst?: number;
  scope?: boolean;
  spinup?: boolean;
  pierceOld?: boolean;
  burn?: boolean;
  saves?: number;
  saveFx?: SaveFx;
  saveSpikeOnly?: boolean;
  reverseChance?: number;
  reverseEvery?: number;
  spikeOff?: number;
  pushSpikes?: boolean;
  chronoEvery?: number;
  shrink?: boolean;
  grow?: boolean;
  snowman?: boolean;
  breakSpike?: boolean;
  randomBonus?: number;
  jackpot?: number;
  confetti?: boolean;
  seed?: boolean;
  bossMult?: number;
  rope?: boolean;
  beam?: boolean;
  previewLen: number;
  previewScale: number;
  previewY: number;
  price?: number;
  coinPrice?: number;
  diamondPrice?: number;
  unlockLevel?: number;
  stats: { rate: number; speed: number; power: number };
}

const base = {
  coinRadius: 15, coinValue: 1, half: 4.75, stick: 30, energy: false, trailFx: 'none' as TrailFx,
  previewLen: 175, previewScale: 0.95, previewY: 30, auto: false, points: 1, recoil: 1, shake: 3,
};
const FIRE = ['#fff3b0', '#ffd23f', '#ff9f1c'];

const ALL_WEAPON_DEFINITIONS: Weapon[] = [
  // ======================== UMUM (7) ========================
  { ...base, id: 'pistol', name: 'SIDEARM', emoji: '🔫', rarity: 'UMUM', perk: 'SEIMBANG', desc: 'Pistol klasik, seimbang di semua hal.',
    speed: 2700, cooldown: 0.12, shake: 15, stick: 17, color: '#ff3030', trail: '255,230,150', sparks: FIRE, casing: '#e0ad40', ejectY: 48, stats: { rate: 3, speed: 3, power: 3 } },
  { ...base, id: 'ak47', name: 'AK-47', emoji: '🪖', rarity: 'UMUM', perk: 'AUTO-FIRE', desc: 'Senapan serbu legendaris. Tahan layar untuk tembak otomatis!',
    speed: 3200, cooldown: 0.085, auto: true, recoil: 3.4, shake: 15, stick: 17, color: '#ff3030', trail: '255,230,150', sparks: FIRE, casing: '#8f9a62', ejectY: 128,
    previewLen: 262, previewScale: 0.86, previewY: 38, stats: { rate: 5, speed: 4, power: 4 } },
  { ...base, id: 'nail', name: 'NAIL GUN', emoji: '🔩', rarity: 'UMUM', perk: 'TIPIS & AUTO', desc: 'Paku super tipis, muat di celah sempit. Tahan untuk tembak beruntun!',
    speed: 3000, cooldown: 0.07, auto: true, recoil: 3.4, shake: 15, half: 2.4, stick: 18, color: '#ffc400', trail: '220,225,230', sparks: ['#ffffff', '#d8dde3', '#ffd23f'],
    previewLen: 200, previewScale: 0.8, previewY: 50, stats: { rate: 5, speed: 3, power: 2 } },
  { ...base, id: 'crossbow', name: 'CROSSBOW', emoji: '🏹', rarity: 'UMUM', perk: 'PRESISI', desc: 'Panah baja yang cepat dan ramping. Hitbox kecil, cocok buat yang presisi.',
    speed: 3600, cooldown: 0.22, recoil: 3.4, shake: 15, half: 3.2, stick: 18, noSmoke: true, unlockLevel: 2, color: '#ff3030', trail: '255,255,255', sparks: ['#ffffff', '#ffd23f', '#d8a060'],
    previewLen: 220, previewScale: 0.85, previewY: 64, stats: { rate: 2, speed: 5, power: 3 } },
  { ...base, id: 'shotgun', name: 'SHOTGUN', emoji: '💥', rarity: 'UMUM', perk: 'TIGA SEKALIGUS', desc: '3 peluru menyebar sekaligus. Cepat selesai, tapi berisiko kena peluru lain!',
    speed: 2700, cooldown: 0.55, recoil: 3.4, shake: 15, half: 4.5, burst: 3, stick: 17, color: '#ff4d2e', trail: '255,200,120', sparks: FIRE, casing: '#d62828', ejectY: 96,
    previewLen: 250, previewScale: 0.82, previewY: 46, stats: { rate: 2, speed: 3, power: 5 } },
  { ...base, id: 'slingshot', name: 'KETAPEL', emoji: '🪨', rarity: 'UMUM', perk: 'KHAS NUSANTARA', desc: 'Ketapel kayu sawo dengan karet ban dalam. Tarik... lepas... CTAK! Batu kali melesat berputar dan hanya nancep sedikit.',
    speed: 2900, cooldown: 0.36, recoil: 3.4, shake: 15, half: 4, stick: 14, noSmoke: true, spinFly: true, color: '#c0803f', trail: '210,200,190', sparks: ['#ffffff', '#c8c0b0', '#8b7d6b'],
    previewLen: 150, previewScale: 1.05, previewY: 32, stats: { rate: 3, speed: 3, power: 2 } },
  { ...base, id: 'blowgun', name: 'SUMPIT DAYAK', emoji: '🎋', rarity: 'UMUM', perk: 'SENYAP & TIPIS', desc: 'Sumpitan tradisional Dayak lengkap dengan mata tombak. Jarumnya paling tipis di game!',
    speed: 3300, cooldown: 0.16, recoil: 3.4, shake: 15, half: 1.5, stick: 16, noSmoke: true, color: '#9ccc65', trail: '230,255,210', sparks: ['#ffffff', '#e8f5c8', '#9ccc65'],
    previewLen: 290, previewScale: 0.78, previewY: 28, stats: { rate: 4, speed: 4, power: 1 } },

  // ======================== LANGKA (7) ========================
  { ...base, id: 'sniper', name: 'SNIPER AWP', emoji: '🎯', rarity: 'LANGKA', perk: 'SLOW-MO SCOPE', desc: 'TAHAN layar untuk membidik dalam slow-motion, LEPAS untuk menembak. 2 poin tiap kena!',
    speed: 7000, cooldown: 0.5, points: 2, recoil: 3.4, shake: 15, half: 3.6, scope: true, color: '#ff2020', trail: '255,240,200', sparks: FIRE, casing: '#e0ad40', ejectY: 150,
    previewLen: 300, previewScale: 0.76, previewY: 50, stats: { rate: 1, speed: 5, power: 4 } },
  { ...base, id: 'flamethrower', name: 'FLAMETHROWER', emoji: '🔥', rarity: 'LANGKA', perk: 'MEMBAKAR', desc: 'Bola api beruntun. Target terbakar dan memberi poin bonus selama api menyala!',
    speed: 1900, cooldown: 0.13, auto: true, recoil: 3.4, shake: 15, half: 5.5, noSmoke: true, burn: true, color: '#ff7a00', trail: '255,140,40', trailFx: 'fire',
    sparks: ['#fff3b0', '#ff9f1c', '#ff4500'], burstFx: { colors: ['255,200,80', '255,120,30', '255,60,20'], n: 8, glow: true, g: -100, spd: 140, size: 8 },
    previewLen: 200, previewY: 34, stats: { rate: 5, speed: 2, power: 3 } },
  { ...base, id: 'plasma', name: 'PLASMA GUN', emoji: '🟢', rarity: 'LANGKA', perk: '2X POIN', desc: 'Peluru plasma lebih lambat, tapi tiap kena dapat 2 poin & koin ikut tertarik.',
    speed: 1700, cooldown: 0.16, points: 2, coinRadius: 30, recoil: 3.4, half: 5, energy: true, unlockLevel: 6, color: '#39ff9c', trail: '57,255,156', trailFx: 'glow',
    sparks: ['#d6ffe9', '#39ff9c', '#00c26e'], stats: { rate: 2, speed: 2, power: 5 } },
  { ...base, id: 'laser', name: 'LASER BEAM', emoji: '🔴', rarity: 'LANGKA', perk: 'INSTAN', desc: 'Secepat cahaya, langsung kena saat ditembak tanpa jeda.',
    speed: 14000, cooldown: 0.14, recoil: 3.4, shake: 15, half: 4.5, energy: true, beam: true, unlockLevel: 8, color: '#ff2a55', trail: '255,42,85', sparks: ['#ffd6de', '#ff2a55', '#ff7a90'],
    stats: { rate: 3, speed: 5, power: 3 } },
  { ...base, id: 'rpg', name: 'RPG-7', emoji: '🚀', rarity: 'LANGKA', perk: 'LEDAKAN 2X', desc: 'Roket anti-tank. Meledak saat kena dan dapat 2 poin!',
    speed: 2100, cooldown: 0.38, points: 2, coinRadius: 22, recoil: 3.4, shake: 15, half: 6.2, price: 80, color: '#ff6a00', trail: '255,170,80', trailFx: 'smoke',
    sparks: ['#fff3b0', '#ff9f1c', '#ff4500'], explode: true, backblast: true, previewLen: 280, previewScale: 0.85, previewY: 40, stats: { rate: 2, speed: 3, power: 5 } },
  { ...base, id: 'bamboo', name: 'MERIAM BAMBU', emoji: '🎍', rarity: 'LANGKA', perk: 'DUARR LEBARAN', desc: 'Meriam bambu khas Lebaran! Petasan meledak DUARR dengan asap putih tebal, 2 poin.',
    speed: 1600, cooldown: 0.5, points: 2, recoil: 3.4, shake: 15, half: 5, color: '#7cb342', trail: '240,240,240', trailFx: 'smoke',
    sparks: ['#ffffff', '#fde68a', '#f87171'], explode: true, explodeFx: 'white', previewLen: 230, previewScale: 0.86, previewY: 40, stats: { rate: 1, speed: 2, power: 5 } },
  { ...base, id: 'fish', name: 'FISH GUN', emoji: '🐟', rarity: 'LANGKA', perk: 'IKAN HOKI', desc: 'Nembak ikan hidup! 35% kemungkinan dapat koin bonus tiap ikan nancep.',
    speed: 1500, cooldown: 0.2, coinRadius: 18, recoil: 3.4, half: 6.2, noSmoke: true, price: 50, color: '#3ec6ff', trail: '120,210,255', trailFx: 'bubble',
    sparks: ['#bfeaff', '#3ec6ff', '#ffffff'], luckyCoin: 0.35, burstFx: { colors: ['#7fd3ff', '#bfeaff', '#ffffff'], n: 10, g: 900 }, stats: { rate: 2, speed: 2, power: 2 } },

  // ======================== EPIC (7) ========================
  { ...base, id: 'minigun', name: 'MINIGUN', emoji: '🌀', rarity: 'EPIC', perk: 'SPIN-UP', desc: 'Tahan layar: laras berputar makin cepat sampai menembak tanpa henti!',
    speed: 3400, cooldown: 0.3, auto: true, spinup: true, recoil: 3.4, shake: 15, half: 3.5, color: '#ff3030', trail: '255,230,150', sparks: FIRE, casing: '#e0ad40', ejectY: 110,
    previewLen: 240, previewScale: 0.8, previewY: 60, stats: { rate: 5, speed: 4, power: 3 } },
  { ...base, id: 'railgun', name: 'RAILGUN', emoji: '🧲', rarity: 'EPIC', perk: 'TEMBUS', desc: 'Peluru elektromagnetik nyaris instan. Bisa menembus 1 peluru LAMA (berkarat) tanpa gagal!',
    speed: 9500, cooldown: 0.35, points: 2, recoil: 3.4, shake: 15, half: 3, energy: true, beam: true, pierceOld: true, color: '#38bdf8', trail: '120,200,255', trailFx: 'spark',
    sparks: ['#ffffff', '#bae6fd', '#38bdf8'], previewLen: 210, previewY: 30, stats: { rate: 2, speed: 5, power: 5 } },
  { ...base, id: 'electro', name: 'ELECTRO GUN', emoji: '⚡', rarity: 'EPIC', perk: 'COMBO+', desc: 'Petir menyambar ke peluru lain. Waktu combo lebih panjang, jadi gampang combo!',
    speed: 2600, cooldown: 0.15, coinRadius: 22, recoil: 3.4, half: 4.5, energy: true, unlockLevel: 12, color: '#5ad1ff', trail: '90,209,255', trailFx: 'spark',
    sparks: ['#ffffff', '#bff1ff', '#5ad1ff'], chain: true, comboWindow: 0.9, stats: { rate: 3, speed: 3, power: 3 } },
  { ...base, id: 'bazooka', name: 'BAZOOKA', emoji: '💣', rarity: 'EPIC', perk: '3X POIN', desc: 'Roket raksasa yang lambat, tapi ledakannya dahsyat. 3 poin tiap kena!',
    speed: 1200, cooldown: 0.5, points: 3, coinRadius: 26, recoil: 3.4, shake: 15, half: 6.5, price: 120, color: '#ff6a00', trail: '255,150,60', trailFx: 'smoke',
    sparks: ['#fff3b0', '#ff9f1c', '#ff4500'], explode: true, backblast: true, previewLen: 270, previewScale: 0.9, previewY: 40, stats: { rate: 1, speed: 1, power: 5 } },
  { ...base, id: 'keris', name: 'KERIS SAKTI', emoji: '🗡️', rarity: 'EPIC', perk: 'TEMBUS GAIB', desc: 'Keris pusaka Jawa berlekuk 5 yang ditembakkan dengan tenaga dalam. Tembus 1 peluru berkarat dan 2 poin!',
    speed: 3000, cooldown: 0.25, points: 2, half: 3, stick: 32, shake: 15, noSmoke: true, pierceOld: true, color: '#4deeea', trail: '77,238,234', trailFx: 'gold',
    sparks: ['#ffffff', '#4deeea', '#ffd056', '#a5f5ff'], previewLen: 220, previewY: 36, stats: { rate: 2, speed: 4, power: 4 } },
  { ...base, id: 'shark', name: 'SHARK LAUNCHER', emoji: '🦈', rarity: 'EPIC', perk: 'GIGITAN HIU', desc: 'Meluncurkan hiu kecil yang lapar. Gigitannya ganas, 3 poin tiap kena!',
    speed: 3400, cooldown: 0.3, points: 3, recoil: 3.4, shake: 15, half: 6.5, stick: 32, noSmoke: true, color: '#0ea5e9', trail: '120,200,255', trailFx: 'bubble',
    sparks: ['#ffffff', '#bae6fd', '#0284c7'], burstFx: { colors: ['#7dd3fc', '#e0f2fe', '#ffffff'], n: 12, g: 900, spd: 180 }, previewLen: 200, previewY: 38, stats: { rate: 2, speed: 4, power: 5 } },
  { ...base, id: 'ghost', name: 'GHOST GUN', emoji: '👻', rarity: 'EPIC', perk: 'TEMBUS DURI', desc: 'Peluru roh hantu yang menembus duri jebakan! Tapi tetap tidak boleh kena peluru lain.',
    speed: 2000, cooldown: 0.22, half: 4.5, energy: true, phaseSpikes: true, color: '#c7d2fe', trail: '220,225,255', trailFx: 'glow',
    sparks: ['#ffffff', '#e0e7ff', '#a5b4fc'], previewY: 34, stats: { rate: 3, speed: 2, power: 3 } },

  // ======================== LEGENDARIS (7) ========================
  { ...base, id: 'freeze', name: 'FREEZE RAY', emoji: '❄️', rarity: 'LEGENDARIS', perk: 'BEKUKAN', desc: 'Tiap tembakan membekukan target sehingga putarannya melambat sebentar.',
    speed: 2200, cooldown: 0.18, recoil: 3.4, shake: 15, energy: true, price: 180, color: '#9be7ff', trail: '155,231,255', trailFx: 'frost',
    sparks: ['#ffffff', '#d6f6ff', '#7fe3ff'], slow: true, slowFactor: 0.3, slowTime: 1.3, slowRgb: '170,230,255', slowText: '❄ BEKU!', previewY: 40, stats: { rate: 3, speed: 3, power: 4 } },
  { ...base, id: 'golden', name: 'GOLDEN GUN', emoji: '🌟', rarity: 'LEGENDARIS', perk: '3X KOIN', desc: 'Pistol emas legendaris ala film James Bond. Koin bernilai 3x dan 2 poin tiap kena.',
    speed: 3000, cooldown: 0.15, points: 2, coinRadius: 18, coinValue: 3, recoil: 3.4, unlockLevel: 20, color: '#ffd23f', trail: '255,215,90', trailFx: 'gold',
    sparks: ['#ffffff', '#fff1a8', '#ffd23f'], casing: '#ffd23f', ejectY: 90, previewScale: 1, previewY: 26, stats: { rate: 3, speed: 4, power: 4 } },
  { ...base, id: 'blackhole', name: 'BLACK HOLE', emoji: '🕳️', rarity: 'LEGENDARIS', perk: 'SEDOT KOIN', desc: 'Menembak lubang hitam mini. Tiap kena, semua koin di target langsung tersedot!',
    speed: 1600, cooldown: 0.25, recoil: 3.4, shake: 15, half: 5, energy: true, price: 250, color: '#a855f7', trail: '168,85,247', trailFx: 'void',
    sparks: ['#ffffff', '#d8b4fe', '#a855f7'], pullCoins: true, stats: { rate: 2, speed: 2, power: 4 } },
  { ...base, id: 'dragon', name: 'DRAGON BREATH', emoji: '🐉', rarity: 'LEGENDARIS', perk: 'PEMBURU BOS', desc: 'Naga api mini yang membakar target. Poin 2x lipat saat melawan BOSS!',
    speed: 2200, cooldown: 0.22, points: 2, recoil: 3.4, shake: 15, half: 6, noSmoke: true, burn: true, bossMult: 2, color: '#ef4444', trail: '255,120,40', trailFx: 'fire',
    sparks: ['#fff3b0', '#ff9f1c', '#ef4444'], burstFx: { colors: ['255,200,80', '255,120,30', '255,40,20'], n: 14, glow: true, g: -80, spd: 200, size: 9 },
    previewLen: 200, previewY: 50, stats: { rate: 3, speed: 3, power: 5 } },
  { ...base, id: 'meteor', name: 'METEOR LAUNCHER', emoji: '☄️', rarity: 'LEGENDARIS', perk: 'HUJAN METEOR', desc: 'Memanggil meteor membara dari luar angkasa. Ledakan dahsyat, hancurkan duri, 4 poin!',
    speed: 1300, cooldown: 0.55, points: 4, recoil: 3.4, shake: 15, half: 7, stick: 20, explode: true, breakSpike: true, color: '#f97316', trail: '255,140,50', trailFx: 'fire',
    sparks: ['#fff3b0', '#fb923c', '#dc2626'], previewY: 38, stats: { rate: 1, speed: 1, power: 5 } },
  { ...base, id: 'diamond', name: 'DIAMOND GUN', emoji: '💎', rarity: 'LEGENDARIS', perk: 'BERLIAN', desc: 'Pistol kristal yang menembakkan berlian. Koin 2x dan 25% kemungkinan JACKPOT +8 koin!',
    speed: 3400, cooldown: 0.16, half: 3, coinValue: 2, jackpot: 0.25, jackpotText: '💎 BERLIAN! +8 💰', noSmoke: true, color: '#67e8f9', trail: '200,250,255', trailFx: 'gold',
    sparks: ['#ffffff', '#cffafe', '#67e8f9'], previewY: 30, stats: { rate: 3, speed: 4, power: 4 } },
  { ...base, id: 'holy', name: 'HOLY LIGHT GUN', emoji: '😇', rarity: 'LEGENDARIS', perk: 'CAHAYA SUCI', desc: 'Senjata bersayap malaikat. Laser cahaya putih secepat kilat menembakkan panah cahaya yang menancap, MENYUCIKAN 1 peluru berkarat setiap kena, plus 1 perisai suci per level.',
    speed: 14000, cooldown: 0.2, points: 2, half: 4, stick: 32, recoil: 3.4, shake: 15, energy: true, beam: true, meltEvery: 1, meltText: '✨ DISUCIKAN!', meltColors: ['255,236,170', '255,255,255', '255,242,176'],
    saves: 1, saveFx: 'bubble', saveText: '😇 PERISAI SUCI!', color: '#fde68a', trail: '255,236,170', sparks: ['#ffffff', '#fff2b0', '#ffd24a'], previewY: 40, stats: { rate: 3, speed: 5, power: 5 } },
];

export const CHEAP_PRICE: Record<Rarity, { coin: number; diamond: number }> = {
  UMUM: { coin: 75, diamond: 0 },
  LANGKA: { coin: 195, diamond: 0 },
  EPIC: { coin: 0, diamond: 34 },
  LEGENDARIS: { coin: 0, diamond: 58 },
};

export function getWeaponCoinPrice(w: Weapon): number {
  if (w.id === 'pistol') return 0;
  if (w.coinPrice !== undefined) return w.coinPrice;
  if (w.price !== undefined) return Math.min(w.price, CHEAP_PRICE[w.rarity].coin);
  return CHEAP_PRICE[w.rarity].coin;
}
export function getWeaponDiamondPrice(w: Weapon): number {
  if (w.id === 'pistol') return 0;
  if (w.diamondPrice !== undefined) return w.diamondPrice;
  return CHEAP_PRICE[w.rarity].diamond;
}
export function getWeaponPriceLabel(w: Weapon): string {
  const c = getWeaponCoinPrice(w);
  const d = getWeaponDiamondPrice(w);
  if (c === 0 && d === 0) return 'FREE';
  if (d > 0 && c === 0) return `${d}💎`;
  if (c > 0 && d === 0) return `${c}🪙`;
  return `${d}💎 / ${c}🪙`;
}
export function isWeaponFree(w: Weapon): boolean {
  return getWeaponCoinPrice(w) === 0 && getWeaponDiamondPrice(w) === 0;
}
export function getWeaponCurrency(w: Weapon): 'coin' | 'diamond' | 'free' {
  if (isWeaponFree(w)) return 'free';
  return getWeaponDiamondPrice(w) > 0 ? 'diamond' : 'coin';
}

export const WEAPONS: Weapon[] = ALL_WEAPON_DEFINITIONS;

export const RARITY_COLOR: Record<Rarity, string> = {
  UMUM: '#9ca3af',
  LANGKA: '#3b82f6',
  EPIC: '#a855f7',
  LEGENDARIS: '#f59e0b',
};

export const getWeapon = (id: string) => WEAPONS.find((w) => w.id === id) || WEAPONS[0];

export function isWeaponUnlocked(w: Weapon, ownedIds: string[] = [], _highestLevel?: number): boolean {
  if (isWeaponFree(w)) return true;
  if (ownedIds.includes(w.id)) return true;
  return false;
}

export function canAffordWithCoins(w: Weapon, coins: number): boolean {
  return coins >= getWeaponCoinPrice(w);
}
export function canAffordWithDiamonds(w: Weapon, diamonds: number): boolean {
  return diamonds >= getWeaponDiamondPrice(w);
}

export const GIFT_RARITY_WEIGHT: Record<Rarity, number> = {
  UMUM: 45,
  LANGKA: 27,
  EPIC: 17,
  LEGENDARIS: 11,
};

export function rollGiftWeapon(excludeId?: string): Weapon {
  const pool = WEAPONS.filter((w) => w.id !== excludeId && w.rarity !== 'LANGKA');
  const source = pool.length > 0 ? pool : WEAPONS;
  const total = source.reduce((s, w) => s + GIFT_RARITY_WEIGHT[w.rarity], 0);
  let r = Math.random() * total;
  for (const w of source) {
    r -= GIFT_RARITY_WEIGHT[w.rarity];
    if (r <= 0) return w;
  }
  return source[source.length - 1];
}

const WEAPON_AMMO: Partial<Record<WeaponId, number>> = {
  // UMUM (7)
  pistol: 0,
  ak47: +3,
  nail: +1,
  crossbow: 0,
  shotgun: +1,
  slingshot: 0,
  blowgun: +2,

  // LANGKA (7)
  sniper: -2,
  flamethrower: +2,
  plasma: -1,
  laser: 0,
  rpg: -3,
  bamboo: +1,
  fish: +1,

  // EPIC (7)
  minigun: +4,
  railgun: -2,
  electro: -1,
  bazooka: -3,
  keris: -1,
  shark: -1,
  ghost: +1,

  // LEGENDARIS (7)
  freeze: -1,
  golden: 0,
  blackhole: -3,
  dragon: -1,
  meteor: -3,
  diamond: -1,
  holy: -2,
};

export function getWeaponAmmoDelta(weapon: Weapon): number {
  return weapon.ammoDelta ?? WEAPON_AMMO[weapon.id] ?? 0;
}

void storage;
