// @ts-nocheck — art asli dari game Halo, dipakai apa adanya
// Pure canvas drawing routines extracted for Keris, Diamond, and Bazooka weapons & projectiles.
const TAU = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

const hsl = (h: number, s: number, l: number, a = 1) =>
  `hsla(${((h % 360) + 360) % 360},${s}%,${l}%,${a})`;

const GOLD = {
  bright: '#fff6cf',
  hi: '#ffe08a',
  mid: '#e8b64c',
  deep: '#b57d16',
  dark: '#8a5a10',
  ink: '#4a2c15',
};

function rgba(hex: string, a: number): string {
  const c = clamp(a, 0, 1);
  if (hex.startsWith('rgba') || hex.startsWith('rgb')) return hex;
  const h = hex.replace('#', '');
  const full = h.length === 3 ? h.split('').map(ch => ch + ch).join('') : h;
  const n = parseInt(full, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${c.toFixed(3)})`;
}

function glowDot(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string, core: string, a: number) {
  ctx.save();
  ctx.globalAlpha = clamp(a * 0.32, 0, 1);
  ctx.beginPath();
  ctx.arc(x, y, r * 2.6, 0, TAU);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.globalAlpha = clamp(a, 0, 1);
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fillStyle = core;
  ctx.fill();
  ctx.restore();
}

type Pt = { x: number; y: number };

function boltPts(x0: number, y0: number, x1: number, y1: number, rough: number, seed = 0): Pt[] {
  let pts: Pt[] = [{ x: x0, y: y0 }, { x: x1, y: y1 }];
  let off = rough;
  let s = seed + 1;
  for (let pass = 0; pass < 4; pass++) {
    const next: Pt[] = [pts[0]];
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i];
      const b = pts[i + 1];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const len = Math.hypot(dx, dy) || 1;
      s = (s * 1664525 + 1013904223) >>> 0;
      const d = (((s & 0xffff) / 0x8000) - 1) * off;
      next.push({ x: (a.x + b.x) / 2 + (-dy / len) * d, y: (a.y + b.y) / 2 + (dx / len) * d });
      next.push(b);
    }
    pts = next;
    off *= 0.5;
  }
  return pts;
}

function strokeJolt(ctx: CanvasRenderingContext2D, pts: Pt[], w: number, alpha: number) {
  if (alpha <= 0.01 || pts.length < 2) return;
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const passes: [number, string][] = [
    [w * 4.2, `rgba(255,170,40,${0.14 * alpha})`],
    [w * 2.1, `rgba(255,205,80,${0.46 * alpha})`],
    [w, `rgba(255,244,200,${0.9 * alpha})`],
    [w * 0.42, `rgba(255,255,252,${0.95 * alpha})`],
  ];
  ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  for (const [width, color] of passes) {
    ctx.lineWidth = width;
    ctx.strokeStyle = color;
    ctx.stroke();
  }
  ctx.restore();
}

export const KERIS_GLEAM_DUR = 0.095;

function drawKerisHulu(ctx: CanvasRenderingContext2D, t: number) {
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(-6.5, 0);
  ctx.bezierCurveTo(-7.5, 12, -5.5, 26, -1.5, 38);
  ctx.bezierCurveTo(1.5, 46, 8.5, 48, 12.5, 42);
  ctx.bezierCurveTo(15.0, 38, 13.0, 31, 9.0, 29);
  ctx.bezierCurveTo(6.0, 28, 5.5, 22, 6.8, 13);
  ctx.bezierCurveTo(7.5, 6, 7.0, 2, 6.5, 0);
  ctx.closePath();
  const woodGrad = ctx.createLinearGradient(-8, 0, 14, 46);
  woodGrad.addColorStop(0, '#1e1107');
  woodGrad.addColorStop(0.28, '#3a210d');
  woodGrad.addColorStop(0.55, '#593518');
  woodGrad.addColorStop(0.8, '#291709');
  woodGrad.addColorStop(1, '#120a04');
  ctx.fillStyle = woodGrad;
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 227, 143, 0.72)';
  ctx.lineWidth = 0.95;
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255, 215, 110, 0.35)';
  ctx.lineWidth = 0.75;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(0, 10 + i * 7.5, 4.8 - i * 0.5, 0.25, Math.PI - 0.25);
    ctx.stroke();
  }
  ctx.fillStyle = '#ffd056';
  ctx.fillRect(-6.8, 1.5, 13.6, 2.0);
  ctx.fillStyle = '#fff5d1';
  ctx.fillRect(-6.5, 5.0, 13.0, 1.3);
  const eyePulse = 0.75 + 0.25 * Math.sin(t * 5);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = rgba('#4deeea', eyePulse);
  ctx.beginPath();
  ctx.arc(6.0, 35.5, 2.0, 0, TAU);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(6.0, 35.5, 0.9, 0, TAU);
  ctx.fill();
  ctx.restore();
  ctx.restore();
}

function drawKerisMendak(ctx: CanvasRenderingContext2D, t: number) {
  ctx.save();
  const mGrad = ctx.createLinearGradient(-11, 0, 11, 0);
  mGrad.addColorStop(0, '#593a10');
  mGrad.addColorStop(0.25, '#ffd056');
  mGrad.addColorStop(0.5, '#ffffff');
  mGrad.addColorStop(0.75, '#ffd056');
  mGrad.addColorStop(1, '#593a10');
  ctx.fillStyle = mGrad;
  ctx.beginPath();
  ctx.roundRect(-9.5, -2.5, 19, 3.8, 1.8);
  ctx.fill();
  ctx.beginPath();
  ctx.roundRect(-11.5, -5.8, 23, 3.5, 1.6);
  ctx.fill();
  for (let i = -2; i <= 2; i++) {
    const glowA = 0.65 + 0.35 * Math.sin(t * 6 + i);
    ctx.fillStyle = i % 2 === 0 ? rgba('#ffd056', glowA) : rgba('#ff2a5f', glowA);
    ctx.beginPath();
    ctx.arc(i * 4.2, -4.0, 1.25, 0, TAU);
    ctx.fill();
  }
  ctx.restore();
}

function drawKerisWarangka(ctx: CanvasRenderingContext2D, t: number) {
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(-48, -28);
  ctx.bezierCurveTo(-34, -22, -20, -18, 0, -18);
  ctx.bezierCurveTo(18, -18, 30, -21, 40, -25);
  ctx.bezierCurveTo(46, -15, 36, -3, 18, 1);
  ctx.bezierCurveTo(6, 3, -8, 3, -20, 0);
  ctx.bezierCurveTo(-36, -4, -46, -16, -48, -28);
  ctx.closePath();
  const wGrad = ctx.createLinearGradient(-48, -28, 42, 4);
  wGrad.addColorStop(0, '#241409');
  wGrad.addColorStop(0.3, '#4a2b13');
  wGrad.addColorStop(0.5, '#663d1d');
  wGrad.addColorStop(0.7, '#4a2b13');
  wGrad.addColorStop(1, '#1a0e06');
  ctx.fillStyle = wGrad;
  ctx.fill();
  const goldTrim = ctx.createLinearGradient(-48, -28, 42, 4);
  goldTrim.addColorStop(0, '#ffe38f');
  goldTrim.addColorStop(0.5, '#ffffff');
  goldTrim.addColorStop(1, '#f39c12');
  ctx.strokeStyle = goldTrim;
  ctx.lineWidth = 1.3;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-15, -18.5);
  ctx.lineTo(15, -18.5);
  ctx.lineTo(12, 2.2);
  ctx.lineTo(-12, 2.2);
  ctx.closePath();
  const pGrad = ctx.createLinearGradient(-15, 0, 15, 0);
  pGrad.addColorStop(0, '#785216');
  pGrad.addColorStop(0.25, '#ffd056');
  pGrad.addColorStop(0.5, '#fff6d6');
  pGrad.addColorStop(0.75, '#e0a938');
  pGrad.addColorStop(1, '#61400e');
  ctx.fillStyle = pGrad;
  ctx.fill();
  ctx.strokeStyle = '#ffea9f';
  ctx.lineWidth = 0.85;
  ctx.stroke();
  const corePulse = 0.7 + 0.3 * Math.sin(t * 4.5);
  ctx.fillStyle = '#241406';
  ctx.beginPath();
  ctx.moveTo(0, -14.5);
  ctx.lineTo(5.0, -8.5);
  ctx.lineTo(0, -2.5);
  ctx.lineTo(-5.0, -8.5);
  ctx.closePath();
  ctx.fill();
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = rgba('#ffd056', 0.88 * corePulse);
  ctx.beginPath();
  ctx.moveTo(0, -13.2);
  ctx.lineTo(3.8, -8.5);
  ctx.lineTo(0, -3.8);
  ctx.lineTo(-3.8, -8.5);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(0, -8.5, 1.4, 0, TAU);
  ctx.fill();
  ctx.restore();
  ctx.strokeStyle = '#fff5d1';
  ctx.lineWidth = 1.4;
  for (const sx of [-14, 14]) {
    ctx.beginPath();
    ctx.moveTo(sx, -18.5);
    ctx.lineTo(sx * 0.86, 2.0);
    ctx.stroke();
  }
  ctx.restore();
}

function drawKerisGanja(ctx: CanvasRenderingContext2D) {
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(-20, -22);
  ctx.quadraticCurveTo(-24, -26, -18, -28);
  ctx.lineTo(18, -28);
  ctx.lineTo(22, -25);
  ctx.lineTo(19, -23);
  ctx.lineTo(23, -21);
  ctx.lineTo(15, -20);
  ctx.lineTo(-16, -20);
  ctx.closePath();
  const gGrad = ctx.createLinearGradient(-22, -24, 22, -24);
  gGrad.addColorStop(0, '#4a3210');
  gGrad.addColorStop(0.25, '#ffd056');
  gGrad.addColorStop(0.5, '#fff3c4');
  gGrad.addColorStop(0.75, '#d49b27');
  gGrad.addColorStop(1, '#3d280b');
  ctx.fillStyle = gGrad;
  ctx.fill();
  ctx.strokeStyle = '#ffea9f';
  ctx.lineWidth = 1.0;
  ctx.stroke();
  ctx.fillStyle = '#fff6cf';
  for (let i = -1; i <= 1; i++) {
    ctx.beginPath();
    ctx.arc(i * 6, -24, 1.2, 0, TAU);
    ctx.fill();
  }
  ctx.restore();
}

function drawSlide4WilahOnGun(ctx: CanvasRenderingContext2D, t: number, flash: number, sinceShot = 99) {
  const gl = clamp(flash, 0, 1);
  const gleamActive = sinceShot >= 0 && sinceShot < KERIS_GLEAM_DUR * 1.15;
  const gleamU = gleamActive ? clamp(sinceShot / KERIS_GLEAM_DUR, 0, 1) : -1;
  const BASE = -28;
  const TOP = -158;
  const LUK = 5;
  const amp = (tt: number) => 5 * (1 - tt * 0.5);
  const halfw = (tt: number) => 13.6 * Math.pow(1 - tt, 0.82) + 1.4;
  const bx = (tt: number) => amp(tt) * Math.sin(tt * LUK * Math.PI);
  const by = (tt: number) => BASE - tt * (BASE - TOP);

  const rings: [number, number, number, number][] = [
    [-136, 24, 6.2, 1.7],
    [-102, 30, 7.6, -1.2],
    [-68, 36, 8.8, 0.9],
  ];
  for (let idx = 0; idx < rings.length; idx++) {
    const [ry, rx, ey, sp] = rings[idx];
    ctx.strokeStyle = `rgba(181,125,22,${0.42 + gl * 0.3})`;
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.ellipse(0, ry, rx, ey, 0, 0, TAU);
    ctx.stroke();
    ctx.strokeStyle = `rgba(255,236,170,${0.3 + gl * 0.3})`;
    ctx.lineWidth = 0.6;
    ctx.beginPath();
    ctx.ellipse(0, ry, rx + 2.6, ey + 1.2, 0, 0, TAU);
    ctx.stroke();
    const a = t * sp + idx * 2.1;
    glowDot(ctx, Math.cos(a) * rx, ry + Math.sin(a) * ey, 1.6, '#e8b64c', '#fffdf6', 0.9);
  }

  const NB = 42;
  ctx.beginPath();
  for (let i = 0; i <= NB; i++) {
    const tt = i / NB;
    const x = bx(tt) - halfw(tt);
    if (i === 0) ctx.moveTo(x, by(tt));
    else ctx.lineTo(x, by(tt));
  }
  for (let i = NB; i >= 0; i--) {
    const tt = i / NB;
    ctx.lineTo(bx(tt) + halfw(tt), by(tt));
  }
  ctx.closePath();

  const bladeGrad = ctx.createLinearGradient(-15, 0, 15, 0);
  bladeGrad.addColorStop(0, '#c98a1e');
  bladeGrad.addColorStop(0.16, '#f0cf7d');
  bladeGrad.addColorStop(0.38, '#fffdf4');
  bladeGrad.addColorStop(0.5, '#ffffff');
  bladeGrad.addColorStop(0.62, '#fffdf4');
  bladeGrad.addColorStop(0.84, '#f0cf7d');
  bladeGrad.addColorStop(1, '#c98a1e');
  ctx.fillStyle = bladeGrad;
  ctx.fill();

  ctx.save();
  ctx.clip();
  const sweep = ((t * 0.38) % 2.0) - 0.4;
  if (sweep >= 0 && sweep <= 1) {
    const sy = BASE - sweep * (BASE - TOP);
    ctx.globalCompositeOperation = 'lighter';
    const sweepG = ctx.createLinearGradient(0, sy - 20, 0, sy + 20);
    sweepG.addColorStop(0, 'rgba(255,255,255,0)');
    sweepG.addColorStop(0.5, 'rgba(255, 248, 220, 0.48)');
    sweepG.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = sweepG;
    ctx.fillRect(-22, sy - 20, 44, 40);
  }
  if (gleamU >= 0) {
    const sy = BASE - gleamU * (BASE - TOP);
    ctx.globalCompositeOperation = 'lighter';
    const shotGleam = ctx.createLinearGradient(0, sy + 36, 0, sy - 36);
    shotGleam.addColorStop(0, 'rgba(255, 208, 86, 0)');
    shotGleam.addColorStop(0.22, 'rgba(255, 215, 90, 0.78)');
    shotGleam.addColorStop(0.44, 'rgba(255, 250, 220, 0.98)');
    shotGleam.addColorStop(0.5, '#ffffff');
    shotGleam.addColorStop(0.56, 'rgba(255, 250, 220, 0.98)');
    shotGleam.addColorStop(0.78, 'rgba(255, 215, 90, 0.78)');
    shotGleam.addColorStop(1, 'rgba(255, 208, 86, 0)');
    ctx.fillStyle = shotGleam;
    ctx.fillRect(-26, sy - 38, 52, 76);
    ctx.save();
    ctx.translate(bx(gleamU), sy);
    ctx.rotate(-0.34);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-24, -4.5, 48, 9);
    ctx.fillStyle = 'rgba(255, 232, 140, 0.92)';
    ctx.fillRect(-24, 7.5, 48, 4.5);
    ctx.restore();
  }
  ctx.restore();

  ctx.lineWidth = 1.1;
  ctx.strokeStyle = GOLD.dark;
  ctx.stroke();

  ctx.lineWidth = 1.1;
  ctx.strokeStyle = 'rgba(176,120,40,0.55)';
  for (const s of [-0.5, 0.5]) {
    ctx.beginPath();
    for (let i = 0; i <= NB; i++) {
      const tt = i / NB;
      const x = bx(tt) + s * halfw(tt);
      if (i === 0) ctx.moveTo(x, by(tt));
      else ctx.lineTo(x, by(tt));
    }
    ctx.stroke();
  }

  ctx.lineWidth = 5.5;
  ctx.strokeStyle = `rgba(255,226,150,${0.32 + gl * 0.4})`;
  ctx.beginPath();
  for (let i = 0; i <= NB; i++) {
    const tt = i / NB;
    if (i === 0) ctx.moveTo(bx(tt), by(tt));
    else ctx.lineTo(bx(tt), by(tt));
  }
  ctx.stroke();
  ctx.lineWidth = 2.1;
  ctx.strokeStyle = `rgba(255,255,255,${0.82 + gl * 0.18})`;
  ctx.stroke();

  if (gleamU >= 0) {
    const sy = BASE - gleamU * (BASE - TOP);
    const sx = bx(gleamU);
    const u0 = Math.max(0, gleamU - 0.38);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const side of [-1, 1]) {
      ctx.strokeStyle = 'rgba(255, 224, 110, 0.92)';
      ctx.lineWidth = 3.2;
      ctx.beginPath();
      for (let i = 0; i <= 16; i++) {
        const uu = u0 + (gleamU - u0) * (i / 16);
        if (i === 0) ctx.moveTo(bx(uu) + side * halfw(uu), by(uu));
        else ctx.lineTo(bx(uu) + side * halfw(uu), by(uu));
      }
      ctx.stroke();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }
    const glintGrad = ctx.createRadialGradient(sx, sy, 1, sx, sy, 22);
    glintGrad.addColorStop(0, '#ffffff');
    glintGrad.addColorStop(0.35, 'rgba(255, 244, 190, 0.92)');
    glintGrad.addColorStop(0.7, 'rgba(255, 208, 86, 0.45)');
    glintGrad.addColorStop(1, 'rgba(255, 208, 86, 0)');
    ctx.fillStyle = glintGrad;
    ctx.beginPath();
    ctx.ellipse(sx, sy, 22, 11, 0, 0, TAU);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.ellipse(sx, sy, 16 * (1 - gleamU * 0.35), 2.4, -0.18, 0, TAU);
    ctx.fill();
    ctx.restore();
  }

  const tick = Math.floor(t * 16);
  if (gleamU >= 0) {
    strokeJolt(ctx, boltPts(0, BASE - 2, bx(gleamU), BASE - gleamU * (BASE - TOP), 6, tick), 1.45, 0.98);
  } else if (gl > 0.08) {
    strokeJolt(ctx, boltPts(0, BASE - 4, 0, TOP + 10, 6, tick), 1.25, Math.min(1, gl + 0.15));
    strokeJolt(ctx, boltPts(bx(0.5), by(0.5), bx(0.5) - 10, by(0.5) - 12, 3, tick + 7), 0.9, gl * 0.8);
    strokeJolt(ctx, boltPts(bx(0.72), by(0.72), bx(0.72) + 9, by(0.72) - 10, 3, tick + 13), 0.9, gl * 0.8);
  } else if (tick % 6 === 0) {
    strokeJolt(ctx, boltPts(bx(0.22), by(0.22), bx(0.72), by(0.72), 4, tick), 0.95, 0.85);
  }

  for (let i = 0; i < 5; i++) {
    const tt = 0.18 + i * 0.16;
    if (tt > 0.96) continue;
    const x = bx(tt) + (i % 2 === 0 ? 1 : -1) * (halfw(tt) + 6.8);
    ctx.save();
    ctx.translate(x, by(tt));
    ctx.rotate(Math.PI / 4);
    ctx.globalAlpha = 0.45 + 0.3 * Math.sin(t * 3 + i * 1.4);
    ctx.fillStyle = '#e8b64c';
    ctx.fillRect(-1.6, -1.6, 3.2, 3.2);
    ctx.strokeStyle = '#8a5a10';
    ctx.lineWidth = 0.5;
    ctx.strokeRect(-1.6, -1.6, 3.2, 3.2);
    ctx.restore();
  }

  for (const m of [-1, 1]) {
    ctx.save();
    ctx.translate(0, BASE - 36);
    ctx.beginPath();
    ctx.moveTo(m * 4, 37);
    ctx.bezierCurveTo(m * 16, 34, m * 20, 22, m * 12, 14);
    ctx.bezierCurveTo(m * 16, 21, m * 12, 27, m * 4.5, 29);
    ctx.closePath();
    const nagaGrad = ctx.createLinearGradient(m * 20, 14, m * 4, 37);
    nagaGrad.addColorStop(0, GOLD.bright);
    nagaGrad.addColorStop(0.55, GOLD.mid);
    nagaGrad.addColorStop(1, GOLD.dark);
    ctx.fillStyle = nagaGrad;
    ctx.fill();
    ctx.strokeStyle = GOLD.ink;
    ctx.lineWidth = 0.9;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(110,66,10,0.8)';
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(m * 6.5, 33);
    ctx.bezierCurveTo(m * 12, 30, m * 14.5, 24, m * 12.5, 18.5);
    ctx.stroke();
    glowDot(ctx, m * 11.5, 18.5, 1.15, '#ff8aa0', '#e02547', 0.9);
    ctx.restore();
  }
}

export function drawKerisHalilintarLukBlade(
  ctx: CanvasRenderingContext2D,
  _tipY: number,
  _tailY: number,
  _maxW: number,
  t = 0,
  isStuck = false,
) {
  ctx.save();
  ctx.translate(0, 36);
  ctx.scale(0.31, 0.34);
  const BASE = -28;
  const TOP = -158;
  const LUK = 5;
  const amp = (tt: number) => 5.6 * (1 - tt * 0.45);
  const halfw = (tt: number) => 15.2 * Math.pow(1 - tt, 0.8) + 1.6;
  const bx = (tt: number) => amp(tt) * Math.sin(tt * LUK * Math.PI);
  const by = (tt: number) => BASE - tt * (BASE - TOP);

  drawKerisHulu(ctx, t);
  drawKerisMendak(ctx, t);
  drawKerisWarangka(ctx, t);
  drawKerisGanja(ctx);

  const NB = 36;
  ctx.beginPath();
  for (let i = 0; i <= NB; i++) {
    const tt = i / NB;
    if (i === 0) ctx.moveTo(bx(tt) - halfw(tt), by(tt));
    else ctx.lineTo(bx(tt) - halfw(tt), by(tt));
  }
  for (let i = NB; i >= 0; i--) {
    const tt = i / NB;
    ctx.lineTo(bx(tt) + halfw(tt), by(tt));
  }
  ctx.closePath();
  const bladeGrad = ctx.createLinearGradient(-16, 0, 16, 0);
  bladeGrad.addColorStop(0, '#c98a1e');
  bladeGrad.addColorStop(0.16, '#f0cf7d');
  bladeGrad.addColorStop(0.38, '#fffdf4');
  bladeGrad.addColorStop(0.5, '#ffffff');
  bladeGrad.addColorStop(0.62, '#fffdf4');
  bladeGrad.addColorStop(0.84, '#f0cf7d');
  bladeGrad.addColorStop(1, '#c98a1e');
  ctx.fillStyle = bladeGrad;
  ctx.fill();
  ctx.lineWidth = 1.6;
  ctx.strokeStyle = GOLD.dark;
  ctx.stroke();

  ctx.lineWidth = 1.3;
  ctx.strokeStyle = 'rgba(176,120,40,0.6)';
  for (const s of [-0.5, 0.5]) {
    ctx.beginPath();
    for (let i = 0; i <= NB; i++) {
      const tt = i / NB;
      if (i === 0) ctx.moveTo(bx(tt) + s * halfw(tt), by(tt));
      else ctx.lineTo(bx(tt) + s * halfw(tt), by(tt));
    }
    ctx.stroke();
  }

  ctx.lineWidth = 5.5;
  ctx.strokeStyle = 'rgba(255,226,150,0.42)';
  ctx.beginPath();
  for (let i = 0; i <= NB; i++) {
    const tt = i / NB;
    if (i === 0) ctx.moveTo(bx(tt), by(tt));
    else ctx.lineTo(bx(tt), by(tt));
  }
  ctx.stroke();
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = 'rgba(255,255,255,0.9)';
  ctx.stroke();

  for (const m of [-1, 1]) {
    ctx.save();
    ctx.translate(0, BASE - 36);
    ctx.beginPath();
    ctx.moveTo(m * 4, 37);
    ctx.bezierCurveTo(m * 16, 34, m * 20, 22, m * 12, 14);
    ctx.bezierCurveTo(m * 16, 21, m * 12, 27, m * 4.5, 29);
    ctx.closePath();
    const nagaGrad = ctx.createLinearGradient(m * 20, 14, m * 4, 37);
    nagaGrad.addColorStop(0, GOLD.bright);
    nagaGrad.addColorStop(0.55, GOLD.mid);
    nagaGrad.addColorStop(1, GOLD.dark);
    ctx.fillStyle = nagaGrad;
    ctx.fill();
    ctx.strokeStyle = GOLD.ink;
    ctx.lineWidth = 1.1;
    ctx.stroke();
    glowDot(ctx, m * 11.5, 18.5, 1.4, '#ff8aa0', '#e02547', 0.95);
    ctx.restore();
  }

  const seed = Math.floor(t * 20);
  if (isStuck) {
    strokeJolt(ctx, boltPts(bx(0.06), by(0.06), bx(0.68), by(0.68), 8, seed), 2.2, 0.95);
    const side = seed % 2 === 0 ? 1 : -1;
    strokeJolt(ctx, boltPts(bx(0.28) + side * halfw(0.28), by(0.28), bx(0.56) + side * (halfw(0.56) + 12), by(0.56), 6, seed + 5), 1.8, 0.9);
    strokeJolt(ctx, boltPts(bx(0.18) - side * halfw(0.18), by(0.18), bx(0.42) - side * (halfw(0.42) + 10), by(0.42), 5, seed + 11), 1.6, 0.85);
  } else {
    strokeJolt(ctx, boltPts(bx(0.08), by(0.08), bx(0.88), by(0.88), 6, seed), 1.9, 0.9);
  }
  ctx.restore();
}

function drawEmergingKerisSpirit(ctx: CanvasRenderingContext2D, riseProgress: number, alpha: number, t: number) {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = clamp(alpha, 0, 1);
  ctx.translate(0, -55 - riseProgress * 105);
  const spiritHalo = ctx.createRadialGradient(0, 0, 2, 0, 0, 34);
  spiritHalo.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
  spiritHalo.addColorStop(0.45, 'rgba(255, 224, 110, 0.65)');
  spiritHalo.addColorStop(1, 'rgba(255, 190, 50, 0)');
  ctx.fillStyle = spiritHalo;
  ctx.beginPath();
  ctx.ellipse(0, 4, 18, 36, 0, 0, TAU);
  ctx.fill();
  drawKerisHalilintarLukBlade(ctx, -18, 52, 14, t, false);
  ctx.restore();
}

export function drawSlide8KerisGun(
  ctx: CanvasRenderingContext2D,
  cx: number,
  y0: number,
  t: number,
  flash = 0,
  recoil = 0,
  sinceShot = 99,
  inPreview = false,
) {
  ctx.save();
  ctx.translate(cx, y0 + 160);
  const delayedRecoil = sinceShot >= 0 && sinceShot < KERIS_GLEAM_DUR
    ? recoil * 0.25 * (sinceShot / KERIS_GLEAM_DUR)
    : recoil;
  ctx.translate(0, delayedRecoil * 12);
  const pulse = 0.5 + 0.5 * Math.sin(t * 3.2);

  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const aura = ctx.createRadialGradient(0, -82, 6, 0, -82, 98);
  aura.addColorStop(0, rgba('#ffd056', 0.15 + pulse * 0.06 + flash * 0.1));
  aura.addColorStop(0.55, rgba('#e8b64c', 0.05 + flash * 0.05));
  aura.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = aura;
  ctx.beginPath();
  ctx.ellipse(0, -82, 66, 100, 0, 0, TAU);
  ctx.fill();
  ctx.restore();

  drawKerisHulu(ctx, t);
  drawKerisMendak(ctx, t);
  drawKerisWarangka(ctx, t);
  drawKerisGanja(ctx);
  drawSlide4WilahOnGun(ctx, t, flash, sinceShot);

  if (sinceShot >= KERIS_GLEAM_DUR * 0.28 && sinceShot < KERIS_GLEAM_DUR) {
    const u = (sinceShot - KERIS_GLEAM_DUR * 0.28) / (KERIS_GLEAM_DUR * 0.72);
    drawEmergingKerisSpirit(ctx, u, 0.35 + u * 0.65, t);
  } else if (inPreview && sinceShot >= KERIS_GLEAM_DUR && sinceShot < 0.32) {
    const flyU = (sinceShot - KERIS_GLEAM_DUR) / (0.32 - KERIS_GLEAM_DUR);
    drawEmergingKerisSpirit(ctx, 1 + flyU * 1.35, 1 - flyU, t);
  }
  ctx.restore();
}

export function drawKerisStuckCrater(ctx: CanvasRenderingContext2D, rimY = 0, t = 0) {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = 'rgba(255, 208, 86, 0.92)';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.ellipse(0, rimY, 6.5, 2.4, 0, 0, TAU);
  ctx.stroke();
  ctx.fillStyle = 'rgba(255, 224, 110, 0.92)';
  ctx.beginPath();
  ctx.arc(0, rimY, 2.8, 0, TAU);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(0, rimY, 1.5, 0, TAU);
  ctx.fill();
  const seed = Math.floor(t * 22);
  const dir = seed % 2 === 0 ? 1 : -1;
  strokeJolt(ctx, boltPts(0, rimY, dir * 11, rimY + 7, 3.2, seed), 1.1, 0.9);
  strokeJolt(ctx, boltPts(0, rimY, -dir * 8, rimY + 12, 2.8, seed + 7), 0.95, 0.82);
  ctx.restore();
}

export function drawKerisSlideProjectile(ctx: CanvasRenderingContext2D, t: number, embedded: boolean) {
  ctx.save();
  if (!embedded) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const trailGrad = ctx.createLinearGradient(0, 32, 0, 82);
    trailGrad.addColorStop(0, 'rgba(255, 255, 255, 0.85)');
    trailGrad.addColorStop(0.3, 'rgba(255, 224, 110, 0.65)');
    trailGrad.addColorStop(0.75, 'rgba(255, 180, 40, 0.25)');
    trailGrad.addColorStop(1, 'rgba(255, 180, 40, 0)');
    ctx.fillStyle = trailGrad;
    ctx.beginPath();
    ctx.moveTo(-4.8, 32);
    ctx.lineTo(4.8, 32);
    ctx.lineTo(0.8, 82);
    ctx.lineTo(-0.8, 82);
    ctx.closePath();
    ctx.fill();
    const spiritAura = ctx.createRadialGradient(0, 14, 2, 0, 14, 34);
    spiritAura.addColorStop(0, 'rgba(255, 252, 230, 0.62)');
    spiritAura.addColorStop(0.5, 'rgba(255, 215, 90, 0.34)');
    spiritAura.addColorStop(1, 'rgba(255, 180, 40, 0)');
    ctx.fillStyle = spiritAura;
    ctx.beginPath();
    ctx.ellipse(0, 14, 18, 36, 0, 0, TAU);
    ctx.fill();
    for (const [dy, sc, al] of [[18, 0.9, 0.32], [34, 0.8, 0.16]] as const) {
      ctx.save();
      ctx.globalAlpha = al;
      ctx.translate(0, dy);
      ctx.scale(sc, sc);
      drawKerisHalilintarLukBlade(ctx, -18, 52, 14, t, false);
      ctx.restore();
    }
    ctx.restore();
    drawKerisHalilintarLukBlade(ctx, -18, 52, 14, t, false);
  } else {
    drawKerisStuckCrater(ctx, 0, t);
    drawKerisHalilintarLukBlade(ctx, -18, 52, 14, t, true);
  }
  ctx.restore();
}

export function drawSlide2DiamondBullet(
  ctx: CanvasRenderingContext2D,
  r: number,
  t: number,
  seed: number,
  flash = 0,
) {
  const halo = ctx.createRadialGradient(0, 0, r * 0.3, 0, 0, r * 2.8);
  halo.addColorStop(0, 'rgba(200,235,255,0.55)');
  halo.addColorStop(1, 'rgba(140,200,255,0)');
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(0, 0, r * 2.8, 0, TAU);
  ctx.fill();

  const tw = 0.5 + 0.5 * Math.sin(t * 6 + seed * 5);
  const pts: [number, number][] = [
    [-0.72, 0.42], [-0.28, 0.62], [0.28, 0.62], [0.72, 0.42], [1, -0.12], [0, -1], [-1, -0.12],
  ];
  const x = (i: number) => pts[i][0] * r;
  const y = (i: number) => pts[i][1] * r;
  const facets: [number[], string][] = [
    [[0, 1, 5, 6], '#e8f6ff'],
    [[1, 2, 5], '#ffffff'],
    [[2, 3, 4, 5], '#c4e6ff'],
    [[0, 6, 4, 3], '#9fd4ff'],
  ];
  for (const [idx, col] of facets) {
    ctx.fillStyle = col;
    ctx.beginPath();
    for (let j = 0; j < idx.length; j++) {
      if (j === 0) ctx.moveTo(x(idx[0]), y(idx[0]));
      else ctx.lineTo(x(idx[j]), y(idx[j]));
    }
    ctx.closePath();
    ctx.fill();
  }
  ctx.strokeStyle = 'rgba(255,255,255,0.95)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  pts.forEach(([px, py], i) => (i === 0 ? ctx.moveTo(px * r, py * r) : ctx.lineTo(px * r, py * r)));
  ctx.closePath();
  ctx.stroke();

  ctx.strokeStyle = 'rgba(120,170,220,0.8)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x(1), y(1)); ctx.lineTo(x(5), y(5));
  ctx.moveTo(x(2), y(2)); ctx.lineTo(x(5), y(5));
  ctx.moveTo(x(0), y(0)); ctx.lineTo(x(6), y(6));
  ctx.moveTo(x(3), y(3)); ctx.lineTo(x(4), y(4));
  ctx.stroke();

  const sa = 0.5 + 0.5 * tw;
  ctx.strokeStyle = `rgba(255,255,255,${sa})`;
  ctx.lineWidth = 1.6;
  const sr = r * (0.9 + tw * 0.5);
  ctx.beginPath();
  ctx.moveTo(-sr, 0); ctx.lineTo(sr, 0);
  ctx.moveTo(0, -sr * 0.7); ctx.lineTo(0, sr * 0.7);
  ctx.stroke();

  if (flash > 0) {
    ctx.fillStyle = `rgba(255,255,255,${Math.min(1, flash) * 0.7})`;
    ctx.beginPath();
    ctx.arc(0, 0, r * 1.1, 0, TAU);
    ctx.fill();
  }
}

export function drawSlide2DiamondMuzzleFormation(
  ctx: CanvasRenderingContext2D,
  cx: number,
  muzzleY: number,
  t: number,
  sinceShot = 9,
  ready = true,
) {
  const safeSince = Number.isFinite(sinceShot) && sinceShot >= 0 ? sinceShot : 9;
  const recoil = safeSince < 0.22 ? Math.max(0, 1 - safeSince / 0.22) : 0;
  const loadP = safeSince < 0.16 ? clamp(safeSince / 0.16, 0, 1) : 1;

  ctx.save();
  ctx.translate(cx, muzzleY);
  for (let i = 0; i < 8; i++) {
    const a = (i * TAU) / 8 + t * 0.8;
    ctx.save();
    ctx.translate(Math.cos(a) * 21, Math.sin(a) * 8.5);
    ctx.rotate(Math.PI / 4);
    const dg2 = ctx.createLinearGradient(-4, -4, 4, 4);
    dg2.addColorStop(0, '#ffffff');
    dg2.addColorStop(1, '#9fd4ff');
    ctx.fillStyle = dg2;
    ctx.fillRect(-4, -4, 8, 8);
    ctx.strokeStyle = 'rgba(255,255,255,0.92)';
    ctx.lineWidth = 0.75;
    ctx.strokeRect(-4, -4, 8, 8);
    ctx.restore();
  }
  const ap = ctx.createRadialGradient(0, 0, 0, 0, 0, 15);
  ap.addColorStop(0, '#ffffff');
  ap.addColorStop(0.6, 'rgba(200,235,255,0.9)');
  ap.addColorStop(1, 'rgba(120,170,220,0.2)');
  ctx.fillStyle = ap;
  ctx.beginPath();
  ctx.ellipse(0, 0, 15, 6, 0, 0, TAU);
  ctx.fill();
  ctx.restore();

  if (recoil > 0.12) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = `rgba(255,255,255,${recoil * 0.75})`;
    ctx.beginPath();
    ctx.ellipse(cx, muzzleY - 4, 28, 13, 0, 0, TAU);
    ctx.fill();
    ctx.restore();
  }

  if (ready) {
    const e = 1 - Math.pow(1 - loadP, 3);
    const py = muzzleY - 22 + (1 - e) * 22 + Math.sin(t * 3.2) * 2;
    ctx.save();
    ctx.translate(cx, py);
    ctx.rotate(Math.sin(t * 1.8) * 0.2);
    drawSlide2DiamondBullet(ctx, 9.5, t, 8.8, 0);
    ctx.restore();
  }

  const sparkOffsets: [number, number, number, number][] = [
    [-25, -8, 3.2, 0.4], [25, -6, 3.0, 1.7], [-19, -22, 2.6, 2.9],
    [20, -21, 2.8, 4.1], [-13, 11, 2.4, 5.2], [14, 12, 2.5, 6.0],
  ];
  for (let i = 0; i < sparkOffsets.length; i++) {
    const [dx, dy, sz, ph] = sparkOffsets[i];
    const pulse = 0.35 + 0.65 * Math.max(0, Math.sin(t * 4.6 + ph));
    const s = sz * (0.65 + 0.35 * pulse);
    ctx.save();
    ctx.translate(cx + dx, muzzleY + dy + Math.sin(t * 2.8 + ph) * 2.2);
    ctx.rotate(t * 1.6 + ph);
    ctx.fillStyle = i % 2 === 0 ? '#ffffff' : '#bfe6ff';
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(-s, 0); ctx.lineTo(0, -s * 0.62); ctx.lineTo(s, 0); ctx.lineTo(0, s * 0.62);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
}

function starPath(ctx: CanvasRenderingContext2D, r: number) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const rr = i % 2 === 0 ? r : r * 0.45;
    const a = (i * Math.PI) / 5 - Math.PI / 2;
    const x = Math.cos(a) * rr;
    const y = Math.sin(a) * rr;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

export function drawSlide3BazookaShell(
  ctx: CanvasRenderingContext2D,
  hue = 45,
  t = 0,
  seed = 1.7,
  flash = 0,
  exhaust = 1,
) {
  ctx.save();
  ctx.rotate(Math.PI / 2);
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  const line = 'rgba(18,20,9,0.92)';
  const flick = Math.sin(t * 43 + seed * 9) * 0.5 + Math.sin(t * 61 + seed * 4) * 0.3;

  ctx.save();
  const bodyGlow = ctx.createRadialGradient(26, 0, 2, 26, 0, 34);
  bodyGlow.addColorStop(0, `rgba(255,195,95,${0.32 + 0.16 * exhaust})`);
  bodyGlow.addColorStop(0.55, `rgba(255,125,35,${0.16 + 0.1 * exhaust})`);
  bodyGlow.addColorStop(1, 'rgba(255,90,20,0)');
  ctx.fillStyle = bodyGlow;
  ctx.beginPath();
  ctx.arc(26, 0, 34, 0, TAU);
  ctx.fill();
  ctx.restore();

  if (exhaust > 0.01) {
    ctx.save();
    const halo = ctx.createRadialGradient(62, 0, 2, 62, 0, 36);
    halo.addColorStop(0, `rgba(255,200,110,${0.55 * exhaust})`);
    halo.addColorStop(0.5, `rgba(255,130,40,${0.25 * exhaust})`);
    halo.addColorStop(1, 'rgba(255,110,30,0)');
    ctx.fillStyle = halo;
    ctx.beginPath();
    ctx.arc(62, 0, 36, 0, TAU);
    ctx.fill();
    ctx.restore();
  }

  for (const s of [-1, 1]) {
    ctx.fillStyle = 'rgba(12,14,6,0.55)';
    ctx.beginPath();
    ctx.moveTo(39, s * 4); ctx.lineTo(55, s * 12.5); ctx.lineTo(57.5, s * 12.5); ctx.lineTo(47, s * 4);
    ctx.closePath();
    ctx.fill();

    const fg = ctx.createLinearGradient(40, 0, 56, s * 12);
    fg.addColorStop(0, '#55652c');
    fg.addColorStop(0.55, '#3d4a20');
    fg.addColorStop(1, '#242b12');
    ctx.fillStyle = fg;
    ctx.strokeStyle = line;
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(38, s * 4); ctx.lineTo(54, s * 11); ctx.lineTo(57, s * 11); ctx.lineTo(46, s * 4);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.strokeStyle = '#e8c832';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(54, s * 11); ctx.lineTo(57, s * 11);
    ctx.stroke();
  }

  const nozG = ctx.createLinearGradient(0, -5, 0, 5);
  nozG.addColorStop(0, '#5a5a64');
  nozG.addColorStop(0.45, '#2b2b30');
  nozG.addColorStop(1, '#121214');
  ctx.fillStyle = nozG;
  ctx.strokeStyle = line;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.roundRect(50, -4.8, 9.5, 9.6, 2);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = '#060608';
  ctx.beginPath();
  ctx.ellipse(59.5, 0, 2.2, 3.4, 0, 0, TAU);
  ctx.fill();
  if (exhaust > 0.01) {
    ctx.fillStyle = `rgba(255,${170 + Math.round(flick * 30)},80,${0.95 * exhaust})`;
    ctx.beginPath();
    ctx.ellipse(59.5, 0, 1.4, 2.4, 0, 0, TAU);
    ctx.fill();
  }

  const bodyG = ctx.createLinearGradient(0, -6.5, 0, 6.5);
  bodyG.addColorStop(0, '#a8b862');
  bodyG.addColorStop(0.22, '#7c8c44');
  bodyG.addColorStop(0.45, '#59682e');
  bodyG.addColorStop(0.72, '#39421e');
  bodyG.addColorStop(1, '#202613');
  ctx.fillStyle = bodyG;
  ctx.strokeStyle = line;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(14, -6.5, 38, 13, 2.5);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = 'rgba(255,255,225,0.42)';
  ctx.fillRect(16, -5.6, 34, 1.8);
  ctx.fillStyle = 'rgba(255,220,150,0.12)';
  ctx.fillRect(16, 3.2, 34, 2.2);

  const bandG = ctx.createLinearGradient(0, -6.5, 0, 6.5);
  bandG.addColorStop(0, '#e0484e');
  bandG.addColorStop(0.5, '#a01e24');
  bandG.addColorStop(1, '#5e1115');
  ctx.fillStyle = bandG;
  ctx.fillRect(30, -6.5, 5, 13);

  ctx.fillStyle = '#e8c832';
  ctx.fillRect(42, -6.5, 3, 13);

  ctx.save();
  ctx.translate(22, 0);
  ctx.scale(0.55, 0.55);
  starPath(ctx, 7);
  ctx.fillStyle = 'rgba(242,242,218,0.95)';
  ctx.fill();
  ctx.restore();

  const noseG = ctx.createLinearGradient(0, -7.5, 0, 7.5);
  noseG.addColorStop(0, '#ffd9a0');
  noseG.addColorStop(0.3, '#e8934a');
  noseG.addColorStop(0.6, '#a05a1a');
  noseG.addColorStop(1, '#5e2f0c');
  ctx.fillStyle = noseG;
  ctx.strokeStyle = line;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-1, 0);
  ctx.quadraticCurveTo(5, -7.5, 15, -6.5);
  ctx.lineTo(15, 6.5);
  ctx.quadraticCurveTo(5, 7.5, -1, 0);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  const fuseG = ctx.createRadialGradient(-2, -1, 0.4, -1.5, 0, 2.8);
  fuseG.addColorStop(0, '#ffffff');
  fuseG.addColorStop(0.6, '#b8b8c4');
  fuseG.addColorStop(1, '#5a5a66');
  ctx.fillStyle = fuseG;
  ctx.strokeStyle = line;
  ctx.lineWidth = 1.3;
  ctx.beginPath();
  ctx.arc(-1.5, 0, 2.5, 0, TAU);
  ctx.fill();
  ctx.stroke();

  const tw = 0.5 + 0.5 * Math.sin(t * 9 + seed * 6);
  ctx.fillStyle = hsl(hue, 100, 62, 0.65 + 0.35 * tw);
  ctx.beginPath();
  ctx.arc(37.5, 0, 1.9, 0, TAU);
  ctx.fill();

  if (exhaust > 0.01) {
    const fl = 17 + flick * 5;
    const wob = Math.sin(t * 55 + seed * 7) * 1.4;
    ctx.save();
    const outer = ctx.createLinearGradient(59, 0, 59 + fl + 14, 0);
    outer.addColorStop(0, `rgba(255,150,50,${0.8 * exhaust})`);
    outer.addColorStop(0.55, `rgba(255,110,25,${0.5 * exhaust})`);
    outer.addColorStop(1, 'rgba(255,70,15,0)');
    ctx.fillStyle = outer;
    ctx.beginPath();
    ctx.moveTo(59, -5.2);
    ctx.quadraticCurveTo(59 + fl * 0.55, -5.5 + wob, 59 + fl + 12, wob * 1.4);
    ctx.quadraticCurveTo(59 + fl * 0.55, 5.5 + wob, 59, 5.2);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = `rgba(255,255,255,${0.95 * exhaust})`;
    ctx.beginPath();
    ctx.ellipse(62.5, wob * 0.3, 5.5, 2.4, 0, 0, TAU);
    ctx.fill();
    for (let i = 0; i < 5; i++) {
      const ph = (t * 5.5 + i * 0.37 + seed) % 1;
      const sx = 61 + ph * (fl + 15);
      const sy = Math.sin(t * 19 + i * 2.4 + seed) * (3.5 + ph * 6.5);
      ctx.fillStyle = i % 2 === 0 ? `rgba(255,235,150,${(1 - ph) * 0.95 * exhaust})` : `rgba(255,150,50,${(1 - ph) * 0.9 * exhaust})`;
      ctx.beginPath();
      ctx.arc(sx, sy, (1 - ph * 0.55) * 1.65, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
    ctx.fillStyle = `rgba(150,148,142,${0.4 * exhaust})`;
    ctx.beginPath();
    ctx.ellipse(59 + fl + 10, wob * 1.4, 7, 4.5, 0, 0, TAU);
    ctx.fill();
  }

  if (flash > 0) {
    ctx.fillStyle = `rgba(255,255,255,${Math.min(1, flash) * 0.7})`;
    ctx.beginPath();
    ctx.roundRect(-2, -7, 61, 14, 4);
    ctx.fill();
  }
  ctx.restore();
}

export function drawSlide3BazookaStuckCrater(ctx: CanvasRenderingContext2D, t = 0, seed = 1.7, bite = 0.6) {
  ctx.save();
  const ck = Math.min(1, Math.max(0.38, bite * 1.4));
  const flick = 0.78 + 0.22 * Math.sin(t * 31 + seed * 9);
  const soot = ctx.createRadialGradient(0, -2, 2, 0, -2, 22);
  soot.addColorStop(0, `rgba(10,7,5,${0.82 * ck})`);
  soot.addColorStop(0.55, `rgba(20,14,9,${0.5 * ck})`);
  soot.addColorStop(1, 'rgba(25,18,12,0)');
  ctx.fillStyle = soot;
  ctx.beginPath();
  ctx.arc(0, -2, 22, 0, TAU);
  ctx.fill();
  ctx.fillStyle = `rgba(8,6,4,${0.72 + 0.23 * ck})`;
  ctx.beginPath();
  ctx.ellipse(0, -2, 8.5, 10, 0, 0, TAU);
  ctx.fill();
  const mg = ctx.createRadialGradient(0, -2, 1, 0, -2, 13);
  mg.addColorStop(0, `rgba(255,245,220,${0.8 * ck * flick})`);
  mg.addColorStop(0.45, `rgba(255,170,70,${0.6 * ck * flick})`);
  mg.addColorStop(1, 'rgba(255,110,30,0)');
  ctx.fillStyle = mg;
  ctx.beginPath();
  ctx.arc(0, -2, 13, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = `rgba(200,190,150,${0.55 + 0.35 * ck})`;
  ctx.lineWidth = 1.8;
  for (const s of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(s * 6, -6);
    ctx.quadraticCurveTo(s * 9, -11, s * 8, -15);
    ctx.stroke();
  }
  for (const [dx, dy] of [[-14, -12], [0, -18], [14, -12]] as const) {
    ctx.strokeStyle = `rgba(255,190,90,${0.58 * ck * flick})`;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, -4);
    ctx.quadraticCurveTo(dx * 0.5, dy * 0.6, dx, dy);
    ctx.stroke();
  }
  for (let i = 0; i < 4; i++) {
    const a = seed * 3 + i * 1.7 + t * 0.6;
    const ex = Math.cos(a) * (11 + (i % 3) * 2.5);
    const ey = -2 + Math.sin(a) * (8 + (i % 2) * 2.5);
    const tw = 0.4 + 0.6 * Math.abs(Math.sin(t * 6 + i * 2.1 + seed * 5));
    ctx.fillStyle = `rgba(255,${145 + Math.round(tw * 65)},70,${tw * ck})`;
    ctx.beginPath();
    ctx.arc(ex, ey, 1.35, 0, TAU);
    ctx.fill();
  }
  ctx.restore();
}

export function drawSlide3BazookaEmbedded(
  ctx: CanvasRenderingContext2D,
  hue = 45,
  t = 0,
  seed = 1.7,
  flash = 0,
  bite = 0.6,
) {
  ctx.save();
  drawSlide3BazookaStuckCrater(ctx, t, seed, bite);
  drawSlide3BazookaShell(ctx, hue, t, seed, flash, 0);
  ctx.restore();
}

export function drawSlide3BazookaMuzzleFx(
  ctx: CanvasRenderingContext2D,
  cx: number,
  y0: number,
  ready: boolean,
  t: number,
  sinceShot: number,
) {
  ctx.save();
  const heat = Math.max(0.28, Math.exp(-sinceShot * 5.5));
  const bgGlow = ctx.createRadialGradient(cx, y0 + 8, 2, cx, y0 + 8, 52);
  bgGlow.addColorStop(0, `rgba(255,145,50,${0.22 + heat * 0.25})`);
  bgGlow.addColorStop(0.6, `rgba(255,105,25,${0.1 + heat * 0.12})`);
  bgGlow.addColorStop(1, 'rgba(255,80,15,0)');
  ctx.fillStyle = bgGlow;
  ctx.beginPath();
  ctx.arc(cx, y0 + 8, 52, 0, TAU);
  ctx.fill();

  if (ready) {
    const loadP = Math.min(1, sinceShot / 0.28);
    const e = 1 - Math.pow(1 - loadP, 3);
    const bob = Math.sin(t * 3.1) * 1.8;
    const tipY = y0 - 30 + (1 - e) * 28 + bob;
    if (e < 0.99) {
      ctx.strokeStyle = `rgba(255,200,110,${(1 - e) * 0.78})`;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(cx, tipY + 12, 12 + (1 - e) * 18, 0, TAU);
      ctx.stroke();
    }
    ctx.save();
    ctx.translate(cx, tipY);
    ctx.scale(0.68, 0.68);
    drawSlide3BazookaShell(ctx, 45, t, 3.3, 0, 0);
    ctx.restore();
  }

  const eg = ctx.createRadialGradient(cx, y0, 0, cx, y0, 20);
  eg.addColorStop(0, `rgba(255,245,220,${heat * 0.85})`);
  eg.addColorStop(0.42, `rgba(255,190,90,${heat * 0.72})`);
  eg.addColorStop(0.78, `rgba(255,120,35,${heat * 0.42})`);
  eg.addColorStop(1, 'rgba(200,60,15,0)');
  ctx.fillStyle = eg;
  ctx.beginPath();
  ctx.ellipse(cx, y0, 19, 6.5, 0, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = `rgba(255,${145 + Math.round(heat * 55)},70,${0.45 + heat * 0.45})`;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.ellipse(cx, y0, 17, 4.2, 0, 0, TAU);
  ctx.stroke();

  for (let i = 0; i < 4; i++) {
    const cyc = (t * 0.85 + i * 0.25) % 1;
    const wx = cx + Math.sin(t * 2.4 + i * 1.9) * (6 + cyc * 10);
    const wy = y0 - 4 - cyc * 24;
    const wr = 4 + cyc * 6.5;
    const wa = (1 - cyc) * 0.28;
    const sg = ctx.createRadialGradient(wx, wy, 0, wx, wy, wr);
    sg.addColorStop(0, `rgba(95,88,78,${wa})`);
    sg.addColorStop(1, 'rgba(60,55,48,0)');
    ctx.fillStyle = sg;
    ctx.beginPath();
    ctx.arc(wx, wy, wr, 0, TAU);
    ctx.fill();
  }

  for (let i = 0; i < 8; i++) {
    const ph = (t * 1.45 + i * 0.125) % 1;
    const side = i % 2 === 0 ? -1 : 1;
    const sx = cx + side * (5 + ((i * 7) % 13)) + Math.sin(t * 5 + i * 1.7) * 5;
    const sy = y0 + 4 - ph * 34;
    const sr = (1 - ph * 0.55) * 1.85;
    const alpha = Math.sin(ph * Math.PI) * 0.95;
    const hg = ctx.createRadialGradient(sx, sy, 0, sx, sy, sr * 3.2);
    hg.addColorStop(0, `rgba(255,190,75,${alpha * 0.65})`);
    hg.addColorStop(1, 'rgba(255,110,25,0)');
    ctx.fillStyle = hg;
    ctx.beginPath();
    ctx.arc(sx, sy, sr * 3.2, 0, TAU);
    ctx.fill();
    ctx.fillStyle = i % 3 === 0 ? `rgba(255,250,210,${alpha})` : `rgba(255,165,55,${alpha})`;
    ctx.beginPath();
    ctx.arc(sx, sy, sr, 0, TAU);
    ctx.fill();
  }
  ctx.restore();
}
