// @ts-nocheck — art asli dari game Halo, dipakai apa adanya
import type { WeaponId } from '../weapons';
import type { GunVariant } from './gunVariants';

export interface GunMetrics {
  totalLen: number;
  centerOffsetY: number;
  centerOffsetX: number;
  span: number;
}

export interface GunInkBox {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

export function getGunInkBox(_id: WeaponId): GunInkBox | null {
  return null;
}

export interface PreviewFit {
  scale: number;
  tx: number;
  ty: number;
}

export function fitInkBoxQuarterTurn(box: GunInkBox, w: number, h: number, pad = 8): PreviewFit {
  const bw = Math.max(1, box.x1 - box.x0);
  const bh = Math.max(1, box.y1 - box.y0);
  const scale = Math.max(0.01, Math.min((w - pad * 2) / bh, (h - pad * 2) / bw));
  const cx = (box.x0 + box.x1) / 2;
  const cy = (box.y0 + box.y1) / 2;
  return { scale, tx: w / 2 + cy * scale, ty: h / 2 - cx * scale };
}

export const GUN_METRICS: Partial<Record<WeaponId, Partial<GunMetrics>>> = {
  pistol: { totalLen: 172, centerOffsetY: 84, centerOffsetX: 22, span: 185 },
  ak47: { totalLen: 265, centerOffsetY: 130, centerOffsetX: 24, span: 270 },
  nail: { totalLen: 168, centerOffsetY: 74, centerOffsetX: 24, span: 182 },
  crossbow: { totalLen: 225, centerOffsetY: 110, centerOffsetX: 0, span: 230 },
  shotgun: { totalLen: 226, centerOffsetY: 113, centerOffsetX: 6, span: 224 },
  slingshot: { totalLen: 176, centerOffsetY: 88, centerOffsetX: 0, span: 184 },
  blowgun: { totalLen: 290, centerOffsetY: 145, centerOffsetX: 5, span: 295 },

  sniper: { totalLen: 236, centerOffsetY: 114, centerOffsetX: -3, span: 242 },
  flamethrower: { totalLen: 186, centerOffsetY: 74, centerOffsetX: 8, span: 192 },
  plasma: { totalLen: 225, centerOffsetY: 106, centerOffsetX: 12, span: 245 },
  laser: { totalLen: 192, centerOffsetY: 94, centerOffsetX: 2, span: 198 },
  rpg: { totalLen: 226, centerOffsetY: 110, centerOffsetX: 4, span: 230 },
  bamboo: { totalLen: 210, centerOffsetY: 100, centerOffsetX: 4, span: 230 },
  fish: { totalLen: 158, centerOffsetY: 78, centerOffsetX: 0, span: 168 },

  minigun: { totalLen: 235, centerOffsetY: 115, centerOffsetX: 0, span: 240 },
  railgun: { totalLen: 214, centerOffsetY: 106, centerOffsetX: 0, span: 218 },
  electro: { totalLen: 180, centerOffsetY: 88, centerOffsetX: 2, span: 192 },
  bazooka: { totalLen: 270, centerOffsetY: 132, centerOffsetX: 12, span: 275 },
  keris: { totalLen: 208, centerOffsetY: 102, centerOffsetX: 0, span: 215 },
  shark: { totalLen: 180, centerOffsetY: 88, centerOffsetX: 16, span: 185 },
  ghost: { totalLen: 152, centerOffsetY: 82, centerOffsetX: 0, span: 186 },

  freeze: { totalLen: 182, centerOffsetY: 82, centerOffsetX: 10, span: 192 },
  golden: { totalLen: 180, centerOffsetY: 86, centerOffsetX: 17, span: 210 },
  blackhole: { totalLen: 174, centerOffsetY: 84, centerOffsetX: 2, span: 180 },
  dragon: { totalLen: 185, centerOffsetY: 82, centerOffsetX: 0, span: 240 },
  meteor: { totalLen: 178, centerOffsetY: 78, centerOffsetX: 3, span: 184 },
  diamond: { totalLen: 165, centerOffsetY: 80, centerOffsetX: 0, span: 170 },
  holy: { totalLen: 175, centerOffsetY: 85, centerOffsetX: 16, span: 180 },
};

export function getGunMetrics(id: WeaponId, _variant?: GunVariant): GunMetrics {
  const custom = GUN_METRICS[id];
  return {
    totalLen: custom?.totalLen ?? 175,
    centerOffsetY: custom?.centerOffsetY ?? 85,
    centerOffsetX: custom?.centerOffsetX ?? 12,
    span: custom?.span ?? 190,
  };
}
