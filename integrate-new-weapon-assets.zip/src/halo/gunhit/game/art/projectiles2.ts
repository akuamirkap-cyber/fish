// @ts-nocheck — art asli dari game Halo, dipakai apa adanya
import type { ProjKind } from '../weapons';
import { TAU, lin, radial } from './kit';
import { drawProjectileExtra2 } from './projectiles3';

type C = CanvasRenderingContext2D;

function glowE(c: C, y: number, rx: number, ry: number, rgb: string, a: number) {
  c.save();
  c.globalCompositeOperation = 'lighter';
  const g = c.createRadialGradient(0, y, 1, 0, y, Math.max(rx, ry));
  g.addColorStop(0, `rgba(${rgb},${a})`);
  g.addColorStop(1, `rgba(${rgb},0)`);
  c.fillStyle = g;
  c.beginPath();
  c.ellipse(0, y, rx, ry, 0, 0, TAU);
  c.fill();
  c.restore();
}

function bullet(c: C, len: number, w: number, tip: string[], body: string[], rim: string) {
  const head = len * 0.36;
  c.beginPath();
  c.moveTo(-w / 2, head);
  c.lineTo(-w / 2, 6);
  c.quadraticCurveTo(-w / 2, -1, 0, -2);
  c.quadraticCurveTo(w / 2, -1, w / 2, 6);
  c.lineTo(w / 2, head);
  c.closePath();
  c.fillStyle = lin(c, -w / 2, w / 2, tip);
  c.fill();
  c.fillStyle = lin(c, -w / 2, w / 2, body);
  c.fillRect(-w / 2 - 0.5, head, w + 1, len - head - 3);
  c.fillStyle = rim;
  c.fillRect(-w / 2 - 1.2, len - 3, w + 2.4, 3);
}

export function drawProjectileExtra(c: C, kind: ProjKind, len: number, t: number, age: number, embedded = false) {
  switch (kind) {
    case 'slingshot': {
      const r = Math.min(7.5, len * 0.42);
      c.save();
      c.translate(0, r);
      c.beginPath();
      for (let i = 0; i < 9; i++) {
        const a = (i / 9) * TAU;
        const rr2 = r * (0.85 + Math.sin(i * 2.7) * 0.15);
        c.lineTo(Math.cos(a) * rr2, Math.sin(a) * rr2 * 0.85);
      }
      c.closePath();
      c.fillStyle = radial(c, 0, 0, r, ['#e7e5e4', '#8a817c', '#3f3a36']);
      c.fill();
      c.strokeStyle = 'rgba(0,0,0,0.35)';
      c.lineWidth = 0.8;
      c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.5)';
      c.beginPath();
      c.ellipse(-r * 0.35, -r * 0.3, r * 0.3, r * 0.18, -0.4, 0, TAU);
      c.fill();
      c.restore();
      break;
    }
    case 'blowgun': {
      c.fillStyle = lin(c, -1, 1, ['#525252', '#f5f5f5', '#525252']);
      c.beginPath();
      c.moveTo(0, -3);
      c.lineTo(1, 4);
      c.lineTo(0.8, len - 12);
      c.lineTo(-0.8, len - 12);
      c.lineTo(-1, 4);
      c.closePath();
      c.fill();
      c.fillStyle = 'rgba(132,204,22,0.8)';
      c.fillRect(-1, 0, 2, 7);
      c.beginPath();
      c.moveTo(0, len - 14);
      c.quadraticCurveTo(6, len - 6, 3, len);
      c.lineTo(-3, len);
      c.quadraticCurveTo(-6, len - 6, 0, len - 14);
      c.fillStyle = radial(c, 0, len - 6, 7, ['#ffffff', '#fef3c7', '#dc2626']);
      c.fill();
      break;
    }
    case 'shotgun': {
      c.fillStyle = lin(c, -5, 5, ['#7f1d1d', '#ef4444', '#991b1b']);
      c.beginPath();
      c.roundRect(-5, 0, 10, len - 10, [3, 3, 0, 0]);
      c.fill();
      c.strokeStyle = 'rgba(0,0,0,0.3)';
      c.lineWidth = 1;
      c.beginPath();
      c.moveTo(-2, 1);
      c.lineTo(0, 4);
      c.lineTo(2, 1);
      c.stroke();
      c.fillStyle = lin(c, -5.5, 5.5, ['#8c5e10', '#ffe695', '#8c5e10']);
      c.fillRect(-5.5, len - 11, 11, 8);
      c.fillStyle = '#c08a24';
      c.fillRect(-6.5, len - 3, 13, 3);
      c.fillStyle = 'rgba(255,255,255,0.3)';
      c.fillRect(-3, 2, 1.2, len - 14);
      break;
    }
    case 'sniper':
      bullet(c, len, 7, ['#7a3212', '#f6b07a', '#7a3212'], ['#8c5e10', '#ffe695', '#8c5e10'], '#c08a24');
      c.fillStyle = '#111';
      c.fillRect(-3.5, len * 0.36, 7, 1.5);
      break;
    case 'minigun':
      bullet(c, len, 6.5, ['#6e300e', '#e89a5a', '#6e300e'], ['#8c5e10', '#f5d77a', '#8c5e10'], '#a87818');
      c.fillStyle = '#374151';
      c.fillRect(-4.5, len - 9, 9, 2.5);
      break;
    case 'railgun': {
      glowE(c, len / 2, 8, len * 0.6, '56,189,248', 0.55);
      c.fillStyle = lin(c, -2.5, 2.5, ['#334155', '#f1f5f9', '#475569']);
      c.fillRect(-2.5, 0, 5, len);
      c.save();
      c.shadowColor = '#38bdf8';
      c.shadowBlur = 10;
      c.strokeStyle = '#7dd3fc';
      c.lineWidth = 1.3;
      for (let i = 0; i < 4; i++) {
        const y = ((t * 60 + i * (len / 4)) % len);
        c.beginPath();
        c.ellipse(0, y, 5, 1.6, 0, 0, TAU);
        c.stroke();
      }
      c.restore();
      c.fillStyle = '#fff';
      c.beginPath();
      c.moveTo(-2.5, 2);
      c.lineTo(0, -3);
      c.lineTo(2.5, 2);
      c.fill();
      break;
    }
    case 'flamethrower':
    case 'dragon': {
      const isDragon = kind === 'dragon';
      glowE(c, len * 0.38, isDragon ? 21 : 12, len * 0.75, '255,120,30', 0.68);
      const flicker = Math.sin(t * 24) * 2;
      c.save(); c.globalCompositeOperation = 'lighter';
      const outer = c.createLinearGradient(0, 0, 0, len + 16);
      outer.addColorStop(0, '#fffbd4'); outer.addColorStop(0.27, '#ffb839');
      outer.addColorStop(0.6, '#ef5b26'); outer.addColorStop(1, 'rgba(185,28,28,0)');
      c.fillStyle = outer;
      c.beginPath(); c.moveTo(0, -6);
      c.bezierCurveTo(12, 6, 8, len * 0.44, 6, len * 0.55);
      c.quadraticCurveTo(13, len * 0.57, 7, len + 12);
      c.quadraticCurveTo(3, len * 0.75, 1, len * 0.74);
      c.quadraticCurveTo(-4, len + 14, -7, len + 7);
      c.quadraticCurveTo(-5, len * 0.65, -8, len * 0.57);
      c.bezierCurveTo(-13, len * 0.38, -11, 8, 0, -6);
      c.closePath(); c.fill();
      const core = c.createLinearGradient(0, 0, 0, len);
      core.addColorStop(0, '#ffffff'); core.addColorStop(0.4, '#fff5c0');
      core.addColorStop(1, 'rgba(255,183,53,0)');
      c.fillStyle = core;
      c.beginPath(); c.moveTo(0, -3);
      c.bezierCurveTo(5, 3, 4 + flicker * 0.3, len * 0.4, 1, len * 0.6);
      c.quadraticCurveTo(-5, len * 0.41, -5, 7);
      c.closePath(); c.fill();
      if (isDragon) {
        for (const side of [-1, 1]) {
          c.fillStyle = 'rgba(255,156,44,0.64)'; c.beginPath();
          c.moveTo(side * 6, 11);
          c.quadraticCurveTo(side * 18, len * 0.33, side * (13 + flicker), len * 0.7);
          c.quadraticCurveTo(side * 12, len * 0.36, side * 5, 20); c.closePath(); c.fill();
        }
        c.fillStyle = '#ffe9a3';
        for (const [x, y, size] of [[-11, len * 0.42, 1.6], [13, len * 0.7, 1.8]]) {
          c.beginPath(); c.arc(x, y, size, 0, TAU); c.fill();
        }
      }
      c.restore();
      break;
    }
    case 'bamboo': {
      c.fillStyle = lin(c, -5, 5, ['#7f1d1d', '#ef4444', '#991b1b']);
      c.fillRect(-5, 4, 10, len - 4);
      c.fillStyle = '#facc15';
      c.fillRect(-5, 9, 10, 3);
      c.fillRect(-5, len - 9, 10, 3);
      c.fillStyle = '#fef3c7';
      c.font = 'bold 6px serif';
      c.textAlign = 'center';
      c.fillText('福', 0, len * 0.55);
      c.fillStyle = '#e7e5e4';
      c.fillRect(-5, 1, 10, 4);
      c.strokeStyle = '#78716c';
      c.lineWidth = 1.2;
      c.beginPath();
      c.moveTo(0, 1);
      c.quadraticCurveTo(3, -3, 1, -6);
      c.stroke();
      if (age < 0.05 || Math.sin(t * 40) > 0) {
        c.fillStyle = '#fde047';
        c.beginPath();
        c.arc(1, -6, 1.6, 0, TAU);
        c.fill();
      }
      break;
    }
    default: {
      drawProjectileExtra2(c, kind, len, t, age, embedded);
      break;
    }
  }
}
