import { useEffect, useMemo, useRef, useState } from 'react';
import Arsenal from './Arsenal';
import { Game, type GameStats, type Screen } from '../game/game';
import { BOSS_INFO, BOSS_ORDER, loadBossRecords, renderBossPortrait, type BossId } from '../game/bosses';

const BOSS_WIN: Record<BossId, string> = {
  jagal: 'Goloknya tumpul, celemeknya robek. Si Jagal tidak akan memotong apa pun lagi.',
  kumis: 'Kumisnya tercukur peluru. Kerajaan mafia Don Kumis runtuh berkeping-keping!',
  pedro: 'Kamu terbangun dari mimpi... Pedro tersenyum dari kejauhan. Atau itu cuma pisang biasa?',
};

function BossPortrait({ id }: { id: BossId }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (ref.current) renderBossPortrait(ref.current, id);
  }, [id]);
  return (
    <canvas
      ref={ref}
      width={320}
      height={230}
      className="block h-auto w-full rounded-2xl border-[3px] border-[#120d0a] bg-[#120d0a]"
    />
  );
}

const TIPS = [
  'KUNGFU: tekan KLIK KANAN tepat saat pukulan musuh datang = PARRY! Kuda-kudanya rusak drastis.',
  'Cahaya MERAH di tangan/kaki musuh = tidak bisa ditangkis. Berputar (SPACE), atau LOMPAT untuk sapuan.',
  'Tendang musuh ke DINDING (combo ke-4/5) = MENTOK! damage & kuda-kuda ekstra.',
  'KATANA: klik beruntun untuk combo 5 jurus — jurus terakhir (KABUTO-WARI) selalu membelah musuh!',
  'Tahan klik dengan katana lalu LEPAS = IAI DASH: semua musuh di jalurmu terbelah sekaligus.',
  'Tahan KLIK KANAN dengan katana untuk menangkis peluru balik ke penembaknya!',
  'KETAPEL itu SENYAP: musuh lain tidak dengar. Tahan untuk menarik, lihat lintasannya, lepas — kena kepala = tumbang!',
  'NOISY CRICKET kecil tapi DAHSYAT — hentakannya melemparmu ke belakang. Jangan tembak di pinggir atap!',
  'Pemukul: klik lagi tepat di akhir ayunan untuk langsung lanjut ayunan berikutnya.',
  'Pemukul bisbol bisa MEMUKUL BALIK peluru, dinamit dan golok musuh — tepat saat diayun!',
  'Peluru SNIPER menembus banyak musuh sekaligus. Jajarkan mereka untuk bonus TEMBUS!',
  'Sniper musuh membidik dengan laser merah — saat titiknya berkedip, langsung BERPUTAR (SPACE) atau berguling!',
  'AK-47 makin lama ditahan makin melenceng. Tembak pendek-pendek supaya akurat.',
  'Jatuh tepat di KEPALA musuh = INJAK! Kamu memantul lagi dan bisa lanjut ke kepala berikutnya.',
  'Di udara tekan F = TENDANGAN TERBANG. Kena musuh = terpental; kena lantai = hentakan yang menjatuhkan musuh di sekitar.',
  'Ambil SHOTGUN di gudang: tembak ke bawah saat di udara untuk SHOTGUN JUMP!',
  'Senjata musuh (Uzi / shotgun) yang jatuh bisa kamu pungut — cukup lewati saja.',
  'Double jump sambil lari = FRONT FLIP, sambil diam = BACKFLIP. Kill sambil flip = poin besar!',
  'Lari lalu tekan arah sebaliknya + W di udara = BACKFLIP menjauh sambil tetap membidik musuh.',
  'Sprint ke meja atau peti = AUTO PARKOUR. Kamu bisa menembak sambil melompatinya!',
  'Tembak LAMPU 2x: bohlam pecah, lalu talinya putus — jatuhkan ke kepala musuh!',
  'Sprint ke pintu kayu (atau tekan F) = TENDANG DOBRAK! Pintunya terpental menghantam musuh di baliknya.',
  'Tahan S saat mendarat untuk ROLL — selama berguling, peluru musuh meleset!',
  'Double jump sambil tahan S = SUPERMAN DIVE, lalu otomatis roll saat mendarat.',
  'Tekan SPACE untuk berputar — selama berputar, peluru musuh akan meleset!',
  'Mode FOKUS (SHIFT) memperlambat waktu. Tembakanmu jadi jauh lebih akurat.',
  'Garis merah tipis dari pistol musuh = dia siap menembak. Menghindar!',
  'Tembak BAREL MERAH saat musuh berkerumun di dekatnya.',
  'Front flip, backflip atau wall-flip sambil menembak = poin gaya lebih besar.',
  'Darahmu pulih sendiri kalau beberapa detik tidak kena tembak.',
  'SPLIT AIM (tahan klik kanan) mengunci tangan kiri ke satu musuh.',
  'Tendang (F) musuh dari dekat untuk membuatnya pusing.',
  'Wajan yang ditembak memantulkan peluru otomatis ke kepala musuh!',
];

const CONTROLS: [string[], string][] = [
  [['A', 'D'], 'Lari · sprint ke meja = AUTO PARKOUR'],
  [['C'], 'Tahan = jalan taktis (senjata siaga)'],
  [['W'], 'Lompat · dekat dinding = WALL-FLIP'],
  [['W', '+', 'W'], 'Double jump: lari = FRONT FLIP, diam = BACKFLIP'],
  [['S'], 'Slide · tahan saat mendarat = ROLL'],
  [['S', '+', 'W'], 'Turun dari platform tipis'],
  [['SPACE'], 'Berputar — menghindari peluru'],
  [['SHIFT'], 'Mode FOKUS (slow-motion)'],
  [['F'], 'Tendang / DOBRAK · di udara = TENDANGAN TERBANG'],
  [['KLIK KIRI'], 'Tembak pistol ganda'],
  [['KLIK KANAN'], 'Tahan = SPLIT AIM · sniper = SCOPE'],
  [['0'], 'TANGAN KOSONG · klik kanan = tangkis / PARRY'],
  [['1-9', 'SCROLL'], 'Ganti senjata (… · bat · ketapel · cricket · KATANA)'],
  [['KLIK', 'KLIK'], 'Katana/bat: klik beruntun = COMBO · tahan-lepas = IAI / GRAND SLAM'],
  [['W', '+', 'KLIK'], 'Katana: tebasan naik · udara: TERBANG WALET · S+klik = tusuk'],
  [['R'], 'Reload · coba lagi saat tewas'],
  [['ESC'], 'Jeda'],
  [['M'], 'Musik on / off'],
  [['TAB'], 'ARSENAL: pilih dari 38 senjata (semua terbuka)'],
  [['Z', 'X'], 'Ganti senjata berikut / sebelumnya (atau roda mouse)'],
  [['R'], 'Reload senjata'],
];

function fmtTime(t: number) {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function fmtNum(n: number) {
  return Math.round(n)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function BananaSvg({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="-26 -26 52 52" className={className} aria-hidden>
      <g strokeLinejoin="round" strokeLinecap="round">
        <path
          d="M-12,-14 Q-20,6 2,16 Q14,20 20,12 Q6,10 -2,2 Q-8,-6 -7,-15 Z"
          fill="#ffd93b"
          stroke="#1b1410"
          strokeWidth="2.4"
        />
        <path d="M-9,-12 Q-14,6 4,13 Q-6,4 -9,-12 Z" fill="#f2b81c" />
        <path d="M-12,-14 L-11,-19 L-6.5,-18 L-7,-15 Z" fill="#5a3a1a" stroke="#1b1410" strokeWidth="1.6" />
        <circle cx="19.5" cy="12" r="2" fill="#5a3a1a" />
        <ellipse cx="-9" cy="-2" rx="2.6" ry="3.2" fill="#fff" stroke="#1b1410" strokeWidth="1.2" />
        <ellipse cx="-3.5" cy="0" rx="2.4" ry="3" fill="#fff" stroke="#1b1410" strokeWidth="1.2" />
        <circle cx="-8.2" cy="-1.6" r="1.3" fill="#111" />
        <circle cx="-2.8" cy="0.4" r="1.2" fill="#111" />
        <path d="M-9,5.5 Q-5.5,8.5 -2,6.5" fill="none" stroke="#1b1410" strokeWidth="1.4" />
      </g>
    </svg>
  );
}

function ControlsList({ compact = false }: { compact?: boolean }) {
  return (
    <ul className={`grid gap-x-6 ${compact ? 'gap-y-1.5 text-[13px]' : 'gap-y-2 text-sm'} sm:grid-cols-2`}>
      {CONTROLS.map(([keys, label]) => (
        <li key={label} className="flex items-center gap-2 text-[#fff7dc]">
          <span className="flex shrink-0 items-center gap-1">
            {keys.map((k, i) =>
              k === '+' ? (
                <span key={i} className="font-black text-[#ffd23f]">
                  +
                </span>
              ) : (
                <kbd key={i} className="key">
                  {k}
                </kbd>
              ),
            )}
          </span>
          <span className="leading-tight">{label}</span>
        </li>
      ))}
    </ul>
  );
}

function Btn({
  children,
  onClick,
  color = 'yellow',
  big = false,
}: {
  children: React.ReactNode;
  onClick: () => void;
  color?: 'yellow' | 'red' | 'green' | 'dark' | 'purple';
  big?: boolean;
}) {
  const bg =
    color === 'yellow'
      ? 'bg-[#ffd23f] text-[#120d0a]'
      : color === 'red'
        ? 'bg-[#ff4d4d] text-white'
        : color === 'green'
          ? 'bg-[#5fd068] text-[#120d0a]'
          : color === 'purple'
            ? 'bg-[#9d4edd] text-white'
            : 'bg-[#2b2235] text-[#fff7dc]';
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      onMouseDown={(e) => e.stopPropagation()}
      className={`hw-btn ${bg} ${big ? 'px-10 py-3 text-4xl' : 'px-6 py-2 text-2xl'} rounded-2xl`}
    >
      {children}
    </button>
  );
}

export default function GameView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [screen, setScreen] = useState<Screen>('menu');
  const [stats, setStats] = useState<GameStats | null>(null);
  const [showControls, setShowControls] = useState(false);
  const [muted, setMuted] = useState(false);
  const [music, setMusic] = useState(true);
  const [tipIdx, setTipIdx] = useState(0);
  const [bossSelect, setBossSelect] = useState(false);
  const [records, setRecords] = useState(() => loadBossRecords());
  const [arsenal, setArsenal] = useState(false);
  const [curWeapon, setCurWeapon] = useState<string>('pistol');
  const arsenalRef = useRef(false);
  const resumeOnClose = useRef(false);
  const touchOnly = useMemo(
    () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(pointer: coarse)').matches,
    [],
  );

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const g = new Game(c, {
      onScreen: (s) => {
        setScreen(s);
        if (s === 'dead') setTipIdx(Math.floor(Math.random() * TIPS.length));
      },
      onStats: (st) => setStats(st),
    });
    gameRef.current = g;
    return () => {
      g.destroy();
      gameRef.current = null;
    };
  }, []);

  const g = () => gameRef.current;

  // ---------------- ARSENAL: semua senjata (lama + HALO) bisa dipilih kapan saja
  const openArsenal = (fromPlay: boolean) => {
    const gm = gameRef.current;
    if (!gm) return;
    resumeOnClose.current = fromPlay;
    setCurWeapon(gm.currentWeapon);
    arsenalRef.current = true;
    setArsenal(true);
  };
  const closeArsenal = () => {
    arsenalRef.current = false;
    setArsenal(false);
    const gm = gameRef.current;
    if (gm && resumeOnClose.current && gm.screen === 'paused') gm.resume();
    resumeOnClose.current = false;
  };
  const pickWeapon = (id: string) => {
    if (g()?.equipWeapon(id)) setCurWeapon(id);
  };
  const arsenalFns = useRef({ openArsenal, closeArsenal });
  arsenalFns.current = { openArsenal, closeArsenal };
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== 'Tab') return;
      e.preventDefault();
      if (e.repeat) return;
      const gm = gameRef.current;
      if (!gm) return;
      if (arsenalRef.current) arsenalFns.current.closeArsenal();
      else if (gm.screen === 'playing' && gm.arsenalAllowed) {
        gm.pause();
        arsenalFns.current.openArsenal(true);
      } else if (gm.screen === 'paused' && gm.arsenalAllowed) arsenalFns.current.openArsenal(false);
      else if (gm.screen === 'menu') arsenalFns.current.openArsenal(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  useEffect(() => {
    if (screen !== 'paused' && screen !== 'menu') {
      arsenalRef.current = false;
      resumeOnClose.current = false;
      setArsenal(false);
    }
  }, [screen]);
  const openBossSelect = () => {
    setRecords(loadBossRecords());
    setBossSelect(true);
  };
  const toBossSelect = () => {
    g()?.toMenu();
    openBossSelect();
  };
  const isBoss = stats?.mode === 'boss';

  const toggleMute = () => {
    const m = !muted;
    setMuted(m);
    g()?.setMuted(m);
  };
  const toggleMusic = () => {
    const m = !music;
    setMusic(m);
    g()?.setMusic(m);
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#0d0a14]">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 block"
        style={{ cursor: screen === 'playing' ? 'none' : 'default' }}
      />

      {screen === 'playing' && (
        <div className="pointer-events-none absolute bottom-3 right-4 hidden text-right text-[11px] font-bold text-white/40 md:block">
          TAB = arsenal · Z/X = ganti senjata · ESC = jeda · SHIFT = fokus · SPACE = putar
        </div>
      )}

      {/* ---------------- MENU ---------------- */}
      {screen === 'menu' && !bossSelect && (
        <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-gradient-to-r from-[#0d0a14]/90 via-[#1a1028]/70 to-[#0d0a14]/40 p-4">
          <div className="flex w-full max-w-6xl flex-col items-center gap-8 lg:flex-row lg:items-center lg:justify-between">
            <div className="anim-pop flex flex-col items-center text-center lg:items-start lg:text-left">
              <div className="flex items-center gap-3">
                <BananaSvg className="anim-bob h-20 w-20 drop-shadow-[0_6px_0_#120d0a] md:h-28 md:w-28" />
                <div>
                  <p className="hw-outline text-xl text-white md:text-2xl">GAME AKSI SLOW-MO</p>
                  <h1 className="hw-title text-6xl leading-[0.9] md:text-8xl">
                    SOBATKU
                    <br />
                    PEDRO
                  </h1>
                </div>
              </div>
              <p className="hw-outline mt-5 text-2xl text-[#ff7b3a] md:text-3xl">LEVEL 1 — GUDANG DAGING SI KUMIS</p>
              <p className="mt-2 max-w-md text-sm font-medium text-[#fff7dc]/85 md:text-base">
                Kamu bocah berkaos kuning dengan dua pistol. Pedro si pisang ajaib membisikkan satu misi: habisi geng
                mafia Don Kumis — dengan flip, slow-motion, dan gaya!
              </p>
              <div className="mt-6 flex flex-wrap items-center justify-center gap-4 lg:justify-start">
                <Btn big onClick={() => g()?.startStory()}>
                  ▶ MAIN STORY
                </Btn>
                <Btn big color="red" onClick={openBossSelect}>
                  ☠ BOSS MODE
                </Btn>
                <Btn big color="green" onClick={() => g()?.startFist()}>
                  🥋 KUNGFU
                </Btn>
                <Btn color="dark" onClick={() => setShowControls((v) => !v)}>
                  {showControls ? 'TUTUP KONTROL' : 'KONTROL'}
                </Btn>
              </div>
              <div className="mt-4 flex gap-3">
                <button
                  onClick={toggleMute}
                  className="rounded-xl border-2 border-[#120d0a] bg-[#2b2235] px-3 py-1 text-sm font-bold text-[#fff7dc] shadow-[0_3px_0_#120d0a]"
                >
                  {muted ? '🔇 Suara: OFF' : '🔊 Suara: ON'}
                </button>
                <button
                  onClick={toggleMusic}
                  className="rounded-xl border-2 border-[#120d0a] bg-[#2b2235] px-3 py-1 text-sm font-bold text-[#fff7dc] shadow-[0_3px_0_#120d0a]"
                >
                  {music ? '🎵 Musik: ON' : '🎵 Musik: OFF'}
                </button>
              </div>
              <div className="mt-3 flex max-w-sm flex-col items-center gap-2">
                <Btn color="purple" onClick={() => openArsenal(false)}>
                  🔫 ARSENAL · 38 SENJATA
                </Btn>
                <p className="text-center text-[12px] font-bold leading-snug text-[#fff7dc]/80">
                  Semua senjata sudah terbuka! 10 senjata lama + 28 senjata baru HALO. Tekan <b className="text-[#ffd23f]">TAB</b> kapan saja
                  untuk ganti, atau <b className="text-[#ffd23f]">Z / X / roda mouse</b>.
                </p>
              </div>
              {touchOnly && (
                <p className="mt-4 max-w-sm rounded-xl border-2 border-[#120d0a] bg-[#ff4d4d] px-3 py-2 text-sm font-bold text-white">
                  Game ini dirancang untuk KEYBOARD + MOUSE. Mainkan di laptop / PC untuk pengalaman terbaik.
                </p>
              )}
            </div>

            <div
              className={`hw-panel anim-pop w-full max-w-xl rounded-3xl bg-[#1d1626]/95 p-5 md:p-6 ${
                showControls ? 'block' : 'hidden lg:block'
              }`}
            >
              <h2 className="hw-outline mb-3 text-3xl text-[#ffd23f]">CARA MAIN</h2>
              <ControlsList />
              <div className="mt-4 rounded-2xl border-2 border-[#120d0a] bg-[#2b2235] p-3 text-[13px] text-[#fff7dc]/90">
                <p className="font-bold text-[#ffd23f]">💡 Gaya = Poin!</p>
                <p className="mt-1 leading-snug">
                  Bunuh musuh sambil <b>front flip</b>, <b>backflip</b>, <b>double flip</b>, <b>wall-flip</b>, <b>vault</b>,{' '}
                  <b>berputar</b>, <b>slide</b>, di <b>zipline</b>, pakai <b>split aim</b>, <b>pantulan wajan</b> atau{' '}
                  <b>lampu jatuh</b> untuk bonus gaya. Tembak lampu &amp; pintu kaca! Kill beruntun = COMBO pengali skor!
                </p>
              </div>
            </div>
          </div>
          <p className="absolute bottom-2 left-0 right-0 text-center text-[11px] font-medium text-white/35">
            Fan-game terinspirasi My Friend Pedro &amp; gaya art Happy Wheels · semua grafis & suara digambar prosedural
          </p>
        </div>
      )}

      {/* ---------------- ARSENAL ---------------- */}
      {arsenal && (screen === 'paused' || screen === 'menu') && (
        <Arsenal
          current={curWeapon}
          onPick={pickWeapon}
          onClose={closeArsenal}
          closeLabel={screen === 'menu' ? '✔ SIMPAN' : resumeOnClose.current ? '▶ LANJUT' : '✔ OK'}
        />
      )}

      {/* ---------------- BOSS SELECT ---------------- */}
      {screen === 'menu' && bossSelect && (
        <div className="absolute inset-0 flex items-start justify-center overflow-y-auto bg-[#0d0a14]/85 p-4 md:items-center">
          <div className="w-full max-w-6xl py-4">
            <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="hw-outline text-xl text-white">MODE PERTARUNGAN</p>
                <h1 className="hw-title text-6xl md:text-7xl" style={{ color: '#ff4d4d' }}>
                  BOSS MODE
                </h1>
                <p className="mt-1 max-w-xl text-sm font-medium text-[#fff7dc]/80">
                  Pilih lawanmu! Kalahkan secepat mungkin dengan damage sekecil mungkin untuk meraih RANK S.
                </p>
              </div>
              <Btn color="dark" onClick={() => setBossSelect(false)}>
                ← KEMBALI
              </Btn>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              {BOSS_ORDER.map((id, i) => {
                const info = BOSS_INFO[id];
                const rec = records[id];
                return (
                  <div
                    key={id}
                    className="hw-panel anim-pop flex flex-col rounded-3xl bg-[#1d1626]/95 p-4"
                    style={{ animationDelay: `${i * 0.08}s` }}
                  >
                    <BossPortrait id={id} />
                    <div className="mt-3 flex items-center justify-between gap-2">
                      <h2 className="hw-outline text-4xl leading-none" style={{ color: info.color }}>
                        {info.name}
                      </h2>
                      <span className="whitespace-nowrap text-lg" title="Tingkat kesulitan">
                        {'💀'.repeat(info.stars)}
                        <span className="opacity-25">{'💀'.repeat(3 - info.stars)}</span>
                      </span>
                    </div>
                    <p className="hw-outline text-lg text-white">{info.title}</p>
                    <p className="mt-1 text-[11px] font-black tracking-wider text-[#ffd23f]">ARENA: {info.arena}</p>
                    <p className="mt-2 text-sm text-[#fff7dc]/85">{info.desc}</p>
                    <ul className="mt-2 space-y-0.5 text-[13px] text-[#fff7dc]">
                      {info.attacks.map((a) => (
                        <li key={a}>⚔️ {a}</li>
                      ))}
                    </ul>
                    <div className="mt-3 rounded-xl border-2 border-[#120d0a] bg-[#2b2235] px-3 py-2 text-xs text-[#fff7dc]/90">
                      {rec ? (
                        <>
                          🏆 Menang {rec.wins}x · Terbaik {fmtTime(rec.bestTime)} · Rank{' '}
                          <b className="text-[#ffd23f]">{rec.bestRank}</b>
                        </>
                      ) : (
                        'Belum pernah dikalahkan'
                      )}
                    </div>
                    <div className="mt-auto flex justify-center pt-4">
                      <Btn
                        big
                        color={id === 'pedro' ? 'purple' : id === 'kumis' ? 'yellow' : 'red'}
                        onClick={() => {
                          setBossSelect(false);
                          g()?.startBoss(id);
                        }}
                      >
                        LAWAN!
                      </Btn>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ---------------- PAUSE ---------------- */}
      {screen === 'paused' && !arsenal && (
        <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-[#0d0a14]/75 p-4 backdrop-blur-[2px]">
          <div className="hw-panel anim-pop w-full max-w-2xl rounded-3xl bg-[#1d1626]/95 p-6">
            <h2 className="hw-title text-center text-6xl">JEDA</h2>
            {stats && (
              <p className="mt-2 text-center font-bold text-[#fff7dc]/80">
                Skor {fmtNum(stats.score)} · Musuh {stats.kills}/{stats.totalEnemies} · Waktu {fmtTime(stats.time)}
              </p>
            )}
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              <Btn onClick={() => g()?.resume()}>▶ LANJUT</Btn>
              {stats?.mode !== 'fist' && (
                <Btn color="purple" onClick={() => openArsenal(false)}>
                  🔫 ARSENAL
                </Btn>
              )}
              {isBoss ? (
                <>
                  <Btn color="red" onClick={() => g()?.start()}>
                    ULANG PERTARUNGAN
                  </Btn>
                  <Btn color="dark" onClick={toBossSelect}>
                    PILIH BOS
                  </Btn>
                </>
              ) : (
                <>
                  <Btn color="dark" onClick={() => g()?.respawn()}>
                    ULANG CHECKPOINT
                  </Btn>
                  <Btn color="red" onClick={() => g()?.start()}>
                    RESTART LEVEL
                  </Btn>
                </>
              )}
              <Btn color="dark" onClick={() => g()?.toMenu()}>
                MENU
              </Btn>
            </div>
            <div className="mt-6">
              <ControlsList compact />
            </div>
            <div className="mt-4 flex justify-center gap-3">
              <button
                onClick={toggleMute}
                className="rounded-xl border-2 border-[#120d0a] bg-[#2b2235] px-3 py-1 text-sm font-bold text-[#fff7dc] shadow-[0_3px_0_#120d0a]"
              >
                {muted ? '🔇 Suara: OFF' : '🔊 Suara: ON'}
              </button>
              <button
                onClick={toggleMusic}
                className="rounded-xl border-2 border-[#120d0a] bg-[#2b2235] px-3 py-1 text-sm font-bold text-[#fff7dc] shadow-[0_3px_0_#120d0a]"
              >
                {music ? '🎵 Musik: ON' : '🎵 Musik: OFF'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------- DEAD ---------------- */}
      {screen === 'dead' && (
        <div className="absolute inset-0 flex items-center justify-center bg-[radial-gradient(ellipse_at_center,rgba(80,0,0,0.25),rgba(20,0,0,0.8))] p-4">
          <div className="anim-pop flex max-w-xl flex-col items-center text-center">
            <h2 className="hw-title text-7xl text-[#ff4d4d] md:text-8xl" style={{ color: '#ff4d4d' }}>
              KAMU TEWAS!
            </h2>
            <div className="hw-panel mt-5 flex items-center gap-3 rounded-2xl bg-[#1d1626]/95 p-4 text-left">
              <BananaSvg className="h-14 w-14 shrink-0" />
              <div>
                <p className="hw-outline text-xl text-[#ffd23f]">PEDRO BILANG:</p>
                <p className="text-sm font-medium text-[#fff7dc]">{TIPS[tipIdx]}</p>
              </div>
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Btn big onClick={() => g()?.respawn()}>
                COBA LAGI (R)
              </Btn>
              {isBoss ? (
                <Btn color="dark" onClick={toBossSelect}>
                  PILIH BOS
                </Btn>
              ) : (
                <Btn color="dark" onClick={() => g()?.start()}>
                  RESTART LEVEL
                </Btn>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ---------------- BOSS COMPLETE ---------------- */}
      {screen === 'complete' && stats && stats.mode === 'boss' && stats.bossId && (
        <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-[#0d0a14]/80 p-4">
          <div className="hw-panel anim-pop relative w-full max-w-2xl rounded-3xl bg-[#1d1626]/95 p-6 md:p-8">
            <div className="absolute -right-3 -top-8 md:-right-8 md:-top-10">
              <div
                className="anim-stamp hw-title flex h-28 w-28 items-center justify-center rounded-full border-[6px] border-[#120d0a] text-7xl shadow-[0_8px_0_#120d0a] md:h-36 md:w-36 md:text-8xl"
                style={{ background: BOSS_INFO[stats.bossId].color, color: '#ffffff' }}
              >
                {stats.rank}
              </div>
            </div>
            <p className="hw-outline text-2xl text-white">BOSS MODE · {BOSS_INFO[stats.bossId].arena}</p>
            <h2 className="hw-title text-5xl md:text-6xl">{stats.bossName} KALAH!</h2>
            <p className="mt-1 text-sm font-medium text-[#fff7dc]/80">{BOSS_WIN[stats.bossId]}</p>
            <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
              {[
                ['WAKTU', fmtTime(stats.time)],
                ['SKOR', fmtNum(stats.score)],
                ['DAMAGE', `${stats.damageTaken}`],
                ['HEADSHOT', `${stats.headshots}`],
                ['COMBO MAKS', `x${stats.maxCombo}`],
                ['PERCOBAAN', `${stats.deaths + 1}`],
                ['REKOR', fmtTime(loadBossRecords()[stats.bossId]?.bestTime ?? stats.time)],
                ['RANK', stats.rank],
              ].map(([k, v]) => (
                <div key={k} className="rounded-2xl border-[3px] border-[#120d0a] bg-[#2b2235] p-3 text-center">
                  <p className="text-[11px] font-black tracking-wider text-[#ffd23f]">{k}</p>
                  <p className="hw-outline text-3xl text-white">{v}</p>
                </div>
              ))}
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Btn big color="green" onClick={() => g()?.start()}>
                LAWAN LAGI
              </Btn>
              <Btn color="dark" onClick={toBossSelect}>
                PILIH BOS
              </Btn>
              <Btn color="dark" onClick={() => g()?.toMenu()}>
                MENU
              </Btn>
            </div>
            <p className="mt-4 text-center text-xs font-medium text-white/50">
              Rank dihitung dari waktu (target {fmtTime(BOSS_INFO[stats.bossId].par)}) dan damage yang kamu terima.
              Rank S = cepat & nyaris tanpa luka!
            </p>
          </div>
        </div>
      )}

      {/* ---------------- KUNGFU COMPLETE ---------------- */}
      {screen === 'complete' && stats && stats.mode === 'fist' && (
        <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-[#0d0a14]/80 p-4">
          <div className="hw-panel anim-pop relative w-full max-w-2xl rounded-3xl bg-[#1d1626]/95 p-6 md:p-8">
            <div className="absolute -right-3 -top-8 md:-right-8 md:-top-10">
              <div className="anim-stamp hw-title flex h-28 w-28 items-center justify-center rounded-full border-[6px] border-[#120d0a] bg-[#c81d2a] text-7xl text-white shadow-[0_8px_0_#120d0a] md:h-36 md:w-36 md:text-8xl">
                {stats.rank}
              </div>
            </div>
            <p className="hw-outline text-2xl text-white">MODE KUNGFU</p>
            <h2 className="hw-title text-5xl md:text-6xl">DOJO DITAKLUKKAN!</h2>
            <p className="mt-1 text-sm font-medium text-[#fff7dc]/80">
              Guru Naga tumbang. Kamu menamatkan dojo di usia {stats.age} tahun.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
              {[
                ['WAKTU', fmtTime(stats.time)],
                ['SKOR', fmtNum(stats.score)],
                ['UMUR', `${stats.age}`],
                ['MATI', `${stats.deaths}x`],
                ['MUSUH', `${stats.kills}`],
                ['COMBO MAKS', `x${stats.maxCombo}`],
                ['GELOMBANG', `${stats.wave}`],
                ['RANK', stats.rank],
              ].map(([k, v]) => (
                <div key={k} className="rounded-2xl border-[3px] border-[#120d0a] bg-[#2b2235] p-3 text-center">
                  <p className="text-[11px] font-black tracking-wider text-[#ffd23f]">{k}</p>
                  <p className="hw-outline text-3xl text-white">{v}</p>
                </div>
              ))}
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Btn big color="green" onClick={() => g()?.start()}>
                MAIN LAGI
              </Btn>
              <Btn color="dark" onClick={() => g()?.toMenu()}>
                MENU
              </Btn>
            </div>
            <p className="mt-4 text-center text-xs font-medium text-white/50">
              Rank dari umur akhir: S ≤ 24 · A ≤ 32 · B ≤ 45 · C ≤ 60
            </p>
          </div>
        </div>
      )}

      {/* ---------------- COMPLETE ---------------- */}
      {screen === 'complete' && stats && stats.mode === 'story' && (
        <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-[#0d0a14]/80 p-4">
          <div className="hw-panel anim-pop relative w-full max-w-2xl rounded-3xl bg-[#1d1626]/95 p-6 md:p-8">
            <div className="absolute -right-3 -top-8 md:-right-8 md:-top-10">
              <div
                className="anim-stamp hw-title flex h-28 w-28 items-center justify-center rounded-full border-[6px] border-[#120d0a] bg-[#ff4d4d] text-7xl shadow-[0_8px_0_#120d0a] md:h-36 md:w-36 md:text-8xl"
                style={{ color: stats.rank === 'S' ? '#ffd23f' : '#fff' }}
              >
                {stats.rank}
              </div>
            </div>
            <p className="hw-outline text-2xl text-white">LEVEL 1</p>
            <h2 className="hw-title text-5xl md:text-7xl">SELESAI!</h2>
            <p className="mt-1 text-sm font-medium text-[#fff7dc]/80">
              Don Kumis tumbang dan gudangnya hancur. Pedro bangga padamu... atau mungkin cuma lapar.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
              {[
                ['SKOR', fmtNum(stats.score)],
                ['WAKTU', fmtTime(stats.time)],
                ['MUSUH', `${stats.kills}/${stats.totalEnemies}`],
                ['HEADSHOT', `${stats.headshots}`],
                ['COMBO MAKS', `x${stats.maxCombo}`],
                ['PISANG', `${stats.bananas}/${stats.totalBananas}`],
                ['TEWAS', `${stats.deaths}x`],
                ['RANK', stats.rank],
              ].map(([k, v]) => (
                <div key={k} className="rounded-2xl border-[3px] border-[#120d0a] bg-[#2b2235] p-3 text-center">
                  <p className="text-[11px] font-black tracking-wider text-[#ffd23f]">{k}</p>
                  <p className="hw-outline text-3xl text-white">{v}</p>
                </div>
              ))}
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Btn big color="green" onClick={() => g()?.start()}>
                MAIN LAGI
              </Btn>
              <Btn color="dark" onClick={() => g()?.toMenu()}>
                MENU
              </Btn>
            </div>
            <p className="mt-4 text-center text-xs font-medium text-white/50">
              Rank: S ≥ 18.000 · A ≥ 12.000 · B ≥ 7.000 · C ≥ 3.500 — rangkai kill bergaya untuk combo besar!
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
