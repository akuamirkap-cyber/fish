import { useEffect, useRef, useState } from 'react';
import { OLD_WEAPON_ORDER, WEAPON_INFO } from '../game/weapons';
import { HALO_DESC, HALO_ORDER, HALO_RARITY_COLOR, haloArtVersion, haloSpec, isHaloId, preloadHaloArt, type HaloRarity } from '../game/halo';
import { drawWeaponIcon } from '../game/weaponIcon';

const RARITIES: HaloRarity[] = ['UMUM', 'LANGKA', 'EPIC', 'LEGENDARIS'];

const OLD_NOTE: Record<string, string> = {
  pistol: 'Dua pistol · klik kanan = split aim',
  uzi: 'Semprot peluru super cepat',
  shotgun: '8 pelet · shotgun jump',
  ak47: 'Otomatis & stabil',
  sniper: 'Tembus 4 musuh · klik kanan = scope',
  bat: 'Pukul balik peluru & musuh',
  sling: 'Tahan untuk tarik, lepas untuk tembak',
  cricket: 'Kecil tapi meledak dahsyat',
  katana: 'Tebas, tangkis & belah peluru',
  fist: 'Kung fu tangan kosong',
};

function Thumb({ id, ver, w = 108, h = 58 }: { id: string; ver: number; w?: number; h?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr);
    cv.height = Math.round(h * dpr);
    const c = cv.getContext('2d');
    if (!c) return;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, w, h);
    try {
      drawWeaponIcon(c, id, w / 2, h / 2, w - 10, h - 8);
    } catch {
      /* ikon gagal digambar: biarkan kosong */
    }
  }, [id, ver, w, h]);
  return <canvas ref={ref} style={{ width: w, height: h }} className="pointer-events-none block" />;
}

function Card({
  id,
  active,
  ver,
  accent,
  label,
  note,
  badge,
  onPick,
  onUse,
}: {
  id: string;
  active: boolean;
  ver: number;
  accent: string;
  label: string;
  note: string;
  badge?: string;
  onPick: () => void;
  onUse: () => void;
}) {
  return (
    <button
      data-weapon={id}
      onClick={(e) => {
        e.stopPropagation();
        onPick();
      }}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onUse();
      }}
      onMouseDown={(e) => e.stopPropagation()}
      className={`relative flex flex-col items-center rounded-xl border-2 px-1 pb-1.5 pt-1 text-center transition-transform hover:-translate-y-0.5 ${
        active ? 'bg-[#ffd23f]/20' : 'bg-[#120d0a]/55 hover:bg-[#2b2235]'
      }`}
      style={{ borderColor: active ? '#ffd23f' : accent, boxShadow: active ? '0 0 0 2px #ffd23f, 0 0 18px rgba(255,210,63,0.45)' : 'none' }}
    >
      {badge && (
        <span className="absolute left-1 top-1 rounded bg-[#120d0a]/80 px-1 text-[10px] font-black leading-4 text-[#ffd23f]">{badge}</span>
      )}
      {active && (
        <span className="absolute right-1 top-1 rounded bg-[#ffd23f] px-1 text-[9px] font-black leading-4 text-[#120d0a]">DIPAKAI</span>
      )}
      <Thumb id={id} ver={ver} />
      <span className="mt-0.5 w-full truncate text-[11px] font-black leading-tight" style={{ color: active ? '#ffd23f' : '#fff7dc' }}>
        {label}
      </span>
      <span className="w-full truncate text-[9.5px] font-bold leading-tight" style={{ color: accent }}>
        {note}
      </span>
    </button>
  );
}

export default function Arsenal({
  current,
  onPick,
  onClose,
  closeLabel,
}: {
  current: string;
  onPick: (id: string) => void;
  onClose: () => void;
  closeLabel: string;
}) {
  const [ver, setVer] = useState(haloArtVersion());
  useEffect(() => {
    preloadHaloArt();
    const t = window.setInterval(() => setVer(haloArtVersion()), 250);
    return () => window.clearInterval(t);
  }, []);

  const halo = isHaloId(current) ? haloSpec(current) : null;
  const info = WEAPON_INFO[current as keyof typeof WEAPON_INFO];

  return (
    <div
      className="absolute inset-0 z-30 flex items-center justify-center bg-[#0d0a14]/80 p-2 backdrop-blur-[2px] md:p-4"
      onMouseDown={(e) => e.stopPropagation()}
    >
      <div className="hw-panel anim-pop flex max-h-full w-full max-w-6xl flex-col rounded-3xl bg-[#1d1626]/95 p-3 md:p-5">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <h2 className="hw-title text-4xl md:text-5xl">ARSENAL</h2>
            <p className="text-[12px] font-bold text-[#fff7dc]/80">
              Semua {OLD_WEAPON_ORDER.length + HALO_ORDER.length} senjata sudah terbuka · klik = pakai · klik 2x = pakai &amp; lanjut · TAB = tutup
            </p>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            onMouseDown={(e) => e.stopPropagation()}
            className="hw-btn rounded-2xl bg-[#5fd068] px-5 py-1.5 text-2xl text-[#120d0a]"
          >
            {closeLabel}
          </button>
        </div>

        <div className="mt-3 min-h-0 flex-1 overflow-y-auto pr-1">
          <h3 className="hw-outline text-xl text-[#ffd23f]">SENJATA LAMA · PARKOUR</h3>
          <div className="mt-1.5 grid grid-cols-3 gap-2 sm:grid-cols-5 lg:grid-cols-10">
            {OLD_WEAPON_ORDER.map((id, i) => (
              <Card
                key={id}
                id={id}
                ver={ver}
                active={current === id}
                accent="#8a7f96"
                label={WEAPON_INFO[id].name}
                note={OLD_NOTE[id] ?? ''}
                badge={`${(i + 1) % 10}`}
                onPick={() => onPick(id)}
                onUse={() => {
                  onPick(id);
                  onClose();
                }}
              />
            ))}
          </div>

          <h3 className="hw-outline mt-4 text-xl text-[#7fe0ff]">SENJATA BARU · HALO ARSENAL</h3>
          {RARITIES.map((r) => (
            <div key={r} className="mt-1.5">
              <div className="mb-1 flex items-center gap-2">
                <span className="rounded px-1.5 text-[11px] font-black leading-5 text-[#120d0a]" style={{ background: HALO_RARITY_COLOR[r] }}>
                  {r}
                </span>
                <span className="h-[2px] flex-1 rounded" style={{ background: HALO_RARITY_COLOR[r], opacity: 0.35 }} />
              </div>
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-7">
                {HALO_ORDER.filter((id) => haloSpec(id).rarity === r).map((id) => {
                  const s = haloSpec(id);
                  return (
                    <Card
                      key={id}
                      id={id}
                      ver={ver}
                      active={current === id}
                      accent={HALO_RARITY_COLOR[r]}
                      label={s.name}
                      note={s.perk}
                      onPick={() => onPick(id)}
                      onUse={() => {
                        onPick(id);
                        onClose();
                      }}
                    />
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-3 flex items-center gap-3 rounded-2xl border-2 border-[#120d0a] bg-[#2b2235] p-2">
          <div className="shrink-0 rounded-xl bg-[#120d0a]/60">
            <Thumb id={current} ver={ver} w={150} h={70} />
          </div>
          <div className="min-w-0 flex-1 text-[#fff7dc]">
            <p className="truncate text-lg font-black leading-tight" style={{ color: halo ? HALO_RARITY_COLOR[halo.rarity] : '#ffd23f' }}>
              {info ? info.name : current}
              {halo && <span className="ml-2 text-[11px] text-[#fff7dc]/70">{halo.rarity} · {halo.perk}</span>}
            </p>
            <p className="line-clamp-2 text-[12px] font-medium leading-snug text-[#fff7dc]/85">
              {halo ? HALO_DESC[halo.art] ?? halo.def.desc : OLD_NOTE[current] ?? ''}
            </p>
            {halo && (
              <p className="mt-0.5 text-[11px] font-bold text-[#fff7dc]/70">
                Magasin {halo.mag} · Damage {halo.dmg}
                {halo.pellets > 1 ? ` x${halo.pellets}` : ''} · Jeda {halo.spinup ? `${halo.cd}→${halo.cdMin}` : halo.cd}s ·{' '}
                {halo.two ? 'Dua tangan' : 'Satu tangan'} · R = reload
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
