// ============================================================================
// MODE "DUNIA LAUT 3D"
// A live three.js scene (orthographic, side-on) that replaces the painted water,
// reef, rocks and sea-floor of the 2D arcade layer. The game logic, collisions and
// fish are untouched: every rock is extruded from the very same signed-distance
// fields the physics uses, so silhouettes line up pixel-for-pixel.
//
// Corals, kelp, boulders, the diver and the Jules-Verne submarine are generated
// by the PENYELAM (Abyssal Garden) procedural mesh builders.
// ============================================================================
import * as THREE from "three";
import type { Ocean, Formation } from "../ocean";
import { WORLD_W, WORLD_H, FLOOR_TOP } from "../ocean";
import {
  SHARED,
  backdropMaterial,
  raysMaterial,
  rockMaterial,
  coralMaterial,
  litMaterial,
  glowMaterial,
  plumeMaterial,
} from "./glsl";
import {
  mulberry32,
  fbm,
  solidToGeometry,
  normalizeGeo,
  kelpGeometry,
  asRockChunk,
  sharedGeo,
  entityGeometry,
  paintLit,
  sampleSdf,
  buildRelief,
  composeTRS,
} from "./geometry";
import type { Relief, Palette } from "./geometry";
// PENYELAM procedural builders (copied verbatim from PENYELAM.zip)
import { meshCoral, meshTubes, meshCoralBloom, meshCoralPlate, meshChunk } from "../penyelam/world.js";
import { buildDiverMesh, buildSubmarineMesh } from "../penyelam/meshes.js";

type RGB = [number, number, number];

// ---------------------------------------------------------------- palettes
const ZONE_ROCK: { rock0: RGB; rock1: RGB; crust: RGB; vein: RGB; veinK: number }[] = [
  { rock0: [0.17, 0.23, 0.27], rock1: [0.46, 0.54, 0.54], crust: [0.8, 0.72, 0.52], vein: [0, 0, 0], veinK: 0 },
  { rock0: [0.12, 0.16, 0.28], rock1: [0.32, 0.4, 0.56], crust: [0.36, 0.48, 0.7], vein: [0.4, 0.6, 1.0], veinK: 0.15 },
  { rock0: [0.09, 0.08, 0.2], rock1: [0.27, 0.23, 0.44], crust: [0.42, 0.3, 0.68], vein: [0.45, 0.85, 1.0], veinK: 1 },
  { rock0: [0.07, 0.07, 0.14], rock1: [0.21, 0.2, 0.31], crust: [0.6, 0.52, 0.4], vein: [1.0, 0.5, 0.2], veinK: 0.9 },
];

// coral kinds
const K_STAG = 0,
  K_FAN = 1,
  K_TUBE = 2,
  K_BLOOM = 3,
  K_PLATE = 4,
  K_KELP = 5;
const KIND_H: [number, number][] = [
  [20, 38],
  [26, 50],
  [14, 28],
  [14, 26],
  [24, 40],
  [34, 70],
];
const KIND_SWAY = [0.05, 0.06, 0.02, 0.03, 0.012, 0.2];

const CORAL_COL: RGB[][][] = [
  // zone 0 : warm sunlit garden
  [
    [[0.93, 0.52, 0.28], [0.95, 0.62, 0.4], [0.9, 0.42, 0.4], [0.96, 0.72, 0.55]],
    [[0.62, 0.45, 0.82], [0.72, 0.55, 0.88], [0.8, 0.4, 0.7]],
    [[0.95, 0.78, 0.2], [0.9, 0.65, 0.15], [0.96, 0.84, 0.3]],
    [[0.95, 0.62, 0.52], [0.98, 0.78, 0.62], [0.9, 0.5, 0.6]],
    [[0.28, 0.72, 0.72], [0.4, 0.8, 0.7], [0.3, 0.6, 0.78]],
    [[0.55, 0.62, 0.22], [0.4, 0.55, 0.25], [0.62, 0.58, 0.2]],
  ],
  // zone 1 : gorgonian canyon
  [
    [[0.9, 0.4, 0.35], [0.95, 0.55, 0.4], [0.85, 0.35, 0.55]],
    [[0.55, 0.45, 0.9], [0.7, 0.5, 0.95], [0.3, 0.6, 0.9], [0.9, 0.4, 0.6]],
    [[0.8, 0.7, 0.3], [0.9, 0.6, 0.3]],
    [[0.85, 0.5, 0.7], [0.7, 0.55, 0.9]],
    [[0.25, 0.6, 0.85], [0.35, 0.75, 0.85]],
    [[0.3, 0.55, 0.4], [0.35, 0.6, 0.5]],
  ],
  // zone 2 : bioluminescent terraces
  [
    [[0.4, 0.6, 1.0], [1.0, 0.4, 0.7], [0.6, 0.45, 1.0]],
    [[0.3, 0.9, 1.0], [0.7, 0.4, 1.0], [1.0, 0.35, 0.8]],
    [[0.5, 1.0, 0.7], [1.0, 0.8, 0.3]],
    [[0.8, 0.5, 1.0], [0.4, 0.8, 1.0]],
    [[0.3, 0.9, 0.9], [0.5, 0.7, 1.0]],
    [[0.4, 0.95, 0.6], [0.3, 0.8, 0.8]],
  ],
  // zone 3 : abyssal vents
  [
    [[1.0, 0.5, 0.25], [0.95, 0.4, 0.35]],
    [[0.6, 0.5, 1.0], [1.0, 0.6, 0.3], [0.4, 0.8, 1.0]],
    [[1.0, 0.35, 0.28], [0.95, 0.9, 0.85], [1.0, 0.55, 0.3]],
    [[1.0, 0.55, 0.75], [0.8, 0.6, 1.0]],
    [[0.5, 0.8, 1.0], [0.7, 0.7, 1.0]],
    [[0.5, 0.8, 0.5], [0.4, 0.7, 0.7]],
  ],
];
const KIND_W: number[][] = [
  [28, 14, 14, 16, 14, 14],
  [20, 28, 16, 12, 10, 14],
  [18, 22, 20, 20, 20, 0],
  [14, 20, 34, 16, 16, 0],
];
const ZONE_GLOW = [0, 0.25, 1, 0.8];

function pick<T>(r: () => number, a: T[]): T {
  return a[Math.min(a.length - 1, (r() * a.length) | 0)];
}
function pickKind(r: () => number, zone: number) {
  const w = KIND_W[zone];
  let tot = 0;
  for (const v of w) tot += v;
  let x = r() * tot;
  for (let k = 0; k < w.length; k++) {
    x -= w[k];
    if (x <= 0) return k;
  }
  return 0;
}

// ---------------------------------------------------------------- batched instancing
interface Item {
  x: number;
  y: number;
  z: number;
  h: number;
  sq: number;
  tilt: number;
  turn: number;
  tint: RGB;
  ph: number;
  glow: number;
}

class Batch {
  items: Item[][] = [[], [], [], [], [], []];
  add(kind: number, x: number, y: number, z: number, h: number, tilt: number, turn: number, tint: RGB, ph: number, glow: number, sq = 1) {
    this.items[kind].push({ x, y, z, h, sq, tilt, turn, tint, ph, glow });
  }
}

interface ChunkItem {
  x: number;
  y: number;
  z: number;
  r: number;
  sy: number;
  turn: number;
}

export class LautWorld {
  private static sup: boolean | null = null;
  static supported() {
    if (LautWorld.sup === null) {
      try {
        const c = document.createElement("canvas");
        const gl = c.getContext("webgl2");
        LautWorld.sup = !!gl;
        (gl?.getExtension("WEBGL_lose_context") as { loseContext?: () => void } | null)?.loseContext?.();
      } catch {
        LautWorld.sup = false;
      }
    }
    return LautWorld.sup;
  }

  ready = false;
  failed = false;
  progress = 0;

  private oc: Ocean;
  private gen: Generator<void, void, void>;
  private renderer!: THREE.WebGLRenderer;
  private cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 1800);
  private scenes: THREE.Scene[] = [new THREE.Scene(), new THREE.Scene(), new THREE.Scene(), new THREE.Scene()];
  private w = 0;
  private h = 0;

  private kindGeo: THREE.BufferGeometry[] = [];
  private chunkGeo: THREE.BufferGeometry[] = [];
  private matCache = new Map<string, THREE.Material>();
  private disposables: { dispose: () => void }[] = [];

  // parallax groups
  private farA = new THREE.Group();
  private farB = new THREE.Group();
  private entA = new THREE.Group(); // submarines
  private entB = new THREE.Group(); // divers
  private fgGroup = new THREE.Group();
  private fgRoot = new THREE.Group();
  private farParams = {
    A: { p: 0.2, s: 0.38, z: -330 },
    B: { p: 0.45, s: 0.62, z: -250 },
  };
  private ENT_A = { p: 0.55, period: 0 };
  private ENT_B = { p: 0.72, period: 0 };
  private FG_P = 1.24;

  private caveForms: Formation[] = [];
  private vents: { g: THREE.Group; x: number; mats: THREE.ShaderMaterial[]; pts: THREE.Points }[] = [];
  private subs: { wrap: THREE.Group; root: THREE.Group; prop: THREE.Mesh; dir: number; phase: number; speed: number; yl: number }[] = [];
  private divers: {
    wrap: THREE.Group;
    root: THREE.Group;
    legL: THREE.Mesh;
    legR: THREE.Mesh;
    armL: THREE.Mesh;
    armR: THREE.Mesh;
    bub: THREE.ShaderMaterial;
    dir: number;
    phase: number;
    speed: number;
    yl: number;
  }[] = [];
  private raysNear!: THREE.Mesh;
  private visible = [true, true, false, false];
  private lastT = 0;

  constructor(oc: Ocean) {
    this.oc = oc;
    this.gen = this.build();
  }

  // ------------------------------------------------------------------ incremental construction
  step(ms: number): boolean {
    if (this.ready || this.failed) return true;
    const t0 = performance.now();
    try {
      do {
        const r = this.gen.next();
        if (r.done) {
          this.ready = true;
          this.progress = 1;
          return true;
        }
      } while (performance.now() - t0 < ms);
    } catch (e) {
      console.error("[Dunia Laut] build failed", e);
      this.failed = true;
      this.dispose();
      return true;
    }
    return false;
  }

  private *build(): Generator<void, void, void> {
    this.initRenderer();
    yield;
    this.makeKinds();
    this.progress = 0.05;
    yield;
    this.makeBackdrop();
    yield* this.buildFar();
    this.progress = 0.2;
    const fs = this.oc.formations;
    for (let i = 0; i < fs.length; i++) {
      this.buildFormation(fs[i]);
      this.progress = 0.2 + (0.5 * (i + 1)) / fs.length;
      yield;
    }
    this.buildFloor();
    this.progress = 0.78;
    yield;
    this.buildForeground();
    yield;
    this.buildEntities();
    this.progress = 0.88;
    yield;
    // compile every program up-front so the first frames do not hitch
    this.cam.position.set(1900, -520, 600);
    for (let i = 0; i < 4; i++) {
      this.renderer.compile(this.scenes[i], this.cam);
      this.progress = 0.88 + 0.03 * (i + 1);
      yield;
    }
  }

  private initRenderer() {
    const canvas = document.createElement("canvas");
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
      premultipliedAlpha: true,
      powerPreference: "high-performance",
      preserveDrawingBuffer: false,
    });
    this.renderer.autoClear = false;
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.setPixelRatio(1);
    this.cam.position.set(0, 0, 600);
    this.cam.lookAt(0, 0, 0);
    for (const s of this.scenes) s.matrixWorldAutoUpdate = true;
  }

  // ------------------------------------------------------------------ shared geometries
  private makeKinds() {
    const norm = (b: any) => normalizeGeo(solidToGeometry(b));
    this.kindGeo[K_STAG] = norm(meshCoral(0).build());
    this.kindGeo[K_FAN] = norm(meshCoral(1).build());
    this.kindGeo[K_TUBE] = norm(meshTubes().build());
    this.kindGeo[K_BLOOM] = norm(meshCoralBloom().build());
    // table corals are tipped towards the viewer so the scalloped plates read from the side
    const plate = solidToGeometry(meshCoralPlate().build());
    plate.rotateX(0.95);
    this.kindGeo[K_PLATE] = normalizeGeo(plate);
    this.kindGeo[K_KELP] = kelpGeometry();
    for (let i = 0; i < 3; i++) {
      const g = normalizeGeo(solidToGeometry(meshChunk(11 + i * 7, 2).build()), "radius");
      this.chunkGeo.push(asRockChunk(g));
    }
  }

  private coralMats(fog: number, dark: number): THREE.Material[] {
    const key = `c${fog}_${dark}`;
    let m = this.matCache.get(key) as any;
    if (!m) {
      m = {
        solid: coralMaterial({ fog, dark, sway: 1, double: true }),
        kelp: coralMaterial({ fog, dark, sway: 1, double: true }),
      };
      this.matCache.set(key, m);
      this.disposables.push(m.solid, m.kelp);
    }
    return [m.solid, m.solid, m.solid, m.solid, m.solid, m.kelp];
  }

  private flushBatch(b: Batch, parent: THREE.Object3D, fog: number, dark: number, order = 0) {
    const mats = this.coralMats(fog, dark);
    const mtx = new THREE.Matrix4();
    for (let kind = 0; kind < 6; kind++) {
      const it = b.items[kind];
      if (!it.length) continue;
      const geo = sharedGeo(this.kindGeo[kind]);
      const n = it.length;
      const tint = new Float32Array(n * 4),
        data = new Float32Array(n * 2);
      const mesh = new THREE.InstancedMesh(geo, mats[kind], n);
      for (let i = 0; i < n; i++) {
        const q = it[i];
        composeTRS(mtx, q.x, -q.y, q.z, q.h * q.sq, q.h, q.h * q.sq, q.tilt, q.turn);
        mesh.setMatrixAt(i, mtx);
        tint[i * 4] = q.tint[0];
        tint[i * 4 + 1] = q.tint[1];
        tint[i * 4 + 2] = q.tint[2];
        tint[i * 4 + 3] = q.ph;
        data[i * 2] = KIND_SWAY[kind];
        data[i * 2 + 1] = q.glow;
      }
      geo.setAttribute("iTint", new THREE.InstancedBufferAttribute(tint, 4));
      geo.setAttribute("iData", new THREE.InstancedBufferAttribute(data, 2));
      mesh.instanceMatrix.needsUpdate = true;
      mesh.computeBoundingSphere();
      if (mesh.boundingSphere) mesh.boundingSphere.radius += 8;
      mesh.renderOrder = order;
      parent.add(mesh);
      this.disposables.push(geo);
    }
  }

  private flushChunks(items: ChunkItem[], parent: THREE.Object3D, zone: number, fog: number, dark: number, key: string) {
    if (!items.length) return;
    const z = ZONE_ROCK[zone];
    const mat = rockMaterial({ ...z, seed: 7 + zone * 13, fog, dark, instanced: true, bump: 1.1 });
    this.disposables.push(mat);
    const mtx = new THREE.Matrix4();
    for (let v = 0; v < this.chunkGeo.length; v++) {
      const mine = items.filter((_, i) => i % this.chunkGeo.length === v);
      if (!mine.length) continue;
      const geo = sharedGeo(this.chunkGeo[v]);
      const mesh = new THREE.InstancedMesh(geo, mat, mine.length);
      mine.forEach((c, i) => {
        composeTRS(mtx, c.x, -c.y, c.z, c.r, c.r * c.sy, c.r, 0, c.turn);
        mesh.setMatrixAt(i, mtx);
      });
      mesh.instanceMatrix.needsUpdate = true;
      mesh.computeBoundingSphere();
      mesh.name = key;
      mesh.renderOrder = 9;
      parent.add(mesh);
      this.disposables.push(geo);
    }
  }

  // ------------------------------------------------------------------ backdrop & light
  private makeBackdrop() {
    const quad = new THREE.PlaneGeometry(2, 2);
    const bd = new THREE.Mesh(quad, backdropMaterial());
    bd.frustumCulled = false;
    bd.renderOrder = -100;
    this.scenes[0].add(bd);

    const mk = (par: number, strength: number, sharp: number, speed: number, off: number, additive: boolean, order: number, scene: THREE.Scene) => {
      const m = new THREE.Mesh(quad, raysMaterial({ par, strength, sharp, speed, off, additive }));
      m.frustumCulled = false;
      m.renderOrder = order;
      scene.add(m);
      return m;
    };
    mk(0.3, 0.55, 0.2, 0.55, 300, true, -90, this.scenes[0]); // far, broad shafts behind the canyon
    mk(0.62, 0.42, 0.7, 0.8, 1700, true, 6, this.scenes[0]); // mid, crisper shafts crossing the far walls
    this.raysNear = mk(1.14, 0.34, 1.3, 1.0, 900, false, 6, this.scenes[3]); // crisp shafts in front of the reef
  }

  // ------------------------------------------------------------------ far canyon walls (parallax 0.2 / 0.45)
  private *buildFar(): Generator<void, void, void> {
    this.buildFarLayer(this.farA, this.farParams.A, 0.84, 0.0, 18, 11, false);
    yield;
    this.buildFarLayer(this.farB, this.farParams.B, 0.56, 0.06, 14, 29, true);
    this.scenes[0].add(this.farA, this.farB);
  }

  private buildFarLayer(group: THREE.Group, P: { p: number; s: number; z: number }, fog: number, dark: number, step: number, seed: number, corals: boolean) {
    const { p, s } = P;
    const x0 = (-520 * (1 - p)) / s,
      wL = (WORLD_W * p + 1050 * (1 - p)) / s;
    const y0 = (-470 * (1 - p) - 60) / s,
      hL = (2700 * p + 950) / s;
    const nx = Math.ceil(wL / step) + 1,
      ny = Math.ceil(hL / step) + 1;
    const floorL = (2700 - (1 - p) * 2480) / s;
    const rng = mulberry32(seed * 977);
    // tower heights + a few arches
    const hAt = (x: number) => floorL * (0.18 + 0.8 * Math.pow(fbm(x * s * 0.0034 + seed, seed * 0.3, seed, 3), 1.6));
    const arches: { x: number; y: number; rx: number; ry: number }[] = [];
    for (let i = 0; i < 9; i++) {
      const ax = x0 + rng() * wL;
      arches.push({ x: ax, y: floorL - hAt(ax) * (0.25 + rng() * 0.5), rx: ((90 + rng() * 150) / s) * 0.75, ry: ((60 + rng() * 90) / s) * 0.75 });
    }
    const S = new Float32Array(nx * ny);
    for (let j = 0; j < ny; j++) {
      const y = y0 + j * step;
      for (let i = 0; i < nx; i++) {
        const x = x0 + i * step;
        const top = floorL - hAt(x);
        let sd = -(y - top + 60 * (fbm(x * 0.009 * s, y * 0.006 * s, seed, 3) - 0.5) * 2);
        for (const a of arches) {
          const ex = (x - a.x) / a.rx,
            ey = (y - a.y) / a.ry;
          const e = (Math.sqrt(ex * ex + ey * ey) - 1) * Math.min(a.rx, a.ry); // <0 inside the arch opening
          if (e < 0) sd = Math.max(sd, -e);
        }
        S[j * nx + i] = sd;
      }
    }
    const rel = buildRelief({ x0, y0, step, nx, ny, S, zMax: 70, zR: 140, amp: 16, seed: seed * 1.3, noiseFreq: 0.01 });
    const zone = group === this.farA ? 1 : 0;
    const zr = ZONE_ROCK[zone];
    const mat = rockMaterial({
      rock0: [zr.rock0[0] * 0.8, zr.rock0[1] * 1.0, zr.rock0[2] * 1.05],
      rock1: zr.rock1,
      crust: zr.crust,
      vein: zr.vein,
      veinK: 0,
      seed,
      fog,
      dark,
      bump: 0.7,
      lite: true,
    });
    this.disposables.push(mat, rel.geo);
    const mesh = new THREE.Mesh(rel.geo, mat);
    mesh.renderOrder = group === this.farA ? -80 : -70;
    mesh.frustumCulled = false;
    group.add(mesh);

    if (corals) {
      const b = new Batch();
      for (let x = x0 + 30; x < x0 + wL - 30; x += 38 + rng() * 46) {
        const top = floorL - hAt(x);
        // only on the open tops, never inside an arch
        let inArch = false;
        for (const a of arches) if (Math.abs(x - a.x) < a.rx && Math.abs(top - a.y) < a.ry * 1.2) inArch = true;
        if (inArch) continue;
        const kind = pickKind(rng, 0);
        const tint = pick(rng, CORAL_COL[0][kind]);
        const hh = ((KIND_H[kind][0] + rng() * (KIND_H[kind][1] - KIND_H[kind][0])) * 1.5) / s;
        b.add(kind, x, top + 6, rel.zAt(x, top + 10) + 2, hh, (rng() - 0.5) * 0.4, rng() * 6.28, tint, rng() * 6.28, 0, 0.9 + rng() * 0.4);
      }
      this.flushBatch(b, group, fog, dark, -69);
    }
  }

  // ------------------------------------------------------------------ main plane: pinnacles
  private buildFormation(f: Formation) {
    const zone = f.zone;
    const zr = ZONE_ROCK[zone];
    const sc = f.sdfCave;
    const nx = sc.sw,
      ny = sc.sh;
    const x0 = f.x - sc.pad,
      y0 = f.y - sc.pad;
    const S = new Float32Array(nx * ny);
    for (let j = 0; j < ny; j++)
      for (let i = 0; i < nx; i++) S[j * nx + i] = sampleSdf(f.sdfSolid, f.x, f.y, x0 + i * sc.step, y0 + j * sc.step);
    const C = new Float32Array(sc.data);
    const rel: Relief = buildRelief({ x0, y0, step: sc.step, nx, ny, S, C, zMax: 30, zR: 40, amp: 7, seed: f.seed * 0.0137, caveZ: 3, lipW: 20 });
    const root = new THREE.Group();
    this.scenes[1].add(root);

    const mat = rockMaterial({ ...zr, seed: (f.seed % 89) + 1, fog: 0, cave: true });
    const mesh = new THREE.Mesh(rel.geo, mat);
    mesh.renderOrder = 12;
    root.add(mesh);
    this.disposables.push(mat, rel.geo);

    // cave lips drawn again over the fish (pass 2)
    if (f.cave) {
      const lm = rockMaterial({ ...zr, seed: (f.seed % 89) + 1, fog: 0, cave: true, lip: true });
      const lip = new THREE.Mesh(rel.geo, lm);
      lip.renderOrder = 12;
      this.scenes[2].add(lip);
      this.disposables.push(lm);
      this.caveForms.push(f);
    }

    // rooted stem / hanging column
    this.buildColumn(f, root);

    // living reef
    const rng = mulberry32(f.seed * 31 + 7);
    const b = new Batch();
    const W = f.w;
    let first = -1,
      last = -1;
    for (let x = 0; x < W; x++)
      if (f.top[x] >= 0) {
        if (first < 0) first = x;
        last = x;
      }
    const glow = ZONE_GLOW[zone];
    const addCoral = (kind: number, wx: number, wy: number, tilt: number, hMul = 1, zOff = 0) => {
      const tint = pick(rng, CORAL_COL[zone][kind]);
      const hh = (KIND_H[kind][0] + rng() * (KIND_H[kind][1] - KIND_H[kind][0])) * hMul * 1.3;
      const z = rel.zAt(wx, wy + 3) + 1.5 + rng() * 5 + zOff;
      b.add(kind, wx, wy, z, hh, tilt, rng() * 6.28, tint, rng() * 6.28, glow, 0.85 + rng() * 0.45);
    };
    // crown
    for (let x = first + 5; x < last - 5; x += 5 + rng() * 9) {
      const xi = Math.round(x);
      const ty = f.top[xi];
      if (ty < 0) continue;
      const a = f.top[Math.max(0, xi - 6)],
        c = f.top[Math.min(W - 1, xi + 6)];
      const slope = a >= 0 && c >= 0 ? Math.atan2(-(c - a), 12) : 0;
      addCoral(pickKind(rng, zone), f.x + x, f.y + ty + 2.5, slope * 0.8 + (rng() - 0.5) * 0.3);
    }
    // shelves on both flanks
    const caveCy = f.cave ? f.cave.y - f.y : -999;
    const caveRy = f.cave ? f.cave.ry : 0;
    for (const fy of [-0.36, -0.02, 0.34]) {
      const yy = Math.round(f.cyl + f.ry * fy);
      let xl = 0;
      while (xl < W && !(f.top[xl] >= 0 && yy >= f.top[xl] && yy <= f.bot[xl])) xl++;
      let xr = W - 1;
      while (xr > 0 && !(f.top[xr] >= 0 && yy >= f.top[xr] && yy <= f.bot[xr])) xr--;
      if (xl >= xr) continue;
      const inMouth = Math.abs(yy - caveCy) < caveRy + 10;
      const openL = f.cave && (f.cave.kind === "tunnel" || f.cave.dir === -1);
      const openR = f.cave && (f.cave.kind === "tunnel" || f.cave.dir === 1);
      for (let n = 0; n < 2; n++) {
        const yv = yy + (n ? 14 : 0) + (rng() - 0.5) * 8;
        if (!(inMouth && openL) && rng() < 0.85) {
          const kk = rng() < 0.6 ? K_FAN : pickKind(rng, zone) || K_PLATE;
          addCoral(kk === K_KELP ? K_FAN : kk, f.x + xl + 2, f.y + yv, 1.15 + (rng() - 0.5) * 0.5, 0.95, 2);
        }
        if (!(inMouth && openR) && rng() < 0.85) {
          const kk = rng() < 0.6 ? K_FAN : pickKind(rng, zone) || K_PLATE;
          addCoral(kk === K_KELP ? K_FAN : kk, f.x + xr - 2, f.y + yv, -1.15 + (rng() - 0.5) * 0.5, 0.95, 2);
        }
      }
    }
    // vines hanging from the underside
    for (let x = first + 14 + rng() * 14; x < last - 14; x += 18 + rng() * 26) {
      const xi = Math.round(x);
      if (f.bot[xi] > 0 && Math.abs(xi - f.cxl) > f.rx * 0.34) {
        const tint = pick(rng, CORAL_COL[zone][K_KELP].length ? CORAL_COL[zone][K_KELP] : CORAL_COL[0][K_KELP]);
        const wy = f.y + f.bot[xi] - 3;
        b.add(K_KELP, f.x + xi, wy, rel.zAt(f.x + xi, wy - 3) + 2, 24 + rng() * 26, Math.PI + (rng() - 0.5) * 0.35, rng() * 6.28, tint, rng() * 6.28, glow, 1);
      }
    }
    this.flushBatch(b, root, 0, 0, 0);
  }

  private buildColumn(f: Formation, root: THREE.Group) {
    const step = 4;
    const hw0 = f.colHw0,
      colTop = f.colTop,
      colH = f.colH;
    const rng = mulberry32(f.colSeed * 13 + 5);
    const s1 = rng() * 9,
      s2 = rng() * 9,
      s3 = rng() * 9,
      s4 = rng() * 9,
      lean = (rng() - 0.5) * 30;
    const cxw = f.colX + f.colW / 2;
    const x0 = f.colX - 8,
      y0 = colTop;
    const nx = Math.ceil((f.colW + 16) / step) + 1,
      ny = Math.ceil(colH / step) + 1;
    const S = new Float32Array(nx * ny);
    for (let j = 0; j < ny; j++) {
      const y = y0 + j * step;
      const t = Math.min(1, (y - colTop) / colH);
      let hw = hw0 * (0.92 + 0.5 * Math.pow(t, 1.4)) + Math.sin((y - colTop) * 0.043 + s1) * 5 + Math.sin((y - colTop) * 0.13 + s2) * 2.2 + (Math.floor((y - colTop) / 41 + s3) & 1) * 4;
      if (f.colRooted) hw += Math.pow(Math.max(0, (t - 0.7) / 0.3), 2) * 38;
      const cx = cxw + Math.sin((y - colTop) * 0.017 + s4) * 7 + lean * t - 0 * 0;
      for (let i = 0; i < nx; i++) {
        const x = x0 + i * step;
        let s = Math.abs(x - cx) - hw;
        s = Math.max(s, colTop - y, y - (colTop + colH));
        S[j * nx + i] = s;
      }
    }
    const rel = buildRelief({ x0, y0, step, nx, ny, S, zMax: 22, zR: 30, amp: 5, seed: f.seed * 0.021 + 3, noiseFreq: 0.04 });
    const zr = ZONE_ROCK[f.zone];
    const rooted = f.colRooted;
    const mat = rockMaterial({
      ...zr,
      rock0: [zr.rock0[0] * 0.85, zr.rock0[1] * 0.85, zr.rock0[2] * 0.9],
      seed: (f.seed % 61) + 3,
      fog: rooted ? 0.14 : 0.22,
      fade: rooted ? undefined : [colTop + colH * 0.5, colTop + colH * 0.98],
      veinK: zr.veinK * 0.6,
    });
    const m = new THREE.Mesh(rel.geo, mat);
    m.position.z = -24;
    m.renderOrder = 5;
    root.add(m);
    this.disposables.push(mat, rel.geo);
  }

  // ------------------------------------------------------------------ sea floor, vents, treasure
  private buildFloor() {
    const top = this.oc.floorProfile();
    const step = 4;
    const topY = (x: number) => {
      let a = 0;
      for (let k = -3; k <= 3; k++) a += top[Math.max(0, Math.min(WORLD_W - 1, Math.round(x) + k))];
      return FLOOR_TOP + a / 7;
    };
    let minTop = 1e9;
    for (let x = 0; x < WORLD_W; x++) minTop = Math.min(minTop, FLOOR_TOP + top[x]);
    const y0 = minTop - 14,
      y1 = WORLD_H + 110;
    const nx = Math.ceil(WORLD_W / step) + 1,
      ny = Math.ceil((y1 - y0) / step) + 1;
    const S = new Float32Array(nx * ny);
    for (let i = 0; i < nx; i++) {
      const ty = topY(i * step);
      for (let j = 0; j < ny; j++) S[j * nx + i] = ty - (y0 + j * step);
    }
    const rel = buildRelief({ x0: 0, y0, step, nx, ny, S, zMax: 34, zR: 70, amp: 6, seed: 5.5, noiseFreq: 0.02 });
    const mat = rockMaterial({
      rock0: [0.2, 0.17, 0.19],
      rock1: [0.46, 0.4, 0.34],
      crust: [0.78, 0.7, 0.54],
      vein: [1, 0.5, 0.2],
      veinK: 0,
      seed: 3,
      fog: 0,
      crustAll: 0.92,
      bump: 0.6,
    });
    const mesh = new THREE.Mesh(rel.geo, mat);
    mesh.renderOrder = 10;
    this.scenes[1].add(mesh);
    this.disposables.push(mat, rel.geo);

    const rng = mulberry32(4242);
    const ventsXY = this.oc.vents.map((v) => ({ x: v.x - 2, y: v.y + 40 }));
    const chest = this.oc.chestPos;
    const clear = (x: number) => {
      for (const v of ventsXY) if (Math.abs(x - v.x) < 44) return false;
      if (Math.abs(x - chest.x) < 54) return false;
      return true;
    };

    // reef at the foot of the trench
    const b = new Batch();
    for (let x = 14; x < WORLD_W - 14; x += 13 + rng() * 34) {
      if (!clear(x)) continue;
      const kind = pickKind(rng, 3);
      const tint = pick(rng, CORAL_COL[3][kind]);
      const hh = KIND_H[kind][0] + rng() * (KIND_H[kind][1] - KIND_H[kind][0]);
      const y = topY(x) + 3;
      b.add(kind, x, y, rel.zAt(x, y + 3) + 2 + rng() * 6, hh * (0.9 + rng() * 0.8), (rng() - 0.5) * 0.3, rng() * 6.28, tint, rng() * 6.28, ZONE_GLOW[3], 0.85 + rng() * 0.5);
    }
    // tube-worm thickets around each black smoker
    for (const v of ventsXY) {
      for (const dx of [-34, -18, 30, 52]) {
        if (rng() < 0.2) continue;
        const x = v.x + dx + (rng() - 0.5) * 8,
          y = topY(x) + 3;
        b.add(K_TUBE, x, y, rel.zAt(x, y + 3) + 3, 18 + rng() * 14, (rng() - 0.5) * 0.3, rng() * 6.28, pick(rng, CORAL_COL[3][K_TUBE]), rng() * 6.28, 0.9, 1);
      }
    }
    this.flushBatch(b, this.scenes[1], 0, 0, 0);

    // boulders (PENYELAM meshChunk)
    const chunks: ChunkItem[] = [];
    for (let i = 0; i < 70; i++) {
      const x = 20 + rng() * (WORLD_W - 40);
      if (!clear(x)) continue;
      const r = 6 + rng() * 16;
      chunks.push({ x, y: topY(x) - r * 0.1, z: rel.zAt(x, topY(x) + 4) + 4, r, sy: 0.6 + rng() * 0.3, turn: rng() * 6 });
    }
    this.flushChunks(chunks, this.scenes[1], 3, 0, 0, "floorchunks");

    // black smokers
    const lit = litMaterial({ fog: 0 });
    this.disposables.push(lit);
    ventsXY.forEach((v, i) => {
      const g = new THREE.Group();
      const prof: THREE.Vector2[] = [
        new THREE.Vector2(19, -4),
        new THREE.Vector2(16, 6),
        new THREE.Vector2(11.5, 20),
        new THREE.Vector2(9, 34),
        new THREE.Vector2(8.5, 46),
        new THREE.Vector2(10.5, 49),
        new THREE.Vector2(7, 48),
      ];
      const chimney = paintLit(new THREE.LatheGeometry(prof, 14), [0.075, 0.07, 0.1], 0, 0.1, 0.9);
      chimney.computeVertexNormals();
      const cm = new THREE.Mesh(chimney, lit);
      g.add(cm);
      const rimG = paintLit(new THREE.TorusGeometry(8.4, 1.6, 6, 16).rotateX(Math.PI / 2), [1.0, 0.45, 0.15], 1.1, 0, 1);
      const rim = new THREE.Mesh(rimG, lit);
      rim.position.y = 49;
      g.add(rim);
      g.position.set(v.x, -v.y, 14 + (i % 2) * 3);
      g.rotation.z = (rng() - 0.5) * 0.08;
      this.scenes[1].add(g);
      this.disposables.push(chimney, rimG);

      // glow + smoke plume
      const gm = glowMaterial([1.0, 0.5, 0.18], 0.75, "radial");
      const gq = new THREE.Mesh(new THREE.PlaneGeometry(74, 56), gm);
      gq.position.set(v.x, -v.y + 52, 24);
      gq.renderOrder = 40;
      this.scenes[1].add(gq);
      const N = 26;
      const pg = new THREE.BufferGeometry();
      pg.setAttribute("position", new THREE.BufferAttribute(new Float32Array(N * 3), 3));
      pg.setAttribute("aSeed", new THREE.BufferAttribute(Float32Array.from({ length: N }, (_, k) => (k + rng() * 0.8) / N), 1));
      const pm = plumeMaterial({ color: [0.2, 0.24, 0.33], additive: false, size: 15, rise: 120, spread: 12, alpha: 0.7, speed: 0.12 });
      (pm.uniforms.uOrigin.value as THREE.Vector3).set(v.x, -v.y + 50, 30);
      const pts = new THREE.Points(pg, pm);
      pts.frustumCulled = false;
      pts.renderOrder = 41;
      this.scenes[1].add(pts);
      this.vents.push({ g, x: v.x, mats: [gm, pm], pts });
      this.disposables.push(gm, pm, pg);
    });

    // treasure chest
    const cg = new THREE.Group();
    const wood: RGB = [0.34, 0.18, 0.08],
      iron: RGB = [0.13, 0.11, 0.1],
      gold: RGB = [1.0, 0.78, 0.22];
    const part = (geo: THREE.BufferGeometry, rgb: RGB, emi: number, met: number, x: number, y: number, z: number) => {
      const m = new THREE.Mesh(paintLit(geo, rgb, emi, met, 0.95), lit);
      m.position.set(x, y, z);
      cg.add(m);
      this.disposables.push(geo);
      return m;
    };
    part(new THREE.BoxGeometry(32, 15, 20), wood, 0, 0.05, 0, 7.5, 0);
    const lid = new THREE.CylinderGeometry(10, 10, 32, 16, 1, false, 0, Math.PI);
    lid.rotateZ(Math.PI / 2);
    lid.rotateY(-Math.PI / 2);
    lid.rotateX(Math.PI / 2 * 0);
    part(lid, [0.4, 0.22, 0.1], 0, 0.05, 0, 15, 0);
    for (const bx of [-11, 11]) {
      part(new THREE.BoxGeometry(3.2, 16, 21), iron, 0, 0.5, bx, 7.5, 0);
      part(new THREE.BoxGeometry(3.4, 5, 21), iron, 0, 0.5, bx, 18.5, 0);
    }
    part(new THREE.BoxGeometry(6, 7, 2), gold, 0.35, 0.9, 0, 12, 10.8);
    cg.position.set(chest.x, -(chest.y + 14), 16);
    this.scenes[1].add(cg);
    const cgm = glowMaterial([1.0, 0.82, 0.3], 0.5, "radial");
    const cq = new THREE.Mesh(new THREE.PlaneGeometry(96, 80), cgm);
    cq.position.set(chest.x, -(chest.y + 4), 24);
    cq.renderOrder = 40;
    this.scenes[1].add(cq);
    this.disposables.push(cgm);
  }

  // ------------------------------------------------------------------ foreground silhouettes (parallax 1.24)
  private buildForeground() {
    const rng = mulberry32(777);
    const b = new Batch();
    const chunks: ChunkItem[] = [];
    const spanL = WORLD_W * this.FG_P + 900;
    const baseY = WORLD_H + 44;
    for (let x = -60; x < spanL; x += 70 + rng() * 120) {
      const roll = rng();
      if (roll < 0.3) {
        const r = 26 + rng() * 38;
        chunks.push({ x, y: baseY - r * 0.1, z: 30 + rng() * 20, r, sy: 0.7 + rng() * 0.3, turn: rng() * 6 });
      } else {
        const kind = [K_STAG, K_STAG, K_FAN, K_KELP, K_KELP, K_TUBE, K_BLOOM][(rng() * 7) | 0];
        const tint = pick(rng, CORAL_COL[3][kind]);
        const hh = kind === K_KELP ? 150 + rng() * 120 : 70 + rng() * 70;
        b.add(kind, x, baseY + 2, 44 + rng() * 30, hh, (rng() - 0.5) * 0.3, rng() * 6.28, tint, rng() * 6.28, 0.5, 0.9 + rng() * 0.6);
      }
    }
    this.fgRoot.position.z = 0;
    this.flushBatch(b, this.fgGroup, 0.08, 0.5, 0);
    this.flushChunks(chunks, this.fgGroup, 3, 0.08, 0.6, "fgchunks");
    this.fgRoot.add(this.fgGroup);
    this.scenes[3].add(this.fgRoot);
  }

  // ------------------------------------------------------------------ PENYELAM residents: submarines & divers (decor only)
  private buildEntities() {
    const PAL: Record<number, [number, number, number, number, number]> = {
      0: [0.78, 0.6, 0.2, 0, 0.1],
      1: [0.66, 0.32, 0.16, 0, 0.75],
      2: [0.78, 0.58, 0.24, 0, 0.85],
      3: [0.95, 0.66, 0.26, 1.0, 0.1],
      4: [0.06, 0.065, 0.075, 0, 0.1],
      5: [0.18, 0.1, 0.055, 0, 0.1],
      6: [0.58, 0.5, 0.26, 0, 0.6],
      7: [1.0, 0.86, 0.5, 2.0, 0.1],
      8: [0.78, 0.28, 0.22, 0, 0.2],
      10: [0.42, 0.29, 0.16, 0, 0.55],
      11: [0.74, 0.55, 0.22, 0, 0.85],
      12: [0.7, 0.48, 0.13, 0, 0.3],
      13: [0.96, 0.66, 0.26, 0.85, 0.1],
      14: [1.0, 0.74, 0.3, 1.1, 0.1],
      15: [0.92, 0.72, 0.3, 0, 0.9],
      16: [1.0, 0.84, 0.5, 2.2, 0.1],
      17: [0.1, 0.11, 0.12, 0, 0.5],
      18: [1.0, 0.5, 0.2, 1.6, 0.1],
      50: [0.84, 0.54, 0.36, 0.12, 0],
      58: [0.84, 0.54, 0.36, 0.12, 0],
      51: [0.16, 0.09, 0.05, 0, 0],
      53: [0.15, 0.05, 0.04, 0, 0],
      55: [0.58, 0.29, 0.24, 0, 0],
      56: [0.14, 0.07, 0.04, 0, 0],
    };
    const pal: Palette = (m) => PAL[m] ?? [0.7, 0.7, 0.7, 0, 0.3];
    const subBuf = buildSubmarineMesh();
    const diverBuf = buildDiverMesh();
    const lit = litMaterial({ fog: 0.12 });
    const litD = litMaterial({ fog: 0.1 });
    this.disposables.push(lit, litD);

    // ---- submarines
    const subBody = entityGeometry(subBuf, (_m, p) => p !== 1 && !(p >= 5 && p <= 10), pal);
    const subProp = entityGeometry(subBuf, (_m, p) => p === 1, pal);
    subProp.translate(0, 0.04, -2.2);
    this.disposables.push(subBody, subProp);
    const beamGeo = (w0: number, w1: number, z0: number, z1: number) => {
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute([0, w0, z0, 0, -w0, z0, 0, w1, z1, 0, -w1, z1], 3));
      g.setAttribute("uv", new THREE.Float32BufferAttribute([0, 1, 0, 0, 1, 1, 1, 0], 2));
      g.setIndex([0, 1, 2, 1, 3, 2]);
      return g;
    };
    const mkSub = (dir: number, yl: number, phase: number, speed: number, scale: number) => {
      const wrap = new THREE.Group();
      const root = new THREE.Group();
      root.scale.setScalar(scale);
      root.rotation.y = dir > 0 ? -Math.PI / 2 : Math.PI / 2;
      root.add(new THREE.Mesh(subBody, lit));
      const prop = new THREE.Mesh(subProp, lit);
      prop.position.set(0, -0.04, 2.2);
      root.add(prop);
      const beam = new THREE.Mesh(beamGeo(0.07, 0.95, -2.4, -10.5), glowMaterial([1.0, 0.86, 0.5], 0.8, "beam"));
      beam.renderOrder = 30;
      root.add(beam);
      wrap.add(root);
      const halo = new THREE.Mesh(new THREE.PlaneGeometry(scale * 5.6, scale * 3.6), glowMaterial([1.0, 0.72, 0.3], 0.16, "radial"));
      halo.renderOrder = 29;
      halo.position.z = 1;
      wrap.add(halo);
      this.entA.add(wrap);
      this.subs.push({ wrap, root, prop, dir, phase, speed, yl });
      this.disposables.push(beam.geometry, beam.material as THREE.Material, halo.geometry, halo.material as THREE.Material);
    };
    // depth bands where the player will meet them: sunlit garden & the abyssal trench
    mkSub(1, this.ENT_A.p * 380, 100, 13, 24);
    mkSub(-1, this.ENT_A.p * 1830, 1400, 11, 22);

    // ---- divers (legs kick, bubbles rise)
    const keepBody = (_m: number, p: number) => !(p === 2 || p === 3 || p === 4 || p === 5 || p === 6 || p === 7 || p === 9);
    const body = entityGeometry(diverBuf, keepBody, pal);
    const legLg = entityGeometry(diverBuf, (_m, p) => p === 4 || p === 6, pal).translate(0.072, -0.295, 0);
    const legRg = entityGeometry(diverBuf, (_m, p) => p === 5 || p === 7, pal).translate(-0.072, -0.295, 0);
    const armLg = entityGeometry(diverBuf, (_m, p) => p === 2, pal).translate(0.155, -0.54, 0);
    const armRg = entityGeometry(diverBuf, (_m, p) => p === 3, pal).translate(-0.155, -0.54, 0);
    this.disposables.push(body, legLg, legRg, armLg, armRg);
    const lampBeam = beamGeo(0.04, 0.5, 0, 0);
    // beam along the model's +y (head direction) in the (y,z) plane
    const bp = lampBeam.getAttribute("position") as THREE.BufferAttribute;
    const lampPts: [number, number, number][] = [
      [0, 1.02, 0.03],
      [0, 1.02, -0.03],
      [0, 3.4, 0.5],
      [0, 3.4, -0.5],
    ];
    lampPts.forEach((p, i) => bp.setXYZ(i, p[0], p[1], p[2]));
    const mkDiver = (dir: number, yl: number, phase: number, speed: number, scale: number) => {
      const wrap = new THREE.Group();
      const root = new THREE.Group();
      root.scale.setScalar(scale);
      root.rotation.set(-1.32, dir > 0 ? -Math.PI / 2 : Math.PI / 2, 0, "YXZ");
      root.add(new THREE.Mesh(body, litD));
      const legL = new THREE.Mesh(legLg, litD);
      legL.position.set(-0.072, 0.295, 0);
      const legR = new THREE.Mesh(legRg, litD);
      legR.position.set(0.072, 0.295, 0);
      const armL = new THREE.Mesh(armLg, litD);
      armL.position.set(-0.155, 0.54, 0);
      const armR = new THREE.Mesh(armRg, litD);
      armR.position.set(0.155, 0.54, 0);
      root.add(legL, legR, armL, armR);
      const beam = new THREE.Mesh(lampBeam, glowMaterial([1.0, 0.92, 0.7], 0.55, "beam"));
      beam.renderOrder = 30;
      // uv.x must run lamp -> far end
      root.add(beam);
      wrap.add(root);
      const halo = new THREE.Mesh(new THREE.PlaneGeometry(scale * 2.4, scale * 2.4), glowMaterial([1.0, 0.8, 0.45], 0.12, "radial"));
      halo.renderOrder = 29;
      halo.position.z = 1;
      wrap.add(halo);
      // bubbles
      const N = 14;
      const pg = new THREE.BufferGeometry();
      pg.setAttribute("position", new THREE.BufferAttribute(new Float32Array(N * 3), 3));
      pg.setAttribute("aSeed", new THREE.BufferAttribute(Float32Array.from({ length: N }, (_, k) => k / N), 1));
      const pm = plumeMaterial({ color: [0.7, 0.92, 1.0], additive: false, size: 3.2, rise: 70, spread: 5, alpha: 0.75, speed: 0.34 });
      const pts = new THREE.Points(pg, pm);
      pts.frustumCulled = false;
      pts.renderOrder = 31;
      wrap.add(pts);
      this.entB.add(wrap);
      this.divers.push({ wrap, root, legL, legR, armL, armR, bub: pm, dir, phase, speed, yl });
      this.disposables.push(beam.geometry, beam.material as THREE.Material, halo.geometry, halo.material as THREE.Material, pg, pm);
    };
    mkDiver(1, this.ENT_B.p * 340, 300, 9, 38);
    mkDiver(-1, this.ENT_B.p * 860, 1700, 8, 36);
    mkDiver(1, this.ENT_B.p * 1400, 900, 8.5, 36);

    this.entA.position.z = -150;
    this.entB.position.z = -95;
    this.scenes[0].add(this.entA, this.entB);
    this.ENT_A.period = WORLD_W * this.ENT_A.p + 1050 * (1 - this.ENT_A.p) + 520;
    this.ENT_B.period = WORLD_W * this.ENT_B.p + 1050 * (1 - this.ENT_B.p) + 400;
  }

  // ------------------------------------------------------------------ per-frame
  update(canvas: HTMLCanvasElement, camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    if (!this.ready) return;
    const w = canvas.width,
      h = canvas.height;
    if (w !== this.w || h !== this.h) {
      this.renderer.setSize(w, h, false);
      this.w = w;
      this.h = h;
    }
    const dt = Math.min(0.1, Math.max(0, t - this.lastT));
    this.lastT = t;
    void dt;
    const cx = camLeft + vw / 2,
      cy = camTop + vh / 2;
    SHARED.uTime.value = t;
    SHARED.uCamC.value.set(cx, cy);
    SHARED.uView.value.set(vw, vh);
    SHARED.uCamTL.value.set(camLeft, camTop);
    SHARED.uPx.value = h / vh;
    const cam = this.cam;
    cam.left = -vw / 2;
    cam.right = vw / 2;
    cam.top = vh / 2;
    cam.bottom = -vh / 2;
    cam.position.set(cx, -cy, 600);
    cam.updateProjectionMatrix();
    cam.updateMatrixWorld();

    // far canyon walls
    for (const [g, P] of [
      [this.farA, this.farParams.A],
      [this.farB, this.farParams.B],
    ] as const) {
      g.position.set(cx * (1 - P.p), -cy * (1 - P.p), P.z);
      g.scale.setScalar(P.s);
    }
    // foreground
    this.fgGroup.position.set(cx * (1 - this.FG_P), 0, 0);
    const nearFloor = camTop + vh > WORLD_H - 320;
    this.fgGroup.visible = nearFloor;
    this.raysNear.visible = camTop < 1150;

    // residents
    const A = this.ENT_A,
      B = this.ENT_B;
    this.entA.position.x = cx * (1 - A.p);
    this.entA.position.y = -cy * (1 - A.p);
    this.entB.position.x = cx * (1 - B.p);
    this.entB.position.y = -cy * (1 - B.p);
    const xMinA = (-520 * (1 - A.p)) - 260,
      xMinB = (-520 * (1 - B.p)) - 200;
    for (const s of this.subs) {
      const x = ((((s.phase + t * s.speed * s.dir) % A.period) + A.period) % A.period) + xMinA;
      const bob = Math.sin(t * 0.45 + s.phase) * 3.5;
      s.wrap.position.set(x, -(s.yl + bob), 0);
      s.wrap.rotation.z = Math.sin(t * 0.3 + s.phase) * 0.025 * s.dir * -1;
      s.prop.rotation.z = t * 9;
      s.wrap.visible = Math.abs(x + this.entA.position.x - cx) < vw / 2 + 300 && Math.abs(-s.yl - bob + this.entA.position.y + cy) < vh / 2 + 160;
    }
    for (const d of this.divers) {
      const x = ((((d.phase + t * d.speed * d.dir) % B.period) + B.period) % B.period) + xMinB;
      const bob = Math.sin(t * 0.8 + d.phase) * 4.5;
      d.wrap.position.set(x, -(d.yl + bob), 0);
      d.wrap.rotation.z = (0.1 + Math.sin(t * 0.37 + d.phase) * 0.1) * d.dir;
      const k = Math.sin(t * 3.4 + d.phase);
      d.legL.rotation.x = k * 0.5;
      d.legR.rotation.x = -k * 0.5;
      d.armL.rotation.x = -k * 0.14;
      d.armR.rotation.x = k * 0.14;
      d.wrap.visible = Math.abs(x + this.entB.position.x - cx) < vw / 2 + 120 && Math.abs(-d.yl - bob + this.entB.position.y + cy) < vh / 2 + 120;
      // bubble origin follows the mouthpiece (behind the helmet in swimming direction)
      const o = d.bub.uniforms.uOrigin.value as THREE.Vector3;
      o.set(0 + d.dir * 14, 6, 0);
      d.bub.uniforms.uDir.value = d.dir;
    }

    // black smokers: only animate what is near the view
    for (const v of this.vents) {
      const on = Math.abs(v.x - cx) < vw / 2 + 120 && camTop + vh > WORLD_H - 420;
      v.g.visible = on;
      v.pts.visible = on;
      v.mats[0].visible = on;
    }

    // visibility of the cave-lip pass
    let lips = false;
    for (const f of this.caveForms) {
      if (f.x + f.w > camLeft - 30 && f.x < camLeft + vw + 30 && f.y + f.h > camTop - 30 && f.y < camTop + vh + 30) {
        lips = true;
        break;
      }
    }
    this.visible[2] = lips;
    this.visible[3] = nearFloor || camTop < 1150;
  }

  /** render one pass of the 3D scene and composite it (1:1 pixels) onto the game canvas */
  drawPass(pass: number, ctx: CanvasRenderingContext2D) {
    if (!this.ready || !this.visible[pass] || this.w === 0) return;
    const r = this.renderer;
    r.clear(true, true, false);
    r.render(this.scenes[pass], this.cam);
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(r.domElement, 0, 0, this.w, this.h);
    ctx.restore();
  }

  dispose() {
    for (const d of this.disposables) {
      try {
        d.dispose();
      } catch {
        /* ignore */
      }
    }
    this.disposables.length = 0;
    try {
      this.renderer?.dispose();
      this.renderer?.forceContextLoss();
    } catch {
      /* ignore */
    }
  }
}
